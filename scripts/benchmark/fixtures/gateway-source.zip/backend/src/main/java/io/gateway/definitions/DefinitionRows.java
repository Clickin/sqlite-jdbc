package io.gateway.definitions;

import java.util.*;
import static io.gateway.definitions.Definitions.*;
import static io.gateway.definitions.DefinitionMapper.Table.*;
import io.gateway.runtime.Payload.Disposition;

/** The only mapping between typed definition records and normalized table rows. */
final class DefinitionRows {
    private final DefinitionMapper db;
    DefinitionRows(DefinitionMapper db){this.db=db;}
    private static String id(){return UUID.randomUUID().toString();}
    private void put(DefinitionMapper.Table table,Object... pairs){Map<String,Object> row=new LinkedHashMap<>();for(int i=0;i<pairs.length;i+=2)row.put((String)pairs[i],pairs[i+1]);db.insert(table,row);}
    private Map<String,Object> one(DefinitionMapper.Table table,String version){List<Map<String,Object>> rows=db.rows(table,version);if(rows.size()!=1)throw new IllegalArgumentException("INCOMPLETE_DEFINITION");return rows.getFirst();}
    private static String s(Map<String,Object> r,String k){Object v=r.get(k);return v==null?null:v.toString();}
    private static int n(Map<String,Object> r,String k){return ((Number)r.get(k)).intValue();}
    private static Integer ni(Map<String,Object> r,String k){return r.get(k)==null?null:n(r,k);}
    private static Long l(Map<String,Object> r,String k){return r.get(k)==null?null:((Number)r.get(k)).longValue();}
    private static boolean b(Map<String,Object> r,String k){Object v=r.get(k);return v instanceof Boolean x?x:v instanceof Number number&&number.intValue()!=0;}
    private static Boolean bn(Map<String,Object> r,String k){return r.get(k)==null?null:b(r,k);}

    void save(String object,String v,Detail detail){
        switch(detail){
            case JdbcSource d -> {
                put(DATASOURCE,"version_id",v,"provider_id","jdbc.mybatis","max_concurrent",d.maxConcurrent(),"queue_timeout_ms",d.queueTimeoutMs());
                put(JDBC_SOURCE,"version_id",v,"jdbc_url",d.jdbcUrl(),"driver_profile_id",d.driverProfileId(),"credential_object_id",d.credentialObjectId(),"pool_min_idle",d.poolMinIdle(),"pool_max_size",d.poolMaxSize(),"acquire_timeout_ms",d.acquireTimeoutMs(),"read_only_policy",d.readOnlyPolicy());
            }
            case HttpSource d -> {
                put(DATASOURCE,"version_id",v,"provider_id","http.classic","max_concurrent",d.maxConcurrent(),"queue_timeout_ms",d.queueTimeoutMs());
                put(HTTP_SOURCE,"version_id",v,"base_uri",d.baseUri(),"authentication_kind",d.authenticationKind(),"credential_object_id",d.credentialObjectId(),"tls_profile_object_id",d.tlsProfileObjectId(),"proxy_profile_id",d.proxyProfileId(),"network_policy_object_id",d.networkPolicyObjectId(),"pool_max_total",d.poolMaxTotal(),"pool_max_per_route",d.poolMaxPerRoute(),"connect_timeout_ms",d.connectTimeoutMs(),"redirect_policy",d.redirectPolicy());
                int i=0;for(Header h:d.headers())put(HEADER,"datasource_version_id",v,"ordinal",i++,"header_name",h.name(),"literal_value",h.literalValue(),"credential_part",h.credentialPart());
            }
            case Mapper d -> {
                put(MAPPER,"version_id",v,"database_profile",d.databaseProfile());int i=0;
                for(MapperDocument doc:d.documents())put(DOCUMENT,"id",id(),"mapper_version_id",v,"resource_name",doc.resourceName(),"xml_text",doc.xmlText(),"ordinal",i++);
                i=0;for(String imp:d.imports())put(IMPORT,"mapper_version_id",v,"imported_mapper_object_id",imp,"ordinal",i++);
            }
            case JdbcOperation d -> {
                operation(v,d.sourceObjectId(),d.inputContractObjectId(),d.outputContractObjectId(),d.effect(),d.timeoutMs(),d.maxResultRows(),d.maxResultBytes());
                references(v,d.referenceBindings());
                put(JDBC_OPERATION,"version_id",v,"mapper_object_id",d.mapperObjectId(),"statement_id",d.statementId(),"execution_mode",d.executionMode(),"transaction_mode",d.transactionMode());int i=0;
                for(OutBinding o:d.outBindings())put(OUT,"operation_version_id",v,"out_parameter_name",o.parameterName(),"output_field_id",o.outputFieldId(),"result_map_name",o.resultMapName(),"ordinal",i++);
            }
            case HttpOperation d -> {
                operation(v,d.sourceObjectId(),d.inputContractObjectId(),d.outputContractObjectId(),d.effect(),d.timeoutMs(),d.maxResultRows(),d.maxResultBytes());
                references(v,d.referenceBindings());
                put(HTTP_OPERATION,"version_id",v,"method",d.method(),"relative_path_template",d.relativePathTemplate(),"request_representation_object_id",d.requestRepresentationObjectId(),"response_representation_object_id",d.responseRepresentationObjectId());int i=0;
                for(Parameter p:d.parameters())put(PARAMETER,"id",id(),"operation_version_id",v,"location",p.location(),"ordinal",i++,"wire_name",p.wireName(),"input_field_id",p.inputFieldId(),"literal_scalar",p.literalScalar(),"required",p.required());
                for(ExpectedStatus s:d.statuses())put(STATUS,"operation_version_id",v,"status_code",s.statusCode(),"interpretation",s.interpretation());
            }
            case Contract d -> {
                put(CONTRACT,"version_id",v,"model_kind",d.modelKind());
                for(Field f:d.fields()){
                    String owner=db.fieldOwner(f.id());if(owner==null)db.fieldIdentity(f.id(),object,f.logicalName());else if(!owner.equals(object))throw new IllegalArgumentException("FIELD_OWNER_MISMATCH");
                    else if(!Objects.equals(f.logicalName(),db.fieldName(f.id())))throw new IllegalArgumentException("FIELD_IDENTITY_IMMUTABLE");
                }
                List<Field> pending=new ArrayList<>(d.fields());Set<String> inserted=new HashSet<>();
                while(!pending.isEmpty()) {int before=pending.size();for(var it=pending.iterator();it.hasNext();){Field f=it.next();if(f.parentFieldId()!=null&&!inserted.contains(f.parentFieldId()))continue;
                    put(FIELD,"contract_version_id",v,"field_id",f.id(),"parent_field_id",f.parentFieldId(),"member_name",f.memberName(),"node_kind",f.nodeKind(),"value_type",f.valueType(),"ordinal",f.ordinal(),"required",f.required(),"nullable",f.nullable(),"precision",f.precision(),"scale",f.scale(),"max_length",f.maxLength(),"audit_disposition",f.auditDisposition().name());inserted.add(f.id());it.remove();}
                    if(before==pending.size())throw new IllegalArgumentException("FIELD_PARENT_CYCLE_OR_MISSING");
                }
            }
            case Representation d -> {
                put(REPRESENTATION,"version_id",v,"contract_object_id",d.contractObjectId(),"codec_id",d.codecId(),"wire_profile",d.wireProfile(),"media_type",d.mediaType(),"charset",d.charset());
                for(JsonBinding j:d.jsonBindings())put(JSON_BINDING,"representation_version_id",v,"field_id",j.fieldId(),"member_name",j.memberName(),"location",j.location());
                for(XmlBinding x:d.xmlBindings())put(XML_BINDING,"representation_version_id",v,"field_id",x.fieldId(),"namespace_uri",x.namespaceUri(),"local_name",x.localName(),"node_kind",x.nodeKind(),"ordinal",x.ordinal(),"null_policy",x.nullPolicy());
            }
            case Converter d -> {
                put(CONVERTER,"version_id",v,"implementation_id",d.implementationId(),"input_contract_object_id",d.inputContractObjectId(),"output_contract_object_id",d.outputContractObjectId());int i=0;
                for(Rule r:d.rules()){String rule=id();put(RULE,"id",rule,"converter_version_id",v,"source_port",r.sourcePort(),"source_field_id",r.sourceFieldId(),"target_field_id",r.targetFieldId(),"transform_code",r.transformCode(),"ordinal",i++);
                    for(Argument a:r.arguments())put(ARGUMENT,"conversion_rule_id",rule,"argument_name",a.name(),"value_type",a.valueType(),"string_value",a.stringValue(),"integer_value",a.integerValue(),"decimal_value",a.decimalValue(),"boolean_value",a.booleanValue());}
            }
            case Workflow d -> {
                put(WORKFLOW,"version_id",v,"error_mapping_object_id",d.errorMappingObjectId());
                for(Stage st:d.stages())put(STAGE,"workflow_version_id",v,"stage_key",st.stageKey(),"stage_order",st.stageOrder(),"operation_object_id",st.operationObjectId(),"converter_object_id",st.converterObjectId());
                for(Port p:d.ports())put(PORT,"workflow_version_id",v,"direction",p.direction(),"representation_object_id",p.representationObjectId(),"status_code",p.statusCode());
                for(SecurityBinding binding:d.securityBindings()) {
                    if(!"SECURITY_BINDING".equals(db.head(binding.securityBindingObjectId()).kind()))throw new IllegalArgumentException("SECURITY_BINDING_KIND");
                    if(binding.targetPolicyObjectId()!=null&&!"TARGET_POLICY".equals(db.head(binding.targetPolicyObjectId()).kind()))throw new IllegalArgumentException("TARGET_POLICY_KIND");
                    put(SECURITY_BINDING,"workflow_version_id",v,"stage_key",binding.stageKey(),"security_binding_object_id",binding.securityBindingObjectId(),"required_action_id",binding.requiredActionId(),"target_policy_object_id",binding.targetPolicyObjectId());
                }
            }
            case Credential ignored -> throw new IllegalArgumentException("USE_CREDENTIAL_SERVICE");
            case ErrorMapping ignored -> throw new IllegalArgumentException("USE_ERROR_MAPPING_EDITOR");
        }
    }
    private void operation(String v,String source,String in,String out,Effect effect,int timeout,Integer rows,Long bytes){put(OPERATION,"version_id",v,"source_object_id",source,"input_contract_object_id",in,"output_contract_object_id",out,"effect_kind",effect.name(),"timeout_ms",timeout,"max_result_rows",rows,"max_result_bytes",bytes);}
    private void references(String version,List<ReferenceBinding> bindings){int ordinal=0;for(ReferenceBinding binding:bindings)put(REFERENCE_BINDING,"operation_version_id",version,"ordinal",ordinal++,"reference_kind",binding.referenceKind(),"output_url_field_id",binding.outputUrlFieldId(),"origin_record_field_id",binding.originRecordFieldId(),"screen_profile_object_id",binding.screenProfileObjectId(),"display_name",binding.displayName());}
    private List<ReferenceBinding> references(String version){return db.rows(REFERENCE_BINDING,version).stream().map(r->new ReferenceBinding(s(r,"reference_kind"),s(r,"output_url_field_id"),s(r,"origin_record_field_id"),s(r,"screen_profile_object_id"),s(r,"display_name"))).toList();}

    Detail load(Version v){String id=v.id();return switch(Kind.valueOf(v.kind())){
        case DATASOURCE -> {
            Map<String,Object> common=one(DATASOURCE,id);
            if("jdbc.mybatis".equals(s(common,"provider_id"))){var r=one(JDBC_SOURCE,id);yield new JdbcSource(s(r,"jdbc_url"),s(r,"driver_profile_id"),s(r,"credential_object_id"),n(r,"pool_min_idle"),n(r,"pool_max_size"),n(r,"acquire_timeout_ms"),b(r,"read_only_policy"),n(common,"max_concurrent"),n(common,"queue_timeout_ms"));}
            var r=one(HTTP_SOURCE,id);yield new HttpSource(s(r,"base_uri"),s(r,"authentication_kind"),s(r,"credential_object_id"),s(r,"tls_profile_object_id"),s(r,"proxy_profile_id"),s(r,"network_policy_object_id"),n(r,"pool_max_total"),n(r,"pool_max_per_route"),n(r,"connect_timeout_ms"),s(r,"redirect_policy"),n(common,"max_concurrent"),n(common,"queue_timeout_ms"),db.rows(HEADER,id).stream().map(h->new Header(s(h,"header_name"),s(h,"literal_value"),s(h,"credential_part"))).toList());
        }
        case MAPPER -> new Mapper(s(one(MAPPER,id),"database_profile"),db.rows(DOCUMENT,id).stream().map(r->new MapperDocument(s(r,"resource_name"),s(r,"xml_text"))).toList(),db.rows(IMPORT,id).stream().map(r->s(r,"imported_mapper_object_id")).toList());
        case OPERATION -> {
            var c=one(OPERATION,id);List<Map<String,Object>> jdbc=db.rows(JDBC_OPERATION,id);
            if(!jdbc.isEmpty()){var r=jdbc.getFirst();yield new JdbcOperation(s(c,"source_object_id"),s(c,"input_contract_object_id"),s(c,"output_contract_object_id"),Effect.valueOf(s(c,"effect_kind")),n(c,"timeout_ms"),ni(c,"max_result_rows"),l(c,"max_result_bytes"),s(r,"mapper_object_id"),s(r,"statement_id"),s(r,"execution_mode"),s(r,"transaction_mode"),db.rows(OUT,id).stream().map(o->new OutBinding(s(o,"out_parameter_name"),s(o,"output_field_id"),s(o,"result_map_name"))).toList(),references(id));}
            var r=one(HTTP_OPERATION,id);yield new HttpOperation(s(c,"source_object_id"),s(c,"input_contract_object_id"),s(c,"output_contract_object_id"),Effect.valueOf(s(c,"effect_kind")),n(c,"timeout_ms"),ni(c,"max_result_rows"),l(c,"max_result_bytes"),s(r,"method"),s(r,"relative_path_template"),s(r,"request_representation_object_id"),s(r,"response_representation_object_id"),db.rows(PARAMETER,id).stream().map(p->new Parameter(s(p,"location"),s(p,"wire_name"),s(p,"input_field_id"),s(p,"literal_scalar"),b(p,"required"))).toList(),db.rows(STATUS,id).stream().map(p->new ExpectedStatus(n(p,"status_code"),s(p,"interpretation"))).toList(),references(id));
        }
        case CONTRACT -> new Contract(s(one(CONTRACT,id),"model_kind"),db.rows(FIELD,id).stream().map(f->new Field(s(f,"field_id"),db.fieldName(s(f,"field_id")),s(f,"parent_field_id"),s(f,"member_name"),s(f,"node_kind"),s(f,"value_type"),n(f,"ordinal"),b(f,"required"),b(f,"nullable"),ni(f,"precision"),ni(f,"scale"),ni(f,"max_length"),Disposition.valueOf(s(f,"audit_disposition")))).toList());
        case REPRESENTATION -> {var r=one(REPRESENTATION,id);yield new Representation(s(r,"contract_object_id"),s(r,"codec_id"),s(r,"wire_profile"),s(r,"media_type"),s(r,"charset"),db.rows(JSON_BINDING,id).stream().map(j->new JsonBinding(s(j,"field_id"),s(j,"member_name"),s(j,"location"))).toList(),db.rows(XML_BINDING,id).stream().map(x->new XmlBinding(s(x,"field_id"),s(x,"namespace_uri"),s(x,"local_name"),s(x,"node_kind"),n(x,"ordinal"),s(x,"null_policy"))).toList());}
        case CONVERTER -> {var r=one(CONVERTER,id);yield new Converter(s(r,"implementation_id"),s(r,"input_contract_object_id"),s(r,"output_contract_object_id"),db.rows(RULE,id).stream().map(rule->new Rule(s(rule,"source_port"),s(rule,"source_field_id"),s(rule,"target_field_id"),s(rule,"transform_code"),db.rows(ARGUMENT,s(rule,"id")).stream().map(a->new Argument(s(a,"argument_name"),s(a,"value_type"),s(a,"string_value"),l(a,"integer_value"),s(a,"decimal_value"),bn(a,"boolean_value"))).toList())).toList());}
        case WORKFLOW -> new Workflow(s(one(WORKFLOW,id),"error_mapping_object_id"),db.rows(STAGE,id).stream().map(r->new Stage(s(r,"stage_key"),n(r,"stage_order"),s(r,"operation_object_id"),s(r,"converter_object_id"))).toList(),db.rows(PORT,id).stream().map(r->new Port(s(r,"direction"),s(r,"representation_object_id"),ni(r,"status_code"))).toList(),db.rows(SECURITY_BINDING,id).stream().map(r->new SecurityBinding(s(r,"stage_key"),s(r,"security_binding_object_id"),s(r,"required_action_id"),s(r,"target_policy_object_id"))).toList());
        case CREDENTIAL -> {var r=one(CREDENTIAL,id);yield new Credential(s(r,"secret_kind"),s(r,"public_username"));}
        case ERROR_MAPPING -> {one(ERROR_MAPPING,id);yield new ErrorMapping(db.rows(ERROR_RULE,id).stream().map(r->new ErrorRule(s(r,"remote_code"),s(r,"public_code"),n(r,"status_code"))).toList());}
    };}
}
