package io.gateway.oauth;

import com.nimbusds.oauth2.sdk.*;
import com.nimbusds.oauth2.sdk.auth.ClientSecretBasic;
import com.nimbusds.oauth2.sdk.http.HTTPRequest;
import com.nimbusds.oauth2.sdk.pkce.*;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

public final class OAuthProtocol {
    private OAuthProtocol() {}
    public static final class Failure extends RuntimeException {
        private final String error,redirect;
        public Failure(String error){this(error,null);}
        public Failure(String error,String redirect){super(error);this.error=error;this.redirect=redirect;}
        public String error(){return error;}
        public String redirect(){return redirect;}
    }
    public static Map<String,List<String>> form(String body,String authorization,String endpoint,boolean token){
        if(body==null||body.length()>32768)throw new Failure("invalid_request");
        try {
            HTTPRequest request=new HTTPRequest(HTTPRequest.Method.POST,URI.create(endpoint));request.setHeader("Content-Type","application/x-www-form-urlencoded");request.setBody(body);if(authorization!=null)request.setAuthorization(authorization);
            var parameters=request.getBodyAsFormParameters(); singletons(parameters);
            if(token){String grant=required(parameters,"grant_type");if(!Set.of("authorization_code","refresh_token").contains(grant))throw new Failure("unsupported_grant_type");TokenRequest.parse(request);}
            return parameters;
        } catch(Failure e){throw e;}catch(Exception e){throw new Failure("invalid_request");}
    }
    public static AuthorizationRequest authorization(Map<String,List<String>> parameters){try{singletons(parameters);return AuthorizationRequest.parse(parameters);}catch(Exception e){throw new Failure("invalid_request");}}
    public static void singletons(Map<String,List<String>> parameters){if(parameters.size()>24||parameters.values().stream().anyMatch(v->v==null||v.size()!=1||v.getFirst()==null||v.getFirst().length()>8192))throw new Failure("invalid_request");}
    public static String required(Map<String,List<String>> values,String name){String value=optional(values,name);if(value==null||value.isBlank())throw new Failure("invalid_request");return value;}
    public static String optional(Map<String,List<String>> values,String name){var value=values.get(name);if(value==null)return null;if(value.size()!=1)throw new Failure("invalid_request");return value.getFirst();}
    public static ClientSecretBasic basic(String header){try{return ClientSecretBasic.parse(header);}catch(Exception e){throw new Failure("invalid_client");}}
    public static boolean redirectAllowed(String candidate,OAuthMapper.Client client,List<OAuthMapper.Redirect> registered){
        try {
            URI requested=URI.create(candidate);
            if(candidate.contains("*")||!requested.isAbsolute()||requested.getHost()==null||requested.getRawFragment()!=null||requested.getRawUserInfo()!=null)return false;
            for(var entry:registered){
                URI allowed=URI.create(entry.uri());
                if(allowed.getFragment()!=null||allowed.getUserInfo()!=null)continue;
                if("https".equals(requested.getScheme())&&entry.uri().equals(candidate))return true;
                if(!client.clientType().equals("PUBLIC_NATIVE")||!entry.loopback()||!"http".equals(requested.getScheme())||!"http".equals(allowed.getScheme()))continue;
                if(!Set.of("127.0.0.1","[::1]").contains(requested.getHost())||!requested.getHost().equals(allowed.getHost())||requested.getPort()==0||requested.getPort()>65535||(requested.getPort()==-1&&!candidate.equals(entry.uri())))continue;
                if(Objects.equals(requested.getRawPath(),allowed.getRawPath())&&Objects.equals(requested.getRawQuery(),allowed.getRawQuery()))return true;
            }
            return false;
        }catch(IllegalArgumentException e){return false;}
    }
    public static boolean pkce(String verifier,String challenge){
        if(verifier==null||!verifier.matches("[A-Za-z0-9._~-]{43,128}")||challenge==null||!challenge.matches("[A-Za-z0-9_-]{43}"))return false;
        try {String actual=CodeChallenge.compute(CodeChallengeMethod.S256,new CodeVerifier(verifier)).getValue();return MessageDigest.isEqual(actual.getBytes(StandardCharsets.US_ASCII),challenge.getBytes(StandardCharsets.US_ASCII));}
        catch(IllegalArgumentException e){return false;}
    }
    public static String response(String redirect,String key,String value,String state,String issuer){String result=redirect+(redirect.contains("?")?"&":"?")+encode(key)+"="+encode(value)+"&iss="+encode(issuer);return state==null?result:result+"&state="+encode(state);}
    private static String encode(String value){return URLEncoder.encode(value,StandardCharsets.UTF_8);}
}
