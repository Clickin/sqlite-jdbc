package io.gateway.runtime;

import io.gateway.authorization.AuthorizedContext;
import io.gateway.contracts.ContractService;
import io.gateway.definitions.Definitions.*;
import jakarta.inject.Singleton;
import java.util.*;
import java.util.function.*;

/** Only server-created authorization contexts reach registered input/convert/output adapters. */
@Singleton
public final class WorkflowRunner {
    private final RuntimeRegistry registry;
    private final ContractService contracts;
    public WorkflowRunner(RuntimeRegistry registry,ContractService contracts){this.registry=registry;this.contracts=contracts;}
    public record StageInput(AuthorizedContext context,Payload payload) {}
    public Payload run(ResolvedGraph graph,AuthorizedContext context,Payload arguments,Cancellation cancellation,
                       BiFunction<String,Payload,StageInput> reauthorize,BiConsumer<String,Payload> inspectOutput){
        Objects.requireNonNull(context);Objects.requireNonNull(reauthorize);Objects.requireNonNull(inspectOutput);
        if(arguments.object().containsKey("authorized"))throw new ExecutionFailure("RESERVED_IDENTITY_ARGUMENT",ExecutionFailure.Outcome.FAILED_BEFORE_EFFECT);
        if(!(graph.require(graph.rootObjectId()).detail() instanceof Workflow workflow))throw new IllegalArgumentException("WORKFLOW_REQUIRED");
        boolean confirmedEffect=false;
        try(RuntimeRegistry.Lease lease=registry.acquire(graph)){
            RuntimeGraph runtime=lease.get();Payload value=arguments;
            for(Stage stage:workflow.stages().stream().sorted(Comparator.comparingInt(Stage::stageOrder)).toList()){
                cancellation.check();
                if("CONVERT".equals(stage.stageKey())) {inspectOutput.accept("CONVERT_REQUEST",value);value=runtime.convert(stage.converterObjectId(),value);validate(graph,((Converter)graph.require(stage.converterObjectId()).detail()).outputContractObjectId(),value);inspectOutput.accept("CONVERT_OUTPUT",value);continue;}
                Detail operation=graph.require(stage.operationObjectId()).detail();
                StageInput checked=Objects.requireNonNull(reauthorize.apply(stage.stageKey(),value));
                context=Objects.requireNonNull(checked.context());value=Objects.requireNonNull(checked.payload());cancellation.check();
                validate(graph,inputContract(operation),value);
                Map<String,Object> canonical=new LinkedHashMap<>(value.object());canonical.putAll(context.parameters());
                Payload bound=new Payload(canonical,value.dispositions());
                String prefix="INPUT".equals(stage.stageKey())?"SOURCE":"TARGET";
                inspectOutput.accept(prefix+"_REQUEST",bound);cancellation.check();
                value=runtime.execute(stage.operationObjectId(),bound,cancellation);
                confirmedEffect|=effect(operation)!=Effect.READ_ONLY;
                try {validate(graph,outputContract(operation),value);inspectOutput.accept(prefix+"_OUTPUT",value);}
                catch(io.gateway.authorization.AccessDenied denial){throw denial;}
                catch(RuntimeException failure){throw new ExecutionFailure("POST_OPERATION_VALIDATION_OR_AUDIT_FAILED",confirmedEffect?ExecutionFailure.Outcome.SUCCEEDED:ExecutionFailure.Outcome.FAILED,true);}
            }
            cancellation.check();return value;
        }catch(ExecutionFailure failure){if(confirmedEffect&&failure.outcome()==ExecutionFailure.Outcome.FAILED_BEFORE_EFFECT)throw new ExecutionFailure(failure.code(),ExecutionFailure.Outcome.SUCCEEDED,true);throw failure;}
        catch(io.gateway.authorization.AccessDenied denial){if(confirmedEffect)throw new ExecutionFailure("AUTHORIZATION_"+denial.outcome().name(),ExecutionFailure.Outcome.SUCCEEDED,true);throw denial;}
        catch(RuntimeException failure){throw new ExecutionFailure("WORKFLOW_FAILED",confirmedEffect?ExecutionFailure.Outcome.SUCCEEDED:ExecutionFailure.Outcome.FAILED_BEFORE_EFFECT,confirmedEffect);}
    }
    void validate(ResolvedGraph graph,String contractId,Payload payload){
        Saved saved=graph.require(contractId);Contract source=(Contract)saved.detail();
        ContractService.Contract contract=new ContractService.Contract(saved.version().id(),source.fields().stream().map(f->new ContractService.Field(f.id(),f.parentFieldId(),f.memberName(),f.nodeKind(),f.valueType(),f.ordinal(),f.required(),f.nullable(),f.precision(),f.scale(),f.maxLength(),f.auditDisposition().name())).toList());
        contracts.validate(contract,payload.object());
    }
    static String inputContract(Detail d){return switch(d){case JdbcOperation o->o.inputContractObjectId();case HttpOperation o->o.inputContractObjectId();default->throw new IllegalArgumentException("OPERATION_REQUIRED");};}
    static String outputContract(Detail d){return switch(d){case JdbcOperation o->o.outputContractObjectId();case HttpOperation o->o.outputContractObjectId();default->throw new IllegalArgumentException("OPERATION_REQUIRED");};}
    static Effect effect(Detail d){return switch(d){case JdbcOperation o->o.effect();case HttpOperation o->o.effect();default->throw new IllegalArgumentException("OPERATION_REQUIRED");};}
}
