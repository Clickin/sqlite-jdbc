package io.gateway.contracts;

import io.gateway.persistence.PlatformMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import java.util.List;

public interface ContractMapper extends PlatformMapper {
    @Select("""
        SELECT f.field_id AS id, f.parent_field_id AS parentId,
               COALESCE(f.member_name,i.logical_name) AS name, f.node_kind AS nodeKind,
               f.value_type AS valueType,f.ordinal,f.required,f.nullable,
               f.precision AS precision,f.scale AS scale,f.max_length AS maxLength,
               f.audit_disposition AS disposition
        FROM contract_field_version f JOIN contract_field i ON i.id=f.field_id
        WHERE f.contract_version_id=#{version} ORDER BY f.ordinal,f.field_id
        """)
    List<ContractService.Field> fields(@Param("version") String version);

    @Select("SELECT model_kind FROM contract_version WHERE version_id=#{version}")
    String model(@Param("version") String version);
}
