package io.gateway.identity;

import io.gateway.authorization.*;
import io.gateway.oauth.OAuthSettings;
import io.gateway.persistence.PlatformStore;
import io.gateway.runtime.InternalOperationExecutor;
import io.gateway.runtime.InternalOperationExecutor.InternalPurpose;
import jakarta.inject.Singleton;
import java.util.*;

@Singleton
public final class ConfiguredAuthority implements Authority {
    private final PlatformStore store;
    private final InternalOperationExecutor executor;
    private final OAuthSettings settings;
    public ConfiguredAuthority(PlatformStore store,InternalOperationExecutor executor,OAuthSettings settings) { this.store=store;this.executor=executor;this.settings=settings; }
    public String securityBindingId(){ return settings.securityBindingId; }
    private SecurityMapper.Binding binding(){
        SecurityMapper.Binding binding=store.read(s->s.getMapper(SecurityMapper.class).binding(settings.securityBindingId));
        if(binding==null) throw unavailable(); return binding;
    }
    public Identity authenticate(String credential) {
        if(credential==null || credential.isBlank() || credential.length()>16384) throw AccessDenied.unauthenticated();
        var binding=binding();
        Map<String,Object> result=invoke(binding.identityOperation(),binding.identityConverter(),Map.of("credential",credential),InternalPurpose.IDENTITY);
        String subject=string(result,"subject");
        if(!Boolean.TRUE.equals(result.get("active"))) throw AccessDenied.unauthenticated();
        return new Identity(binding.identityOperation(),subject,true);
    }
    public Set<String> roles(String providerId,String subject) {
        var binding=binding();
        if(!binding.identityOperation().equals(providerId) || binding.rolesOperation()==null) throw unavailable();
        var result=invoke(binding.rolesOperation(),binding.rolesConverter(),Map.of("subject",subject,"identityProvider",providerId),InternalPurpose.PERMISSION);
        if(!Boolean.TRUE.equals(result.get("active")) || !(result.get("roles") instanceof Collection<?> values) || values.size()>256) throw AccessDenied.denied();
        Set<String> roles=new HashSet<>();
        for(Object value:values) { if(!(value instanceof String role) || role.isBlank() || role.length()>256) throw unavailable(); roles.add(role); }
        return Set.copyOf(roles);
    }
    public Decision decide(String providerId,String subject,String action,CanonicalTarget target) {
        var binding=binding();
        if(!binding.identityOperation().equals(providerId)) throw AccessDenied.denied();
        Map<String,Object> arguments=new HashMap<>(target.parameters());
        arguments.put("subject",subject); arguments.put("identityProvider",providerId); arguments.put("action",action);
        var result=invoke(binding.permissionOperation(),binding.permissionConverter(),Map.copyOf(arguments),InternalPurpose.PERMISSION);
        String outcome=string(result,"outcome");
        if(!Set.of("ALLOW","DENY","PENDING","UNAVAILABLE").contains(outcome)) throw unavailable();
        Object roles=result.get("roles");
        if(!(roles instanceof Collection<?> values) || values.size()>256 || values.stream().anyMatch(v->!(v instanceof String s) || s.isBlank() || s.length()>256)) throw unavailable();
        Set<String> codes=new HashSet<>(); for(Object role:values) codes.add((String)role);
        return new Decision(outcome,string(result,"decisionId"),codes);
    }
    public CanonicalTarget resolve(String providerId,String subject,String action,CanonicalTarget claimed,String targetPolicyId) {
        if(claimed.targetKind().equals("SERVICE")) return claimed;
        var resolvers=store.read(s->{var mapper=s.getMapper(SecurityMapper.class);if(targetPolicyId==null)return mapper.resolvers(claimed.targetKind(),claimed.organization(),claimed.identifierSystem());var selected=mapper.resolver(targetPolicyId,claimed.targetKind(),claimed.organization(),claimed.identifierSystem());return selected==null?List.<SecurityMapper.Resolver>of():List.of(selected);});
        if(resolvers.size()!=1 || resolvers.getFirst().operationId()==null) throw unavailable();
        var resolver=resolvers.getFirst();
        Map<String,Object> arguments=new HashMap<>(claimed.parameters()); arguments.put("subject",subject);arguments.put("identityProvider",providerId);arguments.put("action",action);
        var result=invoke(resolver.operationId(),resolver.converterId(),Map.copyOf(arguments),InternalPurpose.RESOLVER);
        if(!Set.of("targetKind","organization","identifierSystem","patientIdentifier","encounterIdentifier","documentIdentifier").containsAll(result.keySet())) throw unavailable();
        try {
            CanonicalTarget actual=new CanonicalTarget(claimed.targetKind(),string(result,"organization"),string(result,"identifierSystem"),string(result,"patientIdentifier"),optional(result,"encounterIdentifier"),optional(result,"documentIdentifier"));
            if(!claimed.equals(actual)) throw AccessDenied.denied();
            return actual;
        } catch(IllegalArgumentException e) { throw AccessDenied.denied(); }
    }
    private Map<String,Object> invoke(String operation,String converter,Map<String,Object> parameters,InternalPurpose purpose) {
        try { return executor.execute(operation,converter,parameters,purpose); }
        catch(AccessDenied e){ throw e; }
        catch(RuntimeException e){ throw unavailable(); }
    }
    private static String string(Map<String,Object> values,String key){String value=optional(values,key);if(value==null || value.isBlank() || value.length()>1024)throw unavailable();return value;}
    private static String optional(Map<String,Object> values,String key){Object value=values.get(key);if(value==null)return null;if(!(value instanceof String s))throw unavailable();return s;}
    private static AccessDenied unavailable(){return new AccessDenied(AccessDenied.Outcome.UNAVAILABLE,"authority_unavailable");}
}
