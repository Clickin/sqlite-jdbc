package io.gateway.oauth;

import io.gateway.authorization.*;
import io.gateway.identity.Authority;
import io.gateway.persistence.PlatformStore;
import io.micronaut.serde.annotation.Serdeable;
import jakarta.inject.Singleton;
import java.util.*;

@Singleton
public final class BrowserSessionService {
    public static final String COOKIE_NAME="__Host-gateway-session";
    @Serdeable public record View(String csrfToken,boolean authenticated,String sessionKind,String principalId) {}
    public record BrowserSession(String cookie,OAuthMapper.Session row,View view) {}
    private final PlatformStore store;
    private final OAuthSettings settings;
    private final Authority authority;
    public BrowserSessionService(PlatformStore store,OAuthSettings settings,Authority authority){this.store=store;this.settings=settings;this.authority=authority;}
    public BrowserSession session(String cookie) {
        OAuthMapper.Session row=find(cookie);
        if(row==null) return create(null,"PREAUTH",null);
        String csrf=csrf(cookie);
        store.write(s->{long now=System.currentTimeMillis();if(s.getMapper(OAuthMapper.class).touchSession(row.id(),Secrets.digest(csrf),Math.min(now+settings.sessionIdleTtl,row.absoluteExpiresAt()),now)!=1)throw AccessDenied.unauthenticated();return null;});
        return new BrowserSession(cookie,row,new View(csrf,row.principalId()!=null,row.kind(),row.principalId()));
    }
    public OAuthMapper.Session require(String cookie) { OAuthMapper.Session row=find(cookie);if(row==null)throw AccessDenied.unauthenticated();return row; }
    private OAuthMapper.Session find(String cookie) {
        if(cookie==null || !cookie.matches("ss_[A-Za-z0-9_-]{43}"))return null;
        return store.read(s->{var row=s.getMapper(OAuthMapper.class).session(Secrets.digest(cookie));if(!valid(row,System.currentTimeMillis()))return null;if(row.principalId()!=null){var p=s.getMapper(SecurityMapper.class).principal(row.principalId());if(p==null||p.blocked())return null;}return row;});
    }
    public static boolean valid(OAuthMapper.Session row,long now){return row!=null&&row.revokedAt()==null&&row.idleExpiresAt()>now&&row.absoluteExpiresAt()>now;}
    public void requireCsrf(String cookie,String origin,String csrfToken){
        var row=require(cookie);
        if(!settings.publicOrigin.equals(origin) || !Secrets.matches(csrfToken,row.csrfDigest())) throw new AccessDenied(AccessDenied.Outcome.DENY,"csrf_rejected");
    }
    public BrowserSession login(String cookie,String origin,String csrfToken,String credential,String kind) {
        requireCsrf(cookie,origin,csrfToken);
        if(kind==null||!Set.of("USER","MANAGEMENT").contains(kind))throw AccessDenied.denied();
        var before=require(cookie);
        var identity=authority.authenticate(credential);
        if(!identity.active() || identity.subject()==null || identity.subject().isBlank())throw AccessDenied.unauthenticated();
        String principal=store.write(s->{var mapper=s.getMapper(SecurityMapper.class);mapper.insertPrincipal(UUID.randomUUID().toString(),identity.providerId(),identity.subject(),System.currentTimeMillis());var p=mapper.findPrincipal(identity.providerId(),identity.subject());if(p==null||p.blocked())throw AccessDenied.unauthenticated();return p.id();});
        return create(principal,kind,before);
    }
    private BrowserSession create(String principal,String kind,OAuthMapper.Session previous){
        String cookie=Secrets.random("ss"), csrf=csrf(cookie),id=UUID.randomUUID().toString();
        store.write(s->{long now=System.currentTimeMillis();var mapper=s.getMapper(OAuthMapper.class);
            if(previous!=null){var current=mapper.sessionById(previous.id());if(!valid(current,now)||current.generation()!=previous.generation()||mapper.revokeSession(previous.id(),now)!=1)throw AccessDenied.unauthenticated();}
            if(principal!=null){var security=s.getMapper(SecurityMapper.class);var person=security.principal(principal);var binding=security.binding(authority.securityBindingId());if(person==null||person.blocked()||binding==null||!person.providerId().equals(binding.identityOperation()))throw AccessDenied.unauthenticated();}
            mapper.insertSession(values("id",id,"digest",Secrets.digest(cookie),"principal",principal,"now",now,"idle",now+settings.sessionIdleTtl,"absolute",now+settings.sessionAbsoluteTtl,"csrf",Secrets.digest(csrf),"kind",kind));
            if(previous!=null)mapper.rebindRequests(previous.id(),id);
            audit(mapper,"SESSION_CREATED",principal,null,null,null,"ALLOW",kind,now,null);
            return null;
        });
        var row=store.read(s->s.getMapper(OAuthMapper.class).sessionById(id));
        return new BrowserSession(cookie,row,new View(csrf,principal!=null,kind,principal));
    }
    public void logout(String cookie,String origin,String csrf){requireCsrf(cookie,origin,csrf);var row=require(cookie);store.write(s->{var m=s.getMapper(OAuthMapper.class);m.revokeSession(row.id(),System.currentTimeMillis());audit(m,"SESSION_REVOKED",row.principalId(),null,null,null,"ALLOW",null,System.currentTimeMillis(),null);return null;});}
    private String csrf(String cookie){
        try {var mac=javax.crypto.Mac.getInstance("HmacSHA256");mac.init(new javax.crypto.spec.SecretKeySpec(settings.stateKey,"HmacSHA256"));return Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(("csrf:"+cookie).getBytes(java.nio.charset.StandardCharsets.UTF_8)));}
        catch(java.security.GeneralSecurityException e){throw new IllegalStateException("CSRF protection unavailable");}
    }
    public static Map<String,Object> values(Object... entries){Map<String,Object> result=new HashMap<>();for(int i=0;i<entries.length;i+=2)result.put((String)entries[i],entries[i+1]);return result;}
    public static void audit(OAuthMapper mapper,String event,String principal,String client,String grant,String token,String outcome,String reason,long now,String decision){audit(mapper,event,principal,client,grant,token,outcome,reason,now,decision,null);}
    public static void audit(OAuthMapper mapper,String event,String principal,String client,String grant,String token,String outcome,String reason,long now,String decision,String action){mapper.audit(values("id",UUID.randomUUID().toString(),"event",event,"now",now,"principal",principal==null?"anonymous":principal,"client",client==null?"browser":client,"grant",grant,"token",token,"outcome",outcome,"reason",reason,"decision",decision,"action",action));}
}
