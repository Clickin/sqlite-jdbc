package io.gateway.authorization;

import io.gateway.identity.Authority;
import io.gateway.oauth.*;
import io.gateway.persistence.PlatformStore;
import jakarta.inject.Singleton;
import java.util.*;
import org.apache.ibatis.session.SqlSession;

@Singleton
public final class AuthorizationService {
    private final PlatformStore store;
    private final Authority authority;
    private final BrowserSessionService sessions;
    public AuthorizationService(PlatformStore store,Authority authority,BrowserSessionService sessions){this.store=store;this.authority=authority;this.sessions=sessions;}
    public AuthenticatedPrincipal authenticateBearer(List<String> headers,String resourceUri){
        if(headers==null||headers.size()!=1)throw AccessDenied.unauthenticated();
        String value=headers.getFirst();
        if(value==null||!value.matches("(?i:Bearer) at_[A-Za-z0-9_-]{43}"))throw AccessDenied.unauthenticated();
        var row=store.read(s->s.getMapper(SecurityMapper.class).token(Secrets.digest(value.substring(7)),System.currentTimeMillis()));
        if(row==null||!Objects.equals(resourceUri,row.resource()))throw AccessDenied.unauthenticated();
        return principal(row);
    }
    public AuthorizedContext authorizeManagement(String cookie,String action){
        var session=sessions.require(cookie);
        if(!session.kind().equals("MANAGEMENT"))throw AccessDenied.denied();
        var row=store.read(s->s.getMapper(SecurityMapper.class).management(session.id(),System.currentTimeMillis()));
        if(row==null)throw AccessDenied.unauthenticated();
        return authorize(principal(row),action,CanonicalTarget.service());
    }
    private static AuthenticatedPrincipal principal(SecurityMapper.Credential row){return new AuthenticatedPrincipal(row.principalId(),row.providerId(),row.subject(),row.clientId(),row.grantId(),row.tokenId(),row.sessionId(),row.resource());}
    public void recheckLocal(AuthenticatedPrincipal principal){store.read(s->{recheckLocal(s,principal);return null;});}
    public void recheckLocal(SqlSession session,AuthenticatedPrincipal principal){
        if(principal==null)throw AccessDenied.unauthenticated();
        var mapper=session.getMapper(SecurityMapper.class);
        var row=principal.management()?mapper.management(principal.sessionId(),System.currentTimeMillis()):mapper.tokenById(principal.tokenId(),System.currentTimeMillis());
        if(row==null||!row.principalId().equals(principal.principalId())||!Objects.equals(row.grantId(),principal.grantId())||!Objects.equals(row.clientId(),principal.clientId()))throw AccessDenied.unauthenticated();
    }
    public void recheckManagement(SqlSession session,AuthorizedContext context,boolean observedState) {
        if(context==null||!context.principal().management())throw AccessDenied.unauthenticated();
        recheckLocal(session,context.principal());
        var security=session.getMapper(SecurityMapper.class);
        var principal=security.principal(context.principalId());
        var browser=session.getMapper(OAuthMapper.class).sessionById(context.principal().sessionId());
        var action=security.action(context.action());
        if(principal.generation()!=context.principalGeneration||browser.generation()!=context.sessionGeneration
            ||action==null||context.roles.isEmpty()||security.roleAction(context.bindingId,action.id(),action.semanticVersion(),context.roles)==0
            ||observedState&&!context.securityState.equals(managementState(session)))throw AccessDenied.denied();
    }
    private static Map<String,String> managementState(SqlSession session) {
        Map<String,String> state=new TreeMap<>();var mapper=session.getMapper(io.gateway.definitions.DefinitionMapper.class);
        io.gateway.definitions.DefinitionRepository.securityDependencies(session).forEach((id,head)->state.put(id,head.currentVersionId()+":"+head.generation()+":"+head.enabled()+("CREDENTIAL".equals(head.kind())?":"+mapper.revoked(head.currentVersionId()):"")));
        return Map.copyOf(state);
    }
    public Set<String> principalScopes(AuthenticatedPrincipal principal){
        return store.read(s->{recheckLocal(s,principal);if(principal.management())return Set.of();var m=s.getMapper(OAuthMapper.class);var client=m.clientById(principal.clientId());Set<String> allowed=new HashSet<>();for(var scope:m.scopes(client.versionId()))allowed.add(scope.name());Set<String> issued=new HashSet<>(s.getMapper(DiscoveryMapper.class).tokenScopes(principal.tokenId()));issued.retainAll(allowed);return Set.copyOf(issued);});
    }
    public boolean canList(AuthenticatedPrincipal principal,String actionKey){
        Set<String> roles=authority.roles(principal.identityProvider(),principal.subject());
        return store.read(s->{recheckLocal(s,principal);var m=s.getMapper(SecurityMapper.class);var action=m.action(actionKey);if(action==null||roles.isEmpty()||m.roleAction(authority.securityBindingId(),action.id(),action.semanticVersion(),roles)==0)return false;return principal.management()||localAction(m,principal,action,null);});
    }
    public AuthorizedContext authorize(AuthenticatedPrincipal principal,String action,CanonicalTarget claimed){return authorize(principal,action,claimed,authority.securityBindingId(),null);}
    public AuthorizedContext authorize(AuthenticatedPrincipal principal,String actionKey,CanonicalTarget claimed,String bindingId,String targetPolicyId){
        try { return authorizeChecked(principal,actionKey,claimed,bindingId,targetPolicyId); }
        catch(AccessDenied failure) {
            store.write(s->{var action=s.getMapper(SecurityMapper.class).action(actionKey);BrowserSessionService.audit(s.getMapper(OAuthMapper.class),"AUTHORIZATION",principal==null?null:principal.principalId(),principal==null?null:principal.clientId(),principal==null?null:principal.grantId(),principal==null?null:principal.tokenId(),failure.outcome().name(),failure.code(),System.currentTimeMillis(),failure.decisionId(),action==null?null:action.id());return null;});
            throw failure;
        }
    }
    private AuthorizedContext authorizeChecked(AuthenticatedPrincipal principal,String actionKey,CanonicalTarget claimed,String bindingId,String targetPolicyId){
        if(!authority.securityBindingId().equals(bindingId))throw new AccessDenied(AccessDenied.Outcome.UNAVAILABLE,"security_binding_mismatch");
        Objects.requireNonNull(claimed);
        var observed=principal.management()?store.read(s->{recheckLocal(s,principal);return new ManagementState(managementState(s),s.getMapper(SecurityMapper.class).principal(principal.principalId()).generation(),s.getMapper(OAuthMapper.class).sessionById(principal.sessionId()).generation());}):null;
        String version=store.read(s->{recheckLocal(s,principal);var m=s.getMapper(SecurityMapper.class);var binding=m.binding(bindingId);if(binding==null)throw AccessDenied.denied();var action=m.action(actionKey);if(action==null||!targetCompatible(action,claimed)||(!principal.management()&&!localAction(m,principal,action,claimed)))throw AccessDenied.denied();return binding.versionId();});
        CanonicalTarget actual=authority.resolve(principal.identityProvider(),principal.subject(),actionKey,claimed,targetPolicyId);
        if(!actual.equals(claimed))throw AccessDenied.denied();
        var decision=authority.decide(principal.identityProvider(),principal.subject(),actionKey,actual);
        if(!decision.outcome().equals("ALLOW")){
            throw new AccessDenied(AccessDenied.Outcome.valueOf(decision.outcome()),"authority_rejected",decision.decisionId());
        }
        var context=new AuthorizedContext(principal,actionKey,actual,decision.decisionId(),bindingId,decision.roles(),observed==null?Map.of():observed.definitions(),observed==null?0:observed.principalGeneration(),observed==null?0:observed.sessionGeneration());
        store.write(s->{recheckLocal(s,principal);if(observed!=null)recheckManagement(s,context,true);var m=s.getMapper(SecurityMapper.class);var binding=m.binding(bindingId);var action=m.action(actionKey);if(binding==null||!binding.versionId().equals(version)||action==null||!targetCompatible(action,actual)||decision.roles().isEmpty()||m.roleAction(bindingId,action.id(),action.semanticVersion(),decision.roles())==0||(!principal.management()&&!localAction(m,principal,action,actual)))throw AccessDenied.denied();BrowserSessionService.audit(s.getMapper(OAuthMapper.class),"AUTHORIZATION",principal.principalId(),principal.clientId(),principal.grantId(),principal.tokenId(),"ALLOW",null,System.currentTimeMillis(),decision.decisionId(),action.id());return null;});
        return context;
    }
    private record ManagementState(Map<String,String> definitions,long principalGeneration,long sessionGeneration) {}
    private static boolean targetCompatible(SecurityMapper.Action action,CanonicalTarget target){return action.targetKind().equals(target.targetKind())||action.targetKind().equals("PATIENT")&&!target.targetKind().equals("SERVICE");}
    private static boolean localAction(SecurityMapper mapper,AuthenticatedPrincipal principal,SecurityMapper.Action action,CanonicalTarget target){
        if(mapper.clientAction(principal.clientId(),action.id(),action.semanticVersion(),principal.resource())==0||mapper.tokenAction(principal.tokenId(),action.id(),action.semanticVersion())==0)return false;
        return mapper.rules(principal.grantId()).stream().anyMatch(rule->rule.actionId().equals(action.id())&&rule.semanticVersion()==action.semanticVersion()&&(target==null||rule.target().contains(target)));
    }
}
