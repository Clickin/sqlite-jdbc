package io.gateway.oauth;

import io.micronaut.context.annotation.Value;
import io.micronaut.context.annotation.Context;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;

@Context
@io.micronaut.context.annotation.Requires(property="micronaut.server.enabled",notEquals="false",defaultValue="true")
public final class OAuthSettings {
    public final String issuer, resource, publicOrigin, securityBindingId;
    public final long codeTtl, accessTtl, refreshTtl, grantTtl, requestTtl, sessionIdleTtl, sessionAbsoluteTtl;
    public final byte[] stateKey;
    public OAuthSettings(@Value("${gateway.oauth.issuer}") String issuer,
                         @Value("${gateway.oauth.resource}") String resource,
                         @Value("${gateway.oauth.public-origin}") String publicOrigin,
                         @Value("${gateway.oauth.security-binding-id}") String securityBindingId,
                         @Value("${gateway.oauth.code-ttl-seconds}") long code,
                         @Value("${gateway.oauth.access-ttl-seconds}") long access,
                         @Value("${gateway.oauth.refresh-ttl-seconds}") long refresh,
                         @Value("${gateway.oauth.grant-ttl-seconds}") long grant,
                         @Value("${gateway.oauth.request-ttl-seconds}") long request,
                         @Value("${gateway.oauth.session-idle-ttl-seconds}") long idle,
                         @Value("${gateway.oauth.session-absolute-ttl-seconds}") long absolute,
                         @Value("${gateway.oauth.state-key-file}") String keyFile) {
        this.issuer=https(issuer,true); this.resource=https(resource,false); this.publicOrigin=https(publicOrigin,true);
        if(!"/mcp".equals(URI.create(resource).getRawPath())) throw new IllegalArgumentException("MCP resource must match the /mcp metadata endpoint");
        if (securityBindingId==null || securityBindingId.isBlank()) throw new IllegalArgumentException("Security binding is required");
        this.securityBindingId=securityBindingId;
        codeTtl=ttl(code,600); accessTtl=ttl(access,86400); refreshTtl=ttl(refresh,31536000); grantTtl=ttl(grant,31536000);
        requestTtl=ttl(request,3600); sessionIdleTtl=ttl(idle,86400); sessionAbsoluteTtl=ttl(absolute,604800);
        if (sessionIdleTtl>sessionAbsoluteTtl || accessTtl>grantTtl || refreshTtl>grantTtl) throw new IllegalArgumentException("Invalid security lifetime ordering");
        try { stateKey=Base64.getDecoder().decode(Files.readString(Path.of(keyFile)).strip()); }
        catch (Exception e) { throw new IllegalArgumentException("OAuth state key unavailable"); }
        if(stateKey.length!=32) throw new IllegalArgumentException("OAuth state key must be 256 bits");
    }
    private static long ttl(long seconds,long maximum) { if(seconds<1 || seconds>maximum) throw new IllegalArgumentException("Finite security lifetime required"); return Math.multiplyExact(seconds,1000); }
    private static String https(String value,boolean origin) {
        URI uri=URI.create(value);
        if(!"https".equals(uri.getScheme()) || uri.getHost()==null || uri.getUserInfo()!=null || uri.getFragment()!=null || uri.getQuery()!=null || (origin && uri.getRawPath()!=null && !uri.getRawPath().isEmpty())) throw new IllegalArgumentException("Canonical HTTPS URL required");
        if(value.endsWith("/")) throw new IllegalArgumentException("Canonical URL must not end with slash");
        return value;
    }
}
