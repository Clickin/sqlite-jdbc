package io.gateway;

import io.gateway.audit.*;
import io.gateway.authorization.*;
import io.gateway.contracts.*;
import io.gateway.definitions.Definitions;
import io.gateway.mcp.*;
import io.gateway.persistence.PlatformStore;
import io.gateway.runtime.*;
import io.micronaut.context.annotation.Value;
import jakarta.inject.Singleton;
import java.time.Instant;
import java.util.*;

/** REST, console and MCP all enter here; connectors cannot accept an HTTP-supplied principal. */
@Singleton
public final class GatewayExecutionService {
    private final PlatformStore store;
    private final ToolCatalog catalog;
    private final AuthorizationService authorization;
    private final ContractService contracts;
    private final WorkflowRunner runner;
    private final AuditService audit;
    private final RuntimeRegistry runtimes;
    private final io.gateway.results.ResultService results;
    private final long timeoutMillis;
    public GatewayExecutionService(PlatformStore store,ToolCatalog catalog,AuthorizationService authorization,
            ContractService contracts,WorkflowRunner runner,AuditService audit,RuntimeRegistry runtimes,
            io.gateway.results.ResultService results,@Value("${gateway.execution.timeout-ms:30000}")long timeoutMillis) {
        if(timeoutMillis<1||timeoutMillis>3600000)throw new IllegalArgumentException("FINITE_EXECUTION_TIMEOUT_REQUIRED");
        this.store=store;this.catalog=catalog;this.authorization=authorization;this.contracts=contracts;
        this.runner=runner;this.audit=audit;this.timeoutMillis=timeoutMillis;
        this.runtimes=runtimes;this.results=results;
    }
    public Cancellation cancellation(){return new Cancellation(Instant.now().plusMillis(timeoutMillis));}
    public Map<String,Object> executeTool(AuthenticatedPrincipal principal,String name,Map<String,Object> arguments,Cancellation cancellation) {
        return execute(principal,catalog.tool(name),arguments,"MCP",cancellation);
    }
    public Map<String,Object> execute(AuthenticatedPrincipal principal,String workflowKey,Map<String,Object> arguments,String transport) {
        return execute(principal,catalog.workflow(workflowKey),arguments,transport,cancellation());
    }
    public Map<String,Object> execute(AuthenticatedPrincipal principal,String workflowKey,Map<String,Object> arguments,String transport,Cancellation cancellation) {
        return execute(principal,catalog.workflow(workflowKey),arguments,transport,cancellation);
    }

    private Map<String,Object> execute(AuthenticatedPrincipal principal,ToolCatalog.Snapshot snapshot,Map<String,Object> arguments,String transport,Cancellation cancellation) {
        cancellation.check();
        if(!Thread.currentThread().isVirtual())throw new IllegalStateException("BLOCKING_EXECUTION_REQUIRES_VIRTUAL_THREAD");
        if(principal.clientId()==null&&snapshot.graph().definitions().values().stream().anyMatch(d->
                d.detail() instanceof Definitions.JdbcOperation j&&!j.referenceBindings().isEmpty()
                ||d.detail() instanceof Definitions.HttpOperation h&&!h.referenceBindings().isEmpty()))
            throw new AccessDenied(AccessDenied.Outcome.DENY,"client_bound_delegation_required");
        contracts.validate(snapshot.input(),arguments);
        if(!authorization.principalScopes(principal).containsAll(snapshot.scopes()))throw new AccessDenied(AccessDenied.Outcome.DENY,"insufficient_scope");
        var contexts=new LinkedHashMap<ToolMapper.Action,AuthorizedContext>();
        for(var action:snapshot.actions())contexts.put(action,authorize(principal,snapshot,action,arguments));
        catalog.checkSecurityHeads(snapshot);
        var canonical=new HashMap<String,Object>();
        for(var entry:contexts.entrySet()) {
            var policy=snapshot.policies().get(entry.getKey().targetPolicyId());
            if(policy==null)continue;
            for(var binding:policy.bindings()) {
                if(!binding.sourcePort().equals("REQUEST"))continue;
                Object value=switch(binding.targetPart()) {
                    case "PATIENT"->entry.getValue().target().patientIdentifier();
                    case "ENCOUNTER"->entry.getValue().target().encounterIdentifier();
                    case "DOCUMENT"->entry.getValue().target().documentIdentifier();
                    default->throw new IllegalArgumentException("TARGET_BINDING_INVALID");
                };
                if(canonical.containsKey(binding.fieldId())&&!Objects.equals(canonical.get(binding.fieldId()),value))throw AccessDenied.denied();
                canonical.put(binding.fieldId(),value);
            }
        }
        var bound=contracts.bindCanonical(snapshot.input(),arguments,canonical);
        var workflowArguments=mapInput(snapshot,bound,contexts);
        String id=UUID.randomUUID().toString();
        var primary=contexts.entrySet().stream().filter(e->e.getKey().stageKey().equals("INPUT")).findFirst().orElseThrow(AccessDenied::denied);
        try {store.write(session->{
            authorization.recheckLocal(session,principal);
            var mapper=session.getMapper(ExecutionMapper.class);
            var row=new HashMap<String,Object>();
            row.put("id",id);row.put("workflowVersion",snapshot.graph().version(snapshot.graph().rootObjectId()));
            row.put("subject",principal.subject());row.put("client",principal.clientId());row.put("caller",caller(principal));
            row.put("principal",principal.principalId());row.put("grant",principal.grantId());row.put("token",principal.tokenId());
            row.put("transport",transport);row.put("toolVersion",snapshot.tool()==null?null:snapshot.tool().versionId());
            row.put("actionId",primary.getKey().id());row.put("now",System.currentTimeMillis());mapper.start(row);
            for(var definition:snapshot.graph().definitions().values())mapper.dependency(id,"definition/"+definition.object().id(),definition.version().id());
            for(var dependency:snapshot.dependencies().values())mapper.dependency(id,"security/"+dependency.objectId(),dependency.versionId());
            var targets=new HashSet<String>();
            for(var entry:contexts.entrySet()) {
                String key=entry.getKey().stageKey()+"/"+entry.getKey().id()+"/"+entry.getValue().target();
                if(targets.add(key))mapper.target(id,entry.getKey().stageKey(),entry.getKey().id(),entry.getValue());
            }
            append(id,"REQUEST",snapshot.input(),new Payload(bound,Map.of()),principal,transport,snapshot,primary.getValue(),primary.getKey(),"STARTED",null);
            return null;
        });} catch(PlatformStore.StoreException unavailable) {
            // The initial audit transaction failed before the runner could send any business request.
            return failureEnvelope(snapshot,id,"FAILED","FAILED","NOT_SENT","AUDIT_UNAVAILABLE");
        }
        boolean connectorCompleted=false;
        var referenceIds=new ArrayList<String>();
        var effectiveInputs=new HashMap<String,Payload>();
        var stages=new HashMap<String,String>();
        try {
            Payload output=runner.run(snapshot.graph(),primary.getValue(),workflowArguments,cancellation,(stage,stagePayload)->{
                cancellation.check();catalog.checkSecurityHeads(snapshot);
                AuthorizedContext chosen=null;
                Payload canonicalStage=stagePayload;
                for(var action:snapshot.actions())if(action.stageKey().equals(stage)) {
                    var checked=authorize(principal,snapshot,action,bound);
                    canonicalStage=bindStageInput(snapshot,stage,action,checked,canonicalStage);
                    if(chosen==null)chosen=checked;
                }
                if(chosen==null)throw AccessDenied.denied();
                catalog.checkSecurityHeads(snapshot);
                return new WorkflowRunner.StageInput(chosen,canonicalStage);
            },(port,payload)->{
                var contract=stageContract(snapshot,port);
                // Unknown returned identifiers must not be forwarded under the original patient's authority.
                if(port.endsWith("OUTPUT"))checkReturnedTargets(principal,snapshot,contract,payload,contexts,port,id);
                if(port.equals("SOURCE_OUTPUT")||port.equals("TARGET_OUTPUT"))validateReferenceCandidates(snapshot,port,contract,payload);
                String stageKey=port.startsWith("SOURCE")?"INPUT":port.startsWith("CONVERT")?"CONVERT":"OUTPUT";
                if(port.endsWith("REQUEST"))stages.put(stageKey,startStage(id,snapshot,stageKey));
                append(id,port,contract,payload,principal,transport,snapshot,primary.getValue(),primary.getKey(),"OBSERVED",stages.get(stageKey));
                if(port.endsWith("REQUEST"))effectiveInputs.put(port,payload);
                if(port.equals("SOURCE_OUTPUT")||port.equals("TARGET_OUTPUT"))
                    referenceIds.addAll(observeReferences(principal,id,snapshot,port,contract,payload,effectiveInputs,arguments));
                if(port.endsWith("OUTPUT"))store.write(s->{s.getMapper(ExecutionMapper.class).finishStage(stages.get(stageKey),System.currentTimeMillis());return null;});
            });
            connectorCompleted=true;
            Payload publicOutput=mapOutput(snapshot,output);
            contracts.validate(snapshot.output(),publicOutput.object());
            store.write(session->{
                append(id,"RESPONSE",snapshot.output(),publicOutput,principal,transport,snapshot,primary.getValue(),primary.getKey(),"SUCCEEDED",null);
                session.getMapper(ExecutionMapper.class).finish(id,"SUCCEEDED","PREPARED",null,System.currentTimeMillis());
                return null;
            });
            var result=envelope(id,"SUCCEEDED","SUCCEEDED","PREPARED",null);
            result.put("data",publicOutput.value());result.put("references",List.copyOf(referenceIds));
            return result;
        } catch(AccessDenied failure) {
            finish(id,"FAILED","NOT_SENT","ACCESS_DENIED");throw failure;
        } catch(ExecutionFailure failure) {
            String business=failure.outcome()==ExecutionFailure.Outcome.FAILED_BEFORE_EFFECT?"FAILED":failure.outcome().name();
            String status=failure.responseFailed()?"RESPONSE_FAILED":business;
            boolean recorded=finish(id,business,failure.responseFailed()?"FAILED":"PREPARED",failure.code());
            return failureEnvelope(snapshot,id,status,business,failure.responseFailed()?"FAILED":"PREPARED",recorded?failure.code():"AUDIT_UNAVAILABLE");
        } catch(RuntimeException failure) {
            String business=connectorCompleted?"SUCCEEDED":"FAILED";
            String status=connectorCompleted?"RESPONSE_FAILED":"FAILED";
            finish(id,business,"FAILED",status);
            return failureEnvelope(snapshot,id,status,business,"FAILED",status);
        }
    }

    private AuthorizedContext authorize(AuthenticatedPrincipal principal,ToolCatalog.Snapshot snapshot,ToolMapper.Action action,Map<String,Object> arguments) {
        CanonicalTarget target;
        if(action.targetKind().equals("SERVICE"))target=CanonicalTarget.service();
        else {
            var policy=snapshot.policies().get(action.targetPolicyId());
            if(policy==null)throw AccessDenied.denied();
            String patient=null,encounter=null,document=null;
            for(var binding:policy.bindings()) {
                if(!binding.sourcePort().equals("REQUEST"))continue;
                Object value=contracts.value(snapshot.input(),arguments,binding.fieldId());
                if(!(value instanceof String text)||text.isBlank())throw AccessDenied.denied();
                switch(binding.targetPart()) {
                    case "PATIENT"->patient=text;case "ENCOUNTER"->encounter=text;case "DOCUMENT"->document=text;
                    default->throw AccessDenied.denied();
                }
            }
            target=new CanonicalTarget(policy.definition().kind(),policy.definition().organization(),policy.definition().identifierSystem(),patient,encounter,document);
        }
        return authorization.authorize(principal,action.key(),target,action.securityBindingId(),action.targetPolicyId());
    }

    private void checkReturnedTargets(AuthenticatedPrincipal principal,ToolCatalog.Snapshot snapshot,ContractService.Contract contract,Payload output,Map<ToolMapper.Action,AuthorizedContext> contexts,String port,String executionId) {
        for(var entry:contexts.entrySet()) {
            var original=entry.getValue().target();if(original.targetKind().equals("SERVICE"))continue;
            var policy=snapshot.policies().get(entry.getKey().targetPolicyId());
            if(policy==null)throw AccessDenied.denied();
            String patient=original.patientIdentifier(),encounter=original.encounterIdentifier(),document=original.documentIdentifier();
            boolean changed=false;
            for(var binding:policy.bindings())if(binding.sourcePort().equals(port)) {
                Object value=contracts.value(contract,output.object(),binding.fieldId());
                if(!(value instanceof String identifier)||identifier.isBlank())throw AccessDenied.denied();
                switch(binding.targetPart()) {
                    case "PATIENT"->patient=identifier;case "ENCOUNTER"->encounter=identifier;case "DOCUMENT"->document=identifier;
                    default->throw AccessDenied.denied();
                }
                changed=true;
            }
            if(!changed)continue;
            if(!Objects.equals(patient,original.patientIdentifier()))throw AccessDenied.denied();
            String kind=document!=null?"DOCUMENT":encounter!=null?"ENCOUNTER":"PATIENT";
            var actual=new CanonicalTarget(kind,original.organization(),original.identifierSystem(),patient,encounter,document);
            var checked=authorization.authorize(principal,entry.getKey().key(),actual,entry.getKey().securityBindingId(),null);
            store.write(s->{s.getMapper(ExecutionMapper.class).target(executionId,port,entry.getKey().id(),checked);return null;});
        }
    }
    private ContractService.Contract stageContract(ToolCatalog.Snapshot snapshot,String port) {
        var workflow=(Definitions.Workflow)snapshot.graph().require(snapshot.graph().rootObjectId()).detail();
        String stageKey=port.startsWith("SOURCE")?"INPUT":port.startsWith("CONVERT")?"CONVERT":"OUTPUT";
        var stage=workflow.stages().stream().filter(s->s.stageKey().equals(stageKey)).findFirst().orElseThrow();
        var operation=snapshot.graph().require(stage.operationObjectId()==null?stage.converterObjectId():stage.operationObjectId()).detail();
        boolean input=port.endsWith("REQUEST");
        String object=switch(operation) {
            case Definitions.JdbcOperation j->input?j.inputContractObjectId():j.outputContractObjectId();
            case Definitions.HttpOperation h->input?h.inputContractObjectId():h.outputContractObjectId();
            case Definitions.Converter c->input?c.inputContractObjectId():c.outputContractObjectId();
            default->throw new IllegalArgumentException("OPERATION_CONTRACT_REQUIRED");
        };
        var definition=snapshot.graph().require(object);
        var fields=((Definitions.Contract)definition.detail()).fields().stream().map(f->new ContractService.Field(f.id(),f.parentFieldId(),f.memberName()==null?f.logicalName():f.memberName(),f.nodeKind(),f.valueType(),f.ordinal(),f.required(),f.nullable(),f.precision(),f.scale(),f.maxLength(),f.auditDisposition().name())).toList();
        return new ContractService.Contract(definition.version().id(),fields);
    }

    private Payload bindStageInput(ToolCatalog.Snapshot snapshot,String stage,ToolMapper.Action action,AuthorizedContext checked,Payload payload) {
        if(checked.target().targetKind().equals("SERVICE"))return payload;
        var contract=stageContract(snapshot,stage.equals("INPUT")?"SOURCE_REQUEST":"TARGET_REQUEST");
        var ids=new HashSet<String>();contract.fields().forEach(f->ids.add(f.id()));
        var canonical=new HashMap<String,Object>();var parts=new HashSet<String>();
        for(var binding:snapshot.policies().get(action.targetPolicyId()).bindings()) {
            if(!Set.of("REQUEST","CONTEXT").contains(binding.sourcePort()))continue;
            String fieldId=binding.fieldId();
            if(!ids.contains(fieldId)) {
                if(!stage.equals("INPUT")||!binding.sourcePort().equals("REQUEST")||snapshot.tool()!=null&&snapshot.tool().inputMappingId()!=null)continue;
                fieldId=contracts.correspondingField(snapshot.input(),contract,fieldId);
            }
            Object actual=switch(binding.targetPart()) {
                case "PATIENT"->checked.target().patientIdentifier();
                case "ENCOUNTER"->checked.target().encounterIdentifier();
                case "DOCUMENT"->checked.target().documentIdentifier();
                default->throw AccessDenied.denied();
            };
            Object proposed=contracts.value(contract,payload.object(),fieldId);
            if(proposed!=null&&!Objects.equals(proposed,actual))throw AccessDenied.denied();
            canonical.put(fieldId,actual);parts.add(binding.targetPart());
        }
        if(!parts.contains("PATIENT")||checked.target().encounterIdentifier()!=null&&!parts.contains("ENCOUNTER")
                ||checked.target().documentIdentifier()!=null&&!parts.contains("DOCUMENT"))throw new IllegalArgumentException("CANONICAL_STAGE_BINDINGS_REQUIRED");
        return new Payload(contracts.bindCanonical(contract,payload.object(),canonical),payload.dispositions());
    }

    private Payload mapInput(ToolCatalog.Snapshot snapshot,Map<String,Object> arguments,Map<ToolMapper.Action,AuthorizedContext> contexts) {
        if(snapshot.tool()==null||snapshot.tool().inputMappingId()==null)return Payload.of(arguments);
        Payload mapped;
        try(var lease=runtimes.acquire(snapshot.graph())){mapped=lease.get().convert(snapshot.tool().inputMappingId(),Payload.of(arguments));}
        for(var entry:contexts.entrySet())if(entry.getKey().stageKey().equals("INPUT"))
            mapped=bindStageInput(snapshot,"INPUT",entry.getKey(),entry.getValue(),mapped);
        return mapped;
    }
    private Payload mapOutput(ToolCatalog.Snapshot snapshot,Payload output) {
        if(snapshot.tool()==null||snapshot.tool().outputMappingId()==null)return output;
        try(var lease=runtimes.acquire(snapshot.graph())){return lease.get().convert(snapshot.tool().outputMappingId(),output);}
    }
    private Definitions.Saved referenceOperation(ToolCatalog.Snapshot snapshot,String port) {
        var workflow=(Definitions.Workflow)snapshot.graph().require(snapshot.graph().rootObjectId()).detail();
        String stage=port.equals("SOURCE_OUTPUT")?"INPUT":"OUTPUT";
        return snapshot.graph().require(workflow.stages().stream().filter(s->s.stageKey().equals(stage)).findFirst().orElseThrow().operationObjectId());
    }
    private static List<Definitions.ReferenceBinding> referenceRules(Definitions.Saved operation) {
        return operation.detail() instanceof Definitions.JdbcOperation j?j.referenceBindings():((Definitions.HttpOperation)operation.detail()).referenceBindings();
    }
    private void validateReferenceCandidates(ToolCatalog.Snapshot snapshot,String port,ContractService.Contract contract,Payload output) {
        for(var rule:referenceRules(referenceOperation(snapshot,port)))if(rule.referenceKind().equals("WEB_LINK"))
            for(Object url:contracts.values(contract,output.object(),rule.outputUrlFieldId()))
                if(url!=null)results.validateWebReferenceCandidate((String)url);
    }
    private List<String> observeReferences(AuthenticatedPrincipal principal,String executionId,ToolCatalog.Snapshot snapshot,
            String port,ContractService.Contract outputContract,Payload output,Map<String,Payload> effectiveInputs,Map<String,Object> originalArguments) {
        var operation=referenceOperation(snapshot,port);
        String datasource=operation.detail() instanceof Definitions.JdbcOperation j?j.sourceObjectId():((Definitions.HttpOperation)operation.detail()).sourceObjectId();
        var ids=new ArrayList<String>();
        for(var rule:referenceRules(operation)) {
            List<Object> records=rule.originRecordFieldId()==null?Collections.singletonList(null):contracts.values(outputContract,output.object(),rule.originRecordFieldId());
            if(rule.referenceKind().equals("WEB_LINK")) {
                var urls=contracts.values(outputContract,output.object(),rule.outputUrlFieldId());
                if(rule.originRecordFieldId()!=null&&records.size()!=urls.size())throw new IllegalArgumentException("REFERENCE_ARRAY_SCOPE_MISMATCH");
                for(int i=0;i<urls.size();i++)if(urls.get(i)!=null) {
                    String record=rule.originRecordFieldId()==null?null:(String)records.get(i);
                    ids.add(results.recordWebReference(principal,executionId,new io.gateway.results.ResultModels.WebObservation((String)urls.get(i),rule.displayName(),record)));
                }
            } else {
                String requestPort=port.equals("SOURCE_OUTPUT")?"SOURCE_REQUEST":"TARGET_REQUEST";
                var original=ContractAudit.values(snapshot.input(),Payload.of(originalArguments));
                var effective=ContractAudit.values(stageContract(snapshot,requestPort),effectiveInputs.get(requestPort));
                var screen=snapshot.dependencies().get(rule.screenProfileObjectId());
                if(screen==null)throw new IllegalArgumentException("SCREEN_PROFILE_NOT_RESOLVED");
                for(Object record:records)ids.add(results.recordToolReference(principal,executionId,new io.gateway.results.ResultModels.ToolObservation(
                    operation.object().id(),operation.version().id(),snapshot.graph().version(datasource),rule.screenProfileObjectId(),screen.versionId(),(String)record,original,effective)));
            }
        }
        return ids;
    }
    private void append(String id,String port,ContractService.Contract contract,Payload payload,AuthenticatedPrincipal principal,String transport,
                        ToolCatalog.Snapshot snapshot,AuthorizedContext context,ToolMapper.Action action,String outcome,String stageId) {
        var security=new AuditService.SecurityContext(principal.principalId(),principal.clientId(),null,principal.grantId(),principal.tokenId(),transport,snapshot.tool()==null?null:snapshot.tool().versionId(),action.id());
        audit.append(new AuditService.Event(id,stageId,"EXECUTION_PARAMETERS",principal.subject(),caller(principal),context.decisionId(),outcome,null,security),
                AuditProjection.project(port,ContractAudit.values(contract,payload)));
    }
    private static String caller(AuthenticatedPrincipal principal){return principal.clientId()==null?"console":principal.clientId();}
    private boolean finish(String id,String business,String response,String code){
        try {store.write(s->{var mapper=s.getMapper(ExecutionMapper.class);long now=System.currentTimeMillis();
            mapper.finishActiveStages(id,business,code==null?business:"FAILED",code,now);
            mapper.finish(id,business,response,code,now);return null;});return true;}
        catch(PlatformStore.StoreException unavailable){
            org.slf4j.LoggerFactory.getLogger(GatewayExecutionService.class).error("EXECUTION_FINALIZATION_UNAVAILABLE execution={} outcome={}",id,business);
            return false;
        }
    }
    public void responseFailed(String id){finish(id,"SUCCEEDED","FAILED","RESPONSE_FAILED");}
    private String startStage(String executionId,ToolCatalog.Snapshot snapshot,String stageKey){
        var workflow=(Definitions.Workflow)snapshot.graph().require(snapshot.graph().rootObjectId()).detail();
        var stage=workflow.stages().stream().filter(s->s.stageKey().equals(stageKey)).findFirst().orElseThrow();
        String operationVersion=null,effect="READ_ONLY";
        if(stage.operationObjectId()!=null){
            var operation=snapshot.graph().require(stage.operationObjectId());operationVersion=operation.version().id();
            effect=(operation.detail() instanceof Definitions.JdbcOperation j?j.effect():((Definitions.HttpOperation)operation.detail()).effect()).name();
        }
        String id=UUID.randomUUID().toString(),selectedVersion=operationVersion,selectedEffect=effect;
        store.write(s->{s.getMapper(ExecutionMapper.class).startStage(id,executionId,stageKey,selectedVersion,selectedEffect,System.currentTimeMillis());return null;});
        return id;
    }
    private static LinkedHashMap<String,Object> envelope(String id,String status,String business,String response,String code) {
        var result=new LinkedHashMap<String,Object>();result.put("executionId",id);result.put("status",status);result.put("businessOutcome",business);result.put("responseOutcome",response);
        if(code!=null)result.put("error",Map.of("code",code));return result;
    }
    private static Map<String,Object> failureEnvelope(ToolCatalog.Snapshot snapshot,String id,String status,String business,String response,String code){
        var result=envelope(id,status,business,response,code);
        var workflow=(Definitions.Workflow)snapshot.graph().require(snapshot.graph().rootObjectId()).detail();
        if(workflow.errorMappingObjectId()!=null) {
            var mapping=(Definitions.ErrorMapping)snapshot.graph().require(workflow.errorMappingObjectId()).detail();
            for(var rule:mapping.rules())if(rule.remoteCode().equals(code)){
                result.put("error",Map.of("code",rule.publicCode(),"httpStatus",rule.statusCode()));break;
            }
        }
        return result;
    }
}
