package io.gateway.authorization;

import io.micronaut.serde.annotation.Serdeable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

@Serdeable
public record CanonicalTarget(String targetKind, String organization, String identifierSystem,
                              String patientIdentifier, String encounterIdentifier, String documentIdentifier) {
    public CanonicalTarget {
        Objects.requireNonNull(targetKind);
        if (!java.util.Set.of("SERVICE", "PATIENT", "ENCOUNTER", "DOCUMENT").contains(targetKind)) throw new IllegalArgumentException("Invalid target kind");
        if (targetKind.equals("SERVICE")) {
            if (organization != null || identifierSystem != null || patientIdentifier != null || encounterIdentifier != null || documentIdentifier != null) throw new IllegalArgumentException("Service target cannot identify a patient");
        } else {
            requireIdentifier(organization); requireIdentifier(identifierSystem); requireIdentifier(patientIdentifier);
            if (targetKind.equals("ENCOUNTER")) requireIdentifier(encounterIdentifier);
            if (targetKind.equals("DOCUMENT")) requireIdentifier(documentIdentifier);
            if (targetKind.equals("PATIENT") && (encounterIdentifier != null || documentIdentifier != null)) throw new IllegalArgumentException("Patient target contains subordinate identifiers");
            if (targetKind.equals("ENCOUNTER") && documentIdentifier != null) throw new IllegalArgumentException("Encounter target contains document");
            if (encounterIdentifier != null) requireIdentifier(encounterIdentifier);
        }
    }
    private static void requireIdentifier(String value) {
        if (value == null || value.isBlank() || value.length() > 512 || value.indexOf('*') >= 0 || value.chars().anyMatch(Character::isISOControl)) throw new IllegalArgumentException("Explicit target identifier required");
    }
    public static CanonicalTarget service() { return new CanonicalTarget("SERVICE", null, null, null, null, null); }
    public Map<String,Object> parameters() {
        Map<String,Object> values = new LinkedHashMap<>();
        values.put("targetKind",targetKind);
        if (organization != null) values.put("organization",organization);
        if (identifierSystem != null) values.put("identifierSystem",identifierSystem);
        if (patientIdentifier != null) values.put("patientIdentifier",patientIdentifier);
        if (encounterIdentifier != null) values.put("encounterIdentifier",encounterIdentifier);
        if (documentIdentifier != null) values.put("documentIdentifier",documentIdentifier);
        return Map.copyOf(values);
    }
    public boolean contains(CanonicalTarget actual) {
        if (targetKind.equals("SERVICE")) return equals(actual);
        if (!Objects.equals(organization, actual.organization) || !Objects.equals(identifierSystem, actual.identifierSystem) || !Objects.equals(patientIdentifier, actual.patientIdentifier)) return false;
        return switch (targetKind) {
            case "PATIENT" -> !actual.targetKind.equals("SERVICE");
            case "ENCOUNTER" -> Objects.equals(encounterIdentifier,actual.encounterIdentifier);
            case "DOCUMENT" -> Objects.equals(documentIdentifier,actual.documentIdentifier) && (encounterIdentifier == null || Objects.equals(encounterIdentifier,actual.encounterIdentifier));
            default -> false;
        };
    }
}
