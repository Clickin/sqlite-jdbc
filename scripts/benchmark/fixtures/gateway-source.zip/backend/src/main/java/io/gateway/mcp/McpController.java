package io.gateway.mcp;

import io.gateway.GatewayExecutionService;
import io.gateway.authorization.*;
import io.gateway.oauth.OAuthSettings;
import io.micronaut.http.*;
import io.micronaut.http.annotation.*;
import java.util.*;

@Controller("/mcp")
public final class McpController {
    private final AuthorizationService authorization;
    private final OAuthSettings settings;
    private final Mcp2026Adapter adapter;
    private final McpSdkBridge sdk;
    private final GatewayExecutionService gateway;
    public McpController(AuthorizationService authorization,OAuthSettings settings,Mcp2026Adapter adapter,McpSdkBridge sdk,GatewayExecutionService gateway) {
        this.authorization=authorization;this.settings=settings;this.adapter=adapter;this.sdk=sdk;this.gateway=gateway;
    }
    @Post(consumes=MediaType.APPLICATION_JSON,produces=MediaType.APPLICATION_JSON)
    public HttpResponse<String> post(HttpRequest<?> request,@Body String body) {
        Object id=null;
        try {
            List<String> origins=request.getHeaders().getAll("Origin");
            if(!origins.isEmpty()&&(origins.size()!=1||!origins.getFirst().equals(settings.publicOrigin)))
                return safe(HttpResponse.status(HttpStatus.FORBIDDEN).body("{\"error\":\"invalid_origin\"}"));
            var principal=authorization.authenticateBearer(request.getHeaders().getAll(HttpHeaders.AUTHORIZATION),settings.resource);
            var parsed=adapter.request(body,request.getHeaders().asMap());id=parsed.rpc().id();
            var cancellation=gateway.cancellation();
            try(var lifetime=new io.gateway.RequestLifetime(request,cancellation)) {
            var result=sdk.dispatch(parsed,principal,cancellation);
            String response;
            try { response=adapter.serialize(adapter.result(id,result)); }
            catch(RuntimeException failure) {
                if(result.get("structuredContent") instanceof Map<?,?> content && "SUCCEEDED".equals(content.get("businessOutcome"))
                        && content.get("executionId") instanceof String executionId)gateway.responseFailed(executionId);
                throw failure;
            }
            if(cancellation.isCancelled() && result.get("structuredContent") instanceof Map<?,?> content
                    && "SUCCEEDED".equals(content.get("businessOutcome")) && content.get("executionId") instanceof String executionId)
                gateway.responseFailed(executionId);
            return safe(HttpResponse.ok(response));
            }
        } catch(Mcp2026Adapter.ProtocolFailure failure) {
            return safe(HttpResponse.<String>status(HttpStatus.valueOf(failure.status)).body(adapter.serialize(adapter.error(failure))));
        } catch(AccessDenied failure) {
            int status=switch(failure.outcome()) {
                case UNAUTHENTICATED->401;case DENY,PENDING->403;case UNAVAILABLE->503;
            };
            var response=HttpResponse.<String>status(HttpStatus.valueOf(status)).body(adapter.serialize(Map.of("error",failure.code())));
            if(status==401)response.header(HttpHeaders.WWW_AUTHENTICATE,"Bearer resource_metadata=\""+settings.issuer+"/.well-known/oauth-protected-resource/mcp\"");
            if(status==403&&failure.code().equals("insufficient_scope"))response.header(HttpHeaders.WWW_AUTHENTICATE,"Bearer error=\"insufficient_scope\"");
            return safe(response);
        } catch(RuntimeException failure) {
            var error=new Mcp2026Adapter.ProtocolFailure(500,-32603,"Internal error",id,Map.of());
            return safe(HttpResponse.serverError(adapter.serialize(adapter.error(error))));
        }
    }
    @Get public HttpResponse<?> get(){return HttpResponse.notAllowed(HttpMethod.POST);}
    @Delete public HttpResponse<?> delete(){return HttpResponse.notAllowed(HttpMethod.POST);}
    private static <T> MutableHttpResponse<T> safe(MutableHttpResponse<T> response) {
        return response.contentType(MediaType.APPLICATION_JSON_TYPE).header(HttpHeaders.CACHE_CONTROL,"no-store").header("Pragma","no-cache").header("X-Content-Type-Options","nosniff");
    }
}
