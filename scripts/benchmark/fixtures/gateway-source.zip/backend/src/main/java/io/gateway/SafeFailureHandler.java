package io.gateway;

import io.micronaut.http.annotation.Produces;
import io.micronaut.http.*;
import io.micronaut.http.server.exceptions.ExceptionHandler;
import jakarta.inject.Singleton;
import java.util.*;

@Produces
@Singleton
public final class SafeFailureHandler implements ExceptionHandler<Exception,HttpResponse<?>> {
    @Override public HttpResponse<?> handle(HttpRequest request,Exception failure) {
        boolean conflict=failure instanceof IllegalStateException && Set.of("RESULT_REVISION_CONFLICT","DEFINITION_CONFLICT_REVALIDATE","DEPENDENCY_CHANGED_REVALIDATE","CONFIGURATION_CONFLICT").contains(failure.getMessage()==null?"":failure.getMessage());
        int status=conflict?409:failure instanceof IllegalArgumentException?400:500;
        String code=status==409?"state_conflict":status==400?"invalid_request":"internal_error";
        String trace=UUID.randomUUID().toString();
        if(status==500)org.slf4j.LoggerFactory.getLogger(SafeFailureHandler.class).warn("HTTP_FAILURE trace={} type={}",trace,failure.getClass().getName());
        return HttpResponse.status(HttpStatus.valueOf(status)).body(Map.of("error",code,"traceId",trace)).header("Cache-Control","no-store");
    }
}
