package io.gateway.management;

import io.gateway.definitions.DefinitionMapper;
import io.gateway.definitions.DefinitionRepository;
import io.gateway.definitions.Definitions.*;
import io.gateway.persistence.PlatformStore;
import io.micronaut.serde.annotation.Serdeable;
import jakarta.inject.Singleton;
import org.apache.ibatis.session.SqlSession;
import java.net.URI;
import java.util.*;
import static io.gateway.management.ManagementMapper.Table;

@Singleton
public final class SecurityDefinitions {
    private final PlatformStore store;
    private final jakarta.inject.Provider<DefinitionRepository> definitions;
    public SecurityDefinitions(PlatformStore store,jakarta.inject.Provider<DefinitionRepository> definitions) { this.store=store;this.definitions=definitions; }
    @Serdeable public record Draft(String objectId,String logicalKey,String displayName,String description,String reason,String detailType,Map<String,Object> detail) {}
    @Serdeable public record Saved(Head object,Version version,String detailType,Map<String,Object> detail) {}
    private static final Map<String,Map<String,Table>> CHILDREN=Map.of(
        "ROLE",Map.of("actions",Table.ROLE_ACTION),
        "SECURITY_BINDING",Map.of("roleMappings",Table.EXTERNAL_ROLE),
        "TARGET_POLICY",Map.of("arguments",Table.TARGET_ARGUMENT),
        "OAUTH_CLIENT",Map.of("redirects",Table.CLIENT_REDIRECT,"scopes",Table.CLIENT_SCOPE,"resources",Table.CLIENT_RESOURCE,"actions",Table.CLIENT_ACTION),
        "MCP_TOOL",Map.of("scopes",Table.TOOL_SCOPE,"actions",Table.TOOL_ACTION),
        "ERROR_MAPPING",Map.of("rules",Table.ERROR_RULE));
    public List<Head> list() { return store.read(s->s.getMapper(DefinitionMapper.class).heads().stream().filter(h->CHILDREN.containsKey(h.kind())).toList()); }
    public List<Version> history(String id) { return store.read(s->{ head(s,id); return s.getMapper(DefinitionMapper.class).history(id); }); }
    public Saved get(String id,String versionId) { return store.read(s->get(s,id,versionId)); }
    private static Head head(SqlSession s,String id) {
        Head head=s.getMapper(DefinitionMapper.class).head(id);
        if(head==null||!CHILDREN.containsKey(head.kind())) throw new IllegalArgumentException("SECURITY_DEFINITION_NOT_FOUND");
        return head;
    }
    private static Saved get(SqlSession s,String id,String versionId) {
        DefinitionMapper base=s.getMapper(DefinitionMapper.class); Head head=head(s,id);
        Version version=base.version(versionId==null?head.currentVersionId():versionId);
        if(version==null||!version.objectId().equals(id)) throw new IllegalArgumentException("VERSION_NOT_FOUND");
        ManagementMapper mapper=s.getMapper(ManagementMapper.class); Table table=Table.valueOf(head.kind());
        List<Map<String,Object>> rows=mapper.rows(table,version.id());
        if(rows.size()!=1) throw new IllegalArgumentException("INCOMPLETE_DEFINITION");
        Map<String,Object> detail=new LinkedHashMap<>(rows.getFirst()); detail.remove(table.parent);
        for(var entry:CHILDREN.get(head.kind()).entrySet()) {
            List<Map<String,Object>> children=new ArrayList<>();
            for(Map<String,Object> child:mapper.rows(entry.getValue(),version.id())) { Map<String,Object> row=new LinkedHashMap<>(child); row.remove(entry.getValue().parent); children.add(row); }
            detail.put(entry.getKey(),children);
        }
        return new Saved(head,version,head.kind(),detail);
    }
    public Saved draft(Draft draft,String actor) {
        if(!CHILDREN.containsKey(draft.detailType())||draft.detail()==null) throw new IllegalArgumentException("UNSUPPORTED_DEFINITION_TYPE");
        required(draft.logicalKey()); required(draft.displayName()); required(draft.reason());
        return store.write(s->{
            DefinitionMapper base=s.getMapper(DefinitionMapper.class); ManagementMapper mapper=s.getMapper(ManagementMapper.class);
            long now=System.currentTimeMillis(); String id=draft.objectId();
            if(id==null||id.isBlank()) { id=UUID.randomUUID().toString(); base.create(id,draft.detailType(),draft.logicalKey(),now,actor); }
            Head head=head(s,id);
            if(!head.kind().equals(draft.detailType())||!head.logicalKey().equals(draft.logicalKey())) throw new IllegalArgumentException("IMMUTABLE_IDENTITY");
            base.next(id); String versionId=UUID.randomUUID().toString();
            Version version=new Version(versionId,id,head.kind(),head.revisionCounter()+1,now,actor,draft.reason(),draft.displayName(),draft.description()); base.versionInsert(version);
            Map<String,Object> root=new LinkedHashMap<>(draft.detail());
            for(var child:CHILDREN.get(head.kind()).entrySet()) {
                Object value=root.remove(child.getKey());
                if(value!=null&&!(value instanceof List<?>)) throw new IllegalArgumentException("INVALID_CHILD_ROWS");
            }
            Table table=Table.valueOf(head.kind());
            if(root.containsKey("version_id")) throw new IllegalArgumentException("IMMUTABLE_PARENT");
            root.put("version_id",versionId); mapper.insert(table,root);
            for(var child:CHILDREN.get(head.kind()).entrySet()) {
                Object value=draft.detail().get(child.getKey()); if(value==null) continue;
                int ordinal=0;
                for(Object item:(List<?>)value) {
                    if(!(item instanceof Map<?,?> input)) throw new IllegalArgumentException("INVALID_CHILD_ROW");
                    Map<String,Object> row=new LinkedHashMap<>();
                    for(var entry:input.entrySet()) {
                        if(!(entry.getKey() instanceof String key)||key.equals(child.getValue().parent)) throw new IllegalArgumentException("INVALID_COLUMN");
                        row.put(key,entry.getValue());
                    }
                    row.put(child.getValue().parent,versionId);
                    if(child.getValue().columns.contains("ordinal")) row.put("ordinal",ordinal++);
                    mapper.insert(child.getValue(),row);
                }
            }
            mapper.auditMutation(UUID.randomUUID().toString(),"CONFIG_DRAFT",now,actor,"DRAFT_SAVED");
            return get(s,id,versionId);
        });
    }
    public Validation validate(String id,String version) { return store.read(s->validate(s,id,version)); }
    private Validation validate(SqlSession s,String id,String version) {
        Saved saved=get(s,id,version); Map<String,String> dependencies=new TreeMap<>();
        validateReferences(s,saved.detail(),dependencies);
        ManagementMapper mapper=s.getMapper(ManagementMapper.class);
        Map<String,Object> d=saved.detail();
        switch(saved.detailType()) {
            case "ROLE" -> { if(rows(d,"actions").isEmpty()) throw new IllegalArgumentException("ROLE_ACTION_REQUIRED"); }
            case "SECURITY_BINDING" -> {
                for(String key:List.of("identity_operation_object_id","authorization_operation_object_id","roles_operation_object_id")) requireKind(s,d,key,"OPERATION");
                for(String key:List.of("identity_converter_object_id","authorization_converter_object_id","roles_converter_object_id")) requireKind(s,d,key,"CONVERTER");
                for(Map<String,Object> mapping:rows(d,"roleMappings")) requireKind(s,mapping,"role_object_id","ROLE");
            }
            case "TARGET_POLICY" -> {
                if(!"SERVICE".equals(d.get("target_kind"))) {
                    required(d.get("canonical_organization")); required(d.get("identifier_system"));
                    requireKind(s,d,"resolver_operation_object_id","OPERATION"); requireKind(s,d,"resolver_converter_object_id","CONVERTER");
                    if(rows(d,"arguments").isEmpty()) throw new IllegalArgumentException("TARGET_ARGUMENT_REQUIRED");
                    DefinitionMapper base=s.getMapper(DefinitionMapper.class);
                    Head operation=base.head(d.get("resolver_operation_object_id").toString());
                    var source=base.rows(DefinitionMapper.Table.OPERATION,operation.currentVersionId()).getFirst();
                    if(!"READ_ONLY".equals(source.get("effect_kind"))) throw new IllegalArgumentException("RESOLVER_MUST_BE_READ_ONLY");
                    Head output=base.head(source.get("output_contract_object_id").toString());
                    Set<String> allowed=Set.of("targetKind","organization","identifierSystem","patientIdentifier","encounterIdentifier","documentIdentifier");
                    for(Map<String,Object> field:base.rows(DefinitionMapper.Table.FIELD,output.currentVersionId())) {
                        if("SCALAR".equals(field.get("node_kind"))&&(!allowed.contains(Objects.toString(field.get("member_name"),""))||!"PERSIST".equals(field.get("audit_disposition")))) throw new IllegalArgumentException("RESOLVER_MEMBERSHIP_ONLY");
                    }
                    dependencies.put(output.id(),output.currentVersionId());
                }
            }
            case "OAUTH_CLIENT" -> {
                if(!truth(d.get("require_pkce_s256"))) throw new IllegalArgumentException("PKCE_S256_REQUIRED");
                if(rows(d,"redirects").isEmpty()||rows(d,"resources").isEmpty()||rows(d,"actions").isEmpty()) throw new IllegalArgumentException("CLIENT_BINDINGS_REQUIRED");
                for(Map<String,Object> redirect:rows(d,"redirects")) {
                    URI uri=URI.create(Objects.toString(redirect.get("redirect_uri"),""));
                    String scheme=uri.getScheme(); boolean nativeClient="PUBLIC_NATIVE".equals(d.get("client_type"));
                    boolean loopback=nativeClient&&"http".equals(scheme)&&Set.of("127.0.0.1","[::1]","::1").contains(uri.getHost());
                    boolean privateScheme=nativeClient&&scheme!=null&&scheme.contains(".")&&!Set.of("javascript","data","file").contains(scheme);
                    if(uri.toString().contains("*")||uri.getFragment()!=null||uri.getUserInfo()!=null||!("https".equals(scheme)&&uri.getHost()!=null||loopback||privateScheme)) throw new IllegalArgumentException("INVALID_REDIRECT_URI");
                    if(truth(redirect.get("native_loopback_port_policy"))&&!loopback) throw new IllegalArgumentException("INVALID_LOOPBACK_POLICY");
                }
            }
            case "MCP_TOOL" -> {
                if(!saved.object().logicalKey().equals(d.get("public_name"))||!saved.object().logicalKey().matches("[A-Za-z0-9_.-]{1,128}")) throw new IllegalArgumentException("INVALID_PUBLIC_TOOL_NAME");
                requireKind(s,d,"workflow_object_id","WORKFLOW"); requireKind(s,d,"security_binding_object_id","SECURITY_BINDING");
                dependencies.putAll(definitions.get().validatePublicContract(s,d.get("workflow_object_id").toString(),
                    d.get("public_input_contract_version_id").toString(),d.get("public_output_contract_version_id").toString(),
                    Objects.toString(d.get("input_mapping_object_id"),null),Objects.toString(d.get("output_mapping_object_id"),null)));
                if(rows(d,"actions").isEmpty()) throw new IllegalArgumentException("TOOL_ACTION_REQUIRED");
                for(Map<String,Object> row:rows(d,"actions")) {
                    Map<String,Object> action=mapper.actions().stream().filter(a->a.get("id").equals(row.get("action_id"))).findFirst().orElseThrow(()->new IllegalArgumentException("ACTION_NOT_FOUND"));
                    String key=action.get("action_key").toString();
                    if(key.startsWith("config.")||key.startsWith("security.")||key.startsWith("client.")||key.startsWith("credential.")||key.startsWith("audit.")) throw new IllegalArgumentException("MANAGEMENT_TOOL_FORBIDDEN");
                    if(!"SERVICE".equals(action.get("target_kind"))) requireKind(s,d,"target_policy_object_id","TARGET_POLICY");
                }
            }
            case "ERROR_MAPPING" -> { new io.gateway.definitions.Definitions.ErrorMapping(rows(d,"rules").stream().map(rule->new io.gateway.definitions.Definitions.ErrorRule((String)rule.get("remote_code"),(String)rule.get("public_code"),((Number)rule.get("status_code")).intValue())).toList()); }
            default -> throw new IllegalArgumentException("UNSUPPORTED_DEFINITION_TYPE");
        }
        return new Validation(id,saved.version().id(),saved.object().generation(),dependencies);
    }
    public Saved apply(String id,String version,long generation,Map<String,String> expected,String actor,String reason) {
        required(reason);
        return store.write(s->{
            Validation actual=validate(s,id,version);
            if(actual.generation()!=generation||!actual.dependencyVersions().equals(expected)) throw new IllegalStateException("STALE_VALIDATION");
            DefinitionMapper base=s.getMapper(DefinitionMapper.class); Head head=head(s,id);
            lockDependencies(s,actual);
            if(base.cas(id,version,generation)!=1) throw new IllegalStateException("STALE_GENERATION");
            base.change(UUID.randomUUID().toString(),id,head.currentVersionId(),version,generation,generation+1,actor,reason,System.currentTimeMillis());
            s.getMapper(ManagementMapper.class).auditMutation(UUID.randomUUID().toString(),"CONFIG_APPLY",System.currentTimeMillis(),actor,"DEFINITION_APPLIED");
            return get(s,id,version);
        });
    }
    public Saved rollback(String id,String version,long generation,String actor,String reason) {
        Validation validation=validate(id,version);
        return apply(id,version,generation,validation.dependencyVersions(),actor,reason);
    }
    void validateEnablement(SqlSession session,Head head) {
        if("MCP_TOOL".equals(head.kind()))lockDependencies(session,validate(session,head.id(),head.currentVersionId()));
    }
    private static void lockDependencies(SqlSession session,Validation validation) {
        DefinitionMapper mapper=session.getMapper(DefinitionMapper.class);
        for(var dependency:new TreeMap<>(validation.dependencyVersions()).entrySet()) {
            if(mapper.lockDependency(dependency.getKey(),dependency.getValue())!=1)throw new IllegalStateException("STALE_DEPENDENCY");
            Head head=mapper.head(dependency.getKey());
            if("CREDENTIAL".equals(head.kind())&&mapper.revoked(dependency.getValue())!=null)throw new IllegalStateException("CREDENTIAL_REVOKED");
        }
    }
    private static void validateReferences(SqlSession s,Map<String,Object> detail,Map<String,String> dependencies) {
        DefinitionMapper base=s.getMapper(DefinitionMapper.class);
        for(var entry:detail.entrySet()) {
            Object value=entry.getValue(); if(value==null) continue;
            if(entry.getKey().endsWith("_object_id")) {
                Head dependency=base.head(value.toString());
                if(dependency==null||!dependency.enabled()||dependency.currentVersionId()==null) throw new IllegalArgumentException("DEPENDENCY_NOT_READY");
                dependencies.put(dependency.id(),dependency.currentVersionId());
            } else if(entry.getKey().endsWith("_contract_version_id")) {
                Version contract=base.version(value.toString());
                if(contract==null||!"CONTRACT".equals(contract.kind())) throw new IllegalArgumentException("CONTRACT_VERSION_REQUIRED");
                Head contractHead=base.head(contract.objectId());
                if(!contractHead.enabled()||contractHead.currentVersionId()==null) throw new IllegalArgumentException("CONTRACT_DISABLED");
                dependencies.put(contractHead.id(),contractHead.currentVersionId());
            } else if(value instanceof List<?> children) {
                for(Object child:children) if(child instanceof Map<?,?> map) {
                    Map<String,Object> row=new LinkedHashMap<>(); map.forEach((k,v)->row.put(k.toString(),v)); validateReferences(s,row,dependencies);
                }
            }
        }
    }
    private static void requireKind(SqlSession s,Map<String,Object> detail,String key,String kind) {
        Object value=detail.get(key); Head head=value==null?null:s.getMapper(DefinitionMapper.class).head(value.toString());
        if(head==null||!kind.equals(head.kind())) throw new IllegalArgumentException("INVALID_DEPENDENCY_KIND");
    }
    @SuppressWarnings("unchecked") private static List<Map<String,Object>> rows(Map<String,Object> detail,String key) { return (List<Map<String,Object>>)detail.getOrDefault(key,List.of()); }
    private static boolean truth(Object value) { return Boolean.TRUE.equals(value)||value instanceof Number n&&n.intValue()==1; }
    private static void required(Object value) { if(value==null||value.toString().isBlank()) throw new IllegalArgumentException("REQUIRED_VALUE_MISSING"); }
}
