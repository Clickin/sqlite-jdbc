package io.gateway.management;

import io.gateway.persistence.PlatformMapper;
import org.apache.ibatis.annotations.*;
import java.util.*;

public interface ManagementMapper extends PlatformMapper {
    enum Table {
        ROLE("role_version","version_id","version_id"),
        ROLE_ACTION("role_action","role_version_id","role_version_id,action_id,action_semantic_version"),
        SECURITY_BINDING("security_binding_version","version_id","version_id,identity_operation_object_id,identity_converter_object_id,authorization_operation_object_id,authorization_converter_object_id,roles_operation_object_id,roles_converter_object_id"),
        EXTERNAL_ROLE("external_role_mapping","security_binding_version_id","security_binding_version_id,external_role_code,role_object_id"),
        TARGET_POLICY("target_policy_version","version_id","version_id,target_kind,canonical_organization,identifier_system,resolver_operation_object_id,resolver_converter_object_id,require_parent_patient"),
        TARGET_ARGUMENT("target_argument_binding","target_policy_version_id","target_policy_version_id,source_port,contract_field_id,target_part,ordinal"),
        OAUTH_CLIENT("oauth_client_version","version_id","version_id,client_type,token_endpoint_auth_method,display_name,require_pkce_s256,refresh_enabled"),
        CLIENT_REDIRECT("oauth_client_redirect","client_version_id","client_version_id,redirect_uri,native_loopback_port_policy,ordinal"),
        CLIENT_SCOPE("oauth_client_scope","client_version_id","client_version_id,scope_id"),
        CLIENT_RESOURCE("oauth_client_resource","client_version_id","client_version_id,resource_id"),
        CLIENT_ACTION("oauth_client_action","client_version_id","client_version_id,action_id,action_semantic_version"),
        MCP_TOOL("mcp_tool_version","version_id","version_id,public_name,description,workflow_object_id,public_input_contract_version_id,public_output_contract_version_id,security_binding_object_id,target_policy_object_id,input_mapping_object_id,output_mapping_object_id,effect_kind"),
        TOOL_SCOPE("mcp_tool_scope","tool_version_id","tool_version_id,scope_id"),
        TOOL_ACTION("mcp_tool_action","tool_version_id","tool_version_id,action_id"),
        ERROR_MAPPING("error_mapping_version","version_id","version_id"),
        ERROR_RULE("error_mapping_rule","error_mapping_version_id","error_mapping_version_id,remote_code,public_code,status_code");
        final String table,parent; final List<String> columns;
        Table(String table,String parent,String columns) { this.table=table; this.parent=parent; this.columns=List.of(columns.split(",")); }
    }
    @SelectProvider(type=Sql.class,method="rows") List<Map<String,Object>> rows(@Param("table")Table table,@Param("id")String id);
    @InsertProvider(type=Sql.class,method="insert") void insert(@Param("table")Table table,@Param("values")Map<String,Object> values);
    final class Sql {
        public static String rows(Map<String,Object> args) {
            Table t=(Table)args.get("table");
            return "SELECT "+String.join(",",t.columns)+" FROM "+t.table+" WHERE "+t.parent+"=#{id}"+(t.columns.contains("ordinal")?" ORDER BY ordinal":"");
        }
        public static String insert(Map<String,Object> args) {
            Table t=(Table)args.get("table"); Map<?,?> values=(Map<?,?>)args.get("values");
            if(!t.columns.containsAll(values.keySet())) throw new IllegalArgumentException("UNSUPPORTED_COLUMN");
            List<String> columns=t.columns.stream().filter(values::containsKey).toList();
            return "INSERT INTO "+t.table+"("+String.join(",",columns)+") VALUES("+String.join(",",columns.stream().map(c->"#{values."+c+"}").toList())+")";
        }
    }
    @Select("SELECT id,action_key,target_kind,effect_kind,semantic_version FROM protected_action ORDER BY action_key") List<Map<String,Object>> actions();
    @Select("SELECT id,scope_name,description FROM oauth_scope ORDER BY scope_name") List<Map<String,Object>> scopes();
    @Select("SELECT scope_id,action_id,action_semantic_version FROM oauth_scope_action ORDER BY scope_id,action_id") List<Map<String,Object>> scopeActions();
    @Select("SELECT id,resource_uri,resource_kind,public_name,active FROM oauth_resource ORDER BY resource_uri") List<Map<String,Object>> resources();
    @Insert("INSERT INTO protected_action(id,action_key,target_kind,effect_kind,semantic_version) VALUES(#{id},#{action_key},#{target_kind},#{effect_kind},#{semantic_version})") void action(Map<String,Object> row);
    @Insert("INSERT INTO oauth_scope(id,scope_name,description) VALUES(#{id},#{scope_name},#{description})") void scope(Map<String,Object> row);
    @Insert("INSERT INTO oauth_scope_action(scope_id,action_id,action_semantic_version) VALUES(#{scope_id},#{action_id},#{action_semantic_version})") void scopeAction(Map<String,Object> row);
    @Insert("INSERT INTO oauth_resource(id,resource_uri,resource_kind,public_name,active) VALUES(#{id},#{resource_uri},#{resource_kind},#{public_name},TRUE)") void resource(Map<String,Object> row);
    @Select("SELECT id,principal_id,client_object_id,resource_id,purpose_code,issued_at,expires_at,revoked_at FROM oauth_grant ORDER BY issued_at DESC LIMIT 200") List<Map<String,Object>> grants();
    @Select("SELECT id,grant_id,client_object_id,principal_id,resource_id,issued_at,expires_at,revoked_at FROM oauth_access_token ORDER BY issued_at DESC LIMIT 200") List<Map<String,Object>> tokens();
    @Update("UPDATE config_object SET enabled=#{enabled},generation=generation+1 WHERE id=#{id} AND generation=#{generation}") int enabled(@Param("id")String id,@Param("generation")long generation,@Param("enabled")boolean enabled);
    @Select("SELECT id,trace_id,workflow_version_id,actor_subject_id,started_at,finished_at,business_outcome,response_outcome,error_code,transport,CASE WHEN finished_at IS NULL THEN 'INCOMPLETE' ELSE 'COMPLETE' END AS completion_state FROM execution ORDER BY started_at DESC LIMIT #{limit} OFFSET #{offset}") List<Map<String,Object>> executions(@Param("limit")int limit,@Param("offset")int offset);
    @Select("SELECT id,trace_id,workflow_version_id,actor_subject_id,started_at,finished_at,business_outcome,response_outcome,error_code,transport,CASE WHEN finished_at IS NULL THEN 'INCOMPLETE' ELSE 'COMPLETE' END AS completion_state FROM execution WHERE id=#{id}") Map<String,Object> execution(String id);
    @Select("SELECT role_or_path,config_version_id FROM execution_dependency WHERE execution_id=#{id} ORDER BY role_or_path") List<Map<String,Object>> dependencies(String id);
    @Select("SELECT id,stage_key,operation_version_id,started_at,finished_at,effect_kind,business_outcome,error_code,CASE WHEN finished_at IS NULL THEN 'INCOMPLETE' ELSE 'COMPLETE' END AS completion_state FROM execution_stage WHERE execution_id=#{id} ORDER BY started_at") List<Map<String,Object>> stages(String id);
    @Select("SELECT id,execution_id,event_type,occurred_at,actor_subject_id,caller_service_id,outcome,reason_code,transport FROM audit_event ORDER BY occurred_at DESC LIMIT #{limit} OFFSET #{offset}") List<Map<String,Object>> audit(@Param("limit")int limit,@Param("offset")int offset);
    @Select("SELECT id,execution_id,event_type,occurred_at,actor_subject_id,caller_service_id,outcome,reason_code,transport FROM audit_event WHERE execution_id=#{id} ORDER BY occurred_at") List<Map<String,Object>> executionAudit(String id);
    @Select("SELECT id,parent_parameter_id,parameter_name,ordinal,port,field_id,value_type,string_value,integer_value,decimal_text,boolean_value,exclusion_reason FROM audit_parameter WHERE audit_event_id=#{id} ORDER BY port,ordinal") List<Map<String,Object>> parameters(String id);
    record AuditTarget(String action,String targetKind,String organization,String identifierSystem,String patientIdentifier,String encounterIdentifier,String documentIdentifier){
        io.gateway.authorization.CanonicalTarget target(){return new io.gateway.authorization.CanonicalTarget(targetKind,organization,identifierSystem,patientIdentifier,encounterIdentifier,documentIdentifier);}
    }
    @Select("""
        SELECT DISTINCT a.action_key AS action,t.target_kind AS targetKind,t.organization,t.identifier_system AS identifierSystem,
          t.patient_identifier AS patientIdentifier,t.encounter_identifier AS encounterIdentifier,t.document_identifier AS documentIdentifier
        FROM audit_event e JOIN execution_target t ON t.execution_id=e.execution_id JOIN protected_action a ON a.id=t.action_id
        WHERE e.id=#{id} AND t.outcome='ALLOW'
        """)
    List<AuditTarget> parameterTargets(String id);
    @Insert("INSERT INTO audit_event(id,event_type,occurred_at,actor_subject_id,caller_service_id,outcome,reason_code,transport) VALUES(#{id},#{event},#{now},#{actor},'console','SUCCEEDED',#{reason},'CONSOLE')") void auditMutation(@Param("id")String id,@Param("event")String event,@Param("now")long now,@Param("actor")String actor,@Param("reason")String reason);
}
