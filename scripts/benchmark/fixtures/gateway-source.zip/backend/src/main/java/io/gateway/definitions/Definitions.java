package io.gateway.definitions;

import java.util.*;
import io.gateway.runtime.Payload.Disposition;

/** Wire DTOs are typed; persistence stores each attribute in its dedicated table. */
public final class Definitions {
    private Definitions() {}
    public enum Kind { DATASOURCE, MAPPER, OPERATION, CONTRACT, REPRESENTATION, CONVERTER, WORKFLOW, CREDENTIAL, ERROR_MAPPING }
    public enum Effect { READ_ONLY, WRITE, UNKNOWN }
    public record Head(String id, String kind, String logicalKey, String currentVersionId, long revisionCounter, long generation, boolean enabled) {}
    public record Version(String id, String objectId, String kind, long revision, long createdAt, String createdBy, String changeReason, String displayName, String description) {}
    public record Draft(String objectId, String logicalKey, String displayName, String description, String reason, Detail detail) {}
    public record Saved(Head object, Version version, Detail detail) {}
    public record Validation(String objectId, String versionId, long generation, Map<String,String> dependencyVersions) { public Validation { dependencyVersions = Map.copyOf(dependencyVersions); } }
    public record ResolvedGraph(String rootObjectId, Map<String,Saved> definitions) {
        public ResolvedGraph { definitions = Map.copyOf(definitions); }
        public Saved require(String id) { Saved d = definitions.get(id); if (d == null) throw new IllegalArgumentException("UNRESOLVED_DEPENDENCY"); return d; }
        public String version(String id) { return require(id).version().id(); }
        public String key() { return definitions.values().stream().map(d -> d.object().id()+":"+d.version().id()).sorted().collect(java.util.stream.Collectors.joining("|",rootObjectId+"|","")); }
    }
    public sealed interface Detail permits JdbcSource, HttpSource, Mapper, JdbcOperation, HttpOperation, Contract, Representation, Converter, Workflow, Credential, ErrorMapping { Kind kind(); }
    public record JdbcSource(String jdbcUrl, String driverProfileId, String credentialObjectId, int poolMinIdle, int poolMaxSize, int acquireTimeoutMs, boolean readOnlyPolicy, int maxConcurrent, int queueTimeoutMs) implements Detail { public Kind kind(){ return Kind.DATASOURCE; } }
    public record Header(String name, String literalValue, String credentialPart) {}
    public record HttpSource(String baseUri, String authenticationKind, String credentialObjectId, String tlsProfileObjectId, String proxyProfileId, String networkPolicyObjectId, int poolMaxTotal, int poolMaxPerRoute, int connectTimeoutMs, String redirectPolicy, int maxConcurrent, int queueTimeoutMs, List<Header> headers) implements Detail { public HttpSource { headers=List.copyOf(headers); } public Kind kind(){return Kind.DATASOURCE;} }
    public record MapperDocument(String resourceName,String xmlText) { @Override public String toString(){return "MapperDocument["+resourceName+"]";} }
    public record Mapper(String databaseProfile,List<MapperDocument> documents,List<String> imports) implements Detail { public Mapper { documents=List.copyOf(documents); imports=List.copyOf(imports); } public Kind kind(){return Kind.MAPPER;} }
    public record OutBinding(String parameterName,String outputFieldId,String resultMapName) {}
    public record ReferenceBinding(String referenceKind,String outputUrlFieldId,String originRecordFieldId,String screenProfileObjectId,String displayName) {}
    public record JdbcOperation(String sourceObjectId,String inputContractObjectId,String outputContractObjectId,Effect effect,int timeoutMs,Integer maxResultRows,Long maxResultBytes,String mapperObjectId,String statementId,String executionMode,String transactionMode,List<OutBinding> outBindings,List<ReferenceBinding> referenceBindings) implements Detail { public JdbcOperation { outBindings=List.copyOf(outBindings); referenceBindings=List.copyOf(referenceBindings); } public Kind kind(){return Kind.OPERATION;} }
    public record Parameter(String location,String wireName,String inputFieldId,String literalScalar,boolean required) {}
    public record ExpectedStatus(int statusCode,String interpretation) {}
    public record HttpOperation(String sourceObjectId,String inputContractObjectId,String outputContractObjectId,Effect effect,int timeoutMs,Integer maxResultRows,Long maxResultBytes,String method,String relativePathTemplate,String requestRepresentationObjectId,String responseRepresentationObjectId,List<Parameter> parameters,List<ExpectedStatus> statuses,List<ReferenceBinding> referenceBindings) implements Detail { public HttpOperation { parameters=List.copyOf(parameters); statuses=List.copyOf(statuses); referenceBindings=List.copyOf(referenceBindings); } public Kind kind(){return Kind.OPERATION;} }
    public record Field(String id,String logicalName,String parentFieldId,String memberName,String nodeKind,String valueType,int ordinal,boolean required,boolean nullable,Integer precision,Integer scale,Integer maxLength,Disposition auditDisposition) {}
    public record Contract(String modelKind,List<Field> fields) implements Detail { public Contract { fields=List.copyOf(fields); } public Kind kind(){return Kind.CONTRACT;} }
    public record XmlBinding(String fieldId,String namespaceUri,String localName,String nodeKind,int ordinal,String nullPolicy) {}
    public record JsonBinding(String fieldId,String memberName,String location) {}
    public record Representation(String contractObjectId,String codecId,String wireProfile,String mediaType,String charset,List<JsonBinding> jsonBindings,List<XmlBinding> xmlBindings) implements Detail { public Representation { jsonBindings=List.copyOf(jsonBindings); xmlBindings=List.copyOf(xmlBindings); } public Kind kind(){return Kind.REPRESENTATION;} }
    public record Argument(String name,String valueType,String stringValue,Long integerValue,String decimalValue,Boolean booleanValue) {}
    public record Rule(String sourcePort,String sourceFieldId,String targetFieldId,String transformCode,List<Argument> arguments) { public Rule { arguments=List.copyOf(arguments); } }
    public record Converter(String implementationId,String inputContractObjectId,String outputContractObjectId,List<Rule> rules) implements Detail { public Converter { rules=List.copyOf(rules); } public Kind kind(){return Kind.CONVERTER;} }
    public record Stage(String stageKey,int stageOrder,String operationObjectId,String converterObjectId) {}
    public record Port(String direction,String representationObjectId,Integer statusCode) {}
    public record SecurityBinding(String stageKey,String securityBindingObjectId,String requiredActionId,String targetPolicyObjectId) {}
    public record Workflow(String errorMappingObjectId,List<Stage> stages,List<Port> ports,List<SecurityBinding> securityBindings) implements Detail { public Workflow { stages=List.copyOf(stages); ports=List.copyOf(ports); securityBindings=List.copyOf(securityBindings); } public Kind kind(){return Kind.WORKFLOW;} }
    /** Credentials are managed by CredentialService, never by the generic definition draft endpoint. */
    public record Credential(String secretKind,String publicUsername) implements Detail { public Kind kind(){return Kind.CREDENTIAL;} }
    public record ErrorRule(String remoteCode,String publicCode,int statusCode) {
        public ErrorRule {if(remoteCode==null||publicCode==null||!remoteCode.matches("[A-Z][A-Z0-9_.-]{0,127}")||!publicCode.matches("[A-Z][A-Z0-9_.-]{0,127}")||statusCode<400||statusCode>599)throw new IllegalArgumentException("INVALID_ERROR_RULE");}
    }
    public record ErrorMapping(List<ErrorRule> rules) implements Detail {
        public ErrorMapping { rules=List.copyOf(rules);if(rules.isEmpty())throw new IllegalArgumentException("ERROR_RULE_REQUIRED"); }
        public Kind kind(){return Kind.ERROR_MAPPING;}
    }
}
