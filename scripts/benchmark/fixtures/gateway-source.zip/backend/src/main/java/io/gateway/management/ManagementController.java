package io.gateway.management;

import io.gateway.GatewayExecutionService;
import io.gateway.mcp.ToolCatalog;
import io.gateway.credentials.CredentialService;
import io.gateway.definitions.DefinitionMapper;
import io.gateway.definitions.Definitions.*;
import io.gateway.definitions.Definitions.Head;
import io.gateway.oauth.OAuthService;
import io.gateway.persistence.PlatformStore;
import io.micronaut.core.annotation.Nullable;
import io.micronaut.http.*;
import io.micronaut.http.annotation.*;
import io.micronaut.scheduling.TaskExecutors;
import io.micronaut.scheduling.annotation.ExecuteOn;
import io.micronaut.serde.annotation.*;
import java.nio.charset.StandardCharsets;
import java.net.URI;
import java.util.*;

@Controller("/management")
@ExecuteOn(TaskExecutors.BLOCKING)
@SerdeImport(CredentialService.Metadata.class)
public final class ManagementController {
    private final PlatformStore store;
    private final SecurityDefinitions definitions;
    private final ManagementAccess access;
    private final GatewayExecutionService executions;
    private final ToolCatalog tools;
    private final CredentialService credentials;
    private final OAuthService oauth;
    private final io.gateway.authorization.AuthorizationService authorization;
    public ManagementController(PlatformStore store,SecurityDefinitions definitions,ManagementAccess access,CredentialService credentials,OAuthService oauth,GatewayExecutionService executions,ToolCatalog tools,io.gateway.authorization.AuthorizationService authorization) {
        this.store=store; this.definitions=definitions; this.access=access; this.credentials=credentials; this.oauth=oauth; this.executions=executions; this.tools=tools;
        this.authorization=authorization;
    }
    @Serdeable public record Apply(String versionId,long generation,Map<String,String> dependencyVersions,String reason) {}
    @Serdeable public record Rollback(String versionId,long expectedGeneration,String reason) {}
    @Serdeable public record VersionSelection(String versionId) {}
    @Serdeable public record Enabled(boolean enabled,long generation,String reason) {}
    @Serdeable public record Secret(String secret) { @Override public String toString(){return "Secret[REDACTED]";} }
    @Serdeable public record CredentialInput(String logicalKey,String secretKind,String publicUsername,String secret,long expectedGeneration,String reason) { @Override public String toString(){return "CredentialInput[REDACTED]";} }
    @Serdeable public record Registration(String kind,Map<String,Object> values,List<Map<String,Object>> actions) {}
    @Serdeable public record Preview(Map<String,Object> arguments) {}
    @Post("/workflows/{logicalKey}/preview") public HttpResponse<?> preview(String logicalKey,@Body Preview body,HttpRequest<?> request) {
        var context=access.authorize(request,"config.manage",true);
        var cancellation=executions.cancellation();
        try(var lifetime=new io.gateway.RequestLifetime(request,cancellation)) {
            return access.mutate(context,()->ok(executions.execute(context.principal(),logicalKey,body.arguments(),"CONSOLE",cancellation)));
        }
    }
    @Get("/tools/{name}/contract") public HttpResponse<?> toolContract(String name,HttpRequest<?> request) {
        access.authorize(request,"security.manage",false);
        return ok(tools.descriptor(tools.tool(name)));
    }

    @Get("/security/definitions") public HttpResponse<?> securityList(HttpRequest<?> request) { gate(request,"security.manage",false); return ok(definitions.list()); }
    @Get("/security/definitions/{id}{?versionId}") public HttpResponse<?> securityGet(String id,@Nullable String versionId,HttpRequest<?> request) { gate(request,actionFor(id),false); return ok(definitions.get(id,versionId)); }
    @Get("/security/definitions/{id}/history") public HttpResponse<?> history(String id,HttpRequest<?> request) { gate(request,actionFor(id),false); return ok(definitions.history(id)); }
    @Post("/security/definitions") public HttpResponse<?> draft(@Body SecurityDefinitions.Draft body,HttpRequest<?> request) { var context=access.authorize(request,actionKind(body.detailType()),true); return access.mutate(context,()->ok(definitions.draft(body,context.principalId()))); }
    @Post("/security/definitions/{id}/validate") public HttpResponse<?> validate(String id,@Body VersionSelection body,HttpRequest<?> request) { gate(request,actionFor(id),true); return ok(definitions.validate(id,body.versionId())); }
    @Post("/security/definitions/{id}/apply") public HttpResponse<?> apply(String id,@Body Apply body,HttpRequest<?> request) { var context=access.authorize(request,actionFor(id),true); return access.mutate(context,()->ok(definitions.apply(id,body.versionId(),body.generation(),body.dependencyVersions(),context.principalId(),body.reason()))); }
    @Post("/security/definitions/{id}/rollback") public HttpResponse<?> rollback(String id,@Body Rollback body,HttpRequest<?> request) { var context=access.authorize(request,actionFor(id),true); return access.mutate(context,()->ok(definitions.rollback(id,body.versionId(),body.expectedGeneration(),context.principalId(),body.reason()))); }
    @Post("/objects/{id}/enabled") public HttpResponse<?> enabled(String id,@Body Enabled body,HttpRequest<?> request) {
        var context=access.definition(request,id,null,null); String actor=context.principalId();
        if(body.reason()==null||body.reason().isBlank()) throw new IllegalArgumentException("CHANGE_REASON_REQUIRED");
        access.mutateDefinition(context,id,null,null,()->store.write(s->{
            DefinitionMapper base=s.getMapper(DefinitionMapper.class); Head head=base.head(id);
            if(head==null||head.currentVersionId()==null) throw new IllegalArgumentException("CURRENT_VERSION_REQUIRED");
            if(body.enabled())definitions.validateEnablement(s,head);
            if(s.getMapper(ManagementMapper.class).enabled(id,body.generation(),body.enabled())!=1) throw new IllegalStateException("STALE_GENERATION");
            base.change(UUID.randomUUID().toString(),id,head.currentVersionId(),head.currentVersionId(),body.generation(),body.generation()+1,actor,body.reason(),System.currentTimeMillis());
            s.getMapper(ManagementMapper.class).auditMutation(UUID.randomUUID().toString(),"CONFIG_EXPOSURE_CHANGED",System.currentTimeMillis(),actor,body.enabled()?"ENABLED":"DISABLED"); return null;
        }));
        return ok(Map.of("enabled",body.enabled()));
    }
    @Get("/security/catalogue") public HttpResponse<?> catalogue(HttpRequest<?> request) {
        gate(request,"security.manage",false);
        return ok(store.read(s->{ ManagementMapper m=s.getMapper(ManagementMapper.class); return Map.of("actions",m.actions(),"scopes",m.scopes(),"scopeActions",m.scopeActions(),"resources",m.resources()); }));
    }
    @Post("/security/catalogue") public HttpResponse<?> register(@Body Registration body,HttpRequest<?> request) {
        var context=access.authorize(request,"security.manage",true); String actor=context.principalId(),id=UUID.randomUUID().toString();
        if(body.values()==null) throw new IllegalArgumentException("REGISTRATION_REQUIRED");
        Map<String,Object> row=new LinkedHashMap<>(body.values()); row.put("id",id);
        Set<String> columns=switch(body.kind()) {
            case "ACTION" -> Set.of("id","action_key","target_kind","effect_kind","semantic_version");
            case "SCOPE" -> Set.of("id","scope_name","description");
            case "RESOURCE" -> Set.of("id","resource_uri","resource_kind","public_name");
            default -> throw new IllegalArgumentException("UNSUPPORTED_CATALOGUE_KIND");
        };
        if(!columns.containsAll(row.keySet())) throw new IllegalArgumentException("UNSUPPORTED_COLUMN");
        if("RESOURCE".equals(body.kind())) { URI uri=URI.create(Objects.toString(row.get("resource_uri"),"")); if(!"https".equals(uri.getScheme())||uri.getHost()==null||uri.getFragment()!=null||uri.getUserInfo()!=null) throw new IllegalArgumentException("HTTPS_RESOURCE_REQUIRED"); }
        access.mutate(context,()->store.write(s->{
            ManagementMapper m=s.getMapper(ManagementMapper.class);
            switch(body.kind()) {
                case "ACTION" -> m.action(row);
                case "RESOURCE" -> m.resource(row);
                case "SCOPE" -> { m.scope(row); for(Map<String,Object> input:Objects.requireNonNullElse(body.actions(),List.<Map<String,Object>>of())) { if(!Set.of("action_id","action_semantic_version").containsAll(input.keySet())) throw new IllegalArgumentException("UNSUPPORTED_COLUMN"); Map<String,Object> child=new LinkedHashMap<>(input); child.put("scope_id",id); m.scopeAction(child); } }
                default -> throw new IllegalArgumentException("UNSUPPORTED_CATALOGUE_KIND");
            }
            m.auditMutation(UUID.randomUUID().toString(),"SECURITY_CATALOGUE_CREATED",System.currentTimeMillis(),actor,body.kind()); return null;
        }));
        return ok(Map.of("id",id));
    }
    @Get("/security/grants") public HttpResponse<?> grants(HttpRequest<?> request) { gate(request,"security.manage",false); return ok(store.read(s->s.getMapper(ManagementMapper.class).grants())); }
    @Get("/security/tokens") public HttpResponse<?> tokens(HttpRequest<?> request) { gate(request,"security.manage",false); return ok(store.read(s->s.getMapper(ManagementMapper.class).tokens())); }
    @Post("/security/grants/{id}/revoke") public HttpResponse<?> revokeGrant(String id,HttpRequest<?> request) { var context=access.authorize(request,"security.manage",true); return access.mutate(context,()->{oauth.revokeGrant(id,context.principalId());return ok(Map.of("revoked",true));}); }
    @Post("/security/tokens/{id}/revoke") public HttpResponse<?> revokeToken(String id,HttpRequest<?> request) { var context=access.authorize(request,"security.manage",true); return access.mutate(context,()->{oauth.revokeTokenRecord(id,context.principalId());return ok(Map.of("revoked",true));}); }
    @Post("/security/clients/{id}/secret") public HttpResponse<?> rotateSecret(String id,@Body Secret body,HttpRequest<?> request) {
        var context=access.authorize(request,"client.manage",true); if(body.secret()==null) throw new IllegalArgumentException("SECRET_REQUIRED");
        char[] value=body.secret().toCharArray(); try { access.mutate(context,()->{oauth.rotateClientSecret(id,value,context.principalId());return null;}); } finally { Arrays.fill(value,'\0'); }
        return ok(Map.of("replaced",true));
    }
    @Get("/credentials") public HttpResponse<?> credentials(HttpRequest<?> request) {
        gate(request,"config.manage",false);
        var heads=store.read(s->s.getMapper(DefinitionMapper.class).heads().stream().filter(h->"CREDENTIAL".equals(h.kind())).toList());
        return ok(heads.stream().map(h->Map.of("object",h,"metadata",credentials.metadata(h.id()))).toList());
    }
    @Post("/credentials") public HttpResponse<?> createCredential(@Body CredentialInput body,HttpRequest<?> request) {
        var context=access.authorize(request,"config.manage",true); if(body.secret()==null) throw new IllegalArgumentException("SECRET_REQUIRED");
        byte[] secret=body.secret().getBytes(StandardCharsets.UTF_8);
        try { return access.mutate(context,()->ok(credentials.create(body.logicalKey(),body.secretKind(),body.publicUsername(),secret,context.principalId(),body.reason()))); } finally { Arrays.fill(secret,(byte)0); }
    }
    @Post("/credentials/{id}") public HttpResponse<?> replaceCredential(String id,@Body CredentialInput body,HttpRequest<?> request) {
        var context=access.definition(request,id,null,null); if(body.secret()==null) throw new IllegalArgumentException("SECRET_REQUIRED");
        byte[] secret=body.secret().getBytes(StandardCharsets.UTF_8);
        try { return access.mutateDefinition(context,id,null,null,()->ok(credentials.replace(id,body.expectedGeneration(),body.secretKind(),body.publicUsername(),secret,context.principalId(),body.reason()))); } finally { Arrays.fill(secret,(byte)0); }
    }
    @Post("/credentials/versions/{id}/revoke") public HttpResponse<?> revokeCredential(String id,HttpRequest<?> request) {
        String object=store.read(s->{var version=s.getMapper(DefinitionMapper.class).version(id);if(version==null)throw new IllegalArgumentException("VERSION_NOT_FOUND");return version.objectId();});
        var context=access.definition(request,object,null,null);
        return access.mutateDefinition(context,object,null,null,()->{credentials.revoke(id,context.principalId());return ok(Map.of("revoked",true));});
    }
    @Get("/executions{?offset}") public HttpResponse<?> executions(@Nullable Integer offset,HttpRequest<?> request) { gate(request,"audit.read",false); return ok(store.read(s->s.getMapper(ManagementMapper.class).executions(100,offset==null?0:Math.max(0,offset)))); }
    @Get("/executions/{id}") public HttpResponse<?> execution(String id,HttpRequest<?> request) {
        gate(request,"audit.read",false); return ok(store.read(s->{ ManagementMapper m=s.getMapper(ManagementMapper.class); Map<String,Object> execution=m.execution(id); if(execution==null) throw new IllegalArgumentException("EXECUTION_NOT_FOUND"); return Map.of("execution",execution,"dependencies",m.dependencies(id),"stages",m.stages(id),"audit",m.executionAudit(id)); }));
    }
    @Get("/audit{?offset}") public HttpResponse<?> audit(@Nullable Integer offset,HttpRequest<?> request) { gate(request,"audit.read",false); return ok(store.read(s->s.getMapper(ManagementMapper.class).audit(100,offset==null?0:Math.max(0,offset)))); }
    @Get("/audit/{id}/parameters") public HttpResponse<?> parameters(String id,HttpRequest<?> request) {
        var management=access.authorize(request,"audit.read",false);
        var targets=store.read(s->s.getMapper(ManagementMapper.class).parameterTargets(id));
        var permissions=new ArrayList<io.gateway.authorization.AuthorizedContext>();
        for(var target:targets)permissions.add(authorization.authorize(management.principal(),target.action(),target.target()));
        return ok(store.read(s->{
            authorization.recheckManagement(s,management,true);
            for(var permission:permissions)authorization.recheckManagement(s,permission,true);
            return s.getMapper(ManagementMapper.class).parameters(id);
        }));
    }
    private String actionFor(String id) { Head head=store.read(s->s.getMapper(DefinitionMapper.class).head(id)); if(head==null) throw new IllegalArgumentException("DEFINITION_NOT_FOUND"); return actionKind(head.kind()); }
    private static String actionKind(String kind) { return "OAUTH_CLIENT".equals(kind)?"client.manage":Set.of("ROLE","TARGET_POLICY","SECURITY_BINDING","MCP_TOOL").contains(kind)?"security.manage":"config.manage"; }
    private void gate(HttpRequest<?> request,String action,boolean mutation) {
        access.authorize(request,action,mutation);
    }
    private static HttpResponse<?> ok(Object value) { return HttpResponse.ok(value).header("Cache-Control","no-store").header("Referrer-Policy","no-referrer"); }
}
