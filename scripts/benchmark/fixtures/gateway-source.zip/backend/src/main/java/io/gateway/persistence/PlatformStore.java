package io.gateway.persistence;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import io.micronaut.context.annotation.Value;
import jakarta.annotation.PreDestroy;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.logging.nologging.NoLoggingImpl;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.LocalCacheScope;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;
import org.flywaydb.core.Flyway;

import java.nio.file.Path;
import java.util.Objects;
import java.util.function.Function;

import java.util.function.BiConsumer;
import java.util.function.Supplier;
@Singleton
public final class PlatformStore implements AutoCloseable {
    private final HikariDataSource reader;
    private final HikariDataSource writer;
    private final SqlSessionFactory reads;
    private final SqlSessionFactory writes;
    private final boolean sqlite;
    private final int busyTimeoutMs;
    private final ThreadLocal<WriteTransaction> transaction = new ThreadLocal<>();
    private final ThreadLocal<Integer> readDepth = ThreadLocal.withInitial(() -> 0);
    private final ThreadLocal<BiConsumer<SqlSession,Boolean>> writeGuard = new ThreadLocal<>();

    @Inject
    public PlatformStore(@Value("${gateway.database.url:}") String url,
                         @Value("${gateway.database.username:}") String username,
                         @Value("${gateway.database.password:}") String password,
                         @Value("${gateway.database.reader-size:8}") int readerSize,
                         @Value("${gateway.database.busy-timeout-ms:5000}") int busyTimeoutMs) {
        if (url == null || url.isBlank()) throw new StoreException("DATABASE_URL_REQUIRED");
        sqlite = url.startsWith("jdbc:sqlite:");
        if ((!sqlite && !url.startsWith("jdbc:postgresql:")) || readerSize < 1 || busyTimeoutMs < 1)
            throw new StoreException("DATABASE_CONFIGURATION_INVALID");
        if (sqlite && (url.contains(":memory:") || url.contains("mode=memory")))
            throw new StoreException("DATABASE_FILE_REQUIRED");
        this.busyTimeoutMs = busyTimeoutMs;
        writer = pool(url, username, password, false, 1);
        HikariDataSource openedReader = null;
        try {
            var migration=Flyway.configure().dataSource(writer)
                .locations("classpath:db/migration/" + (sqlite ? "sqlite" : "postgresql"))
                // An older application must not accept a schema migrated by a newer release.
                .ignoreMigrationPatterns(new String[0])
                .cleanDisabled(true).validateMigrationNaming(true);
            // PostgreSQL session-level migration locking lets Flyway use the single writer connection.
            if(!sqlite)migration.configuration(java.util.Map.of("flyway.postgresql.transactional.lock","false"));
            migration.load().migrate();
            writes = factory(writer);
            openedReader = pool(url, username, password, true, readerSize);
            reads = factory(openedReader);
            reader = openedReader;
            read(session -> null);
            write(session -> null);
        } catch (RuntimeException failure) {
            if (openedReader != null) openedReader.close();
            writer.close();
            throw new StoreException("DATABASE_INITIALIZATION_FAILED");
        }
    }

    /** Isolated file for tests/offline commands. This method never removes the file. */
    public PlatformStore(Path sqliteFile) {
        this("jdbc:sqlite:" + sqliteFile.toAbsolutePath(), "", "", 4, 5000);
    }

    private HikariDataSource pool(String url, String username, String password, boolean readOnly, int size) {
        HikariConfig config = new HikariConfig();
        if(sqlite)config.setJdbcUrl(url);
        else {
            var primary=new org.postgresql.ds.PGSimpleDataSource();
            primary.setURL(url);
            primary.setTargetServerType("primary");
            config.setDataSource(primary);
        }
        if (!username.isEmpty()) config.setUsername(username);
        if (!password.isEmpty()) config.setPassword(password);
        config.setMaximumPoolSize(size);
        config.setMinimumIdle(0);
        config.setAutoCommit(false);
        config.setConnectionTimeout(Math.max(250, busyTimeoutMs));
        config.setPoolName("platform-" + (readOnly ? "read" : "write") + "-" + java.util.UUID.randomUUID());
        if (sqlite) {
            config.addDataSourceProperty("foreign_keys", "true");
            config.addDataSourceProperty("journal_mode", "WAL");
            config.addDataSourceProperty("synchronous", "FULL");
            config.addDataSourceProperty("busy_timeout", Integer.toString(busyTimeoutMs));
            config.setConnectionInitSql("PRAGMA query_only = " + (readOnly ? "ON" : "OFF"));
        } else {
            // Both pools use the same primary URL: current security state never reads a replica.
            config.setReadOnly(readOnly);
            config.setTransactionIsolation(readOnly ? "TRANSACTION_REPEATABLE_READ" : "TRANSACTION_READ_COMMITTED");
        }
        return new HikariDataSource(config);
    }

    private static SqlSessionFactory factory(HikariDataSource source) {
        Configuration configuration = new Configuration(new Environment("platform", new JdbcTransactionFactory(), source));
        configuration.setMapUnderscoreToCamelCase(true);
        configuration.setArgNameBasedConstructorAutoMapping(true);
        configuration.setCacheEnabled(false);
        configuration.setLocalCacheScope(LocalCacheScope.STATEMENT);
        configuration.setLogImpl(NoLoggingImpl.class);
        // Xerial implements getBytes, not ResultSet.getBlob; BYTEA also uses the same binary binding.
        configuration.getTypeHandlerRegistry().register(byte[].class, org.apache.ibatis.type.JdbcType.BLOB,
            new org.apache.ibatis.type.ByteArrayTypeHandler());
        configuration.addMappers("io.gateway", PlatformMapper.class);
        return new SqlSessionFactoryBuilder().build(configuration);
    }

    /** Every invocation opens a new read snapshot, including nested invocations. */
    public <T> T read(Function<SqlSession, T> work) {
        Objects.requireNonNull(work);
        int depth = readDepth.get();
        readDepth.set(depth + 1);
        try (SqlSession session = reads.openSession(false)) {
            verifyConnection(session, true);
            return work.apply(session);
        } catch (PersistenceException failure) {
            throw new StoreException("DATABASE_READ_FAILED");
        } finally {
            if (depth == 0) readDepth.remove(); else readDepth.set(depth);
        }
    }

    /** Lexical, thread-confined guard; validation, encryption and remote I/O stay outside the writer. */
    public <T> T withWriteGuard(BiConsumer<SqlSession,Boolean> guard, Supplier<T> work) {
        if (inTransaction() || writeGuard.get() != null) throw new StoreException("NESTED_WRITE_GUARD");
        writeGuard.set(Objects.requireNonNull(guard));
        try { return work.get(); }
        finally { writeGuard.remove(); }
    }

    /** Nested writes participate in the same transaction and mark it rollback-only on failure. */
    public <T> T write(Function<SqlSession, T> work) {
        Objects.requireNonNull(work);
        if (readDepth.get() > 0) throw new StoreException("READ_TRANSACTION_CANNOT_WRITE");
        WriteTransaction current = transaction.get();
        if (current != null) {
            try { return work.apply(current.session); }
            catch (RuntimeException | Error failure) { current.rollbackOnly = true; throw failure; }
        }
        try (SqlSession session = writes.openSession(false)) {
            verifyConnection(session, false);
            current = new WriteTransaction(session);
            transaction.set(current);
            try {
                // ponytail: PG platform writes are globally serialized, like SQLite. Replace with consistently
                // ordered per-security/family row locks when measured contention warrants it.
                if (sqlite) session.getMapper(PragmaMapper.class).lockSqliteWriter();
                else session.getMapper(PragmaMapper.class).lockWriter();
                var guard = writeGuard.get();
                if (guard != null) guard.accept(session, true);
                T result = work.apply(session);
                if (guard != null) guard.accept(session, false);
                if (current.rollbackOnly) throw new StoreException("TRANSACTION_ROLLBACK_ONLY");
                session.commit(true);
                return result;
            } catch (RuntimeException | Error failure) {
                session.rollback(true);
                throw failure;
            } finally {
                transaction.remove();
            }
        } catch (PersistenceException failure) {
            throw new StoreException("DATABASE_WRITE_FAILED");
        }
    }

    private void verifyConnection(SqlSession session, boolean queryOnly) {
        if (!sqlite) return;
        PragmaMapper mapper = session.getMapper(PragmaMapper.class);
        if (mapper.foreignKeys() != 1 || !"wal".equalsIgnoreCase(mapper.journalMode())
            || mapper.synchronous() != 2 || mapper.busyTimeout() != busyTimeoutMs
            || mapper.queryOnly() != (queryOnly ? 1 : 0))
            throw new StoreException("DATABASE_CONNECTION_POLICY_INVALID");
    }

    public boolean inTransaction() { return transaction.get() != null || readDepth.get() > 0; }
    public boolean sqlite() { return sqlite; }

    @PreDestroy
    @Override public void close() {
        reader.close();
        writer.close();
        transaction.remove();
        readDepth.remove();
    }

    private static final class WriteTransaction {
        final SqlSession session;
        boolean rollbackOnly;
        WriteTransaction(SqlSession session) { this.session = session; }
    }

    public interface PragmaMapper extends PlatformMapper {
        @Select("SELECT 1 FROM pg_advisory_xact_lock(715214871234::bigint)") int lockWriter();
        @org.apache.ibatis.annotations.Update("UPDATE config_object SET generation=generation WHERE 1=0") void lockSqliteWriter();
        @Select("PRAGMA foreign_keys") int foreignKeys();
        @Select("PRAGMA journal_mode") String journalMode();
        @Select("PRAGMA synchronous") int synchronous();
        @Select("PRAGMA busy_timeout") int busyTimeout();
        @Select("PRAGMA query_only") int queryOnly();
    }

    /** Deliberately excludes SQL, bound parameters, driver messages and original causes. */
    public static final class StoreException extends RuntimeException {
        public StoreException(String safeCode) { super(safeCode, null, false, false); }
    }
}
