package io.gateway.oauth;

import io.micronaut.http.*;
import io.micronaut.http.server.exceptions.ExceptionHandler;
import io.micronaut.http.annotation.Produces;
import jakarta.inject.Singleton;
import java.net.URI;
import java.util.Map;

@Produces
@Singleton
public final class OAuthErrorHandler implements ExceptionHandler<OAuthProtocol.Failure,HttpResponse<?>> {
    private final io.gateway.persistence.PlatformStore store;
    public OAuthErrorHandler(io.gateway.persistence.PlatformStore store){this.store=store;}
    public HttpResponse<?> handle(HttpRequest request,OAuthProtocol.Failure error){
        store.write(s->{BrowserSessionService.audit(s.getMapper(OAuthMapper.class),"OAUTH_REJECTED",null,null,null,null,"DENY",error.error(),System.currentTimeMillis(),null);return null;});
        if(error.redirect()!=null)return BrowserController.protectedResponse(HttpResponse.seeOther(URI.create(error.redirect())));
        HttpStatus status=error.error().equals("invalid_client")?HttpStatus.UNAUTHORIZED:error.error().equals("temporarily_unavailable")?HttpStatus.SERVICE_UNAVAILABLE:HttpStatus.BAD_REQUEST;
        MutableHttpResponse<?> response=HttpResponse.status(status).body(Map.of("error",error.error()));
        if(error.error().equals("invalid_client"))response.header("WWW-Authenticate","Basic realm=\"oauth\"");
        return BrowserController.protectedResponse(response);
    }
}
