package io.gateway.definitions;

import io.gateway.persistence.PlatformStore;
import io.gateway.runtime.RuntimeRegistry;
import jakarta.inject.Singleton;
import org.apache.ibatis.session.SqlSession;
import java.util.*;
import static io.gateway.definitions.Definitions.*;

@Singleton
public final class DefinitionRepository {
    private final PlatformStore store;
    private final RuntimeRegistry runtimes;
    private final int maximumCachedRevisions;
    private final LinkedHashMap<String,ImmutableRevision> revisions=new LinkedHashMap<>(32,0.75f,true);
    private record ImmutableRevision(Version version,Detail detail){}
    public DefinitionRepository(PlatformStore store,RuntimeRegistry runtimes,@io.micronaut.context.annotation.Value("${gateway.definitions.maximum-cached-revisions:1024}") int maximumCachedRevisions){if(maximumCachedRevisions<1)throw new IllegalArgumentException("DEFINITION_CACHE_LIMIT");this.store=store;this.runtimes=runtimes;this.maximumCachedRevisions=maximumCachedRevisions;}
    public List<Head> list(){return store.read(s->s.getMapper(DefinitionMapper.class).heads());}
    public List<Version> history(String objectId){return store.read(s->s.getMapper(DefinitionMapper.class).history(objectId));}
    public Saved get(String objectId,String versionId){return store.read(s->load(s.getMapper(DefinitionMapper.class),objectId,versionId,false));}
    public Saved draft(Draft request,String actor){
        Objects.requireNonNull(request.detail());requireText(actor);requireText(request.logicalKey());requireText(request.reason());
        DefinitionValidator.local(request.detail());
        return store.write(s->{DefinitionMapper m=s.getMapper(DefinitionMapper.class);String object=request.objectId()==null?UUID.randomUUID().toString():request.objectId();Head head=m.head(object);
            if(head==null){if(request.objectId()!=null)throw new IllegalArgumentException("UNKNOWN_OBJECT");m.create(object,request.detail().kind().name(),request.logicalKey(),System.currentTimeMillis(),actor);}
            else if(!head.kind().equals(request.detail().kind().name()))throw new IllegalArgumentException("KIND_MISMATCH");
            else if(!head.logicalKey().equals(request.logicalKey()))throw new IllegalArgumentException("LOGICAL_KEY_IMMUTABLE");
            if(m.next(object)!=1)throw new IllegalStateException("REVISION_CONFLICT");head=m.head(object);
            Version version=new Version(UUID.randomUUID().toString(),object,head.kind(),head.revisionCounter(),System.currentTimeMillis(),actor,request.reason(),request.displayName(),request.description());
            m.versionInsert(version);new DefinitionRows(m).save(object,version.id(),request.detail());return new Saved(head,version,request.detail());
        });
    }
    public ResolvedGraph resolve(String rootObjectId){return store.read(s->resolve(s,rootObjectId));}
    /** Caller must keep all metadata queries in this same short, consistent snapshot. */
    public ResolvedGraph resolve(SqlSession session,String rootObjectId){return graph(session.getMapper(DefinitionMapper.class),rootObjectId,Map.of());}
    /** Current authority/resolver closure, including disabled dependencies that could later be enabled. */
    public static Map<String,Head> securityDependencies(SqlSession session) {
        var mapper=session.getMapper(DefinitionMapper.class);
        var security=session.getMapper(io.gateway.management.ManagementMapper.class);
        Map<String,Head> heads=new HashMap<>(), result=new TreeMap<>();
        ArrayDeque<String> pending=new ArrayDeque<>();
        for(Head head:mapper.heads()) {
            heads.put(head.id(),head);
            if(Set.of("SECURITY_BINDING","TARGET_POLICY","ROLE").contains(head.kind()))pending.add(head.id());
        }
        while(!pending.isEmpty()) {
            String id=pending.removeFirst();Head head=heads.get(id);
            if(head==null||result.putIfAbsent(id,head)!=null||head.currentVersionId()==null)continue;
            String version=head.currentVersionId();
            if(Set.of("SECURITY_BINDING","TARGET_POLICY","ROLE").contains(head.kind())) {
                var table=io.gateway.management.ManagementMapper.Table.valueOf(head.kind());
                for(var row:security.rows(table,version))securityReferences(row,pending);
                if("SECURITY_BINDING".equals(head.kind()))for(var row:security.rows(io.gateway.management.ManagementMapper.Table.EXTERNAL_ROLE,version))securityReferences(row,pending);
            } else if(supported(head.kind())) {
                pending.addAll(dependencies(new DefinitionRows(mapper).load(mapper.version(version))).keySet());
            }
        }
        return Map.copyOf(result);
    }
    private static void securityReferences(Map<String,Object> row,Deque<String> pending) {
        row.forEach((key,value)->{if(key.endsWith("_object_id")&&value!=null)pending.add(value.toString());});
    }
    /** Runs again inside the mutation transaction, not merely when choosing the web action. */
    public static String managementAction(SqlSession session,String objectId,String versionId,Detail candidate) {
        var mapper=session.getMapper(DefinitionMapper.class);
        Head head=objectId==null?null:mapper.head(objectId);
        if(head!=null) {
            if("OAUTH_CLIENT".equals(head.kind()))return "client.manage";
            if("MCP_TOOL".equals(head.kind())||securityDependencies(session).containsKey(objectId))return "security.manage";
        }
        Detail selected=candidate;
        if(selected==null&&head!=null&&"WORKFLOW".equals(head.kind())&&versionId!=null)selected=new DefinitionRows(mapper).load(mapper.version(versionId));
        if(selected instanceof Workflow workflow) {
            List<SecurityBinding> previous=head==null||head.currentVersionId()==null?List.of():((Workflow)new DefinitionRows(mapper).load(mapper.version(head.currentVersionId()))).securityBindings();
            if(!new HashSet<>(previous).equals(new HashSet<>(workflow.securityBindings())))return "security.manage";
        }
        return "config.manage";
    }
    private record Checked(Saved candidate,List<ResolvedGraph> graphs,Map<String,String> dependencies) {}
    public Validation validate(String objectId,String versionId){
        Checked checked=store.read(s->check(s,objectId,versionId));
        for(ResolvedGraph g:checked.graphs()){DefinitionValidator.graph(g);runtimes.validate(g);}
        return new Validation(objectId,checked.candidate().version().id(),checked.candidate().object().generation(),checked.dependencies());
    }
    private Checked check(SqlSession session,String objectId,String versionId) {
        var mapper=session.getMapper(DefinitionMapper.class);
        Saved candidate=load(mapper,objectId,versionId,true);Map<String,String> override=Map.of(objectId,candidate.version().id());
        List<ResolvedGraph> graphs=new ArrayList<>();graphs.add(graph(mapper,objectId,override));
        // ponytail: linear scan of metadata at apply time; reverse-edge index if configuration volume warrants it.
        List<Head> heads=mapper.heads();Map<String,Set<String>> edges=new HashMap<>();
        for(Head head:heads)if(head.currentVersionId()!=null&&supported(head.kind()))edges.put(head.id(),dependencies(load(mapper,head.id(),head.currentVersionId(),false).detail()).keySet());
        for(Head head:heads)if(!head.id().equals(objectId)&&head.enabled()&&head.currentVersionId()!=null&&supported(head.kind())&&reaches(head.id(),objectId,edges,new HashSet<>()))graphs.add(graph(mapper,head.id(),override));
        Map<String,String> deps=new TreeMap<>();
        validatePublicContracts(mapper,session.getMapper(io.gateway.mcp.ToolMapper.class),objectId,override,edges,graphs,deps);
        for(ResolvedGraph graph:graphs)for(Saved saved:graph.definitions().values())if(!saved.object().id().equals(objectId))deps.put(saved.object().id(),saved.version().id());
        for(ResolvedGraph graph:graphs)for(Saved saved:graph.definitions().values())externalHeads(mapper,saved.detail(),deps);
        return new Checked(candidate,List.copyOf(graphs),Map.copyOf(deps));
    }
    public Saved apply(Validation submitted,String actor,String reason){
        requireText(actor);requireText(reason);
        Validation actual=validate(submitted.objectId(),submitted.versionId());
        if(!actual.equals(submitted))throw new IllegalStateException("DEFINITION_CONFLICT_REVALIDATE");
        return store.write(s->{DefinitionMapper m=s.getMapper(DefinitionMapper.class);
            Checked current=check(s,actual.objectId(),actual.versionId());
            if(current.candidate().object().generation()!=actual.generation()||!current.dependencies().equals(actual.dependencyVersions()))throw new IllegalStateException("DEFINITION_CONFLICT_REVALIDATE");
            // Row locks prevent another process changing dependencies between the check and commit on PostgreSQL.
            for(var dep:new TreeMap<>(actual.dependencyVersions()).entrySet())if(m.lockDependency(dep.getKey(),dep.getValue())!=1)throw new IllegalStateException("DEPENDENCY_CHANGED_REVALIDATE");
            Saved saved=current.candidate();
            for(var dep:actual.dependencyVersions().entrySet()) {Head h=m.head(dep.getKey());if("CREDENTIAL".equals(h.kind())&&m.revoked(dep.getValue())!=null)throw new IllegalStateException("CREDENTIAL_REVOKED");}
            if(m.cas(actual.objectId(),actual.versionId(),actual.generation())!=1)throw new IllegalStateException("DEFINITION_CONFLICT_REVALIDATE");
            m.change(UUID.randomUUID().toString(),actual.objectId(),saved.object().currentVersionId(),actual.versionId(),actual.generation(),actual.generation()+1,actor,reason,System.currentTimeMillis());
            return new Saved(m.head(actual.objectId()),saved.version(),saved.detail());
        });
    }
    public Saved rollback(String objectId,String versionId,long expectedGeneration,String actor,String reason){Validation v=validate(objectId,versionId);if(v.generation()!=expectedGeneration)throw new IllegalStateException("DEFINITION_CONFLICT_REVALIDATE");return apply(v,actor,reason);}
    private static void requireText(String s){if(s==null||s.isBlank()||s.length()>1024)throw new IllegalArgumentException("REQUIRED_BOUNDED_TEXT");}
    private static boolean supported(String kind){try{Kind.valueOf(kind);return true;}catch(IllegalArgumentException e){return false;}}
    private static boolean reaches(String current,String target,Map<String,Set<String>> edges,Set<String> seen){if(current.equals(target))return true;if(!seen.add(current))return false;for(String dependency:edges.getOrDefault(current,Set.of()))if(reaches(dependency,target,edges,seen))return true;return false;}
    private void validatePublicContracts(DefinitionMapper mapper,io.gateway.mcp.ToolMapper tools,String changed,Map<String,String> override,Map<String,Set<String>> edges,List<ResolvedGraph> graphs,Map<String,String> versions){
        for(var tool:tools.tools()){
            boolean affected=reaches(tool.workflowId(),changed,edges,new HashSet<>())
                ||tool.inputMappingId()!=null&&reaches(tool.inputMappingId(),changed,edges,new HashSet<>())
                ||tool.outputMappingId()!=null&&reaches(tool.outputMappingId(),changed,edges,new HashSet<>());
            if(!affected)continue;
            versions.put(tool.objectId(),tool.versionId());
            validatePublicContract(mapper,tool.workflowId(),tool.inputVersion(),tool.outputVersion(),tool.inputMappingId(),tool.outputMappingId(),override,graphs);
        }
    }
    /** Metadata-only check, safe in the same writer transaction as tool publication or enablement. */
    public Map<String,String> validatePublicContract(SqlSession session,String workflowId,String inputVersion,String outputVersion,String inputMappingId,String outputMappingId) {
        DefinitionMapper mapper=session.getMapper(DefinitionMapper.class);
        List<ResolvedGraph> graphs=new ArrayList<>();
        validatePublicContract(mapper,workflowId,inputVersion,outputVersion,inputMappingId,outputMappingId,Map.of(),graphs);
        Map<String,String> versions=new TreeMap<>();
        for(ResolvedGraph graph:graphs)for(Saved saved:graph.definitions().values()) {
            versions.put(saved.object().id(),saved.version().id());
            externalHeads(mapper,saved.detail(),versions);
        }
        return Map.copyOf(versions);
    }
    private void validatePublicContract(DefinitionMapper mapper,String workflowId,String inputVersion,String outputVersion,String inputMappingId,String outputMappingId,Map<String,String> override,List<ResolvedGraph> graphs) {
        ResolvedGraph workflowGraph=graph(mapper,workflowId,override);graphs.add(workflowGraph);
        if(!(workflowGraph.require(workflowId).detail() instanceof Workflow workflow))throw new IllegalArgumentException("WORKFLOW_REQUIRED");
        List<Stage> stages=workflow.stages().stream().sorted(Comparator.comparingInt(Stage::stageOrder)).toList();
        Detail first=workflowGraph.require(stages.getFirst().operationObjectId()).detail();
        Stage last=stages.getLast();Detail lastDetail=workflowGraph.require(last.operationObjectId()!=null?last.operationObjectId():last.converterObjectId()).detail();
        Contract actualInput=(Contract)workflowGraph.require(DefinitionValidator.input(first)).detail();
        Contract actualOutput=(Contract)workflowGraph.require(DefinitionValidator.output(lastDetail)).detail();
        Contract publicInput=pinnedContract(mapper,inputVersion),publicOutput=pinnedContract(mapper,outputVersion);
        if(inputMappingId==null)compatible(publicInput,actualInput);
        else validatePublicMapping(mapper,inputMappingId,publicInput,actualInput,override,graphs);
        if(outputMappingId==null)compatible(actualOutput,publicOutput);
        else validatePublicMapping(mapper,outputMappingId,actualOutput,publicOutput,override,graphs);
    }
    private void validatePublicMapping(DefinitionMapper mapper,String id,Contract input,Contract output,Map<String,String> override,List<ResolvedGraph> graphs) {
        ResolvedGraph mapping=graph(mapper,id,override);graphs.add(mapping);
        if(!(mapping.require(id).detail() instanceof Converter converter))throw new IllegalArgumentException("CONVERTER_REQUIRED");
        compatible(input,(Contract)mapping.require(converter.inputContractObjectId()).detail());
        compatible((Contract)mapping.require(converter.outputContractObjectId()).detail(),output);
        new io.gateway.convert.ConverterEngine(mapping,converter);
    }
    private Contract pinnedContract(DefinitionMapper mapper,String version){ImmutableRevision pinned=revision(mapper,version);if(!"CONTRACT".equals(pinned.version().kind()))throw new IllegalArgumentException("PINNED_CONTRACT_MISSING");return (Contract)pinned.detail();}
    private record Shape(String name,String kind,String type,int ordinal,boolean required,boolean nullable,Integer precision,Integer scale,Integer maxLength,io.gateway.runtime.Payload.Disposition disposition,List<Shape> children){}
    private static List<Shape> shape(Contract contract,String parent){return contract.fields().stream().filter(f->Objects.equals(f.parentFieldId(),parent)).sorted(Comparator.comparingInt(Field::ordinal)).map(f->new Shape(f.memberName(),f.nodeKind(),f.valueType(),f.ordinal(),f.required(),f.nullable(),f.precision(),f.scale(),f.maxLength(),f.auditDisposition(),shape(contract,f.id()))).toList();}
    private static void compatible(Contract left,Contract right){if(!left.modelKind().equals(right.modelKind())||!shape(left,null).equals(shape(right,null)))throw new IllegalArgumentException("PINNED_PUBLIC_CONTRACT_INCOMPATIBLE");}
    private static void externalHeads(DefinitionMapper mapper,Detail detail,Map<String,String> versions){
        if(detail instanceof Workflow workflow)for(SecurityBinding binding:workflow.securityBindings()){externalHead(mapper,binding.securityBindingObjectId(),"SECURITY_BINDING",versions);externalHead(mapper,binding.targetPolicyObjectId(),"TARGET_POLICY",versions);}
        for(ReferenceBinding binding:DefinitionValidator.references(detail))externalHead(mapper,binding.screenProfileObjectId(),"SCREEN_PROFILE",versions);
    }
    private static void externalHead(DefinitionMapper mapper,String id,String kind,Map<String,String> versions){if(id==null)return;Head head=mapper.head(id);if(head==null||!head.kind().equals(kind)||!head.enabled()||head.currentVersionId()==null)throw new IllegalArgumentException("EXTERNAL_DEPENDENCY_INVALID");versions.put(id,head.currentVersionId());}
    private ImmutableRevision revision(DefinitionMapper mapper,String id){
        if(id==null)throw new IllegalArgumentException("UNPUBLISHED_OR_UNKNOWN_VERSION");
        synchronized(revisions){ImmutableRevision existing=revisions.get(id);if(existing!=null)return existing;}
        Version version=mapper.version(id);if(version==null)throw new IllegalArgumentException("UNPUBLISHED_OR_UNKNOWN_VERSION");
        ImmutableRevision loaded=new ImmutableRevision(version,new DefinitionRows(mapper).load(version));
        synchronized(revisions){ImmutableRevision existing=revisions.get(id);if(existing!=null)return existing;revisions.put(id,loaded);while(revisions.size()>maximumCachedRevisions)revisions.pollFirstEntry();return loaded;}
    }
    private Saved load(DefinitionMapper mapper,String object,String version,boolean active){return load(mapper,mapper.head(object),version,active);}
    private Saved load(DefinitionMapper mapper,Head head,String version,boolean active){
        if(head==null)throw new IllegalArgumentException("UNKNOWN_OBJECT");if(active&&!head.enabled())throw new IllegalStateException("DISABLED_OBJECT");
        ImmutableRevision selected=revision(mapper,version==null?head.currentVersionId():version);Version metadata=selected.version();
        if(!head.id().equals(metadata.objectId())||!head.kind().equals(metadata.kind()))throw new IllegalArgumentException("VERSION_OWNER_MISMATCH");
        if(active&&"CREDENTIAL".equals(head.kind())&&mapper.revoked(metadata.id())!=null)throw new IllegalStateException("CREDENTIAL_REVOKED");
        return new Saved(head,metadata,selected.detail());
    }
    private ResolvedGraph graph(DefinitionMapper mapper,String root,Map<String,String> overrides){
        Map<String,Head> snapshot=new HashMap<>();for(Head head:mapper.heads())snapshot.put(head.id(),head);
        Map<String,Saved> result=new LinkedHashMap<>();visit(mapper,root,overrides,snapshot,result,new HashSet<>());return new ResolvedGraph(root,result);
    }
    private void visit(DefinitionMapper mapper,String id,Map<String,String> overrides,Map<String,Head> snapshot,Map<String,Saved> done,Set<String> visiting){
        if(visiting.contains(id))throw new IllegalArgumentException("DEPENDENCY_CYCLE");if(done.containsKey(id))return;
        visiting.add(id);Saved saved=load(mapper,snapshot.get(id),overrides.get(id),true);
        for(var edge:dependencies(saved.detail()).entrySet()){
            Head target=snapshot.get(edge.getKey());if(target==null||!target.kind().equals(edge.getValue().name()))throw new IllegalArgumentException("DEPENDENCY_KIND_MISMATCH");
            visit(mapper,edge.getKey(),overrides,snapshot,done,visiting);
        }
        visiting.remove(id);done.put(id,saved);
    }
    static Map<String,Kind> dependencies(Detail detail){Map<String,Kind> d=new LinkedHashMap<>();switch(detail){
        case JdbcSource s -> edge(d,s.credentialObjectId(),Kind.CREDENTIAL);
        case HttpSource s -> {edge(d,s.credentialObjectId(),Kind.CREDENTIAL);if(s.tlsProfileObjectId()!=null||s.networkPolicyObjectId()!=null)throw new IllegalArgumentException("UNSUPPORTED_HTTP_PROFILE");}
        case Mapper m -> m.imports().forEach(id->edge(d,id,Kind.MAPPER));
        case JdbcOperation o -> {edge(d,o.sourceObjectId(),Kind.DATASOURCE);edge(d,o.mapperObjectId(),Kind.MAPPER);edge(d,o.inputContractObjectId(),Kind.CONTRACT);edge(d,o.outputContractObjectId(),Kind.CONTRACT);}
        case HttpOperation o -> {edge(d,o.sourceObjectId(),Kind.DATASOURCE);edge(d,o.inputContractObjectId(),Kind.CONTRACT);edge(d,o.outputContractObjectId(),Kind.CONTRACT);edge(d,o.requestRepresentationObjectId(),Kind.REPRESENTATION);edge(d,o.responseRepresentationObjectId(),Kind.REPRESENTATION);}
        case Representation r -> edge(d,r.contractObjectId(),Kind.CONTRACT);
        case Converter c -> {edge(d,c.inputContractObjectId(),Kind.CONTRACT);edge(d,c.outputContractObjectId(),Kind.CONTRACT);}
        case Workflow w -> {edge(d,w.errorMappingObjectId(),Kind.ERROR_MAPPING);w.stages().forEach(s->{edge(d,s.operationObjectId(),Kind.OPERATION);edge(d,s.converterObjectId(),Kind.CONVERTER);});w.ports().forEach(p->edge(d,p.representationObjectId(),Kind.REPRESENTATION));}
        case Contract ignored -> {}
        case Credential ignored -> {}
        case ErrorMapping ignored -> {}
    }return d;}
    private static void edge(Map<String,Kind> edges,String id,Kind kind){if(id!=null){Kind old=edges.putIfAbsent(id,kind);if(old!=null&&old!=kind)throw new IllegalArgumentException("DEPENDENCY_KIND_MISMATCH");}}
}
