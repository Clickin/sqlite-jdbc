package io.gateway.operations;

import io.gateway.audit.AuditService;
import io.gateway.authorization.AuthenticatedPrincipal;
import io.gateway.authorization.AuthorizationService;
import io.gateway.persistence.PlatformStore;
import io.micronaut.serde.annotation.Serdeable;
import io.micronaut.scheduling.annotation.Scheduled;
import jakarta.inject.Singleton;
import java.time.Duration;
import java.util.*;
import static io.gateway.operations.RetentionMapper.Step.*;

@Singleton
public final class RetentionService {
    @Serdeable public record Policy(String dataset,Long retentionDays,boolean cleanupEnabled,Long cleanupInterval,Integer batchLimit,long generation,String versionId) {}
    @Serdeable public record Update(Long retentionDays,boolean cleanupEnabled,Long cleanupInterval,Integer batchLimit,long expectedGeneration) {}
    private final PlatformStore store;
    private final AuthorizationService authorization;
    private final AuditService audit;
    private final Map<String,Long> nextRun=new HashMap<>();
    public RetentionService(PlatformStore store,AuthorizationService authorization,AuditService audit) { this.store=store; this.authorization=authorization; this.audit=audit; }
    public List<Policy> policies() {
        Map<String,Policy> current=new LinkedHashMap<>();
        for(String name:List.of("AUDIT","GENERATED_RESULT")) current.put(name,new Policy(name,null,false,null,null,0,null));
        for(var row:store.read(s->s.getMapper(RetentionMapper.class).policies())) current.put((String)row.get("dataset"),policy(row));
        return List.copyOf(current.values());
    }
    public synchronized Policy update(AuthenticatedPrincipal actor,String dataset,Update update) {
        dataset(dataset);
        if(update==null || update.expectedGeneration()<0 || update.retentionDays()!=null && (update.retentionDays()<1 || update.retentionDays()>365000) || update.cleanupInterval()!=null && (update.cleanupInterval()<1 || update.cleanupInterval()>31536000) || update.batchLimit()!=null && (update.batchLimit()<1 || update.batchLimit()>100) || update.cleanupEnabled() && (update.retentionDays()==null || update.cleanupInterval()==null || update.batchLimit()==null)) throw new IllegalArgumentException("INVALID_RETENTION_POLICY");
        var result=store.write(s->{
            authorization.recheckLocal(s,actor);
            var mapper=s.getMapper(RetentionMapper.class);
            String key="retention."+dataset.toLowerCase(Locale.ROOT);
            var existing=mapper.object(key);
            long generation=existing==null?0:((Number)existing.get("generation")).longValue();
            if(generation!=update.expectedGeneration()) throw new IllegalStateException("RETENTION_REVISION_CONFLICT");
            String object=existing==null?UUID.randomUUID().toString():(String)existing.get("id");
            long now=System.currentTimeMillis();
            if(existing==null) mapper.insertObject(row("id",object,"key",key,"now",now,"actor",actor.subject()));
            String version=UUID.randomUUID().toString();
            mapper.insertVersion(row("id",version,"object",object,"revision",existing==null?1:((Number)existing.get("revision_counter")).longValue()+1,"now",now,"actor",actor.subject(),"dataset",dataset));
            mapper.insertPolicy(row("id",version,"dataset",dataset,"days",update.retentionDays(),"enabled",update.cleanupEnabled(),"interval",update.cleanupInterval(),"limit",update.batchLimit()));
            if(mapper.head(object,version,generation)!=1) throw new IllegalStateException("RETENTION_REVISION_CONFLICT");
            mapper.change(row("id",UUID.randomUUID().toString(),"object",object,"before",existing==null?null:existing.get("current_version_id"),"after",version,"generation",generation,"next",generation+1,"actor",actor.subject(),"now",now));
            audit.record("RETENTION_POLICY_CHANGED",actor.subject(),"SUCCEEDED",dataset);
            return new Policy(dataset,update.retentionDays(),update.cleanupEnabled(),update.cleanupInterval(),update.batchLimit(),generation+1,version);
        });
        nextRun.remove(dataset); return result;
    }
    /** A tick does no deletion for unset/disabled policies; intervals are configured seconds. */
    @Scheduled(fixedDelay="1s",initialDelay="1s") public synchronized void scheduledCleanup() { cleanup(System.currentTimeMillis(),false); }
    public synchronized Map<String,Integer> cleanupNow() { return cleanup(System.currentTimeMillis(),true); }
    Map<String,Integer> cleanup(long now,boolean manual) {
        Map<String,Integer> counts=new LinkedHashMap<>();
        for(var policy:policies()) {
            if(!policy.cleanupEnabled() || policy.retentionDays()==null || !manual && now<nextRun.getOrDefault(policy.dataset(),0L)) { counts.put(policy.dataset(),0); continue; }
            long cutoff=now-Duration.ofDays(policy.retentionDays()).toMillis();
            int removed=remove(RetentionMapper.Dataset.valueOf(policy.dataset()),cutoff,policy.batchLimit(),policy);
            if(policy.dataset().equals("GENERATED_RESULT")) removed+=remove(RetentionMapper.Dataset.REFERENCE,cutoff,policy.batchLimit(),policy);
            counts.put(policy.dataset(),removed);
            nextRun.put(policy.dataset(),now+Duration.ofSeconds(policy.cleanupInterval()).toMillis());
        }
        return counts;
    }
    /** Authentication expiry is independent of audit/result retention; never deletes a live refresh replay chain. */
    @Scheduled(fixedDelay="1m",initialDelay="1m") public void cleanupAuthentication() {
        long now=System.currentTimeMillis();
        for(var dataset:List.of(RetentionMapper.Dataset.ACCESS,RetentionMapper.Dataset.CODE,RetentionMapper.Dataset.REQUEST,RetentionMapper.Dataset.SESSION,RetentionMapper.Dataset.FAMILY,RetentionMapper.Dataset.GRANT)) remove(dataset,now,100,null);
    }
    private int remove(RetentionMapper.Dataset dataset,long cutoff,int limit,Policy policy) {
        int count=0;
        for(int i=0;i<limit;i++) {
            boolean removed=store.write(s->{
                var mapper=s.getMapper(RetentionMapper.class);
                if(policy!=null) {
                    var current=mapper.object("retention."+policy.dataset().toLowerCase(Locale.ROOT));
                    if(current==null || !Objects.equals(policy.versionId(),current.get("current_version_id"))) return false;
                }
                var ids=mapper.candidates(dataset,cutoff,1); if(ids.isEmpty()) return false;
                String id=ids.getFirst();
                var steps=switch(dataset) {
                    case AUDIT -> List.of(AUDIT_PARAMETERS,AUDIT);
                    case GENERATED_RESULT -> List.of(RESULT_HEAD,RESULT_LINKS,RESULT_VALUES,REVISIONS,RESULT_TARGETS,RESULT);
                    case REFERENCE -> List.of(REF_PARAMETERS,WEB,TOOL,REF_TARGETS,REFERENCE);
                    case ACCESS -> List.of(ACCESS_SCOPES,ACCESS);
                    case CODE -> List.of(CODE);
                    case REQUEST -> List.of(REQUEST_SCOPES,REQUEST_RULES,REQUEST);
                    case SESSION -> List.of(SESSION);
                    case FAMILY -> List.of(FAMILY_HEAD,REFRESH_SCOPES,REFRESH,FAMILY);
                    case GRANT -> List.of(GRANT_SCOPES,GRANT_RULES,GRANT);
                };
                for(var step:steps) mapper.step(step,id);
                return true;
            });
            if(!removed) break; count++;
        }
        return count;
    }
    private static Policy policy(Map<String,Object> row) { return new Policy((String)row.get("dataset"),number(row.get("retention_days")),Boolean.TRUE.equals(row.get("cleanup_enabled")) || row.get("cleanup_enabled") instanceof Number n && n.intValue()==1,number(row.get("cleanup_interval")),row.get("batch_limit")==null?null:((Number)row.get("batch_limit")).intValue(),((Number)row.get("generation")).longValue(),(String)row.get("version_id")); }
    private static Long number(Object value) { return value==null?null:((Number)value).longValue(); }
    private static void dataset(String dataset) { if(!Set.of("AUDIT","GENERATED_RESULT").contains(dataset)) throw new IllegalArgumentException("INVALID_RETENTION_DATASET"); }
    private static Map<String,Object> row(Object... pairs) { Map<String,Object> row=new HashMap<>(); for(int i=0;i<pairs.length;i+=2) row.put((String)pairs[i],pairs[i+1]); return row; }
}
