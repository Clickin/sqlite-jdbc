package io.gateway.authorization;

public final class AccessDenied extends RuntimeException {
    public enum Outcome { DENY, PENDING, UNAVAILABLE, UNAUTHENTICATED }
    private final Outcome outcome;
    private final String code;
    private final String decisionId;
    public AccessDenied(Outcome outcome, String code) { this(outcome,code,null); }
    public AccessDenied(Outcome outcome,String code,String decisionId) { super(code);this.outcome=outcome;this.code=code;this.decisionId=decisionId; }
    public String decisionId(){ return decisionId; }
    public Outcome outcome(){ return outcome; }
    public String code(){ return code; }
    public static AccessDenied denied(){ return new AccessDenied(Outcome.DENY,"access_denied"); }
    public static AccessDenied unauthenticated(){ return new AccessDenied(Outcome.UNAUTHENTICATED,"invalid_token"); }
}
