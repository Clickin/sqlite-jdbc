package io.gateway.contracts;

import io.gateway.audit.AuditProjection;
import io.gateway.runtime.Payload;
import java.math.BigDecimal;
import java.util.*;

public final class ContractAudit {
    private ContractAudit() {}
    public static List<AuditProjection.Value> values(ContractService.Contract contract,Payload payload) {
        var tree=new HashMap<String,List<ContractService.Field>>();
        for(var field:contract.fields())tree.computeIfAbsent(field.parentId()==null?"":field.parentId(),_->new ArrayList<>()).add(field);
        Map<String,Object> input=payload.object();
        var result=new ArrayList<AuditProjection.Value>();
        for(var field:tree.getOrDefault("",List.of()))result.add(value(field,tree,input.get(field.name()),input.containsKey(field.name()),"path:/"+pointer(field.name()),payload.dispositions()));
        return List.copyOf(result);
    }
    private static AuditProjection.Value value(ContractService.Field field,Map<String,List<ContractService.Field>> tree,
                                               Object data,boolean present,String path,Map<String,Payload.Disposition> provenance) {
        var disposition=AuditProjection.Disposition.valueOf(field.disposition());
        for(var entry:provenance.entrySet()) {
            if(entry.getKey().equals(field.id())||entry.getKey().equals(path)||path.startsWith(entry.getKey()+"/"))
                disposition=disposition.merge(AuditProjection.Disposition.valueOf(entry.getValue().name()));
        }
        var children=new ArrayList<AuditProjection.Value>();
        AuditProjection.Kind kind;Object scalar=null;
        if(!present)kind=AuditProjection.Kind.MISSING;
        else if(data==null)kind=AuditProjection.Kind.NULL;
        else if(field.nodeKind().equals("OBJECT")) {
            kind=AuditProjection.Kind.OBJECT;
            if(!(data instanceof Map<?,?> map))throw new ContractService.InvalidContract();
            for(var child:tree.getOrDefault(field.id(),List.of()))children.add(value(child,tree,map.get(child.name()),map.containsKey(child.name()),path+"/"+pointer(child.name()),provenance));
        } else if(field.nodeKind().equals("ARRAY")) {
            kind=AuditProjection.Kind.ARRAY;
            if(!(data instanceof List<?> list))throw new ContractService.InvalidContract();
            var element=tree.getOrDefault(field.id(),List.of());
            if(element.size()!=1)throw new ContractService.InvalidContract();
            for(Object elementValue:list)children.add(value(element.getFirst(),tree,elementValue,true,path+"/*",provenance));
        } else {
            kind=switch(field.valueType()) {
                case "INTEGER","LONG"->AuditProjection.Kind.INTEGER;
                case "DECIMAL","NUMBER"->AuditProjection.Kind.DECIMAL;
                case "BOOLEAN"->AuditProjection.Kind.BOOLEAN;
                default->AuditProjection.Kind.STRING;
            };
            scalar=kind==AuditProjection.Kind.DECIMAL && data instanceof Number n?new BigDecimal(n.toString()):data;
            if(field.valueType().equals("BINARY") && data instanceof byte[] bytes)scalar=Base64.getEncoder().encodeToString(bytes);
        }
        return new AuditProjection.Value(field.id(),field.name(),kind,scalar,children,disposition);
    }
    private static String pointer(String name){return name.replace("~","~0").replace("/","~1");}
}
