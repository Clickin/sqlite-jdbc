package io.gateway.oauth;

import io.micronaut.http.*;
import io.micronaut.http.annotation.*;
import java.net.URI;
import java.util.*;
import static io.gateway.oauth.BrowserController.*;

@Controller
public final class OAuthController {
    private final OAuthSettings settings;
    private final OAuthService service;
    private final BrowserSessionService sessions;
    public OAuthController(OAuthSettings settings,OAuthService service,BrowserSessionService sessions){this.settings=settings;this.service=service;this.sessions=sessions;}
    @Get("/.well-known/oauth-authorization-server") public Map<String,Object> metadata(){
        return Map.ofEntries(Map.entry("issuer",settings.issuer),Map.entry("authorization_endpoint",settings.issuer+"/oauth/authorize"),Map.entry("token_endpoint",settings.issuer+"/oauth/token"),Map.entry("revocation_endpoint",settings.issuer+"/oauth/revoke"),Map.entry("response_types_supported",List.of("code")),Map.entry("grant_types_supported",List.of("authorization_code","refresh_token")),Map.entry("token_endpoint_auth_methods_supported",List.of("none","client_secret_basic")),Map.entry("revocation_endpoint_auth_methods_supported",List.of("none","client_secret_basic")),Map.entry("code_challenge_methods_supported",List.of("S256")),Map.entry("authorization_response_iss_parameter_supported",true));
    }
    @Get("/.well-known/oauth-protected-resource/mcp") public Map<String,Object> resourceMetadata(){return Map.of("resource",settings.resource,"authorization_servers",List.of(settings.issuer),"bearer_methods_supported",List.of("header"));}
    @Get("/oauth/authorize") public HttpResponse<?> authorize(HttpRequest<?> request){
        Map<String,List<String>> query=new LinkedHashMap<>();request.getParameters().names().forEach(name->query.put(name,request.getParameters().getAll(name)));
        var session=sessions.session(cookie(request));
        String id=service.begin(query,session.cookie());
        return protectedResponse(HttpResponse.seeOther(URI.create(settings.publicOrigin+"/auth/consent?request_id="+id))).cookie(sessionCookie(session.cookie()));
    }
    @Post(value="/oauth/token",consumes=MediaType.APPLICATION_FORM_URLENCODED) public HttpResponse<?> token(HttpRequest<?> request,@Body String body){return protectedResponse(HttpResponse.ok(service.token(body,authorization(request))));}
    @Post(value="/oauth/revoke",consumes=MediaType.APPLICATION_FORM_URLENCODED) public HttpResponse<?> revoke(HttpRequest<?> request,@Body String body){service.revoke(body,authorization(request));return protectedResponse(HttpResponse.ok());}
    private static String authorization(HttpRequest<?> request){var headers=request.getHeaders().getAll(HttpHeaders.AUTHORIZATION);if(headers.size()>1)throw new OAuthProtocol.Failure("invalid_client");return headers.isEmpty()?null:headers.getFirst();}
}
