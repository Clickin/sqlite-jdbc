package io.gateway.results;

import io.gateway.authorization.CanonicalTarget;
import io.micronaut.serde.annotation.Serdeable;
import java.util.List;
import java.util.Map;

/** Result values are instances of a published contract, never an untyped JSON document. */
public final class ResultModels {
    private ResultModels() {}

    @Serdeable public record ValueInput(String key, String parentKey, String fieldId, int ordinal,
            String valueType, String textValue, Long integerValue, String decimalText, Boolean booleanValue) {}
    @Serdeable public record ReferenceInput(String referenceId, String valueKey, int ordinal) {}
    @Serdeable public record CreateResult(String executionId, String outputContractVersionId,
            String externalGenerationId, String submittedModel, List<ValueInput> values, List<ReferenceInput> references) {}
    @Serdeable public record ReviseResult(String expectedRevisionId, CreateResult content) {}
    @Serdeable public record StoredValue(String id, String parentValueId, String fieldId, int ordinal,
            String nodeKind, String valueType, String textValue, Long integerValue, String decimalText, Boolean booleanValue) {}
    @Serdeable public record StoredReference(String referenceId, String resultValueId, int ordinal) {}
    @Serdeable public record ResultDocument(String id, String revisionId, int revision,
            String outputContractVersionId, String sourceExecutionId, String externalGenerationId, String submittedModel,
            List<CanonicalTarget> targets, List<StoredValue> values, List<StoredReference> references, Object data) {}
    @Serdeable public record ResultSummary(String id, String revisionId, int revision) {}
    public record WebObservation(String url, String displayName, String originRecordId) {}
    public record ToolObservation(String operationObjectId, String observedOperationVersionId,
            String observedDatasourceVersionId, String screenProfileObjectId, String observedScreenProfileVersionId,
            String originRecordId, List<io.gateway.audit.AuditProjection.Value> originalParameters,
            List<io.gateway.audit.AuditProjection.Value> effectiveParameters) {}
    @Serdeable public record ResolvedReference(String id, String kind, String directUrl, String displayName,
            String adapterId, String screenCode, String launchProfile, Map<String,Object> parameters,
            String supportStatus) {}
}
