package io.gateway.credentials;

import io.gateway.persistence.PlatformMapper;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface CredentialMapper extends PlatformMapper {
    String ROW = """
        SELECT o.id AS object_id,o.logical_key,o.revision_counter,o.generation,o.enabled,
            v.id AS version_id,v.revision,d.secret_kind,d.public_username,c.key_id,c.nonce,c.ciphertext,
            c.authentication_tag,c.cipher_generation,s.revoked_at
        FROM config_object o JOIN config_version v ON v.object_id=o.id
        JOIN credential_version d ON d.version_id=v.id
        JOIN credential_cipher c ON c.credential_version_id=v.id
        JOIN credential_state s ON s.credential_version_id=v.id
        """;

    record Row(String objectId, String logicalKey, long revisionCounter, long generation, boolean enabled,
               String versionId, long revision, String secretKind, String publicUsername, String keyId,
               byte[] nonce, byte[] ciphertext, byte[] authenticationTag, long cipherGeneration, Long revokedAt) {
        @Override public String toString() { return "CredentialRow[redacted]"; }
    }

    @Select(ROW + " WHERE o.id=#{objectId} AND v.id=o.current_version_id") Row current(String objectId);
    @Select(ROW + " WHERE v.id=#{versionId}") Row versionRow(String versionId);
    record Head(String logicalKey, long revisionCounter, long generation, String versionId) {}
    @Select("""
        SELECT logical_key,revision_counter,generation,current_version_id AS version_id
        FROM config_object WHERE id=#{objectId} AND kind='CREDENTIAL'
        """)
    Head head(String objectId);
    @Select("""
        SELECT o.id AS object_id,v.id AS version_id,v.revision,o.generation,
            d.secret_kind,d.public_username,c.key_id,s.revoked_at
        FROM config_object o JOIN config_version v ON v.id=o.current_version_id
        JOIN credential_version d ON d.version_id=v.id
        JOIN credential_cipher c ON c.credential_version_id=v.id
        JOIN credential_state s ON s.credential_version_id=v.id WHERE o.id=#{objectId}
        """)
    CredentialService.Metadata metadata(String objectId);
    @Select("SELECT count(*) FROM credential_version WHERE version_id=#{versionId}")
    int exists(String versionId);
    @Select("""
        SELECT count(*) FROM config_version v
        JOIN config_object o ON o.id=v.object_id
        JOIN credential_state s ON s.credential_version_id=v.id
        JOIN credential_cipher c ON c.credential_version_id=v.id
        WHERE v.id=#{versionId} AND v.kind='CREDENTIAL' AND o.enabled=TRUE AND s.revoked_at IS NULL
        """)
    int available(String versionId);

    @Insert("""
        INSERT INTO config_object(id,kind,logical_key,revision_counter,generation,enabled,created_at,created_by)
        VALUES(#{id},'CREDENTIAL',#{key},1,0,TRUE,#{now},#{actor})
        """)
    void createObject(@Param("id") String id, @Param("key") String key, @Param("now") long now, @Param("actor") String actor);

    @Update("""
        UPDATE config_object SET revision_counter=revision_counter+1
        WHERE id=#{id} AND kind='CREDENTIAL' AND generation=#{generation} AND revision_counter=#{counter}
        """)
    int increment(@Param("id") String id, @Param("generation") long generation, @Param("counter") long counter);

    @Insert("""
        INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name)
        VALUES(#{id},#{objectId},'CREDENTIAL',#{revision},#{now},#{actor},#{reason},#{name})
        """)
    void version(@Param("id") String id, @Param("objectId") String objectId, @Param("revision") long revision,
                 @Param("now") long now, @Param("actor") String actor, @Param("reason") String reason, @Param("name") String name);

    @Insert("INSERT INTO credential_version(version_id,secret_kind,public_username) VALUES(#{id},#{kind},#{username})")
    void detail(@Param("id") String id, @Param("kind") String kind, @Param("username") String username);

    @Insert("""
        INSERT INTO credential_cipher(credential_version_id,key_id,nonce,ciphertext,authentication_tag,cipher_generation,encrypted_at)
        VALUES(#{id},#{keyId},#{nonce},#{ciphertext},#{tag},1,#{now})
        """)
    void cipher(@Param("id") String id, @Param("keyId") String keyId, @Param("nonce") byte[] nonce,
                @Param("ciphertext") byte[] ciphertext, @Param("tag") byte[] tag, @Param("now") long now);

    @Insert("INSERT INTO credential_state(credential_version_id) VALUES(#{id})") void state(String id);

    @Update("""
        UPDATE config_object SET current_version_id=#{versionId},generation=generation+1
        WHERE id=#{objectId} AND kind='CREDENTIAL' AND generation=#{generation}
        """)
    int apply(@Param("objectId") String objectId, @Param("versionId") String versionId, @Param("generation") long generation);

    @Insert("""
        INSERT INTO configuration_change(id,object_id,before_version_id,after_version_id,before_generation,after_generation,
            actor_subject_id,reason,changed_at)
        VALUES(#{id},#{objectId},#{before},#{after},#{beforeGeneration},#{afterGeneration},#{actor},#{reason},#{now})
        """)
    void change(@Param("id") String id, @Param("objectId") String objectId, @Param("before") String before,
                @Param("after") String after, @Param("beforeGeneration") long beforeGeneration,
                @Param("afterGeneration") long afterGeneration, @Param("actor") String actor,
                @Param("reason") String reason, @Param("now") long now);

    @Update("""
        UPDATE credential_state SET revoked_at=#{now},revoked_by=#{actor}
        WHERE credential_version_id=#{id} AND revoked_at IS NULL
        """)
    int revoke(@Param("id") String id, @Param("now") long now, @Param("actor") String actor);

    @Update("""
        UPDATE credential_cipher SET key_id=#{keyId},nonce=#{nonce},ciphertext=#{ciphertext},authentication_tag=#{tag},
            cipher_generation=cipher_generation+1,encrypted_at=#{now}
        WHERE credential_version_id=#{id} AND cipher_generation=#{generation}
            AND EXISTS (SELECT 1 FROM credential_state s JOIN config_version v ON v.id=s.credential_version_id
                JOIN config_object o ON o.id=v.object_id
                WHERE s.credential_version_id=#{id} AND s.revoked_at IS NULL AND o.enabled=TRUE)
        """)
    int reencrypt(@Param("id") String id, @Param("generation") long generation, @Param("keyId") String keyId,
                  @Param("nonce") byte[] nonce, @Param("ciphertext") byte[] ciphertext, @Param("tag") byte[] tag,
                  @Param("now") long now);
}
