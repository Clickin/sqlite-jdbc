package io.gateway.authorization;

import io.gateway.oauth.BrowserController;
import io.micronaut.http.annotation.Produces;
import io.micronaut.http.*;
import io.micronaut.http.server.exceptions.ExceptionHandler;
import jakarta.inject.Singleton;
import java.util.Map;

@Produces
@Singleton
public final class AccessDeniedHandler implements ExceptionHandler<AccessDenied,HttpResponse<?>> {
    public HttpResponse<?> handle(HttpRequest request,AccessDenied error){
        HttpStatus status=switch(error.outcome()){case UNAUTHENTICATED->HttpStatus.UNAUTHORIZED;case UNAVAILABLE->HttpStatus.SERVICE_UNAVAILABLE;case DENY,PENDING->HttpStatus.FORBIDDEN;};
        return BrowserController.protectedResponse(HttpResponse.status(status).body(Map.of("error",error.code(),"outcome",error.outcome().name())));
    }
}
