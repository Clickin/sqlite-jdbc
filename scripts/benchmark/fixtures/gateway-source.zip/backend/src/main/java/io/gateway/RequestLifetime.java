package io.gateway;

import io.gateway.runtime.Cancellation;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.server.netty.NettyHttpRequest;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;

/** Pinned Netty adapter: only cancellation notification runs on its event loop, never JDBC. */
public final class RequestLifetime implements AutoCloseable {
    private final ChannelFuture closed;
    private final ChannelFutureListener listener;
    public RequestLifetime(HttpRequest<?> request,Cancellation cancellation) {
        if(!(request instanceof NettyHttpRequest<?> netty))throw new IllegalStateException("NETTY_REQUEST_REQUIRED");
        closed=netty.getChannelHandlerContext().channel().closeFuture();
        listener=_ -> cancellation.cancel();
        closed.addListener(listener);
    }
    @Override public void close(){closed.removeListener(listener);}
}
