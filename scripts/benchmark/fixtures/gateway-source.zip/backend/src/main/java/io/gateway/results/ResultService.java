package io.gateway.results;

import io.gateway.audit.AuditProjection;
import io.gateway.audit.AuditService;
import io.gateway.authorization.*;
import io.gateway.contracts.ContractService;
import io.gateway.persistence.PlatformStore;
import io.gateway.results.ResultModels.*;
import io.micronaut.context.annotation.Value;
import jakarta.inject.Singleton;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Pattern;

@Singleton
public final class ResultService {
    private static final Pattern QUERY_KEY_SEPARATORS=Pattern.compile("[^a-z0-9]");
    private static final Set<String> SECRET_QUERY_KEYS=Set.of(
            "token","accesstoken","refreshtoken","idtoken","authtoken","oauthtoken","oauthtokensecret",
            "secret","clientsecret","clientassertion","assertion","password","passwd","pwd",
            "authorization","authentication","auth","bearer","credential","credentials",
            "apikey","xapikey","key","accesskey","accesskeyid","secretaccesskey","secretkey","privatekey",
            "code","authcode","state","signature","sig","hmac","jwt","securitytoken","samlresponse","samlrequest",
            "session","sessionid","sessiontoken","cookie","setcookie",
            "xamzsignature","xamzcredential","xamzsecuritytoken","xgoogsignature","xgoogcredential");
    private final PlatformStore store;
    private final AuthorizationService authorization;
    private final ContractService contracts;
    private final AuditService audit;
    private final Set<String> webOrigins, queryParameters;

    public ResultService(PlatformStore store, AuthorizationService authorization, ContractService contracts, AuditService audit,
            @Value("${gateway.references.web-origins:}") String webOrigins,
            @Value("${gateway.references.web-query-parameters:}") String queryParameters) {
        this.store=store; this.authorization=authorization; this.contracts=contracts; this.audit=audit;
        this.webOrigins=csv(webOrigins); this.queryParameters=csv(queryParameters);
        for (String origin : this.webOrigins) if (!origin.equals(origin(URI.create(origin)))) throw new IllegalArgumentException("INVALID_REFERENCE_ORIGIN");
    }
    public ResultDocument create(AuthenticatedPrincipal principal, CreateResult request) { return save(principal, null, null, request); }
    public ResultDocument revise(AuthenticatedPrincipal principal, String id, ReviseResult request) {
        if (request == null || request.expectedRevisionId() == null) throw invalid();
        return save(principal,id,request.expectedRevisionId(),request.content());
    }
    private ResultDocument save(AuthenticatedPrincipal principal, String existingId, String expectedRevision, CreateResult request) {
        if (request == null || request.executionId() == null || request.references() == null || request.references().size()>1000) throw invalid();
        var contract=contracts.load(request.outputContractVersionId());
        var prepared=ResultValues.prepare(request.values(),contract);
        contracts.validate(contract,prepared.data());
        Set<CanonicalTarget> targets=new LinkedHashSet<>(executionTargets(principal,request.executionId(),true));
        Set<String> references=new LinkedHashSet<>();
        Set<Integer> referenceOrdinals=new HashSet<>();
        for (var reference : request.references()) {
            if (reference == null || reference.ordinal()<0 || !referenceOrdinals.add(reference.ordinal()) || (reference.valueKey()!=null && !prepared.ids().containsKey(reference.valueKey()))) throw invalid();
            referenceOwner(principal,reference.referenceId());
            targets.addAll(store.read(s->s.getMapper(ResultMapper.class).referenceTargets(reference.referenceId())));
            references.add(reference.referenceId());
        }
        if (existingId != null) {
            resultOwner(principal,existingId);
            targets.addAll(store.read(s->s.getMapper(ResultMapper.class).resultTargets(existingId)));
        }
        check(principal,"result.create",targets);
        for (String reference : references) check(principal,"reference.read",store.read(s->s.getMapper(ResultMapper.class).referenceTargets(reference)));
        String resultId=existingId==null?UUID.randomUUID().toString():existingId;
        String revisionId=UUID.randomUUID().toString();
        int revision=store.write(s->{
            authorization.recheckLocal(s,principal);
            var mapper=s.getMapper(ResultMapper.class);
            owned(mapper.execution(request.executionId()),principal,"principal_id","client_object_id");
            for (String reference : references) owned(mapper.reference(reference),principal,"owner_principal_id","owner_client_object_id");
            int before=0;
            List<CanonicalTarget> oldTargets=List.of();
            if (existingId==null) mapper.insertResult(row("id",resultId,"principal",principal.principalId(),"client",principal.clientId(),"grant",principal.grantId()));
            else {
                var previous=mapper.result(resultId); owned(previous,principal,"owner_principal_id","owner_client_object_id");
                if (!Objects.equals(expectedRevision,previous.get("current_revision_id"))) throw new IllegalStateException("RESULT_REVISION_CONFLICT");
                before=((Number)previous.get("revision_counter")).intValue(); oldTargets=mapper.resultTargets(resultId);
            }
            mapper.insertRevision(row("id",revisionId,"result",resultId,"revision",before+1,"contract",request.outputContractVersionId(),"generation",request.externalGenerationId(),"model",request.submittedModel(),"execution",request.executionId(),"now",System.currentTimeMillis()));
            for (var value : prepared.values()) mapper.insertValue(revisionId,value);
            for (var reference : request.references()) mapper.link(revisionId,reference.valueKey()==null?null:prepared.ids().get(reference.valueKey()),reference.referenceId(),reference.ordinal());
            String action=mapper.action("result.create");
            for (var target : targets) if (!oldTargets.contains(target)) mapper.resultTarget(resultId,action,target);
            if (mapper.head(resultId,revisionId,before)!=1) throw new IllegalStateException("RESULT_REVISION_CONFLICT");
            audit(principal,request.executionId(),"RESULT_SAVED","result.create");
            return before+1;
        });
        return new ResultDocument(resultId,revisionId,revision,request.outputContractVersionId(),request.executionId(),request.externalGenerationId(),request.submittedModel(),List.copyOf(targets),prepared.values(),request.references().stream().map(r->new StoredReference(r.referenceId(),r.valueKey()==null?null:prepared.ids().get(r.valueKey()),r.ordinal())).toList(),prepared.data());
    }
    public List<ResultSummary> list(AuthenticatedPrincipal principal) {
        List<ResultSummary> result=new ArrayList<>();
        for (var item : store.read(s->s.getMapper(ResultMapper.class).list(principal.principalId(),principal.clientId()))) {
            try { check(principal,"result.read",store.read(s->s.getMapper(ResultMapper.class).resultTargets(item.id()))); result.add(item); }
            catch (AccessDenied denied) { /* Only currently authorized objects are discoverable. */ }
        }
        return List.copyOf(result);
    }
    public ResultDocument read(AuthenticatedPrincipal principal, String id) {
        var owner=resultOwner(principal,id);
        var targets=store.read(s->s.getMapper(ResultMapper.class).resultTargets(id));
        check(principal,"result.read",targets);
        String revisionId=(String)owner.get("current_revision_id");
        var revision=store.read(s->s.getMapper(ResultMapper.class).revision(revisionId));
        if (revision==null) throw denied();
        var values=store.read(s->s.getMapper(ResultMapper.class).values(revisionId));
        var references=store.read(s->s.getMapper(ResultMapper.class).references(revisionId));
        var contract=contracts.load((String)revision.get("output_contract_version_id"));
        store.write(s->{ authorization.recheckLocal(s,principal); audit(principal,(String)revision.get("source_execution_id"),"RESULT_READ","result.read"); return null; });
        return new ResultDocument(id,revisionId,((Number)revision.get("revision")).intValue(),contract.version(),(String)revision.get("source_execution_id"),(String)revision.get("external_generation_id"),(String)revision.get("submitted_model"),targets,values,references,ResultValues.assemble(values,contract));
    }
    /** Called only by the server's observed execution path, never from a public request DTO. */
    public String recordWebReference(AuthenticatedPrincipal principal, String executionId, WebObservation observation) {
        validateWebReferenceCandidate(observation.url());
        if (observation.displayName()==null || observation.displayName().isBlank()) throw invalid();
        var targets=executionTargets(principal,executionId,false);
        check(principal,"reference.read",targets);
        return store.write(s->{
            authorization.recheckLocal(s,principal);
            var mapper=s.getMapper(ResultMapper.class);
            String id=insertReference(mapper,principal,executionId,"WEB_LINK",targets);
            mapper.insertWeb(id,observation); audit(principal,executionId,"REFERENCE_RECORDED","reference.read"); return id;
        });
    }
    /** Original and effective values are projected independently; omitted values cannot become launch arguments. */
    public String recordToolReference(AuthenticatedPrincipal principal, String executionId, ToolObservation observation) {
        var targets=executionTargets(principal,executionId,false);
        check(principal,"reference.read",targets);
        List<AuditProjection.Parameter> parameters=new ArrayList<>();
        parameters.addAll(AuditProjection.project("ORIGINAL",observation.originalParameters()));
        parameters.addAll(AuditProjection.project("EFFECTIVE",observation.effectiveParameters()));
        return store.write(s->{
            authorization.recheckLocal(s,principal);
            var mapper=s.getMapper(ResultMapper.class);
            if (mapper.observed(executionId,observation.observedOperationVersionId())==0 || mapper.observed(executionId,observation.observedDatasourceVersionId())==0 || mapper.versionOwner(observation.observedOperationVersionId(),observation.operationObjectId())!=1 || mapper.versionOwner(observation.observedDatasourceVersionId(),mapper.datasource(observation.observedOperationVersionId()))!=1) throw denied();
            var profile=observation.observedScreenProfileVersionId()==null
                    ? mapper.screen(observation.screenProfileObjectId())
                    : mapper.screenVersion(observation.screenProfileObjectId(),observation.observedScreenProfileVersionId());
            if (profile==null || !truth(profile.get("enabled"))) throw denied();
            String id=insertReference(mapper,principal,executionId,"TOOL_REFERENCE",targets);
            mapper.insertTool(id,observation,(String)profile.get("version_id"));
            for (var p : parameters) mapper.insertParameter(row("id",p.id(),"reference",id,"parent",p.parentParameterId(),"name",p.parameterName(),"ordinal",p.ordinal(),"port",p.port(),"field",p.fieldId(),"type",p.valueType(),"text",p.stringValue(),"integer",p.integerValue(),"decimal",p.decimalText(),"boolean",p.booleanValue(),"exclusion",p.exclusionReason()));
            audit(principal,executionId,"REFERENCE_RECORDED","reference.read"); return id;
        });
    }
    public ResolvedReference resolve(AuthenticatedPrincipal principal, String id) {
        var reference=referenceOwner(principal,id);
        check(principal,"reference.resolve",store.read(s->s.getMapper(ResultMapper.class).referenceTargets(id)));
        String execution=(String)reference.get("source_execution_id");
        if (store.read(s->s.getMapper(ResultMapper.class).disabledDependencies(execution))!=0) throw denied();
        ResolvedReference resolved;
        if ("WEB_LINK".equals(reference.get("reference_kind"))) {
            var web=store.read(s->s.getMapper(ResultMapper.class).web(id));
            validateWebReferenceCandidate((String)web.get("original_url"));
            resolved=new ResolvedReference(id,"WEB_LINK",(String)web.get("original_url"),(String)web.get("display_name"),null,null,null,Map.of(),"DIRECT_LINK");
        } else {
            var tool=store.read(s->s.getMapper(ResultMapper.class).tool(id));
            var profile=store.read(s->s.getMapper(ResultMapper.class).screenVersion((String)tool.get("screen_profile_object_id"),(String)tool.get("observed_screen_profile_version_id")));
            if (profile==null || !truth(profile.get("enabled"))) throw denied();
            for (String field : List.of("adapter_id","screen_code","allowed_launch_profile")) if (!(profile.get(field) instanceof String value) || !value.matches("[A-Za-z0-9_.:-]{1,128}")) throw invalid();
            var parameters=store.read(s->s.getMapper(ResultMapper.class).parameters(id));
            var bindings=store.read(s->s.getMapper(ResultMapper.class).bindings((String)profile.get("version_id")));
            Map<String,Object> launch=new LinkedHashMap<>();
            for (var binding : bindings) {
                String name=(String)binding.get("tool_parameter_name");
                String port="EFFECTIVE";
                if (name.startsWith("original.")) { port="ORIGINAL"; name=name.substring(9); }
                else if (name.startsWith("effective.")) name=name.substring(10);
                Map<String,Object> found=null;
                for (var p : parameters) if (port.equals(p.get("port")) && name.equals(p.get("parameter_name")) && p.get("parent_parameter_id")==null) { if(found!=null) throw invalid(); found=p; }
                if (found==null || !Objects.equals(binding.get("value_type"),found.get("value_type")) || found.get("exclusion_reason")!=null) throw new IllegalStateException("REFERENCE_NOT_REPRODUCIBLE");
                String screenName=(String)binding.get("screen_parameter_name");
                if (screenName==null || !screenName.matches("[A-Za-z][A-Za-z0-9_]{0,127}") || launch.containsKey(screenName)) throw invalid();
                Object value=switch ((String)found.get("value_type")) {
                    case "STRING" -> found.get("string_value"); case "INTEGER" -> found.get("integer_value");
                    case "DECIMAL" -> found.get("decimal_text"); case "BOOLEAN" -> truth(found.get("boolean_value"));
                    case "NULL" -> null; default -> throw new IllegalStateException("REFERENCE_NOT_REPRODUCIBLE");
                };
                launch.put(screenName,value);
            }
            // No protocol is invented: this metadata cannot execute a command or replay the original operation.
            resolved=new ResolvedReference(id,"TOOL_REFERENCE",null,null,(String)profile.get("adapter_id"),(String)profile.get("screen_code"),(String)profile.get("allowed_launch_profile"),Collections.unmodifiableMap(launch),"METADATA_ONLY");
        }
        store.write(s->{ authorization.recheckLocal(s,principal); audit(principal,execution,"REFERENCE_METADATA_READ","reference.resolve"); return null; });
        return resolved;
    }
    private String insertReference(ResultMapper mapper, AuthenticatedPrincipal principal, String execution, String kind, Collection<CanonicalTarget> targets) {
        owned(mapper.execution(execution),principal,"principal_id","client_object_id");
        String id=UUID.randomUUID().toString();
        mapper.insertReference(row("id",id,"kind",kind,"principal",principal.principalId(),"client",principal.clientId(),"grant",principal.grantId(),"execution",execution,"now",System.currentTimeMillis()));
        String action=mapper.action("reference.read");
        for (var target : targets) mapper.referenceTarget(id,action,target);
        return id;
    }
    private List<CanonicalTarget> executionTargets(AuthenticatedPrincipal principal, String id, boolean completed) {
        return store.read(s->{ var mapper=s.getMapper(ResultMapper.class); var execution=mapper.execution(id); owned(execution,principal,"principal_id","client_object_id");
            if (completed && (!"SUCCEEDED".equals(execution.get("business_outcome")) || execution.get("finished_at")==null)) throw denied();
            var targets=mapper.executionTargets(id); if(targets.isEmpty()) throw denied(); return targets; });
    }
    private Map<String,Object> resultOwner(AuthenticatedPrincipal principal,String id) { var result=store.read(s->s.getMapper(ResultMapper.class).result(id)); owned(result,principal,"owner_principal_id","owner_client_object_id"); return result; }
    private Map<String,Object> referenceOwner(AuthenticatedPrincipal principal,String id) { var reference=store.read(s->s.getMapper(ResultMapper.class).reference(id)); owned(reference,principal,"owner_principal_id","owner_client_object_id"); return reference; }
    private static void owned(Map<String,Object> row,AuthenticatedPrincipal principal,String user,String client) {
        if (row==null || principal.clientId()==null || !Objects.equals(row.get(user),principal.principalId()) || !Objects.equals(row.get(client),principal.clientId())) throw denied();
    }
    private void check(AuthenticatedPrincipal principal,String action,Collection<CanonicalTarget> targets) { if(targets.isEmpty()) throw denied(); for(var target:targets) authorization.authorize(principal,action,target); }
    private void audit(AuthenticatedPrincipal principal,String execution,String event,String action) {
        store.write(session->{
            String actionId=session.getMapper(ResultMapper.class).action(action);
            audit.append(new AuditService.Event(execution,null,event,principal.subject(),principal.clientId(),null,"SUCCEEDED",null,new AuditService.SecurityContext(principal.principalId(),principal.clientId(),null,principal.grantId(),principal.tokenId(),"INTERNAL",null,actionId)),List.of());
            return null;
        });
    }
    /** Validates observed URLs before output auditing, without reading or writing any store. */
    public void validateWebReferenceCandidate(String url) {
        try {
            if(url==null || url.length()>8192) throw invalid();
            URI uri=URI.create(url);
            if(!webOrigins.contains(origin(uri)) || uri.getUserInfo()!=null || uri.getFragment()!=null) throw invalid();
            if(uri.getRawQuery()!=null) for(String part:uri.getRawQuery().split("[&;]",-1)) {
                String key=URLDecoder.decode(part.split("=",2)[0],StandardCharsets.UTF_8);
                String normalized=QUERY_KEY_SEPARATORS.matcher(key.toLowerCase(Locale.ROOT)).replaceAll("");
                if(key.indexOf('%')>=0 || !queryParameters.contains(key) || SECRET_QUERY_KEYS.contains(normalized)) throw invalid();
            }
        } catch (IllegalArgumentException e) { throw new IllegalArgumentException("REFERENCE_URL_NOT_ALLOWED"); }
    }
    private static String origin(URI uri) { if(!"https".equals(uri.getScheme()) || uri.getHost()==null || uri.getUserInfo()!=null) throw invalid(); return "https://"+uri.getHost().toLowerCase(Locale.ROOT)+(uri.getPort()==-1||uri.getPort()==443?"":":"+uri.getPort()); }
    private static Set<String> csv(String value) { if(value==null||value.isBlank()) return Set.of(); return Set.copyOf(Arrays.stream(value.split(",")).map(String::strip).toList()); }
    static Map<String,Object> row(Object... pairs) { Map<String,Object> row=new HashMap<>(); for(int i=0;i<pairs.length;i+=2) row.put((String)pairs[i],pairs[i+1]); return row; }
    private static boolean truth(Object value) { return Boolean.TRUE.equals(value) || value instanceof Number n && n.intValue()==1; }
    private static IllegalArgumentException invalid() { return new IllegalArgumentException("INVALID_RESULT_OR_REFERENCE"); }
    private static AccessDenied denied() { return AccessDenied.denied(); }
}
