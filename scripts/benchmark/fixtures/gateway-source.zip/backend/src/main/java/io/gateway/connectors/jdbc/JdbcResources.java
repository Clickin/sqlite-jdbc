package io.gateway.connectors.jdbc;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import io.gateway.connectors.OperationAdapter;
import io.gateway.definitions.Definitions.*;
import io.gateway.runtime.Cancellation;
import io.gateway.runtime.ExecutionFailure;
import io.gateway.runtime.ExecutionFailure.Outcome;
import io.gateway.runtime.Payload;
import io.gateway.runtime.Payload.Disposition;
import io.gateway.credentials.CredentialService;
import jakarta.annotation.PreDestroy;
import jakarta.inject.Singleton;
import java.io.StringReader;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import javax.sql.DataSource;
import java.util.*;
import java.util.concurrent.*;
import org.apache.ibatis.builder.xml.XMLMapperBuilder;
import org.apache.ibatis.logging.nologging.NoLoggingImpl;
import org.apache.ibatis.mapping.*;
import org.apache.ibatis.session.*;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;

/** Immutable mapper factories share source pools, never sessions or request parameters. */
@Singleton
public final class JdbcResources implements AutoCloseable {
    private static final int DEFAULT_ROWS = 10_000;
    private static final long DEFAULT_BYTES = 16 * 1024 * 1024;
    private static final int MAX_MAPPER_CHARS = 2 * 1024 * 1024;
    private final CredentialService credentials;
    private final Map<PoolKey, Pool> pools = new HashMap<>();
    private final ScheduledThreadPoolExecutor deadlines;
    private boolean closed;

    public JdbcResources(CredentialService credentials) {
        this.credentials = Objects.requireNonNull(credentials);
        deadlines = new ScheduledThreadPoolExecutor(1, Thread.ofPlatform().daemon().name("jdbc-deadline").factory());
        deadlines.setRemoveOnCancelPolicy(true);
    }

    private record PoolKey(String url, String profile, String credentialVersion, int minIdle,
                           int maxSize, int acquireMs, boolean readOnly, int concurrency, int queueMs) {}
    private static final class Pool {
        final PoolKey key;
        final HikariDataSource source;
        final Semaphore admission;
        int references;
        Pool(PoolKey key, HikariDataSource source) {
            this.key = key;
            this.source = source;
            admission = new Semaphore(key.concurrency(), true);
        }
    }

    /** Decrypts only while opening a physical connection; neither Hikari nor this object retains a password. */
    private static final class SourceConnections implements DataSource {
        private final PoolKey key;
        private final CredentialService credentials;
        SourceConnections(PoolKey key, CredentialService credentials) {
            this.key = key;
            this.credentials = credentials;
        }
        @Override public Connection getConnection() throws SQLException {
            Properties properties = new Properties();
            try {
                // Xerial cannot switch a normal open connection to read-only; establish the native flag first.
                if (key.profile().equals("SQLITE") && key.readOnly())
                    properties.setProperty("open_mode", Integer.toString(org.sqlite.SQLiteOpenMode.READONLY.flag));
                if (key.credentialVersion() == null) return DriverManager.getConnection(key.url(), properties);
                try (CredentialService.Secret secret = credentials.resolveVersion(key.credentialVersion())) {
                    if (secret.publicUsername() != null) properties.setProperty("user", secret.publicUsername());
                    properties.setProperty("password", secret.utf8());
                    return DriverManager.getConnection(key.url(), properties);
                }
            } catch (Exception failure) {
                throw new SQLException("JDBC_CONNECTION_FAILED");
            } finally { properties.clear(); }
        }
        @Override public Connection getConnection(String username, String password) throws SQLException {
            throw new SQLFeatureNotSupportedException("JDBC_CREDENTIAL_OVERRIDE_FORBIDDEN");
        }
        @Override public java.io.PrintWriter getLogWriter() { return null; }
        @Override public void setLogWriter(java.io.PrintWriter writer) throws SQLException {
            throw new SQLFeatureNotSupportedException("JDBC_WIRE_LOGGING_FORBIDDEN");
        }
        @Override public int getLoginTimeout() { return 0; }
        @Override public void setLoginTimeout(int seconds) throws SQLException {
            throw new SQLFeatureNotSupportedException("JDBC_LOGIN_TIMEOUT_PROFILE_ONLY");
        }
        @Override public java.util.logging.Logger getParentLogger() throws SQLFeatureNotSupportedException {
            throw new SQLFeatureNotSupportedException("JDBC_LOGGER_UNAVAILABLE");
        }
        @Override public boolean isWrapperFor(Class<?> type) { return type.isInstance(this); }
        @Override public <T> T unwrap(Class<T> type) throws SQLException {
            if (type.isInstance(this)) return type.cast(this);
            throw new SQLException("JDBC_UNWRAP_UNSUPPORTED");
        }
    }

    /**
     * SELECT_ONE returns its mapped row object. OPTIONAL requires one nullable OBJECT output field;
     * MANY requires one ARRAY field, EXECUTE one INTEGER/LONG field. CALL uses explicit OUT field bindings.
     */
    public OperationAdapter prepare(ResolvedGraph graph, JdbcOperation operation) {
        Pool pool = null;
        try {
            JdbcSource source = (JdbcSource) graph.require(operation.sourceObjectId()).detail();
            validate(operation, source);
            Configuration configuration = compileMapper(graph, operation.mapperObjectId(), profile(source.driverProfileId()));
            MappedStatement statement = configuration.getMappedStatement(operation.statementId());
            boolean select = Set.of("SELECT_ONE", "OPTIONAL", "MANY").contains(operation.executionMode());
            if (select && statement.getSqlCommandType() != SqlCommandType.SELECT)
                throw invalid("JDBC_MODE_MISMATCH");
            if (operation.executionMode().equals("CALL") != (statement.getStatementType() == StatementType.CALLABLE))
                throw invalid("JDBC_CALL_MODE_MISMATCH");
            if (operation.executionMode().equals("EXECUTE") && !Set.of(SqlCommandType.INSERT,
                    SqlCommandType.UPDATE, SqlCommandType.DELETE).contains(statement.getSqlCommandType()))
                throw invalid("JDBC_MODE_MISMATCH");
            Map<String, String> outputs = outputNames(graph, operation, configuration);
            String envelope = outputEnvelope(graph, operation);
            Map<String, Disposition> dispositions = dispositions(graph, operation.outputContractObjectId());
            pool = acquire(graph, source);
            configuration.setEnvironment(new Environment("registered-source", new JdbcTransactionFactory(), pool.source));
            return new Adapter(pool, new SqlSessionFactoryBuilder().build(configuration), operation, outputs, dispositions, envelope);
        } catch (Exception failure) {
            if (pool != null) release(pool);
            if (failure instanceof ExecutionFailure safe) throw safe;
            throw invalid("JDBC_PREPARATION_FAILED");
        }
    }

    /** Connection-only management probe: never resolves or executes a mapper/business statement. */
    public void probe(ResolvedGraph graph, String sourceObjectId) {
        Pool pool = null;
        boolean admitted = false;
        try {
            JdbcSource source = (JdbcSource) graph.require(sourceObjectId).detail();
            validateSource(source);
            pool = acquire(graph, source);
            admitted = pool.admission.tryAcquire(source.queueTimeoutMs(), TimeUnit.MILLISECONDS);
            if (!admitted) throw invalid("JDBC_ADMISSION_TIMEOUT");
            try (Connection connection = pool.source.getConnection()) {
                if (!connection.isValid((int) Math.max(1, (source.acquireTimeoutMs() + 999L) / 1000)))
                    throw invalid("JDBC_CONNECTION_INVALID");
            }
        } catch (Exception failure) {
            if (failure instanceof InterruptedException) Thread.currentThread().interrupt();
            if (failure instanceof ExecutionFailure safe) throw safe;
            throw invalid("JDBC_CONNECTION_FAILED");
        } finally {
            if (admitted) pool.admission.release();
            if (pool != null) release(pool);
        }
    }

    /** Validates stored mapper graphs without allocating a connection pool or contacting a source. */
    public static void validateMappers(ResolvedGraph graph) {
        try {
            for (Saved saved : graph.definitions().values()) if (saved.detail() instanceof Mapper mapper)
                compileMapper(graph, saved.object().id(), profile(mapper.databaseProfile()));
        } catch (Exception failure) {
            if (failure instanceof ExecutionFailure safe) throw safe;
            throw invalid("JDBC_MAPPER_INVALID");
        }
    }

    private static Configuration compileMapper(ResolvedGraph graph, String mapperId, String profile) throws Exception {
        Configuration configuration = new Configuration();
        configuration.setLogImpl(NoLoggingImpl.class);
        configuration.setCacheEnabled(false);
        configuration.setLocalCacheScope(LocalCacheScope.STATEMENT);
        configuration.setLazyLoadingEnabled(false);
        configuration.setCallSettersOnNulls(true);
        configuration.setReturnInstanceForEmptyRow(true);
        configuration.setDefaultExecutorType(ExecutorType.SIMPLE);
        configuration.setDatabaseId(profile);
        configuration.addInterceptor(new JdbcExecution.Guard());
        JdbcExecution.registerLobHandlers(configuration);
        loadMappers(graph, mapperId, configuration, profile, new HashSet<>(), new HashSet<>(), new HashSet<>());
        // Forces pending include/resultMap/statement resolution before publishing a factory.
        for (String name : configuration.getMappedStatementNames()) {
            if (!name.contains(".")) continue;
            if (configuration.getMappedStatement(name).getStatementType() == StatementType.STATEMENT)
                throw invalid("JDBC_PREPARED_STATEMENT_REQUIRED");
        }
        return configuration;
    }

    private static String outputEnvelope(ResolvedGraph graph, JdbcOperation operation) {
        if (!Set.of("MANY", "EXECUTE", "OPTIONAL").contains(operation.executionMode())) return null;
        if (operation.outputContractObjectId() == null) throw invalid("JDBC_OUTPUT_CONTRACT_REQUIRED");
        Contract contract = (Contract) graph.require(operation.outputContractObjectId()).detail();
        List<Field> roots = contract.fields().stream().filter(field -> field.parentFieldId() == null).toList();
        if (roots.size() != 1) throw invalid("JDBC_OUTPUT_ENVELOPE_INVALID");
        Field root = roots.getFirst();
        boolean valid = switch (operation.executionMode()) {
            case "MANY" -> root.nodeKind().equals("ARRAY");
            case "OPTIONAL" -> root.nodeKind().equals("OBJECT") && root.nullable();
            default -> root.nodeKind().equals("SCALAR") && Set.of("INTEGER", "LONG").contains(root.valueType());
        };
        if (!valid) throw invalid("JDBC_OUTPUT_ENVELOPE_INVALID");
        return root.memberName();
    }

    private static void validateSource(JdbcSource source) {
        profile(source.driverProfileId());
        if (source.jdbcUrl() == null || !source.jdbcUrl().startsWith(switch (profile(source.driverProfileId())) {
            case "ORACLE19C" -> "jdbc:oracle:thin:@";
            case "POSTGRES" -> "jdbc:postgresql:";
            default -> "jdbc:sqlite:";
        })) throw invalid("JDBC_URL_PROFILE_MISMATCH");
        String url = URLDecoder.decode(source.jdbcUrl(), StandardCharsets.UTF_8).toLowerCase(Locale.ROOT);
        if (url.matches("(?s).*(user|username|password|passwd|pwd)\\s*=.*")
                || url.contains("//") && url.substring(url.indexOf("//") + 2).split("/", 2)[0].contains("@"))
            throw invalid("JDBC_URL_CREDENTIAL_FORBIDDEN");
        if (source.poolMinIdle() < 0 || source.poolMaxSize() < 1 || source.poolMinIdle() > source.poolMaxSize()
                || source.acquireTimeoutMs() < 250 || source.maxConcurrent() < 1 || source.queueTimeoutMs() < 1)
            throw invalid("JDBC_LIMIT_INVALID");
    }

    private static void validate(JdbcOperation operation, JdbcSource source) {
        validateSource(source);
        if (operation.timeoutMs() < 1 || operation.maxResultRows() != null && operation.maxResultRows() < 1
                || operation.maxResultBytes() != null && operation.maxResultBytes() < 1)
            throw invalid("JDBC_LIMIT_INVALID");
        if (!Set.of("SELECT_ONE", "OPTIONAL", "MANY", "EXECUTE", "CALL").contains(operation.executionMode())
                || !Set.of("READ_ONLY", "LOCAL_WRITE", "NONE").contains(operation.transactionMode()))
            throw invalid("JDBC_MODE_INVALID");
        if ((source.readOnlyPolicy() || operation.transactionMode().equals("READ_ONLY")) && operation.effect() != Effect.READ_ONLY)
            throw invalid("JDBC_READ_ONLY_EFFECT_MISMATCH");
    }

    private static String profile(String value) {
        if (value == null) throw invalid("JDBC_DRIVER_PROFILE_INVALID");
        return switch (value.toUpperCase(Locale.ROOT)) {
            case "ORACLE19C" -> "ORACLE19C";
            case "POSTGRES", "POSTGRESQL" -> "POSTGRES";
            case "SQLITE" -> "SQLITE";
            default -> throw invalid("JDBC_DRIVER_PROFILE_INVALID");
        };
    }

    private static void loadMappers(ResolvedGraph graph, String id, Configuration configuration, String profile,
                                    Set<String> visiting, Set<String> loaded, Set<String> resources) throws Exception {
        if (loaded.contains(id)) return;
        if (!visiting.add(id)) throw invalid("JDBC_MAPPER_IMPORT_CYCLE");
        Mapper mapper = (Mapper) graph.require(id).detail();
        if (!profile(mapper.databaseProfile()).equals(profile)) throw invalid("JDBC_MAPPER_PROFILE_MISMATCH");
        if (new HashSet<>(mapper.imports()).size() != mapper.imports().size()) throw invalid("JDBC_DUPLICATE_IMPORT");
        for (String dependency : mapper.imports()) loadMappers(graph, dependency, configuration, profile, visiting, loaded, resources);
        for (MapperDocument document : mapper.documents()) {
            if (document.xmlText() == null || document.xmlText().length() > MAX_MAPPER_CHARS)
                throw invalid("JDBC_MAPPER_SIZE_LIMIT");
            String resource = id + "/" + document.resourceName();
            if (!resources.add(resource)) throw invalid("JDBC_DUPLICATE_RESOURCE");
            // Choices belong in trusted if/choose nodes; raw string substitution is never a parameter API.
            String xml = document.xmlText();
            if (xml.contains("${")) throw invalid("JDBC_LITERAL_SUBSTITUTION_FORBIDDEN");
            JdbcExecution.validateMapperXml(xml);
            new XMLMapperBuilder(new StringReader(xml), configuration, resource, configuration.getSqlFragments()).parse();
        }
        visiting.remove(id);
        loaded.add(id);
    }

    private static Map<String, String> outputNames(ResolvedGraph graph, JdbcOperation operation, Configuration configuration) {
        Map<String, String> fields = new HashMap<>();
        if (operation.outputContractObjectId() != null) {
            Contract contract = (Contract) graph.require(operation.outputContractObjectId()).detail();
            for (Field field : contract.fields()) if (field.parentFieldId() == null) fields.put(field.id(), field.memberName());
        }
        Map<String, String> outputs = new LinkedHashMap<>();
        Set<String> members = new HashSet<>();
        for (OutBinding binding : operation.outBindings()) {
            String member = fields.get(binding.outputFieldId());
            if (member == null || binding.parameterName() == null || outputs.putIfAbsent(binding.parameterName(), member) != null
                    || !members.add(member)) throw invalid("JDBC_OUT_BINDING_INVALID");
            if (binding.resultMapName() != null && !configuration.hasResultMap(binding.resultMapName()))
                throw invalid("JDBC_OUT_RESULT_MAP_MISSING");
        }
        return Collections.unmodifiableMap(outputs);
    }

    private static Map<String, Disposition> dispositions(ResolvedGraph graph, String contractId) {
        if (contractId == null) return Map.of();
        Map<String, Disposition> result = new HashMap<>();
        Contract contract = (Contract) graph.require(contractId).detail();
        for (Field field : contract.fields())
            result.put(field.id(), field.auditDisposition() == null ? Disposition.PERSIST : field.auditDisposition());
        return Map.copyOf(result);
    }

    private synchronized Pool acquire(ResolvedGraph graph, JdbcSource source) {
        if (closed) throw invalid("JDBC_RESOURCES_CLOSED");
        String credential = source.credentialObjectId() == null ? null : graph.version(source.credentialObjectId());
        if (credential != null) credentials.checkVersion(credential);
        PoolKey key = new PoolKey(source.jdbcUrl(), profile(source.driverProfileId()), credential, source.poolMinIdle(),
                source.poolMaxSize(), source.acquireTimeoutMs(), source.readOnlyPolicy(), source.maxConcurrent(), source.queueTimeoutMs());
        Pool pool = pools.get(key);
        if (pool == null) {
            HikariConfig config = new HikariConfig();
            try {
                Class.forName(switch (key.profile()) {
                    case "ORACLE19C" -> "oracle.jdbc.OracleDriver";
                    case "POSTGRES" -> "org.postgresql.Driver";
                    default -> "org.sqlite.JDBC";
                });
            } catch (ClassNotFoundException failure) { throw invalid("JDBC_DRIVER_UNAVAILABLE"); }
            config.setDataSource(new SourceConnections(key, credentials));
            config.setMinimumIdle(key.minIdle());
            config.setMaximumPoolSize(key.maxSize());
            config.setConnectionTimeout(key.acquireMs());
            config.setReadOnly(key.readOnly());
            config.setInitializationFailTimeout(-1);
            config.setPoolName("source-" + UUID.randomUUID());
            config.setRegisterMbeans(false);
            pool = new Pool(key, new HikariDataSource(config));
            pools.put(key, pool);
        }
        pool.references++;
        return pool;
    }

    private synchronized void release(Pool pool) {
        if (--pool.references == 0) {
            pools.remove(pool.key, pool);
            pool.source.close();
        }
    }

    @PreDestroy
    @Override public synchronized void close() {
        closed = true;
        // Adapters retain ownership until their last driver call returns, including during shutdown.
        deadlines.shutdown();
    }

    private final class Adapter implements OperationAdapter {
        private final Pool pool;
        private final SqlSessionFactory factory;
        private final JdbcOperation operation;
        private final Map<String, String> outputs;
        private final Map<String, Disposition> dispositions;
        private final String envelope;
        private int active;
        private boolean retired;
        Adapter(Pool pool, SqlSessionFactory factory, JdbcOperation operation, Map<String, String> outputs,
                Map<String, Disposition> dispositions, String envelope) {
            this.pool = pool;
            this.factory = factory;
            this.operation = operation;
            this.outputs = outputs;
            this.dispositions = dispositions;
            this.envelope = envelope;
        }
        private synchronized void enter() {
            if (retired) throw invalid("JDBC_ADAPTER_CLOSED");
            active++;
        }
        private synchronized void leave() { if (--active == 0 && retired) release(pool); }
        @Override public synchronized void close() {
            if (!retired) { retired = true; if (active == 0) release(pool); }
        }
        @Override public Payload execute(Payload input, Cancellation cancellation) {
            enter();
            boolean admitted = false;
            SqlSession session = null;
            boolean local = !operation.transactionMode().equals("NONE");
            boolean committed = false;
            boolean commitAttempted = false;
            boolean rolledBack = false;
            JdbcExecution state = null;
            ExecutionFailure reported = null;
            AutoCloseable callback = null;
            ScheduledFuture<?> alarm = null;
            try {
                cancellation.check();
                if (pool.key.credentialVersion() != null) credentials.checkVersion(pool.key.credentialVersion());
                state = new JdbcExecution(cancellation, operation.timeoutMs(),
                        operation.maxResultRows() == null ? DEFAULT_ROWS : operation.maxResultRows(),
                        operation.maxResultBytes() == null ? DEFAULT_BYTES : operation.maxResultBytes(),
                        operation.effect() != Effect.READ_ONLY, !local, operation.outBindings());
                JdbcExecution current = state;
                callback = cancellation.onCancel(current::requestCancel);
                alarm = deadlines.schedule(current::requestCancel, current.remainingMillis(), TimeUnit.MILLISECONDS);
                admitted = pool.admission.tryAcquire(Math.min(pool.key.queueMs(), current.remainingMillis()), TimeUnit.MILLISECONDS);
                if (!admitted) throw invalid("JDBC_ADMISSION_TIMEOUT");
                current.check();
                JdbcExecution.bind(current);
                Map<String, Object> parameters = JdbcExecution.copyParameters(input.object());
                session = factory.openSession(ExecutorType.SIMPLE, !local);
                Object value;
                switch (operation.executionMode()) {
                    case "SELECT_ONE", "OPTIONAL", "MANY" -> {
                        List<Object> rows = session.selectList(operation.statementId(), parameters);
                        if (!operation.executionMode().equals("MANY")) {
                            if (rows.size() > 1 || rows.isEmpty() && operation.executionMode().equals("SELECT_ONE"))
                                throw invalid("JDBC_RESULT_CARDINALITY");
                            value = rows.isEmpty() ? null : rows.getFirst();
                            if (operation.executionMode().equals("OPTIONAL")) value = Collections.singletonMap(envelope, value);
                        } else value = Map.of(envelope, rows);
                    }
                    case "EXECUTE" -> value = Map.of(envelope, session.update(operation.statementId(), parameters));
                    case "CALL" -> {
                        MappedStatement mapped = factory.getConfiguration().getMappedStatement(operation.statementId());
                        if (mapped.getSqlCommandType() == SqlCommandType.SELECT) session.selectList(operation.statementId(), parameters);
                        else session.update(operation.statementId(), parameters);
                        Map<String, Object> result = new LinkedHashMap<>();
                        for (Map.Entry<String, String> output : outputs.entrySet())
                            result.put(output.getValue(), factory.getConfiguration().newMetaObject(parameters).getValue(output.getKey()));
                        value = result;
                    }
                    default -> throw invalid("JDBC_MODE_INVALID");
                }
                current.check();
                Object detached = current.materialize(value);
                if (operation.transactionMode().equals("LOCAL_WRITE")) {
                    commitAttempted = true;
                    session.commit(true);
                    committed = true;
                } else if (local) {
                    session.rollback(true);
                    rolledBack = true;
                }
                return new Payload(detached, dispositions);
            } catch (Exception failure) {
                if (failure instanceof InterruptedException) Thread.currentThread().interrupt();
                if (local && session != null && !committed) {
                    try { session.rollback(true); rolledBack = true; } catch (Exception ignored) { /* effect remains unknown */ }
                }
                String code = failure instanceof ExecutionFailure safe ? safe.code() : "JDBC_EXECUTION_FAILED";
                boolean write = operation.effect() != Effect.READ_ONLY;
                Outcome outcome = committed || state != null && state.effectConfirmed ? Outcome.SUCCEEDED
                        : state == null || !state.attempted ? Outcome.FAILED_BEFORE_EFFECT
                        : !write || rolledBack && !commitAttempted ? Outcome.FAILED : Outcome.OUTCOME_UNKNOWN;
                reported = new ExecutionFailure(code, outcome, outcome == Outcome.SUCCEEDED);
                throw reported;
            } finally {
                if (alarm != null) alarm.cancel(false);
                if (callback != null) try { callback.close(); } catch (Exception ignored) { /* registration only */ }
                try {
                    if (session != null) session.close();
                } catch (Exception ignored) {
                    if (reported == null) {
                        Outcome outcome = committed || state != null && state.effectConfirmed ? Outcome.SUCCEEDED
                                : operation.effect() != Effect.READ_ONLY && state != null && state.attempted && !rolledBack
                                ? Outcome.OUTCOME_UNKNOWN : Outcome.FAILED;
                        throw new ExecutionFailure("JDBC_CLEANUP_FAILED", outcome, outcome == Outcome.SUCCEEDED);
                    }
                }
                finally {
                    JdbcExecution.unbind();
                    if (admitted) pool.admission.release();
                    leave();
                }
            }
        }
    }

    static ExecutionFailure invalid(String code) { return new ExecutionFailure(code, Outcome.FAILED_BEFORE_EFFECT); }
}
