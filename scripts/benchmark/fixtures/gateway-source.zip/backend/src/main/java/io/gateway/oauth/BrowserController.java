package io.gateway.oauth;

import io.micronaut.http.*;
import io.micronaut.http.annotation.*;
import io.micronaut.http.cookie.Cookie;
import io.micronaut.http.cookie.SameSite;
import io.micronaut.serde.annotation.Serdeable;
import java.util.Map;

@Controller("/auth")
public final class BrowserController {
    @Serdeable public record Login(String credential,String sessionKind) { @Override public String toString(){return "Login[redacted]";} }
    private final BrowserSessionService sessions;
    private final OAuthService oauth;
    public BrowserController(BrowserSessionService sessions,OAuthService oauth){this.sessions=sessions;this.oauth=oauth;}
    @Get("/session") public HttpResponse<?> session(HttpRequest<?> request){var session=sessions.session(cookie(request));return protectedResponse(HttpResponse.ok(session.view())).cookie(sessionCookie(session.cookie()));}
    @Post("/session/login") public HttpResponse<?> login(HttpRequest<?> request,@Body Login login){var session=sessions.login(cookie(request),singleHeader(request,"Origin"),singleHeader(request,"X-CSRF-Token"),login.credential(),login.sessionKind());return protectedResponse(HttpResponse.ok(session.view())).cookie(sessionCookie(session.cookie()));}
    @Post("/logout") public HttpResponse<?> logout(HttpRequest<?> request){sessions.logout(cookie(request),singleHeader(request,"Origin"),singleHeader(request,"X-CSRF-Token"));return protectedResponse(HttpResponse.ok(Map.of("loggedOut",true))).cookie(sessionCookie("").maxAge(0));}
    @Get("/requests/{id}") public HttpResponse<?> request(String id,HttpRequest<?> request){return protectedResponse(HttpResponse.ok(oauth.request(id,cookie(request))));}
    @Post("/requests/{id}/consent") public HttpResponse<?> consent(String id,HttpRequest<?> request,@Body OAuthService.Consent consent){String redirect=oauth.consent(id,cookie(request),singleHeader(request,"Origin"),singleHeader(request,"X-CSRF-Token"),consent);return protectedResponse(HttpResponse.ok(Map.of("redirectUri",redirect)));}
    public static String cookie(HttpRequest<?> request){if(!request.getHeaders().getAll(HttpHeaders.AUTHORIZATION).isEmpty())throw io.gateway.authorization.AccessDenied.denied();return request.getCookies().findCookie(BrowserSessionService.COOKIE_NAME).map(Cookie::getValue).orElse(null);}
    private static String singleHeader(HttpRequest<?> request,String name){var values=request.getHeaders().getAll(name);if(values.size()!=1)throw io.gateway.authorization.AccessDenied.denied();return values.getFirst();}
    public static Cookie sessionCookie(String value){return Cookie.of(BrowserSessionService.COOKIE_NAME,value).path("/").secure(true).httpOnly(true).sameSite(SameSite.Lax);}
    public static <T> MutableHttpResponse<T> protectedResponse(MutableHttpResponse<T> response){return response.header("Cache-Control","no-store").header("Pragma","no-cache").header("Referrer-Policy","no-referrer").header("X-Content-Type-Options","nosniff").header("Content-Security-Policy","default-src 'none'; frame-ancestors 'none'");}
}
