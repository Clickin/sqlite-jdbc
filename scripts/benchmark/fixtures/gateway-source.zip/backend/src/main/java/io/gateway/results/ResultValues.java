package io.gateway.results;

import io.gateway.contracts.ContractService;
import io.gateway.results.ResultModels.*;
import java.math.BigDecimal;
import java.util.*;

/** Converts only the registered contract tree; IDs attach citations to occurrences, not positions. */
final class ResultValues {
    record Prepared(List<StoredValue> values, Map<String,String> ids, Map<String,Object> data) {}
    static Prepared prepare(List<ValueInput> input, ContractService.Contract contract) {
        if (input == null || input.size() > 10000) throw invalid();
        Map<String,ContractService.Field> fields = new HashMap<>();
        for (var field : contract.fields()) fields.put(field.id(), field);
        Map<String,ValueInput> byKey = new LinkedHashMap<>();
        Map<String,String> ids = new HashMap<>();
        for (var value : input) {
            if (value == null || value.key() == null || value.key().isBlank() || value.key().length() > 128 || byKey.putIfAbsent(value.key(), value) != null) throw invalid();
            ids.put(value.key(), UUID.randomUUID().toString());
        }
        List<StoredValue> output = new ArrayList<>();
        Set<String> visiting = new HashSet<>(), visited = new HashSet<>(), ordinals = new HashSet<>();
        for (var value : input) add(value, byKey, ids, fields, output, visiting, visited, ordinals, 0);
        return new Prepared(List.copyOf(output), Map.copyOf(ids), assemble(output, contract));
    }
    private static void add(ValueInput value, Map<String,ValueInput> byKey, Map<String,String> ids,
            Map<String,ContractService.Field> fields, List<StoredValue> output, Set<String> visiting,
            Set<String> visited, Set<String> ordinals, int depth) {
        if (visited.contains(value.key())) return;
        if (depth > 32 || !visiting.add(value.key())) throw invalid();
        var field = fields.get(value.fieldId());
        if (field == null || !"PERSIST".equals(field.disposition()) || value.ordinal() < 0) throw invalid();
        ValueInput parent = value.parentKey() == null ? null : byKey.get(value.parentKey());
        if (value.parentKey() != null && parent == null) throw invalid();
        if (!Objects.equals(field.parentId(), parent == null ? null : parent.fieldId())) throw invalid();
        if (parent != null && !Set.of("OBJECT","ARRAY").contains(parent.valueType())) throw invalid();
        if (parent != null) add(parent, byKey, ids, fields, output, visiting, visited, ordinals, depth + 1);
        if (!ordinals.add(Objects.toString(value.parentKey(), "") + "\u0000" + value.ordinal())) throw invalid();
        String type = value.valueType();
        int scalars = (value.textValue() == null ? 0 : 1) + (value.integerValue() == null ? 0 : 1) + (value.decimalText() == null ? 0 : 1) + (value.booleanValue() == null ? 0 : 1);
        if (type == null) throw invalid();
        boolean container = field.nodeKind().equals("OBJECT") || field.nodeKind().equals("ARRAY");
        if (container && !field.nodeKind().equals(type) && !Set.of("NULL","MISSING").contains(type)) throw invalid();
        if (!container && !Set.of("SCALAR", "COLUMN").contains(field.nodeKind())) throw invalid();
        boolean valid = switch (type) {
            case "OBJECT", "ARRAY" -> container && scalars == 0;
            case "NULL", "MISSING" -> scalars == 0;
            case "STRING" -> !container && scalars == 1 && value.textValue() != null;
            case "INTEGER" -> !container && scalars == 1 && value.integerValue() != null;
            case "DECIMAL" -> !container && scalars == 1 && value.decimalText() != null;
            case "BOOLEAN" -> !container && scalars == 1 && value.booleanValue() != null;
            default -> false;
        };
        if (!valid) throw invalid();
        if (value.decimalText() != null) try { new BigDecimal(value.decimalText()); } catch (NumberFormatException e) { throw invalid(); }
        output.add(new StoredValue(ids.get(value.key()), ids.get(value.parentKey()), value.fieldId(), value.ordinal(), field.nodeKind(), type, value.textValue(), value.integerValue(), value.decimalText(), value.booleanValue()));
        visiting.remove(value.key()); visited.add(value.key());
    }
    static Map<String,Object> assemble(List<StoredValue> values, ContractService.Contract contract) {
        Map<String,ContractService.Field> fields = new HashMap<>();
        for (var field : contract.fields()) fields.put(field.id(), field);
        Map<String,List<StoredValue>> children = new HashMap<>();
        for (var value : values) children.computeIfAbsent(Objects.toString(value.parentValueId(), ""), ignored -> new ArrayList<>()).add(value);
        for (var siblings : children.values()) siblings.sort(Comparator.comparingInt(StoredValue::ordinal));
        return object(children.getOrDefault("", List.of()), children, fields, 0);
    }
    private static Map<String,Object> object(List<StoredValue> values, Map<String,List<StoredValue>> children, Map<String,ContractService.Field> fields, int depth) {
        Map<String,Object> result = new LinkedHashMap<>();
        Set<String> names = new HashSet<>();
        for (var value : values) {
            var field = fields.get(value.fieldId());
            if (field == null || !names.add(field.name())) throw invalid();
            if (!value.valueType().equals("MISSING")) result.put(field.name(), scalar(value, children, fields, depth + 1));
        }
        return result;
    }
    private static Object scalar(StoredValue value, Map<String,List<StoredValue>> children, Map<String,ContractService.Field> fields, int depth) {
        if (depth > 32) throw invalid();
        var nested = children.getOrDefault(value.id(), List.of());
        return switch (value.valueType()) {
            case "OBJECT" -> object(nested, children, fields, depth);
            case "ARRAY" -> {
                List<Object> array = new ArrayList<>();
                for (int i = 0; i < nested.size(); i++) {
                    if (nested.get(i).ordinal() != i || nested.get(i).valueType().equals("MISSING")) throw invalid();
                    array.add(scalar(nested.get(i), children, fields, depth + 1));
                }
                yield array;
            }
            case "STRING" -> value.textValue();
            case "INTEGER" -> value.integerValue();
            case "DECIMAL" -> new BigDecimal(value.decimalText());
            case "BOOLEAN" -> value.booleanValue();
            case "NULL" -> null;
            default -> throw invalid();
        };
    }
    static IllegalArgumentException invalid() { return new IllegalArgumentException("INVALID_RESULT_VALUES"); }
}
