package io.gateway.results;

import io.gateway.authorization.CanonicalTarget;
import io.gateway.persistence.PlatformMapper;
import io.gateway.results.ResultModels.*;
import org.apache.ibatis.annotations.*;
import java.util.List;
import java.util.Map;

public interface ResultMapper extends PlatformMapper {
    @Select("SELECT * FROM execution WHERE id=#{id}") Map<String,Object> execution(String id);
    @Select("SELECT DISTINCT target_kind,organization,identifier_system,patient_identifier,encounter_identifier,document_identifier FROM execution_target WHERE execution_id=#{id} AND outcome='ALLOW'") List<CanonicalTarget> executionTargets(String id);
    @Select("SELECT * FROM generated_result WHERE id=#{id}") Map<String,Object> result(String id);
    @Select("SELECT * FROM generated_result_revision WHERE id=#{id}") Map<String,Object> revision(String id);
    @Select("SELECT id,current_revision_id AS revisionId,revision_counter AS revision FROM generated_result WHERE owner_principal_id=#{principal} AND owner_client_object_id=#{client} ORDER BY id") List<ResultSummary> list(@Param("principal") String principal, @Param("client") String client);
    @Select("SELECT target_kind,organization,identifier_system,patient_identifier,encounter_identifier,document_identifier FROM result_target WHERE result_id=#{id}") List<CanonicalTarget> resultTargets(String id);
    @Select("SELECT target_kind,organization,identifier_system,patient_identifier,encounter_identifier,document_identifier FROM reference_target WHERE reference_id=#{id}") List<CanonicalTarget> referenceTargets(String id);
    @Select("SELECT id,parent_value_id,contract_field_id AS field_id,ordinal,node_kind,value_type,text_value,integer_value,decimal_text,boolean_value FROM result_value WHERE result_revision_id=#{id} ORDER BY ordinal,id") List<StoredValue> values(String id);
    @Select("SELECT reference_id,result_value_id,ordinal FROM result_reference WHERE result_revision_id=#{id} ORDER BY ordinal") List<StoredReference> references(String id);
    @Select("SELECT * FROM source_reference WHERE id=#{id}") Map<String,Object> reference(String id);
    @Select("SELECT * FROM web_reference WHERE reference_id=#{id}") Map<String,Object> web(String id);
    @Select("SELECT * FROM tool_reference WHERE reference_id=#{id}") Map<String,Object> tool(String id);
    @Select("SELECT * FROM reference_parameter WHERE reference_id=#{id} ORDER BY port,ordinal,id") List<Map<String,Object>> parameters(String id);
    @Select("SELECT p.*,o.enabled FROM config_object o JOIN screen_profile_version p ON p.version_id=o.current_version_id WHERE o.id=#{id}") Map<String,Object> screen(String id);
    @Select("SELECT p.*,o.enabled FROM config_object o JOIN config_version v ON v.object_id=o.id JOIN screen_profile_version p ON p.version_id=v.id WHERE o.id=#{object} AND v.id=#{version}") Map<String,Object> screenVersion(@Param("object") String object, @Param("version") String version);
    @Select("SELECT * FROM screen_parameter_binding WHERE screen_profile_version_id=#{id} ORDER BY ordinal") List<Map<String,Object>> bindings(String id);
    @Select("SELECT count(*) FROM execution_dependency d JOIN config_version v ON v.id=d.config_version_id JOIN config_object o ON o.id=v.object_id LEFT JOIN credential_state c ON c.credential_version_id=v.id WHERE d.execution_id=#{id} AND (o.enabled=FALSE OR c.revoked_at IS NOT NULL)") int disabledDependencies(String id);
    @Select("SELECT count(*) FROM execution_dependency WHERE execution_id=#{execution} AND config_version_id=#{version}") int observed(@Param("execution") String execution, @Param("version") String version);
    @Select("SELECT count(*) FROM config_version v JOIN config_object o ON o.id=v.object_id WHERE v.id=#{version} AND o.id=#{object} AND o.enabled=TRUE") int versionOwner(@Param("version") String version, @Param("object") String object);
    @Select("SELECT source_object_id FROM operation_version WHERE version_id=#{version}") String datasource(String version);
    @Select("SELECT id FROM protected_action WHERE action_key=#{key}") String action(String key);

    @Insert("INSERT INTO generated_result(id,owner_scope,caller_service_id,owner_principal_id,owner_client_object_id,public_grant_id) VALUES(#{id},#{principal},#{client},#{principal},#{client},#{grant})") void insertResult(Map<String,Object> row);
    @Insert("INSERT INTO generated_result_revision(id,result_id,revision,output_contract_version_id,external_generation_id,submitted_model,source_execution_id,created_at) VALUES(#{id},#{result},#{revision},#{contract},#{generation},#{model},#{execution},#{now})") void insertRevision(Map<String,Object> row);
    @Update("UPDATE generated_result SET current_revision_id=#{revision},revision_counter=revision_counter+1 WHERE id=#{id} AND revision_counter=#{expected}") int head(@Param("id") String id, @Param("revision") String revision, @Param("expected") int expected);
    @Insert("INSERT INTO result_value(id,result_revision_id,parent_value_id,contract_field_id,node_kind,ordinal,value_type,text_value,integer_value,decimal_text,boolean_value) VALUES(#{value.id},#{revision},#{value.parentValueId},#{value.fieldId},#{value.nodeKind},#{value.ordinal},#{value.valueType},#{value.textValue},#{value.integerValue},#{value.decimalText},#{value.booleanValue})") void insertValue(@Param("revision") String revision, @Param("value") StoredValue value);
    @Insert("INSERT INTO result_reference(result_revision_id,result_value_id,reference_id,ordinal) VALUES(#{revision},#{value},#{reference},#{ordinal})") void link(@Param("revision") String revision, @Param("value") String value, @Param("reference") String reference, @Param("ordinal") int ordinal);
    @Insert("INSERT INTO result_target(result_id,action_id,target_kind,organization,identifier_system,patient_identifier,encounter_identifier,document_identifier) VALUES(#{id},#{action},#{target.targetKind},#{target.organization},#{target.identifierSystem},#{target.patientIdentifier},#{target.encounterIdentifier},#{target.documentIdentifier})") void resultTarget(@Param("id") String id, @Param("action") String action, @Param("target") CanonicalTarget target);
    @Insert("INSERT INTO reference_target(reference_id,action_id,target_kind,organization,identifier_system,patient_identifier,encounter_identifier,document_identifier) VALUES(#{id},#{action},#{target.targetKind},#{target.organization},#{target.identifierSystem},#{target.patientIdentifier},#{target.encounterIdentifier},#{target.documentIdentifier})") void referenceTarget(@Param("id") String id, @Param("action") String action, @Param("target") CanonicalTarget target);
    @Insert("INSERT INTO source_reference(id,reference_kind,owner_scope,owner_principal_id,owner_client_object_id,public_grant_id,source_execution_id,created_at) VALUES(#{id},#{kind},#{principal},#{principal},#{client},#{grant},#{execution},#{now})") void insertReference(Map<String,Object> row);
    @Insert("INSERT INTO web_reference(reference_id,original_url,display_name,origin_record_id) VALUES(#{id},#{observation.url},#{observation.displayName},#{observation.originRecordId})") void insertWeb(@Param("id") String id, @Param("observation") WebObservation observation);
    @Insert("INSERT INTO tool_reference(reference_id,operation_object_id,observed_operation_version_id,observed_datasource_version_id,screen_profile_object_id,observed_screen_profile_version_id,origin_record_id) VALUES(#{id},#{observation.operationObjectId},#{observation.observedOperationVersionId},#{observation.observedDatasourceVersionId},#{observation.screenProfileObjectId},#{screenVersion},#{observation.originRecordId})") void insertTool(@Param("id") String id, @Param("observation") ToolObservation observation, @Param("screenVersion") String screenVersion);
    @Insert("INSERT INTO reference_parameter(id,reference_id,parent_parameter_id,parameter_name,ordinal,port,field_id,value_type,string_value,integer_value,decimal_text,boolean_value,exclusion_reason) VALUES(#{id},#{reference},#{parent},#{name},#{ordinal},#{port},#{field},#{type},#{text},#{integer},#{decimal},#{boolean},#{exclusion})") void insertParameter(Map<String,Object> row);
}
