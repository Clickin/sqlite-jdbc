package io.gateway.definitions;

import java.net.URI;
import java.util.*;
import io.gateway.convert.ConverterEngine;
import static io.gateway.definitions.Definitions.*;

final class DefinitionValidator {
    private DefinitionValidator(){}
    static void local(Detail d){
        sourcePolicy(d);
        switch(d){
            case JdbcSource s -> {positive(s.poolMaxSize());positive(s.acquireTimeoutMs());positive(s.maxConcurrent());positive(s.queueTimeoutMs());if(s.poolMinIdle()<0||s.poolMinIdle()>s.poolMaxSize())bad("POOL_LIMIT");if(s.jdbcUrl()==null||!s.jdbcUrl().startsWith("jdbc:")||s.jdbcUrl().matches("(?is).*(password|pwd|user)\\s*=.*"))bad("JDBC_URL");if(!Set.of("ORACLE19C","POSTGRES","SQLITE").contains(s.driverProfileId().toUpperCase(Locale.ROOT)))bad("DRIVER_PROFILE");}
            case HttpSource s -> {URI uri=URI.create(s.baseUri());if(!Set.of("http","https").contains(uri.getScheme())||uri.getHost()==null||uri.getRawUserInfo()!=null||uri.getRawQuery()!=null||uri.getRawFragment()!=null)bad("BASE_URI");positive(s.poolMaxTotal());positive(s.poolMaxPerRoute());positive(s.connectTimeoutMs());positive(s.maxConcurrent());positive(s.queueTimeoutMs());if(!"NEVER".equals(s.redirectPolicy()))bad("REDIRECT_POLICY");if(s.proxyProfileId()!=null)bad("UNSUPPORTED_PROXY_PROFILE");for(Header h:s.headers()){if((h.literalValue()==null)==(h.credentialPart()==null))bad("HEADER_VALUE_SOURCE");if(h.literalValue()!=null&&Set.of("authorization","cookie","proxy-authorization").contains(h.name().toLowerCase(Locale.ROOT)))bad("SECRET_HEADER_LITERAL");}}
            case Mapper m -> {if(m.documents().isEmpty())bad("MAPPER_DOCUMENT_REQUIRED");Set<String> names=new HashSet<>();for(MapperDocument doc:m.documents()){if(doc.resourceName()==null||!names.add(doc.resourceName())||doc.xmlText()==null||doc.xmlText().length()>2_000_000||doc.xmlText().contains("${"))bad("MAPPER_DOCUMENT_INVALID");}if(new HashSet<>(m.imports()).size()!=m.imports().size())bad("DUPLICATE_IMPORT");}
            case JdbcOperation o -> {operation(o.sourceObjectId(),o.inputContractObjectId(),o.outputContractObjectId(),o.timeoutMs(),o.maxResultRows(),o.maxResultBytes());if(o.mapperObjectId()==null||o.statementId()==null||!Set.of("SELECT_ONE","OPTIONAL","MANY","EXECUTE","CALL").contains(o.executionMode())||!Set.of("READ_ONLY","LOCAL_WRITE","NONE").contains(o.transactionMode()))bad("JDBC_OPERATION_MODE");if(o.effect()!=Effect.READ_ONLY&&"READ_ONLY".equals(o.transactionMode()))bad("WRITE_READ_ONLY_TRANSACTION");}
            case HttpOperation o -> {operation(o.sourceObjectId(),o.inputContractObjectId(),o.outputContractObjectId(),o.timeoutMs(),o.maxResultRows(),o.maxResultBytes());if(!Set.of("GET","POST","PUT","PATCH","DELETE","HEAD","OPTIONS").contains(o.method()))bad("HTTP_METHOD");if(o.relativePathTemplate()==null||o.relativePathTemplate().startsWith("//")||o.relativePathTemplate().contains("://")||o.relativePathTemplate().contains("\\")||o.relativePathTemplate().contains("..")||o.relativePathTemplate().contains("#"))bad("RELATIVE_PATH");if(o.statuses().isEmpty())bad("EXPECTED_STATUS_REQUIRED");for(Parameter p:o.parameters())if((p.inputFieldId()==null)==(p.literalScalar()==null)||!Set.of("PATH","QUERY","HEADER").contains(p.location()))bad("HTTP_PARAMETER");}
            case Contract c -> contract(c);
            case Representation r -> {if(!Set.of("json","xml").contains(r.codecId().toLowerCase(Locale.ROOT)))bad("CODEC_UNAVAILABLE");if(!"UTF-8".equalsIgnoreCase(r.charset()))bad("CHARSET_UNSUPPORTED");}
            case Converter c -> {if(!"basic".equals(c.implementationId()))bad("CONVERTER_UNAVAILABLE");Set<String> targets=new HashSet<>();for(Rule r:c.rules()){if(!targets.add(r.targetFieldId()))bad("DUPLICATE_TARGET_FIELD");if(!Set.of("COPY","CONSTANT","STRING","INTEGER","DECIMAL","BOOLEAN","DATE","DATETIME","DEFAULT_MISSING","DEFAULT_NULL","CODE_MAP").contains(r.transformCode()))bad("UNSUPPORTED_TRANSFORM");if(!"INPUT".equals(r.sourcePort()))bad("SOURCE_PORT");Set<String> args=new HashSet<>();for(Argument a:r.arguments()){if(!args.add(a.name()))bad("DUPLICATE_ARGUMENT");ConverterEngine.argument(a);}}}
            case Workflow w -> {Set<String> stages=new HashSet<>();for(Stage s:w.stages()){if(!stages.add(s.stageKey()))bad("DUPLICATE_STAGE");int order=switch(s.stageKey()){case "INPUT"->0;case "CONVERT"->1;case "OUTPUT"->2;default->throw new IllegalArgumentException("INVALID_STAGE");};if(s.stageOrder()!=order)bad("STAGE_ORDER");if("CONVERT".equals(s.stageKey())?(s.converterObjectId()==null||s.operationObjectId()!=null):(s.operationObjectId()==null||s.converterObjectId()!=null))bad("STAGE_KIND");}if(!stages.contains("INPUT"))bad("INPUT_REQUIRED");Set<String> ports=new HashSet<>();for(Port p:w.ports())if(!Set.of("REQUEST","RESPONSE","ERROR").contains(p.direction())||!ports.add(p.direction()))bad("WORKFLOW_PORT");}
            case Credential ignored -> {}
            case ErrorMapping ignored -> {}
        }
    }
    private static void operation(String source,String in,String out,int timeout,Integer rows,Long bytes){if(source==null||in==null||out==null)bad("OPERATION_CONTRACT_REQUIRED");positive(timeout);if(rows!=null)positive(rows);if(bytes!=null&&bytes<=0)bad("RESULT_LIMIT");}
    private static void positive(int value){if(value<=0)bad("POSITIVE_LIMIT_REQUIRED");}
    private static void contract(Contract c){
        if(!"VALUE".equals(c.modelKind()))bad("UNSUPPORTED_CONTRACT_MODEL");Map<String,Field> fields=new HashMap<>();Set<String> siblingNames=new HashSet<>(),orders=new HashSet<>();
        for(Field f:c.fields()){if(f.id()==null||fields.put(f.id(),f)!=null)bad("DUPLICATE_FIELD");if(!Set.of("OBJECT","ARRAY","SCALAR").contains(f.nodeKind()))bad("UNSUPPORTED_FIELD_KIND");if(!siblingNames.add(f.parentFieldId()+"/"+f.memberName())||!orders.add(f.parentFieldId()+"/"+f.ordinal()))bad("DUPLICATE_SIBLING");if(f.ordinal()<0||f.maxLength()!=null&&f.maxLength()<0)bad("FIELD_LIMIT");if(f.auditDisposition()==null)bad("AUDIT_DISPOSITION_REQUIRED");if("SCALAR".equals(f.nodeKind())&&!Set.of("STRING","TEXT","INTEGER","LONG","DECIMAL","NUMBER","BOOLEAN","DATE","DATETIME","INSTANT","TIME","BINARY").contains(f.valueType()))bad("UNSUPPORTED_VALUE_TYPE");}
        for(Field f:c.fields()){
            Set<String> seen=new HashSet<>();Field cursor=f;while(cursor.parentFieldId()!=null){if(!seen.add(cursor.id()))bad("FIELD_CYCLE");cursor=fields.get(cursor.parentFieldId());if(cursor==null)bad("MISSING_PARENT_FIELD");if("SCALAR".equals(cursor.nodeKind()))bad("SCALAR_PARENT");}
            List<Field> children=c.fields().stream().filter(x->f.id().equals(x.parentFieldId())).toList();if("ARRAY".equals(f.nodeKind())&&children.size()!=1)bad("ARRAY_ELEMENT_REQUIRED");
            Field parent=fields.get(f.parentFieldId());if((parent==null||!"ARRAY".equals(parent.nodeKind()))&&(f.memberName()==null||f.memberName().isBlank()))bad("MEMBER_NAME_REQUIRED");
        }
    }
    static void graph(ResolvedGraph g){io.gateway.connectors.jdbc.JdbcResources.validateMappers(g);for(Saved saved:g.definitions().values()){Detail d=saved.detail();local(d);validateReferences(g,d);switch(d){
        case JdbcOperation o -> {if(!(g.require(o.sourceObjectId()).detail() instanceof JdbcSource source))bad("SOURCE_PROVIDER_MISMATCH");else if(!source.driverProfileId().equalsIgnoreCase(((Mapper)g.require(o.mapperObjectId()).detail()).databaseProfile()))bad("MAPPER_DATABASE_PROFILE");for(OutBinding out:o.outBindings())field(g,o.outputContractObjectId(),out.outputFieldId());}
        case HttpOperation o -> {if(!(g.require(o.sourceObjectId()).detail() instanceof HttpSource))bad("SOURCE_PROVIDER_MISMATCH");for(Parameter p:o.parameters())if(p.inputFieldId()!=null)field(g,o.inputContractObjectId(),p.inputFieldId());representation(g,o.requestRepresentationObjectId(),o.inputContractObjectId());representation(g,o.responseRepresentationObjectId(),o.outputContractObjectId());}
        case Representation r -> {for(JsonBinding b:r.jsonBindings())field(g,r.contractObjectId(),b.fieldId());for(XmlBinding b:r.xmlBindings())field(g,r.contractObjectId(),b.fieldId());}
        case Converter c -> {for(Rule r:c.rules()){field(g,c.outputContractObjectId(),r.targetFieldId());if(r.sourceFieldId()!=null)field(g,c.inputContractObjectId(),r.sourceFieldId());}new ConverterEngine(g,c);}
        case Workflow w -> {String previous=null;for(Stage stage:w.stages().stream().sorted(Comparator.comparingInt(Stage::stageOrder)).toList()){Detail stageDef=g.require(stage.operationObjectId()!=null?stage.operationObjectId():stage.converterObjectId()).detail();String in=input(stageDef),out=output(stageDef);if(previous!=null&&!previous.equals(in))bad("STAGE_CONTRACT_MISMATCH");previous=out;}for(Port p:w.ports()){Representation r=(Representation)g.require(p.representationObjectId()).detail();if("RESPONSE".equals(p.direction())&&!r.contractObjectId().equals(previous))bad("RESPONSE_CONTRACT_MISMATCH");if("REQUEST".equals(p.direction())){Stage first=w.stages().stream().filter(s->s.stageKey().equals("INPUT")).findFirst().orElseThrow();if(!r.contractObjectId().equals(input(g.require(first.operationObjectId()).detail())))bad("REQUEST_CONTRACT_MISMATCH");}}}
        default -> {}
    }}}
    static String input(Detail d){return switch(d){case JdbcOperation o->o.inputContractObjectId();case HttpOperation o->o.inputContractObjectId();case Converter c->c.inputContractObjectId();default->null;};}
    static String output(Detail d){return switch(d){case JdbcOperation o->o.outputContractObjectId();case HttpOperation o->o.outputContractObjectId();case Converter c->c.outputContractObjectId();default->null;};}
    private static void representation(ResolvedGraph g,String id,String contract){if(id!=null&&!((Representation)g.require(id).detail()).contractObjectId().equals(contract))bad("REPRESENTATION_CONTRACT_MISMATCH");}
    static Field field(ResolvedGraph g,String contract,String id){return ((Contract)g.require(contract).detail()).fields().stream().filter(f->f.id().equals(id)).findFirst().orElseThrow(()->new IllegalArgumentException("FIELD_CONTRACT_MISMATCH"));}
    static List<ReferenceBinding> references(Detail detail){return switch(detail){case JdbcOperation operation->operation.referenceBindings();case HttpOperation operation->operation.referenceBindings();default->List.of();};}
    private static void validateReferences(ResolvedGraph graph,Detail detail){
        for(ReferenceBinding binding:references(detail)){
            if(binding.displayName()==null||binding.displayName().isBlank())bad("REFERENCE_DISPLAY_NAME");
            if("WEB_LINK".equals(binding.referenceKind())){if(binding.outputUrlFieldId()==null||binding.screenProfileObjectId()!=null)bad("REFERENCE_BINDING");}
            else if("TOOL_REFERENCE".equals(binding.referenceKind())){if(binding.screenProfileObjectId()==null||binding.outputUrlFieldId()!=null)bad("REFERENCE_BINDING");}
            else bad("REFERENCE_KIND");
            for(String id:new String[]{binding.outputUrlFieldId(),binding.originRecordFieldId()})if(id!=null){
                Field field=field(graph,output(detail),id);
                if(!"SCALAR".equals(field.nodeKind())||!Set.of("STRING","TEXT").contains(field.valueType())||field.auditDisposition()!=io.gateway.runtime.Payload.Disposition.PERSIST)bad("REFERENCE_FIELD_NOT_PERSISTABLE");
            }
        }
    }
    private static void sourcePolicy(Detail detail) {
        if(detail instanceof Representation representation&&representation.codecId()!=null&&representation.codecId().toLowerCase(Locale.ROOT).contains("xapi"))throw new io.gateway.runtime.ExecutionFailure("XAPI_BLOCKED_INTERNAL_NEXUS",io.gateway.runtime.ExecutionFailure.Outcome.FAILED_BEFORE_EFFECT);
        if(detail instanceof JdbcSource source) {
            String url=Objects.requireNonNull(source.jdbcUrl(),"JDBC_URL");
            String profile=Objects.requireNonNull(source.driverProfileId(),"DRIVER_PROFILE").toUpperCase(Locale.ROOT);
            if("ORACLE19C".equals(profile)&&!url.startsWith("jdbc:oracle:thin:@"))bad("JDBC_URL");
            if("POSTGRES".equals(profile)&&(!url.startsWith("jdbc:postgresql://")||URI.create(url.substring(5)).getRawUserInfo()!=null))bad("JDBC_URL");
            if("SQLITE".equals(profile)&&!url.startsWith("jdbc:sqlite:"))bad("JDBC_URL");
        }
        if(detail instanceof HttpSource source) {
            if(!Set.of("NONE","BASIC","BEARER","HEADER").contains(source.authenticationKind()))bad("HTTP_AUTH_KIND");
            if(!"NONE".equals(source.authenticationKind())&&source.credentialObjectId()==null)bad("HTTP_CREDENTIAL_REQUIRED");
            for(Header header:source.headers()) {
                if(header.name()==null||!header.name().matches("[!#$%&'*+.^_`|~0-9A-Za-z-]+"))bad("HEADER_NAME");
                if(header.literalValue()!=null&&(header.literalValue().contains("\r")||header.literalValue().contains("\n")))bad("HEADER_VALUE");
            }
        }
        if(detail instanceof Workflow workflow) {
            Set<String> bindings=new HashSet<>();
            for(SecurityBinding binding:workflow.securityBindings()) {
                if(!Set.of("INPUT","OUTPUT").contains(binding.stageKey())||binding.securityBindingObjectId()==null||binding.requiredActionId()==null||!bindings.add(binding.stageKey()+":"+binding.requiredActionId()))bad("WORKFLOW_SECURITY_BINDING");
            }
        }
    }
    private static void bad(String code){throw new IllegalArgumentException(code);}
}
