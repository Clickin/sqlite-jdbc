package io.gateway.mcp;

import io.modelcontextprotocol.spec.McpSchema;
import jakarta.inject.Singleton;
import tools.jackson.core.StreamReadConstraints;
import tools.jackson.core.StreamReadFeature;
import tools.jackson.core.json.JsonFactory;
import tools.jackson.databind.DeserializationFeature;
import tools.jackson.databind.json.JsonMapper;
import java.nio.ByteBuffer;
import java.nio.charset.*;
import java.util.*;

/** SDK 2.0 models are reused; only the 2026 HTTP/profile differences live here. */
@Singleton
public final class Mcp2026Adapter {
    public static final String VERSION = "2026-07-28";
    public static final String PROTOCOL = "io.modelcontextprotocol/protocolVersion";
    public static final String CAPABILITIES = "io.modelcontextprotocol/clientCapabilities";
    private final JsonMapper json = JsonMapper.builder(JsonFactory.builder()
        .enable(StreamReadFeature.STRICT_DUPLICATE_DETECTION)
        .streamReadConstraints(StreamReadConstraints.builder().maxNestingDepth(32).maxStringLength(1048576).build()).build())
        .enable(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)
        .enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS).build();

    public static final class ProtocolFailure extends RuntimeException {
        public final int status, code;
        public final Object id;
        public final Map<String,Object> data;
        public ProtocolFailure(int status,int code,String message,Object id,Map<String,Object> data) {
            super(message); this.status=status;this.code=code;this.id=id;this.data=data;
        }
    }
    public record Request(McpSchema.JSONRPCRequest rpc, Map<String,Object> parameters) {}

    @SuppressWarnings("unchecked")
    public Request request(String body, Map<String,List<String>> headers) {
        Map<String,Object> map;
        try {
            Object parsed = json.readValue(body,Object.class);
            if (!(parsed instanceof Map<?,?>)) throw failure(-32600,"Invalid request",null);
            map=(Map<String,Object>)parsed;
        } catch (ProtocolFailure e) { throw e; }
        catch (RuntimeException e) { throw failure(-32700,"Parse error",null); }
        Object id = map.get("id");
        if (!(id instanceof String || id instanceof Integer || id instanceof Long)) id=null;
        if (!"2.0".equals(map.get("jsonrpc")) || id==null || !(map.get("method") instanceof String method)
                || map.containsKey("result") || map.containsKey("error")) throw failure(-32600,"Invalid request",id);
        if (!(map.get("params") instanceof Map<?,?> raw)) throw failure(-32602,"Required request metadata missing",id);
        Map<String,Object> params=(Map<String,Object>)raw;
        if (!(params.get("_meta") instanceof Map<?,?> meta)
                || !(meta.get(PROTOCOL) instanceof String version)
                || !(meta.get(CAPABILITIES) instanceof Map<?,?>)) throw failure(-32602,"Required request metadata missing",id);
        if (!one(headers,"MCP-Protocol-Version",id).equals(version)
                || !one(headers,"Mcp-Method",id).equals(method)) throw failure(-32020,"Header mismatch",id);
        if (method.equals("tools/call") || method.equals("prompts/get") || method.equals("resources/read")) {
            String name=decode(one(headers,"Mcp-Name",id),id);
            Object bodyName=params.get(method.equals("resources/read")?"uri":"name");
            if (!name.equals(bodyName)) throw failure(-32020,"Header mismatch",id);
        }
        if (!VERSION.equals(version)) throw new ProtocolFailure(400,-32022,"Unsupported protocol version",id,
                Map.of("supported",List.of(VERSION),"requested",version));
        var accepts=all(headers,"Accept");
        boolean acceptsJson=false,acceptsSse=false;
        for (String header:accepts) for(String range:header.split(",")) {
            String[] parts=range.strip().split(";");
            boolean enabled=Arrays.stream(parts).skip(1).noneMatch(p->p.strip().matches("q=0(?:\\.0*)?"));
            acceptsJson |= enabled && parts[0].strip().equalsIgnoreCase("application/json");
            acceptsSse |= enabled && parts[0].strip().equalsIgnoreCase("text/event-stream");
        }
        if (!acceptsJson || !acceptsSse) throw new ProtocolFailure(406,-32600,"JSON and event-stream acceptance required",id,Map.of());
        if (!Set.of("server/discover","tools/list","tools/call").contains(method))
            throw new ProtocolFailure(404,-32601,"Method not found; supported protocol 2026-07-28",id,Map.of());
        if (method.equals("tools/list") && params.containsKey("cursor")) throw failure(-32602,"Pagination cursor unsupported",id);
        return new Request(new McpSchema.JSONRPCRequest("2.0",method,id,params),params);
    }

    public String serialize(Object value) { return json.writeValueAsString(value); }

    public Map<String,Object> result(Object id,Map<String,Object> contents) {
        var result=new LinkedHashMap<String,Object>(contents);
        result.put("resultType","complete");
        result.put("_meta",Map.of("io.modelcontextprotocol/serverInfo",Map.of("name","gateway","version","0.1.0")));
        // The older SDK rejects id-less errors; those are encoded separately below.
        var response=McpSchema.JSONRPCResponse.result(id,result);
        return Map.of("jsonrpc",response.jsonrpc(),"id",response.id(),"result",response.result());
    }

    public Map<String,Object> error(ProtocolFailure error) {
        var result=new LinkedHashMap<String,Object>();
        result.put("jsonrpc","2.0");
        if(error.id!=null) result.put("id",error.id);
        var detail=new LinkedHashMap<String,Object>();
        detail.put("code",error.code); detail.put("message",error.getMessage());
        if(!error.data.isEmpty()) detail.put("data",error.data);
        result.put("error",detail);
        return result;
    }

    public static String decode(String value,Object id) {
        if (value.startsWith("=?base64?") && value.endsWith("?=")) {
            try {
                byte[] bytes=Base64.getDecoder().decode(value.substring(9,value.length()-2));
                return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
            } catch(IllegalArgumentException|CharacterCodingException e) { throw failure(-32020,"Malformed encoded header",id); }
        }
        if (!value.equals(value.strip()) || value.chars().anyMatch(c->c!=9 && (c<32||c>126)))
            throw failure(-32020,"Malformed header",id);
        return value;
    }
    private static String one(Map<String,List<String>> headers,String name,Object id) {
        var values=all(headers,name);
        if(values.size()!=1 || values.getFirst().isEmpty() || values.getFirst().chars().anyMatch(c->c!=9 && (c<32||c>126)))
            throw failure(-32020,"Required header missing or malformed",id);
        return values.getFirst();
    }
    private static List<String> all(Map<String,List<String>> headers,String name) {
        return headers.entrySet().stream().filter(e->e.getKey().equalsIgnoreCase(name)).flatMap(e->e.getValue().stream()).toList();
    }
    private static ProtocolFailure failure(int code,String message,Object id) { return new ProtocolFailure(400,code,message,id,Map.of()); }
}
