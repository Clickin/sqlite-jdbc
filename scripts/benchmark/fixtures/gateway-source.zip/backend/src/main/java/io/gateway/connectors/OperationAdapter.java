package io.gateway.connectors;

import io.gateway.runtime.Cancellation;
import io.gateway.runtime.Payload;

/** A prepared, immutable registered operation; SDK resources never cross this interface. */
public interface OperationAdapter extends AutoCloseable {
    Payload execute(Payload input, Cancellation cancellation);
    @Override void close();
}
