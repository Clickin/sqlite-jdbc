package io.gateway.operations;

import io.gateway.persistence.PlatformStore;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/** Offline SQLite snapshot to an empty, independently migrated PostgreSQL schema. */
public final class RepositoryTransfer {
    static final Map<String,String> HEADS=Map.of("config_object","current_version_id","generated_result","current_revision_id","oauth_refresh_family","current_token_id");
    public record ForeignKey(String parent,Map<String,String> columns) {}
    public record Table(String name,LinkedHashMap<String,Integer> columns,List<ForeignKey> foreignKeys) {}
    public record Report(Map<String,Long> rows) {}
    private record Head(Table table,String column,Object id,Object value) {}
    private RepositoryTransfer() {}

    public static Report transfer(PlatformStore source,PlatformStore target) {
        if(source==target) throw new IllegalArgumentException("TRANSFER_REQUIRES_DISTINCT_STORES");
        return source.read(read->target.write(write->{
            var sourceTables=inventory(read); var targetTables=inventory(write);
            if(!sourceTables.keySet().equals(targetTables.keySet())) throw new IllegalStateException("TRANSFER_SCHEMA_MISMATCH");
            var from=read.getMapper(TransferMapper.class); var to=write.getMapper(TransferMapper.class);
            for(var table:targetTables.values()) {
                if(!table.columns().keySet().equals(sourceTables.get(table.name()).columns().keySet())) throw new IllegalStateException("TRANSFER_SCHEMA_MISMATCH");
                if(to.count(table)!=0) throw new IllegalStateException("TRANSFER_TARGET_NOT_EMPTY");
            }
            List<Head> heads=new ArrayList<>(); Map<String,Long> counts=new LinkedHashMap<>(); Set<String> completed=new HashSet<>();
            var pending=new LinkedHashMap<>(targetTables);
            while(!pending.isEmpty()) {
                boolean progress=false;
                for(var iterator=pending.entrySet().iterator();iterator.hasNext();) {
                    var table=iterator.next().getValue();
                    if(!ready(table,completed,targetTables.size())) continue;
                    var rows=from.rows(sourceTables.get(table.name()));
                    for(var row:rows) {
                        normalize(row,table);
                        String head=HEADS.get(table.name());
                        if(head!=null && row.get(head)!=null) { heads.add(new Head(table,head,row.get("id"),row.get(head))); row.put(head,null); }
                    }
                    try { insertRows(to,table,rows); }
                    catch(PersistenceException failure) { throw new IllegalStateException("TRANSFER_INSERT_FAILED:"+table.name()); }
                    counts.put(table.name(),(long)rows.size()); completed.add(table.name()); iterator.remove(); progress=true;
                }
                if(!progress) throw new IllegalStateException("TRANSFER_FOREIGN_KEY_CYCLE");
            }
            for(var head:heads) {
                try { to.head(head.table(),head.column(),head.id(),head.value()); }
                catch(PersistenceException failure) { throw new IllegalStateException("TRANSFER_HEAD_FAILED:"+head.table().name()); }
            }
            // Verify complete rows, not merely counts: IDs, revisions, heads, typed values and bytes all survive.
            for(var table:targetTables.values()) {
                var expected=from.rows(sourceTables.get(table.name())); for(var row:expected) normalize(row,table);
                var actual=to.rows(table);
                if(!multiset(expected).equals(multiset(actual))) throw new IllegalStateException("TRANSFER_VERIFICATION_FAILED:"+table.name());
            }
            return new Report(Collections.unmodifiableMap(counts));
        }));
    }
    private static boolean ready(Table table,Set<String> complete,int tableCount) {
        if(table.name().equals("configuration_change") && complete.size()!=tableCount-1) return false;
        if(table.name().equals("oauth_token_scope") && !complete.contains("oauth_grant_scope")) return false;
        if(Set.of("oauth_authorization_code","oauth_access_token").contains(table.name()) && (!complete.contains("oauth_grant_rule") || !complete.contains("oauth_grant_scope"))) return false;
        for(var fk:table.foreignKeys()) if(!fk.parent().equals(table.name()) && !fk.columns().containsKey(HEADS.get(table.name())) && !complete.contains(fk.parent())) return false;
        return true;
    }
    private static void insertRows(TransferMapper mapper,Table table,List<Map<String,Object>> rows) {
        var self=table.foreignKeys().stream().filter(f->f.parent().equals(table.name())).toList();
        if(self.isEmpty()) { for(var row:rows) mapper.insert(table,row); return; }
        // ponytail: one table is held in memory; move to an external sort if a self-referencing table outgrows memory.
        Map<ForeignKey,Set<List<Object>>> available=new HashMap<>();
        for(var fk:self) available.put(fk,new HashSet<>());
        List<Map<String,Object>> pending=new ArrayList<>(rows);
        while(!pending.isEmpty()) {
            boolean progress=false;
            for(var iterator=pending.iterator();iterator.hasNext();) {
                var row=iterator.next(); boolean ready=true;
                for(var fk:self) {
                    var key=fk.columns().keySet().stream().map(row::get).toList();
                    if(key.stream().noneMatch(Objects::isNull) && !available.get(fk).contains(key)) { ready=false; break; }
                }
                if(!ready) continue;
                mapper.insert(table,row);
                for(var fk:self) available.get(fk).add(fk.columns().values().stream().map(row::get).toList());
                iterator.remove(); progress=true;
            }
            if(!progress) throw new IllegalStateException("TRANSFER_ROW_CYCLE");
        }
    }
    private static void normalize(Map<String,Object> row,Table table) {
        for(var column:table.columns().entrySet()) {
            Object value=row.get(column.getKey());
            if(value instanceof Number number) {
                if(column.getValue()==Types.BOOLEAN || column.getValue()==Types.BIT) row.put(column.getKey(),number.intValue()!=0);
                else if(Set.of(Types.BIGINT,Types.INTEGER,Types.SMALLINT,Types.TINYINT).contains(column.getValue())) row.put(column.getKey(),number.longValue());
            }
        }
    }
    private static Map<Map<String,Object>,Integer> multiset(List<Map<String,Object>> rows) {
        Map<Map<String,Object>,Integer> counts=new HashMap<>();
        for(var source:rows) {
            Map<String,Object> row=new HashMap<>();
            for(var entry:source.entrySet()) if(entry.getValue()!=null) row.put(entry.getKey(),entry.getValue() instanceof byte[] bytes?Base64.getEncoder().encodeToString(bytes):entry.getValue() instanceof Number number?new java.math.BigDecimal(number.toString()).stripTrailingZeros():entry.getValue());
            counts.merge(row,1,Integer::sum);
        }
        return counts;
    }
    private static Map<String,Table> inventory(SqlSession session) {
        try {
            DatabaseMetaData metadata=session.getConnection().getMetaData();
            boolean postgres=metadata.getDatabaseProductName().equals("PostgreSQL"); String schema=postgres?"public":null;
            Map<String,Table> tables=new TreeMap<>();
            try(var result=metadata.getTables(null,schema,"%",new String[]{"TABLE"})) {
                while(result.next()) {
                    String name=result.getString("TABLE_NAME");
                    if(name.equals("flyway_schema_history") || name.startsWith("sqlite_")) continue;
                    TransferMapper.Sql.name(name); tables.put(name,new Table(name,new LinkedHashMap<>(),new ArrayList<>()));
                }
            }
            for(var table:tables.values()) {
                try(var columns=metadata.getColumns(null,schema,table.name(),"%")) { while(columns.next()) table.columns().put(columns.getString("COLUMN_NAME"),columns.getInt("DATA_TYPE")); }
                Map<String,ForeignKey> keys=new LinkedHashMap<>();
                if(!postgres) {
                    // Xerial reports blank FK names and interleaves composite keys; SQLite's FK id is unambiguous.
                    for(var foreign:session.getMapper(TransferMapper.class).sqliteKeys(table.name())) {
                        var key=keys.computeIfAbsent(Integer.toString(foreign.id()),ignored->new ForeignKey(foreign.parent(),new LinkedHashMap<>()));
                        key.columns().put(foreign.childColumn(),foreign.parentColumn());
                    }
                } else {
                    try(var foreign=metadata.getImportedKeys(null,schema,table.name())) {
                        while(foreign.next()) {
                            String name=foreign.getString("FK_NAME"),parent=foreign.getString("PKTABLE_NAME");
                            var key=keys.computeIfAbsent(name,ignored->new ForeignKey(parent,new LinkedHashMap<>()));
                            key.columns().put(foreign.getString("FKCOLUMN_NAME"),foreign.getString("PKCOLUMN_NAME"));
                        }
                    }
                }
                table.foreignKeys().addAll(keys.values());
            }
            return tables;
        } catch(SQLException e) { throw new IllegalStateException("TRANSFER_SCHEMA_UNAVAILABLE"); }
    }
    public static void main(String[] args) throws Exception {
        if(args.length!=2 || !args[0].equals("--offline-snapshot")) throw new IllegalArgumentException("Usage: RepositoryTransfer --offline-snapshot BACKUP/platform.db; target credentials are GATEWAY_TRANSFER_URL/USER/PASSWORD");
        Path snapshot=Path.of(args[1]).toAbsolutePath();
        if(!Files.isRegularFile(snapshot) || Files.exists(Path.of(snapshot+"-wal")) || Files.exists(Path.of(snapshot+"-journal"))) throw new IllegalArgumentException("CONSISTENT_BACKUP_SNAPSHOT_REQUIRED");
        String url=System.getenv("GATEWAY_TRANSFER_URL");
        if(url==null || !url.startsWith("jdbc:postgresql:")) throw new IllegalArgumentException("POSTGRESQL_TARGET_REQUIRED");
        Path staging=Files.createTempDirectory("gateway-transfer-"); Path copy=staging.resolve("platform.db");
        try {
            Files.copy(snapshot,copy);
            try(var source=new PlatformStore(copy);var target=new PlatformStore(url,Objects.toString(System.getenv("GATEWAY_TRANSFER_USER"),""),Objects.toString(System.getenv("GATEWAY_TRANSFER_PASSWORD"),""),1,5000)) {
                var report=transfer(source,target);
                System.out.println("Transfer verified: "+report.rows().size()+" tables; target Flyway history preserved. No gateway was started.");
            }
        } finally {
            for(String suffix:List.of("-wal","-shm","-journal","")) Files.deleteIfExists(Path.of(copy+suffix));
            Files.deleteIfExists(staging);
        }
    }
}
