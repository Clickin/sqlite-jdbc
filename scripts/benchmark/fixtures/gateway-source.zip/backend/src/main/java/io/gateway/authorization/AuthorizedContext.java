package io.gateway.authorization;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/** Only the policy enforcement point can construct a context. */
public final class AuthorizedContext {
    private final AuthenticatedPrincipal principal;
    private final String action;
    private final CanonicalTarget target;
    private final String decisionId;
    final String bindingId;
    final Set<String> roles;
    final Map<String,String> securityState;
    final long principalGeneration;
    final long sessionGeneration;
    AuthorizedContext(AuthenticatedPrincipal principal, String action, CanonicalTarget target, String decisionId,
                      String bindingId, Set<String> roles, Map<String,String> securityState, long principalGeneration, long sessionGeneration) {
        this.principal=principal; this.action=action; this.target=target; this.decisionId=decisionId;
        this.bindingId=bindingId; this.roles=Set.copyOf(roles); this.securityState=Map.copyOf(securityState);
        this.principalGeneration=principalGeneration; this.sessionGeneration=sessionGeneration;
    }
    public String principalId() { return principal.principalId(); }
    public String clientId() { return principal.clientId(); }
    public String grantId() { return principal.grantId(); }
    public AuthenticatedPrincipal principal() { return principal; }
    public String action() { return action; }
    public CanonicalTarget target() { return target; }
    public String decisionId() { return decisionId; }
    public Map<String,Object> parameters() {
        Map<String,Object> result = new HashMap<>(target.parameters());
        result.put("principalId",principalId()); result.put("subject",principal.subject());
        result.put("identityProvider",principal.identityProvider());
        result.put("action",action);
        if (clientId()!=null) result.put("clientId",clientId());
        if (grantId()!=null) result.put("grantId",grantId());
        return Map.of("authorized",Map.copyOf(result));
    }
}
