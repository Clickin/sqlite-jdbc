package io.gateway.mcp;

import io.gateway.GatewayExecutionService;
import io.gateway.authorization.*;
import io.gateway.runtime.Cancellation;
import io.modelcontextprotocol.server.*;
import io.modelcontextprotocol.spec.*;
import io.modelcontextprotocol.common.McpTransportContext;
import jakarta.annotation.PreDestroy;
import jakarta.inject.Singleton;
import reactor.core.publisher.Mono;
import tools.jackson.databind.json.JsonMapper;
import java.util.*;

/** No SDK session or caller-specific global registry. Registry replacement is leased. */
@Singleton
public final class McpSdkBridge {
    private static final String EXCHANGE="gateway.exchange";
    private final ToolCatalog catalog;
    private final GatewayExecutionService gateway;
    private final JsonMapper json=JsonMapper.builder().build();
    private Registry current;
    public McpSdkBridge(ToolCatalog catalog,GatewayExecutionService gateway){this.catalog=catalog;this.gateway=gateway;}
    private static final class Exchange {
        final AuthenticatedPrincipal principal;final Cancellation cancellation;
        AccessDenied denied;
        boolean invoked;
        Exchange(AuthenticatedPrincipal principal,Cancellation cancellation){this.principal=principal;this.cancellation=cancellation;}
    }
    private static final class Transport implements McpStatelessServerTransport {
        McpStatelessServerHandler handler;
        @Override public void setMcpHandler(McpStatelessServerHandler handler){this.handler=handler;}
        @Override public Mono<Void> closeGracefully(){return Mono.empty();}
        @Override public List<String> protocolVersions(){return List.of(Mcp2026Adapter.VERSION);}
    }
    private static final class Registry {
        final String key;final Transport transport;final McpStatelessSyncServer server;
        int leases;boolean retired;
        Registry(String key,Transport transport,McpStatelessSyncServer server){this.key=key;this.transport=transport;this.server=server;}
    }

    @SuppressWarnings("unchecked")
    public Map<String,Object> dispatch(Mcp2026Adapter.Request request,AuthenticatedPrincipal principal,Cancellation cancellation) {
        if(request.rpc().method().equals("server/discover"))return Map.of("supportedVersions",List.of(Mcp2026Adapter.VERSION),"capabilities",Map.of("tools",Map.of()));
        var registry=acquire();
        try {
            var exchange=new Exchange(principal,cancellation);
            var response=registry.transport.handler.handleRequest(McpTransportContext.create(Map.of(EXCHANGE,exchange)),request.rpc()).block();
            if(exchange.denied!=null)throw exchange.denied;
            if(response==null)throw new IllegalStateException("MCP_EMPTY_RESULT");
            if(response.error()!=null)throw new Mcp2026Adapter.ProtocolFailure(response.error().code()==-32601?404:400,
                    response.error().code(),"Invalid MCP request",request.rpc().id(),Map.of());
            Map<String,Object> result=json.convertValue(response.result(),Map.class);
            if(request.rpc().method().equals("tools/call")&&Boolean.TRUE.equals(result.get("isError"))&&result.get("structuredContent")==null){
                String code=exchange.invoked?"EXECUTION_UNAVAILABLE":"INVALID_ARGUMENTS";
                String outcome=exchange.invoked?"OUTCOME_UNKNOWN":"NOT_EXECUTED";
                result=new LinkedHashMap<>(result);
                result.put("structuredContent",Map.of("status",exchange.invoked?"OUTCOME_UNKNOWN":"FAILED","businessOutcome",outcome,"responseOutcome","PREPARED","error",Map.of("code",code)));
                result.put("content",List.of(Map.of("type","text","text",code)));
            }
            if(request.rpc().method().equals("tools/list")) {
                Set<String> names=new HashSet<>();
                for(var visible:catalog.visible(principal))names.add(visible.tool().name());
                var tools=(List<Map<String,Object>>)result.getOrDefault("tools",List.of());
                result=new LinkedHashMap<>(result);
                result.put("tools",tools.stream().filter(t->names.contains(t.get("name"))).sorted(Comparator.comparing(t->(String)t.get("name"))).toList());
                result.remove("nextCursor");
            }
            return result;
        } finally { release(registry); }
    }

    private synchronized Registry acquire() {
        var tools=catalog.registered();
        String key=tools.stream().map(t->t.objectId()+":"+t.versionId()+":"+t.generation()).reduce("",(a,b)->a+"|"+b);
        if(current==null||!current.key.equals(key)) {
            var transport=new Transport();
            var builder=McpServer.sync(transport).immediateExecution(true).serverInfo("gateway","0.1.0")
                    .capabilities(McpSchema.ServerCapabilities.builder().tools(false).build());
            for(var tool:tools) {
                var snapshot=catalog.tool(tool.name());
                var descriptor=json.convertValue(catalog.descriptor(snapshot),McpSchema.Tool.class);
                builder.toolCall(descriptor,(context,request)->{
                    var exchange=(Exchange)context.get(EXCHANGE);
                    if(exchange==null)throw AccessDenied.unauthenticated();
                    exchange.invoked=true;
                    try {
                        var result=gateway.executeTool(exchange.principal,request.name(),request.arguments(),exchange.cancellation);
                        return McpSchema.CallToolResult.builder().structuredContent(result)
                            .addTextContent((String)result.get("status")).isError(!"SUCCEEDED".equals(result.get("status"))).build();
                    } catch(AccessDenied denied) {
                        exchange.denied=denied;
                        return McpSchema.CallToolResult.builder().addTextContent("Access denied").isError(true).build();
                    } catch(io.gateway.contracts.ContractService.InvalidContract invalid) {
                        var result=Map.of("status","FAILED","businessOutcome","NOT_EXECUTED","responseOutcome","PREPARED","error",Map.of("code","INVALID_ARGUMENTS"));
                        return McpSchema.CallToolResult.builder().structuredContent(result).addTextContent("INVALID_ARGUMENTS").isError(true).build();
                    }
                });
            }
            Registry next=new Registry(key,transport,builder.build());
            if(current!=null){current.retired=true;if(current.leases==0)current.server.closeGracefully();}
            current=next;
        }
        current.leases++;return current;
    }
    private synchronized void release(Registry registry){registry.leases--;if(registry.retired&&registry.leases==0)registry.server.closeGracefully();}
    @PreDestroy public synchronized void close(){if(current!=null){current.retired=true;if(current.leases==0)current.server.closeGracefully();current=null;}}
}
