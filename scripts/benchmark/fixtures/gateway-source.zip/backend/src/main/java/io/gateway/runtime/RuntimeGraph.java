package io.gateway.runtime;

import io.gateway.connectors.OperationAdapter;
import io.gateway.connectors.jdbc.JdbcResources;
import io.gateway.connectors.http.HttpResources;
import io.gateway.convert.ConverterEngine;
import io.gateway.definitions.Definitions.*;
import io.micronaut.context.annotation.Parameter;
import io.micronaut.context.annotation.Prototype;
import jakarta.annotation.PreDestroy;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Created and destroyed by BeanContext; registry owns cache and request references. */
@Prototype
public final class RuntimeGraph {
    private final ResolvedGraph definitions;
    private final Map<String,OperationAdapter> operations;
    private final Map<String,ConverterEngine> converters;
    private final AtomicBoolean closed=new AtomicBoolean();
    public RuntimeGraph(@Parameter ResolvedGraph definitions,JdbcResources jdbc,HttpResources http){
        this.definitions=definitions;Map<String,OperationAdapter> adapters=new HashMap<>();Map<String,ConverterEngine> conversions=new HashMap<>();
        try {for(var entry:definitions.definitions().entrySet())switch(entry.getValue().detail()){
            case JdbcOperation operation -> adapters.put(entry.getKey(),jdbc.prepare(definitions,operation));
            case HttpOperation operation -> adapters.put(entry.getKey(),http.prepare(definitions,operation));
            case Converter converter -> conversions.put(entry.getKey(),new ConverterEngine(definitions,converter));
            default -> {}
        };}catch(RuntimeException e){adapters.values().forEach(OperationAdapter::close);throw e;}
        operations=Map.copyOf(adapters);converters=Map.copyOf(conversions);
    }
    public ResolvedGraph definitions(){return definitions;}
    Payload execute(String operation,Payload input,Cancellation cancellation){if(closed.get())throw new IllegalStateException("RUNTIME_CLOSED");OperationAdapter adapter=operations.get(operation);if(adapter==null)throw new IllegalArgumentException("OPERATION_NOT_RESOLVED");return adapter.execute(input,cancellation);}
    public Payload convert(String converter,Payload input){if(closed.get())throw new IllegalStateException("RUNTIME_CLOSED");ConverterEngine engine=converters.get(converter);if(engine==null)throw new IllegalArgumentException("CONVERTER_NOT_RESOLVED");return engine.convert(input);}
    @PreDestroy public void close(){if(closed.compareAndSet(false,true))for(OperationAdapter adapter:operations.values())adapter.close();}
}
