package io.gateway.oauth;

import com.nimbusds.oauth2.sdk.AuthorizationRequest;
import io.gateway.authorization.*;
import io.gateway.identity.Authority;
import io.gateway.persistence.PlatformStore;
import io.micronaut.serde.annotation.Serdeable;
import jakarta.inject.Singleton;
import java.util.*;
import org.apache.ibatis.session.SqlSession;
import static io.gateway.oauth.BrowserSessionService.*;
import static io.gateway.oauth.OAuthProtocol.*;

@Singleton
public final class OAuthService {
    @Serdeable public record ActionTarget(String action,CanonicalTarget target) {}
    @Serdeable public record Consent(String purpose,List<ActionTarget> actionTargets,boolean approve) {}
    @Serdeable public record RequestView(String requestId,String clientName,List<String> scopes,List<String> actions,long expiresAt) {}
    private record Check(SecurityMapper.Action action,CanonicalTarget target,Authority.Decision decision) {}
    private record Snapshot(OAuthMapper.Grant grant,OAuthMapper.Client client,SecurityMapper.Principal principal,String bindingVersion,List<Check> checks) {}
    private final PlatformStore store;
    private final OAuthSettings settings;
    private final BrowserSessionService sessions;
    private final Authority authority;
    public OAuthService(PlatformStore store,OAuthSettings settings,BrowserSessionService sessions,Authority authority){this.store=store;this.settings=settings;this.sessions=sessions;this.authority=authority;}
    public String begin(Map<String,List<String>> parameters,String sessionCookie){
        singletons(parameters);
        String clientId=required(parameters,"client_id"),redirect=required(parameters,"redirect_uri");
        var client=store.read(s->s.getMapper(OAuthMapper.class).client(clientId));
        if(client==null||!redirectAllowed(redirect,client,store.read(s->s.getMapper(OAuthMapper.class).redirects(client.versionId()))))throw new Failure("invalid_request");
        String state=optional(parameters,"state");
        try {
            AuthorizationRequest parsed=authorization(parameters);
            if(!"code".equals(parsed.getResponseType().toString()))throw new Failure("unsupported_response_type");
            if(!"S256".equals(required(parameters,"code_challenge_method"))||!required(parameters,"code_challenge").matches("[A-Za-z0-9_-]{43}"))throw new Failure("invalid_request");
            if(state!=null&&state.length()>4096)throw new Failure("invalid_request");
            if(!Set.of("response_type","client_id","redirect_uri","scope","state","resource","code_challenge","code_challenge_method","response_mode").containsAll(parameters.keySet())||(parameters.containsKey("response_mode")&&!"query".equals(optional(parameters,"response_mode"))))throw new Failure("invalid_request");
            String resourceUri=required(parameters,"resource");
            var resource=store.read(s->s.getMapper(OAuthMapper.class).resource(client.versionId(),resourceUri));if(resource==null)throw new Failure("invalid_target");
            List<OAuthMapper.Scope> scopes=selectScopes(required(parameters,"scope"),store.read(s->s.getMapper(OAuthMapper.class).scopes(client.versionId())));
            var browser=sessions.require(sessionCookie);
            String id=Secrets.random("ar");var encrypted=Secrets.encrypt(settings.stateKey,id,state);
            store.write(s->{long now=System.currentTimeMillis();var m=s.getMapper(OAuthMapper.class);currentClient(m,client);if(!valid(m.sessionById(browser.id()),now))throw AccessDenied.unauthenticated();
                m.insertRequest(values("id",id,"client",client.id(),"version",client.versionId(),"generation",client.generation(),"resource",resource.id(),"redirect",redirect,"challenge",required(parameters,"code_challenge"),"cipher",encrypted.cipher(),"keyId",state==null?null:"configured","nonce",encrypted.nonce(),"tag",encrypted.tag(),"session",browser.id(),"now",now,"expires",now+settings.requestTtl,"binding",Secrets.digest(id)));
                for(var scope:scopes)m.requestScope(id,scope.id());return null;});
            return id;
        }catch(Failure failure){throw new Failure(failure.error(),response(redirect,"error",failure.error(),state,settings.issuer));}
    }
    public RequestView request(String id,String cookie){var browser=sessions.require(cookie);return store.read(s->{var m=s.getMapper(OAuthMapper.class);var request=requireRequest(m,id,browser.id());var client=m.clientById(request.clientId());if(client==null)throw AccessDenied.denied();return new RequestView(id,client.displayName(),m.requestScopes(id).stream().map(OAuthMapper.Scope::name).toList(),m.requestActions(id),request.expiresAt());});}
    public String consent(String id,String cookie,String origin,String csrf,Consent consent){
        sessions.requireCsrf(cookie,origin,csrf);var browser=sessions.require(cookie);
        if(!"USER".equals(browser.kind())||browser.principalId()==null)throw AccessDenied.unauthenticated();
        var request=store.read(s->requireRequest(s.getMapper(OAuthMapper.class),id,browser.id()));
        String state=Secrets.decrypt(settings.stateKey,id,request.stateCipher(),request.stateNonce(),request.stateTag());
        if(!consent.approve()) {rejectRequest(request,browser,"DENY");return response(request.redirectUri(),"error","access_denied",state,settings.issuer);}
        if(consent.purpose()==null||consent.purpose().isBlank()||consent.purpose().length()>128||consent.actionTargets()==null||consent.actionTargets().isEmpty()||consent.actionTargets().size()>64||new HashSet<>(consent.actionTargets()).size()!=consent.actionTargets().size())throw new Failure("invalid_request");
        var client=store.read(s->s.getMapper(OAuthMapper.class).clientById(request.clientId()));
        var principal=store.read(s->s.getMapper(SecurityMapper.class).principal(browser.principalId()));
        if(client==null||principal==null||principal.blocked()||client.generation()!=request.clientGeneration())throw AccessDenied.denied();
        String bindingVersion=bindingVersion();
        List<String> allowed=store.read(s->s.getMapper(OAuthMapper.class).requestActions(id));List<Check> checks=new ArrayList<>();
        try {for(var candidate:consent.actionTargets()) {if(candidate==null||candidate.action()==null||candidate.target()==null||!allowed.contains(candidate.action()))throw AccessDenied.denied();checks.add(check(principal,candidate.action(),candidate.target()));}}
        catch(AccessDenied failure){rejectRequest(request,browser,failure.outcome().name());return response(request.redirectUri(),"error","access_denied",state,settings.issuer);}
        String grantId=UUID.randomUUID().toString(),code=Secrets.random("ac"),codeId=UUID.randomUUID().toString();
        store.write(s->{long now=System.currentTimeMillis();var m=s.getMapper(OAuthMapper.class);requireRequest(m,id,browser.id());var currentSession=m.sessionById(browser.id());if(!valid(currentSession,now)||!Objects.equals(currentSession.principalId(),principal.id()))throw AccessDenied.unauthenticated();currentClient(m,client);checkLocal(s,principal,client,bindingVersion,checks,request.resourceId());
            if(m.finishRequest(id,"COMPLETED",now)!=1)throw new Failure("invalid_request");
            m.insertGrant(values("id",grantId,"principal",principal.id(),"client",client.id(),"resource",request.resourceId(),"purpose",consent.purpose(),"authenticated",browser.authenticatedAt(),"now",now,"expires",now+settings.grantTtl,"generation",principal.generation()));
            for(var item:checks)m.insertRule(values("id",UUID.randomUUID().toString(),"grant",grantId,"action",item.action.id(),"semantic",item.action.semanticVersion(),"target",item.target,"decision",item.decision.decisionId()));
            for(var scope:m.requestScopes(id))m.grantScope(grantId,scope.id());
            m.insertCode(values("id",codeId,"digest",Secrets.digest(code),"request",id,"grant",grantId,"client",client.id(),"resource",request.resourceId(),"redirect",request.redirectUri(),"challenge",request.challenge(),"now",now,"expires",now+settings.codeTtl));
            audit(m,"CODE_ISSUED",principal.id(),client.id(),grantId,codeId,"ALLOW",null,now,null);return null;});
        return response(request.redirectUri(),"code",code,state,settings.issuer);
    }
    private void rejectRequest(OAuthMapper.Request request,OAuthMapper.Session session,String outcome){store.write(s->{var m=s.getMapper(OAuthMapper.class);requireRequest(m,request.id(),session.id());m.finishRequest(request.id(),"REJECTED",System.currentTimeMillis());audit(m,"CONSENT_REJECTED",session.principalId(),request.clientId(),null,null,outcome,null,System.currentTimeMillis(),null);return null;});}
    private OAuthMapper.Request requireRequest(OAuthMapper mapper,String id,String sessionId){var request=mapper.request(id);if(request==null||!Secrets.matches(id,request.bindingDigest())||!Objects.equals(request.sessionId(),sessionId)||!request.status().equals("OPEN")||request.expiresAt()<=System.currentTimeMillis())throw AccessDenied.denied();return request;}
    public Map<String,Object> token(String body,String authorization){
        var parameters=form(body,authorization,settings.issuer+"/oauth/token",true);
        var client=authenticateClient(parameters,authorization);
        try { return switch(required(parameters,"grant_type")){case "authorization_code"->exchange(parameters,client);case "refresh_token"->refresh(parameters,client);default->throw new Failure("unsupported_grant_type");}; }
        catch(AccessDenied failure) {
            store.write(s->{audit(s.getMapper(OAuthMapper.class),"TOKEN_REJECTED",null,client.id(),null,null,failure.outcome().name(),failure.code(),System.currentTimeMillis(),failure.decisionId());return null;});
            throw new Failure(failure.outcome()==AccessDenied.Outcome.UNAVAILABLE?"temporarily_unavailable":"invalid_grant");
        }
    }
    private OAuthMapper.Client authenticateClient(Map<String,List<String>> parameters,String authorization){
        String clientId=optional(parameters,"client_id");char[] secret=null;
        if(parameters.containsKey("client_secret")||parameters.containsKey("client_assertion"))throw new Failure("invalid_client");
        if(authorization!=null){var basic=basic(authorization);if(clientId!=null&&!clientId.equals(basic.getClientID().getValue()))throw new Failure("invalid_client");clientId=basic.getClientID().getValue();secret=basic.getClientSecret().getValue().toCharArray();}
        if(clientId==null)throw new Failure("invalid_client");
        String selected=clientId;var client=store.read(s->s.getMapper(OAuthMapper.class).client(selected));
        if(client==null)throw new Failure("invalid_client");
        try {
            if(client.clientType().equals("PUBLIC_NATIVE")){if(secret!=null||!client.authMethod().equals("none"))throw new Failure("invalid_client");}
            else {if(secret==null||!client.authMethod().equals("client_secret_basic"))throw new Failure("invalid_client");boolean matches=false;for(var stored:store.read(s->s.getMapper(OAuthMapper.class).secrets(client.id(),System.currentTimeMillis())))if(stored.kdf().equals("PBKDF2_SHA256"))matches|=Secrets.verify(secret,stored.digest(),stored.salt(),stored.iterations(),stored.keyLength());if(!matches)throw new Failure("invalid_client");}
        }finally{if(secret!=null)Arrays.fill(secret,'\0');}
        return client;
    }
    private Map<String,Object> exchange(Map<String,List<String>> p,OAuthMapper.Client client){
        String raw=required(p,"code");if(!raw.matches("ac_[A-Za-z0-9_-]{43}"))throw new Failure("invalid_grant");
        var code=store.read(s->s.getMapper(OAuthMapper.class).code(Secrets.digest(raw)));
        if(code==null||code.clientGeneration()!=client.generation()||code.consumedAt()!=null||code.revokedAt()!=null||code.expiresAt()<=System.currentTimeMillis()||!client.id().equals(code.clientId())||!required(p,"redirect_uri").equals(code.redirectUri())||!pkce(optional(p,"code_verifier"),code.challenge()))throw new Failure("invalid_grant");
        var snapshot=prepareGrant(code.grantId(),client,required(p,"resource"));
        var scopes=store.read(s->s.getMapper(OAuthMapper.class).grantScopes(code.grantId()));
        if(p.containsKey("scope"))throw new Failure("invalid_request");
        return store.write(s->{var m=s.getMapper(OAuthMapper.class);finalGrant(s,snapshot);long now=System.currentTimeMillis();if(m.consumeCode(code.id(),now)!=1)throw new Failure("invalid_grant");return issue(m,snapshot,scopes,null,null,now);});
    }
    private Map<String,Object> refresh(Map<String,List<String>> p,OAuthMapper.Client client){
        if(!client.refreshEnabled())throw new Failure("unauthorized_client");
        if(p.containsKey("patient")||p.containsKey("patientId")||p.containsKey("authorization_details"))throw new Failure("invalid_request");
        String raw=required(p,"refresh_token");if(!raw.matches("rt_[A-Za-z0-9_-]{43}"))throw new Failure("invalid_grant");String digest=Secrets.digest(raw);
        var previous=store.read(s->s.getMapper(OAuthMapper.class).refresh(digest));
        if(previous==null)throw new Failure("invalid_grant");
        var grant=store.read(s->s.getMapper(OAuthMapper.class).grant(previous.grantId()));if(grant==null||!grant.clientId().equals(client.id()))throw new Failure("invalid_grant");
        if(previous.consumedAt()!=null){store.write(s->{var m=s.getMapper(OAuthMapper.class);var current=lockedRefresh(m,previous.familyId(),digest);if(current.consumedAt()!=null)replay(m,current,grant,System.currentTimeMillis());return null;});throw new Failure("invalid_grant");}
        if(previous.revokedAt()!=null||previous.familyRevokedAt()!=null||previous.expiresAt()<=System.currentTimeMillis()||previous.familyExpiresAt()<=System.currentTimeMillis())throw new Failure("invalid_grant");
        var snapshot=prepareGrant(previous.grantId(),client,required(p,"resource"));
        var oldScopes=store.read(s->s.getMapper(OAuthMapper.class).refreshScopes(previous.id()));
        var scopes=p.containsKey("scope")?selectScopes(required(p,"scope"),oldScopes):oldScopes;
        var response=store.write(s->{var m=s.getMapper(OAuthMapper.class);var current=lockedRefresh(m,previous.familyId(),digest);long now=System.currentTimeMillis();
            if(current.consumedAt()!=null){replay(m,current,grant,now);return null;}
            if(current.familyRevokedAt()!=null||current.revokedAt()!=null||current.familyExpiresAt()<=now||current.expiresAt()<=now||!current.id().equals(current.currentTokenId()))throw new Failure("invalid_grant");
            finalGrant(s,snapshot);
            if(m.consumeRefresh(current.id(),now)!=1){replay(m,current,grant,now);return null;}
            return issue(m,snapshot,scopes,current.familyId(),current,now);
        });
        if(response==null)throw new Failure("invalid_grant");return response;
    }
    private Snapshot prepareGrant(String grantId,OAuthMapper.Client client,String resource){
        var grant=store.read(s->s.getMapper(OAuthMapper.class).grant(grantId));if(grant==null||grant.revokedAt()!=null||grant.expiresAt()<=System.currentTimeMillis()||!grant.clientId().equals(client.id()))throw new Failure("invalid_grant");
        var expected=store.read(s->s.getMapper(OAuthMapper.class).resource(client.versionId(),resource));if(expected==null||!expected.id().equals(grant.resourceId()))throw new Failure("invalid_target");
        var principal=store.read(s->s.getMapper(SecurityMapper.class).principal(grant.principalId()));if(principal==null||principal.blocked())throw new Failure("invalid_grant");
        String binding=bindingVersion();var rules=store.read(s->s.getMapper(SecurityMapper.class).rules(grantId));if(rules.isEmpty())throw new Failure("invalid_grant");List<Check> checks=new ArrayList<>();
        for(var rule:rules){var action=store.read(s->s.getMapper(GrantActionMapper.class).actionById(rule.actionId()));if(action==null||action.semanticVersion()!=rule.semanticVersion())throw new Failure("invalid_grant");checks.add(check(principal,action.actionKey(),rule.target()));}
        return new Snapshot(grant,client,principal,binding,List.copyOf(checks));
    }
    private Check check(SecurityMapper.Principal principal,String actionKey,CanonicalTarget target){
        var action=store.read(s->s.getMapper(SecurityMapper.class).action(actionKey));if(action==null||!action.targetKind().equals(target.targetKind()))throw AccessDenied.denied();
        var actual=authority.resolve(principal.providerId(),principal.subject(),actionKey,target,null);if(!target.equals(actual))throw AccessDenied.denied();
        var decision=authority.decide(principal.providerId(),principal.subject(),actionKey,actual);if(!decision.outcome().equals("ALLOW"))throw new AccessDenied(AccessDenied.Outcome.valueOf(decision.outcome()),"authority_rejected");
        return new Check(action,actual,decision);
    }
    private String bindingVersion(){var b=store.read(s->s.getMapper(SecurityMapper.class).binding(authority.securityBindingId()));if(b==null)throw AccessDenied.denied();return b.versionId();}
    private void checkLocal(SqlSession s,SecurityMapper.Principal observed,OAuthMapper.Client client,String bindingVersion,List<Check> checks,String resourceId){
        var m=s.getMapper(SecurityMapper.class);var p=m.principal(observed.id());var b=m.binding(authority.securityBindingId());var resource=s.getMapper(OAuthMapper.class).resourceById(resourceId);
        if(p==null||p.blocked()||p.generation()!=observed.generation()||b==null||!b.versionId().equals(bindingVersion)||resource==null)throw AccessDenied.denied();
        for(var check:checks){var action=m.action(check.action.actionKey());if(action==null||action.semanticVersion()!=check.action.semanticVersion()||check.decision.roles().isEmpty()||m.roleAction(authority.securityBindingId(),action.id(),action.semanticVersion(),check.decision.roles())==0||m.clientAction(client.id(),action.id(),action.semanticVersion(),resource.uri())==0)throw AccessDenied.denied();}
    }
    private void finalGrant(SqlSession s,Snapshot snapshot){var m=s.getMapper(OAuthMapper.class);currentClient(m,snapshot.client);var grant=m.grant(snapshot.grant.id());if(grant==null||grant.revokedAt()!=null||grant.expiresAt()<=System.currentTimeMillis())throw new Failure("invalid_grant");checkLocal(s,snapshot.principal,snapshot.client,snapshot.bindingVersion,snapshot.checks,grant.resourceId());}
    private static void currentClient(OAuthMapper mapper,OAuthMapper.Client observed){var current=mapper.clientById(observed.id());if(current==null||current.generation()!=observed.generation()||!current.versionId().equals(observed.versionId()))throw new Failure("invalid_client");}
    private Map<String,Object> issue(OAuthMapper m,Snapshot snapshot,List<OAuthMapper.Scope> scopes,String family,OAuthMapper.Refresh predecessor,long now){
        String refresh=null;var grant=snapshot.grant;var client=snapshot.client;
        Set<String> current=new HashSet<>();for(var scope:m.scopes(client.versionId()))current.add(scope.id());if(scopes.isEmpty()||scopes.stream().anyMatch(v->!current.contains(v.id())))throw new Failure("invalid_scope");
        if(client.refreshEnabled()){
            long familyExpiry=predecessor==null?Math.min(now+settings.refreshTtl,grant.expiresAt()):predecessor.familyExpiresAt();
            if(family==null){family=UUID.randomUUID().toString();m.insertFamily(values("id",family,"grant",grant.id(),"now",now,"expires",familyExpiry));}
            refresh=Secrets.random("rt");String refreshId=UUID.randomUUID().toString();
            m.insertRefresh(values("id",refreshId,"family",family,"digest",Secrets.digest(refresh),"predecessor",predecessor==null?null:predecessor.id(),"now",now,"expires",familyExpiry));
            for(var scope:scopes)m.refreshScope(refreshId,scope.id());
            int changed=predecessor==null?m.initialHead(family,refreshId):m.rotateHead(family,predecessor.id(),refreshId,now);
            if(changed!=1)throw new Failure("invalid_grant");
        }
        String token=Secrets.random("at"),tokenId=UUID.randomUUID().toString();long expires=Math.min(now+settings.accessTtl,grant.expiresAt());
        if(client.refreshEnabled())expires=Math.min(expires,predecessor==null?now+settings.refreshTtl:predecessor.familyExpiresAt());
        m.insertAccess(values("id",tokenId,"digest",Secrets.digest(token),"grant",grant.id(),"family",family,"client",client.id(),"principal",grant.principalId(),"resource",grant.resourceId(),"now",now,"expires",expires));
        for(var scope:scopes)m.tokenScope(tokenId,scope.id());audit(m,predecessor==null?"TOKEN_ISSUED":"REFRESH_ROTATED",grant.principalId(),client.id(),grant.id(),tokenId,"ALLOW",null,now,null);
        Map<String,Object> result=new LinkedHashMap<>();result.put("access_token",token);result.put("token_type","Bearer");result.put("expires_in",(expires-now)/1000);result.put("scope",String.join(" ",scopes.stream().map(OAuthMapper.Scope::name).sorted().toList()));if(refresh!=null)result.put("refresh_token",refresh);return Map.copyOf(result);
    }
    private static OAuthMapper.Refresh lockedRefresh(OAuthMapper mapper,String family,String digest) {
        // Every family path takes this row before any token row, then rereads after waiting.
        if(mapper.lockFamily(family)!=1)throw new Failure("invalid_grant");
        var refresh=mapper.refresh(digest);
        if(refresh==null||!family.equals(refresh.familyId()))throw new Failure("invalid_grant");
        return refresh;
    }
    private static void replay(OAuthMapper m,OAuthMapper.Refresh refresh,OAuthMapper.Grant grant,long now){m.revokeFamily(refresh.familyId(),now);m.revokeFamilyAccess(refresh.familyId(),now);m.revokeFamilyRefresh(refresh.familyId(),now);audit(m,"REFRESH_REPLAY",grant.principalId(),grant.clientId(),grant.id(),refresh.id(),"DENY","refresh_reused",now,null);}
    private static List<OAuthMapper.Scope> selectScopes(String requested,List<OAuthMapper.Scope> allowed){Set<String> names=new HashSet<>(Arrays.asList(requested.split(" ",-1)));if(names.isEmpty()||names.contains("")||names.size()!=requested.split(" ",-1).length)throw new Failure("invalid_scope");List<OAuthMapper.Scope> selected=allowed.stream().filter(s->names.contains(s.name())).toList();if(selected.size()!=names.size())throw new Failure("invalid_scope");return selected;}
    public void revoke(String body,String authorization){
        var p=form(body,authorization,settings.issuer+"/oauth/revoke",false);var client=authenticateClient(p,authorization);
        String digest=Secrets.digest(required(p,"token"));
        store.write(s->{
            var m=s.getMapper(OAuthMapper.class);currentClient(m,client);long now=System.currentTimeMillis();
            var refresh=m.refresh(digest);
            if(refresh!=null){
                var grant=m.grant(refresh.grantId());
                if(grant!=null&&grant.clientId().equals(client.id())){
                    refresh=lockedRefresh(m,refresh.familyId(),digest);
                    m.revokeFamily(refresh.familyId(),now);m.revokeFamilyAccess(refresh.familyId(),now);m.revokeFamilyRefresh(refresh.familyId(),now);
                    audit(m,"TOKEN_REVOKED",grant.principalId(),client.id(),grant.id(),refresh.id(),"ALLOW",null,now,null);
                }
            }else{
                String id=m.ownedAccess(digest,client.id());
                if(id!=null){m.revokeAccess(id,now);audit(m,"TOKEN_REVOKED",null,client.id(),null,id,"ALLOW",null,now,null);}
            }
            return null;
        });
    }
    public void revokeGrant(String id,String actor){store.write(s->{var m=s.getMapper(OAuthMapper.class);m.revokeGrant(id,System.currentTimeMillis());audit(m,"GRANT_REVOKED",actor,null,id,null,"ALLOW",null,System.currentTimeMillis(),null);return null;});}
    public void revokeTokenRecord(String id,String actor){store.write(s->{var m=s.getMapper(OAuthMapper.class);m.revokeAccess(id,System.currentTimeMillis());audit(m,"TOKEN_REVOKED",actor,null,null,id,"ALLOW",null,System.currentTimeMillis(),null);return null;});}
    public void rotateClientSecret(String clientId,char[] secret,String actor){Secrets.PasswordHash hash;try{hash=Secrets.hash(secret);}finally{Arrays.fill(secret,'\0');}store.write(s->{var m=s.getMapper(OAuthMapper.class);var client=m.clientById(clientId);if(client==null||!client.clientType().equals("CONFIDENTIAL_WEB"))throw AccessDenied.denied();long now=System.currentTimeMillis();m.revokeSecrets(clientId,now);m.insertSecret(values("id",UUID.randomUUID().toString(),"client",clientId,"digest",hash.digest(),"salt",hash.salt(),"iterations",hash.iterations(),"keyLength",hash.keyLength(),"now",now));s.getMapper(GrantActionMapper.class).bumpClient(clientId);audit(m,"CLIENT_SECRET_ROTATED",actor,clientId,null,null,"ALLOW",null,now,null);return null;});}
    public void invalidateForRestore(){store.write(s->{var m=s.getMapper(OAuthMapper.class);long now=System.currentTimeMillis();m.invalidateSessions(now);m.invalidateCodes(now);m.invalidateFamilies(now);m.invalidateAccess(now);m.invalidateRefresh(now);m.invalidateGrants(now);m.invalidateRequests();audit(m,"RESTORE_AUTH_INVALIDATED",null,null,null,null,"ALLOW","restore",now,null);return null;});}
}
