package io.gateway.identity;

import io.gateway.authorization.CanonicalTarget;
import java.util.Set;

/** Implementations must verify identity against an authority, never trust a submitted subject. */
public interface Authority {
    record Identity(String providerId, String subject, boolean active) {}
    record Decision(String outcome, String decisionId, Set<String> roles) {
        public Decision { roles = Set.copyOf(roles); }
    }
    Identity authenticate(String credential);
    Decision decide(String providerId, String subject, String action, CanonicalTarget target);
    CanonicalTarget resolve(String providerId, String subject, String action, CanonicalTarget claimed, String targetPolicyId);
    Set<String> roles(String providerId, String subject);
    String securityBindingId();
}
