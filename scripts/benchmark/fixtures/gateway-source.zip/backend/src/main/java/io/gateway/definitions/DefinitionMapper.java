package io.gateway.definitions;

import io.gateway.persistence.PlatformMapper;
import org.apache.ibatis.annotations.*;
import java.util.*;
import static io.gateway.definitions.Definitions.*;

public interface DefinitionMapper extends PlatformMapper {
    String HEAD_COLUMNS="id,kind,logical_key AS logicalKey,current_version_id AS currentVersionId,revision_counter AS revisionCounter,generation,enabled";
    String VERSION_COLUMNS="id,object_id AS objectId,kind,revision,created_at AS createdAt,created_by AS createdBy,change_reason AS changeReason,display_name AS displayName,description";
    @Select("SELECT "+HEAD_COLUMNS+" FROM config_object WHERE id=#{id}") Head head(String id);
    @Select("SELECT "+HEAD_COLUMNS+" FROM config_object ORDER BY kind,logical_key") List<Head> heads();
    @Select("SELECT "+VERSION_COLUMNS+" FROM config_version WHERE id=#{id}") Version version(String id);
    @Select("SELECT "+VERSION_COLUMNS+" FROM config_version WHERE object_id=#{id} ORDER BY revision DESC") List<Version> history(String id);
    @Insert("INSERT INTO config_object(id,kind,logical_key,current_version_id,revision_counter,generation,enabled,created_at,created_by) VALUES(#{id},#{kind},#{key},NULL,0,0,TRUE,#{now},#{actor})")
    void create(@Param("id") String id,@Param("kind") String kind,@Param("key") String key,@Param("now") long now,@Param("actor") String actor);
    @Update("UPDATE config_object SET revision_counter=revision_counter+1 WHERE id=#{id}") int next(String id);
    @Insert("INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name,description) VALUES(#{id},#{objectId},#{kind},#{revision},#{createdAt},#{createdBy},#{changeReason},#{displayName},#{description})") void versionInsert(Version version);
    @Update("UPDATE config_object SET current_version_id=#{version},generation=generation+1 WHERE id=#{object} AND generation=#{generation}")
    int cas(@Param("object") String object,@Param("version") String version,@Param("generation") long generation);
    @Update("UPDATE config_object SET generation=generation WHERE id=#{object} AND current_version_id=#{version} AND enabled=TRUE")
    int lockDependency(@Param("object") String object,@Param("version") String version);
    @Insert("INSERT INTO configuration_change(id,object_id,before_version_id,after_version_id,before_generation,after_generation,actor_subject_id,reason,changed_at) VALUES(#{id},#{object},#{before},#{after},#{generation},#{nextGeneration},#{actor},#{reason},#{now})")
    void change(@Param("id") String id,@Param("object") String object,@Param("before") String before,@Param("after") String after,@Param("generation") long generation,@Param("nextGeneration") long nextGeneration,@Param("actor") String actor,@Param("reason") String reason,@Param("now") long now);
    @Select("SELECT revoked_at FROM credential_state WHERE credential_version_id=#{id}") Long revoked(String id);
    @Select("SELECT contract_object_id FROM contract_field WHERE id=#{id}") String fieldOwner(String id);
    @Select("SELECT logical_name FROM contract_field WHERE id=#{id}") String fieldName(String id);
    @Insert("INSERT INTO contract_field(id,contract_object_id,logical_name) VALUES(#{id},#{owner},#{name})") void fieldIdentity(@Param("id")String id,@Param("owner")String owner,@Param("name")String name);

    // Table and column identifiers are a closed, compiled allowlist, never caller input.
    enum Table {
        DATASOURCE("datasource_version","version_id","version_id,provider_id,max_concurrent,queue_timeout_ms"),
        JDBC_SOURCE("jdbc_datasource_version","version_id","version_id,jdbc_url,driver_profile_id,credential_object_id,pool_min_idle,pool_max_size,acquire_timeout_ms,read_only_policy"),
        HTTP_SOURCE("http_datasource_version","version_id","version_id,base_uri,authentication_kind,credential_object_id,tls_profile_object_id,proxy_profile_id,network_policy_object_id,pool_max_total,pool_max_per_route,connect_timeout_ms,redirect_policy"),
        HEADER("http_source_header","datasource_version_id","datasource_version_id,ordinal,header_name,literal_value,credential_part"),
        MAPPER("mapper_version","version_id","version_id,database_profile"),
        DOCUMENT("mapper_document","mapper_version_id","id,mapper_version_id,resource_name,xml_text,ordinal"),
        IMPORT("mapper_import","mapper_version_id","mapper_version_id,imported_mapper_object_id,ordinal"),
        OPERATION("operation_version","version_id","version_id,source_object_id,input_contract_object_id,output_contract_object_id,effect_kind,timeout_ms,max_result_rows,max_result_bytes"),
        JDBC_OPERATION("jdbc_operation_version","version_id","version_id,mapper_object_id,statement_id,execution_mode,transaction_mode"),
        OUT("jdbc_out_binding","operation_version_id","operation_version_id,out_parameter_name,output_field_id,result_map_name,ordinal"),
        HTTP_OPERATION("http_operation_version","version_id","version_id,method,relative_path_template,request_representation_object_id,response_representation_object_id"),
        PARAMETER("http_parameter_binding","operation_version_id","id,operation_version_id,location,ordinal,wire_name,input_field_id,literal_scalar,required"),
        STATUS("http_expected_status","operation_version_id","operation_version_id,status_code,interpretation"),
        REFERENCE_BINDING("operation_reference_binding","operation_version_id","operation_version_id,ordinal,reference_kind,output_url_field_id,origin_record_field_id,screen_profile_object_id,display_name"),
        CONTRACT("contract_version","version_id","version_id,model_kind"),
        FIELD("contract_field_version","contract_version_id","contract_version_id,field_id,parent_field_id,member_name,node_kind,value_type,ordinal,required,nullable,precision,scale,max_length,audit_disposition"),
        REPRESENTATION("representation_version","version_id","version_id,contract_object_id,codec_id,wire_profile,media_type,charset"),
        JSON_BINDING("json_field_binding","representation_version_id","representation_version_id,field_id,member_name,location"),
        XML_BINDING("xml_field_binding","representation_version_id","representation_version_id,field_id,namespace_uri,local_name,node_kind,ordinal,null_policy"),
        CONVERTER("converter_version","version_id","version_id,implementation_id,input_contract_object_id,output_contract_object_id"),
        RULE("conversion_rule","converter_version_id","id,converter_version_id,source_port,source_field_id,target_field_id,transform_code,ordinal"),
        ARGUMENT("conversion_argument","conversion_rule_id","conversion_rule_id,argument_name,value_type,string_value,integer_value,decimal_value,boolean_value"),
        WORKFLOW("workflow_version","version_id","version_id,error_mapping_object_id"),
        STAGE("workflow_stage","workflow_version_id","workflow_version_id,stage_key,stage_order,operation_object_id,converter_object_id"),
        PORT("workflow_port","workflow_version_id","workflow_version_id,direction,representation_object_id,status_code"),
        SECURITY_BINDING("workflow_security_binding","workflow_version_id","workflow_version_id,stage_key,security_binding_object_id,required_action_id,target_policy_object_id"),
        ERROR_MAPPING("error_mapping_version","version_id","version_id"),
        ERROR_RULE("error_mapping_rule","error_mapping_version_id","error_mapping_version_id,remote_code,public_code,status_code"),
        CREDENTIAL("credential_version","version_id","version_id,secret_kind,public_username,certificate_subject,certificate_issuer,certificate_serial,certificate_not_before_ms,certificate_not_after_ms");
        final String table,parent; final List<String> columns;
        Table(String table,String parent,String columns){this.table=table;this.parent=parent;this.columns=List.of(columns.split(","));}
    }
    @SelectProvider(type=Sql.class,method="rows") List<Map<String,Object>> rows(@Param("table")Table table,@Param("id")String id);
    @InsertProvider(type=Sql.class,method="insert") void insert(@Param("table")Table table,@Param("values")Map<String,Object> values);
    final class Sql {
        public static String rows(Map<String,Object> args) {
            Table t=(Table)args.get("table");
            String sql="SELECT "+String.join(",",t.columns)+" FROM "+t.table+" WHERE "+t.parent+"=#{id}";
            if(t.columns.contains("ordinal")) sql+=" ORDER BY ordinal";
            else if(t.columns.contains("stage_order")) sql+=" ORDER BY stage_order";
            return sql;
        }
        public static String insert(Map<String,Object> args) {
            Table t=(Table)args.get("table"); Map<?,?> values=(Map<?,?>)args.get("values");
            if(!t.columns.containsAll(values.keySet())) throw new IllegalArgumentException("UNSUPPORTED_COLUMN");
            List<String> columns=t.columns.stream().filter(values::containsKey).toList();
            return "INSERT INTO "+t.table+"("+String.join(",",columns)+") VALUES("+String.join(",",columns.stream().map(c->"#{values."+c+"}").toList())+")";
        }
    }
}
