package io.gateway.runtime;

/** Deliberately carries no raw SDK exception, SQL, remote body, or credential. */
public final class ExecutionFailure extends RuntimeException {
    public enum Outcome { FAILED_BEFORE_EFFECT, FAILED, OUTCOME_UNKNOWN, SUCCEEDED }
    private final String code;
    private final Outcome outcome;
    private final boolean responseFailed;
    public ExecutionFailure(String code, Outcome outcome) { this(code, outcome, false); }
    public ExecutionFailure(String code, Outcome outcome, boolean responseFailed) {
        super(code, null, false, false);
        this.code = code; this.outcome = outcome; this.responseFailed = responseFailed;
    }
    public String code() { return code; }
    public Outcome outcome() { return outcome; }
    public boolean responseFailed() { return responseFailed; }
}
