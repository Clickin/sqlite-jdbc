package io.gateway.authorization;

import io.gateway.persistence.PlatformMapper;
import java.util.List;
import org.apache.ibatis.annotations.Select;

public interface DiscoveryMapper extends PlatformMapper {
    @Select("SELECT s.scope_name FROM oauth_token_scope t JOIN oauth_scope s ON s.id=t.scope_id WHERE t.access_token_id=#{id}") List<String> tokenScopes(String id);
}
