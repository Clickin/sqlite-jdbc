package io.gateway.results;

import io.gateway.authorization.AuthenticatedPrincipal;
import io.gateway.authorization.AuthorizationService;
import io.gateway.results.ResultModels.*;
import io.micronaut.context.annotation.Value;
import io.micronaut.http.HttpHeaders;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.*;
import java.util.List;

@Controller("/api")
public final class ResultsController {
    private final ResultService results;
    private final AuthorizationService authorization;
    private final String resource;
    public ResultsController(ResultService results, AuthorizationService authorization,
            @Value("${gateway.oauth.rest-resource}") String resource) {
        this.results=results; this.authorization=authorization; this.resource=resource;
    }
    private AuthenticatedPrincipal principal(HttpRequest<?> request) {
        return authorization.authenticateBearer(request.getHeaders().getAll(HttpHeaders.AUTHORIZATION),resource);
    }
    @Get("/results") public HttpResponse<List<ResultSummary>> list(HttpRequest<?> request) { return secure(results.list(principal(request))); }
    @Post("/results") public HttpResponse<ResultDocument> create(HttpRequest<?> request,@Body CreateResult body) { return secure(results.create(principal(request),body)); }
    @Post("/results/{id}/revisions") public HttpResponse<ResultDocument> revise(HttpRequest<?> request,String id,@Body ReviseResult body) { return secure(results.revise(principal(request),id,body)); }
    @Get("/results/{id}") public HttpResponse<ResultDocument> read(HttpRequest<?> request,String id) { return secure(results.read(principal(request),id)); }
    @Get("/references/{id}") public HttpResponse<ResolvedReference> resolve(HttpRequest<?> request,String id) { return secure(results.resolve(principal(request),id)); }
    private static <T> HttpResponse<T> secure(T body) { return HttpResponse.ok(body).header(HttpHeaders.CACHE_CONTROL,"no-store").header("Referrer-Policy","no-referrer"); }
}
