package io.gateway.contracts;

import io.gateway.persistence.PlatformStore;
import jakarta.inject.Singleton;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.*;
import java.util.*;

/** The same immutable relational field tree generates the wire schema and validates values. */
@Singleton
public final class ContractService {
    public record Field(String id, String parentId, String name, String nodeKind, String valueType,
                        int ordinal, boolean required, boolean nullable, Integer precision,
                        Integer scale, Integer maxLength, String disposition) {}
    public record Contract(String version, List<Field> fields) {
        public Contract { fields = List.copyOf(fields); }
    }
    public static final class InvalidContract extends IllegalArgumentException {
        public InvalidContract() { super("INVALID_CONTRACT_OR_ARGUMENTS"); }
    }
    private final PlatformStore store;
    public ContractService(PlatformStore store) { this.store = store; }

    public Contract load(String version) {
        return store.read(session -> {
            var mapper = session.getMapper(ContractMapper.class);
            if (!"VALUE".equals(mapper.model(version))) throw new InvalidContract();
            var contract = new Contract(version, mapper.fields(version));
            schema(contract);
            return contract;
        });
    }

    public Map<String,Object> schema(Contract contract) {
        var tree = tree(contract);
        var result = objectSchema(tree.getOrDefault("", List.of()), tree, 0);
        result.put("$schema", "https://json-schema.org/draft/2020-12/schema");
        return Collections.unmodifiableMap(result);
    }

    public void validate(Contract contract, Map<String,Object> value) {
        if (value == null) throw new InvalidContract();
        var tree = tree(contract);
        validateObject(tree.getOrDefault("", List.of()), tree, value, 0);
    }

    public Map<String,Object> bindCanonical(Contract contract, Map<String,Object> values,
                                             Map<String,Object> canonicalByFieldId) {
        var tree = tree(contract);
        var result = new LinkedHashMap<>(values);
        bind(tree.getOrDefault("", List.of()), tree, result, canonicalByFieldId);
        validate(contract, result);
        return Collections.unmodifiableMap(result);
    }

    public Object value(Contract contract, Map<String,Object> values, String fieldId) {
        var found=values(contract,values,fieldId);
        if(found.size()!=1)throw new InvalidContract();
        return found.getFirst();
    }
    public List<Object> values(Contract contract,Map<String,Object> values,String fieldId) {
        var result=new ArrayList<Object>();collectField(values,fieldChain(contract,fieldId),0,result);
        return Collections.unmodifiableList(result);
    }
    private static void collectField(Object value,List<Field> path,int index,List<Object> result) {
        if(index==path.size()||value==null){result.add(value);return;}
        Field field=path.get(index);
        if(index>0&&path.get(index-1).nodeKind().equals("ARRAY")) {
            if(!(value instanceof List<?> elements))throw new InvalidContract();
            for(Object element:elements)collectField(element,path,index+1,result);
        } else {
            if(!(value instanceof Map<?,?> object))throw new InvalidContract();
            collectField(object.get(field.name()),path,index+1,result);
        }
    }

    public String correspondingField(Contract source,Contract target,String sourceFieldId) {
        var path=fieldPath(source,sourceFieldId);
        for(var candidate:target.fields())if(candidate.name()!=null && fieldPath(target,candidate.id()).equals(path))return candidate.id();
        throw new InvalidContract();
    }
    private static List<String> fieldPath(Contract contract,String id) {
        var chain=fieldChain(contract,id);var names=new ArrayList<String>();
        for(int i=0;i<chain.size();i++)names.add(i>0&&chain.get(i-1).nodeKind().equals("ARRAY")?"*":chain.get(i).name());
        return List.copyOf(names);
    }
    private static List<Field> fieldChain(Contract contract,String id) {
        var fields=new HashMap<String,Field>();contract.fields().forEach(f->fields.put(f.id(),f));
        var path=new ArrayDeque<Field>();var seen=new HashSet<String>();
        for(var field=fields.get(id);field!=null;field=fields.get(field.parentId())) {
            if(!seen.add(field.id())||seen.size()>32)throw new InvalidContract();
            path.addFirst(field);
        }
        if(path.isEmpty())throw new InvalidContract();
        return List.copyOf(path);
    }

    private static Map<String,List<Field>> tree(Contract contract) {
        if (contract.fields().size() > 1024) throw new InvalidContract();
        var byId = new HashMap<String,Field>();
        var result = new HashMap<String,List<Field>>();
        for (var field : contract.fields()) {
            if (field.id()==null || field.id().isBlank() || byId.putIfAbsent(field.id(),field)!=null
                    || !Set.of("PERSIST","OMIT_RECOVERABLE","OMIT_SECRET").contains(field.disposition()))
                throw new InvalidContract();
            result.computeIfAbsent(field.parentId() == null ? "" : field.parentId(), _ -> new ArrayList<>()).add(field);
        }
        for (var field : contract.fields()) {
            var parentField=field.parentId()==null?null:byId.get(field.parentId());
            if (field.parentId()!=null && parentField==null) throw new InvalidContract();
            if ((parentField==null || !parentField.nodeKind().equals("ARRAY")) && (field.name()==null || field.name().isBlank()))
                throw new InvalidContract();
            var seen = new HashSet<String>();
            Field cursor = field;
            while (cursor.parentId() != null) {
                if (!seen.add(cursor.id()) || seen.size() > 32) throw new InvalidContract();
                String parent = cursor.parentId();
                cursor = byId.get(parent);
                if(cursor==null)throw new InvalidContract();
            }
        }
        return result;
    }

    private static LinkedHashMap<String,Object> objectSchema(List<Field> fields, Map<String,List<Field>> tree, int depth) {
        if (depth > 32) throw new InvalidContract();
        var properties = new LinkedHashMap<String,Object>();
        var required = new ArrayList<String>();
        for (var field : fields) {
            if (properties.put(field.name(), fieldSchema(field, tree, depth + 1)) != null) throw new InvalidContract();
            if (field.required()) required.add(field.name());
        }
        var result = new LinkedHashMap<String,Object>();
        result.put("type", "object"); result.put("properties", properties);
        result.put("required", required); result.put("additionalProperties", false);
        return result;
    }

    private static Map<String,Object> fieldSchema(Field field, Map<String,List<Field>> tree, int depth) {
        if (depth > 32) throw new InvalidContract();
        var children = tree.getOrDefault(field.id(), List.of());
        Map<String,Object> schema;
        switch (field.nodeKind()) {
            case "OBJECT" -> schema = objectSchema(children, tree, depth);
            case "ARRAY" -> {
                if (children.size() != 1) throw new InvalidContract();
                schema = new LinkedHashMap<>(Map.of("type", "array", "items", fieldSchema(children.getFirst(), tree, depth + 1)));
                if (field.maxLength() != null) schema.put("maxItems", field.maxLength());
            }
            case "SCALAR" -> {
                if (!children.isEmpty()) throw new InvalidContract();
                String type = switch (field.valueType()) {
                    case "STRING", "TEXT", "DATE", "DATETIME", "INSTANT", "TIME", "BINARY" -> "string";
                    case "INTEGER", "LONG" -> "integer";
                    case "DECIMAL", "NUMBER" -> "number";
                    case "BOOLEAN" -> "boolean";
                    default -> throw new InvalidContract();
                };
                schema = new LinkedHashMap<>(Map.of("type", type));
                if (field.maxLength() != null && type.equals("string")) schema.put("maxLength", field.maxLength());
                if (field.valueType().equals("BINARY")) {
                    schema.put("contentEncoding", "base64");
                    schema.put("pattern", "^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$");
                    if (field.maxLength() != null) schema.put("maxLength", 4L * ((field.maxLength() + 2L) / 3L));
                }
                if (type.equals("integer")) { schema.put("minimum", Long.MIN_VALUE); schema.put("maximum", Long.MAX_VALUE); }
                if (field.precision() != null || field.scale() != null) {
                    // Decimal precision/scale are enforced exactly, not approximated by binary doubles.
                    if (!type.equals("number") || field.scale() != null && field.scale() < 0
                            || field.precision() != null && (field.scale() == null || field.precision() < 1 || field.scale() > field.precision()))
                        throw new InvalidContract();
                    if (field.scale() != null) schema.put("multipleOf", BigDecimal.ONE.scaleByPowerOfTen(-field.scale()));
                    if (field.precision() != null) {
                        int scale = field.scale() == null ? 0 : field.scale();
                        BigDecimal max = BigDecimal.TEN.pow(field.precision() - scale).subtract(BigDecimal.ONE.scaleByPowerOfTen(-scale));
                        schema.put("maximum", max); schema.put("minimum", max.negate());
                    }
                }
                if (field.valueType().equals("DATE")) schema.put("format", "date");
                if (field.valueType().equals("INSTANT")) schema.put("format", "date-time");
                if (field.valueType().equals("TIME")) schema.put("format", "time");
            }
            default -> throw new InvalidContract();
        }
        if (field.nullable()) schema.put("type", List.of(schema.get("type"), "null"));
        return schema;
    }

    private static void validateObject(List<Field> fields, Map<String,List<Field>> tree, Map<?,?> value, int depth) {
        if (depth > 32) throw new InvalidContract();
        var allowed = new HashSet<String>();
        for (var field : fields) {
            allowed.add(field.name());
            if (!value.containsKey(field.name())) {
                if (field.required()) throw new InvalidContract();
            } else validateField(field, tree, value.get(field.name()), depth + 1);
        }
        if (!allowed.containsAll(value.keySet())) throw new InvalidContract();
    }

    private static void validateField(Field field, Map<String,List<Field>> tree, Object value, int depth) {
        if (depth > 32) throw new InvalidContract();
        if (value == null) { if (!field.nullable()) throw new InvalidContract(); return; }
        var children = tree.getOrDefault(field.id(), List.of());
        switch (field.nodeKind()) {
            case "OBJECT" -> {
                if (!(value instanceof Map<?,?> map)) throw new InvalidContract();
                validateObject(children, tree, map, depth);
            }
            case "ARRAY" -> {
                if (!(value instanceof List<?> list) || children.size() != 1
                        || field.maxLength() != null && list.size() > field.maxLength()) throw new InvalidContract();
                for (Object element : list) validateField(children.getFirst(), tree, element, depth + 1);
            }
            case "SCALAR" -> {
                try {
                    switch (field.valueType()) {
                        case "STRING", "TEXT", "DATE", "DATETIME", "INSTANT", "TIME" -> {
                            if (!(value instanceof String text) || field.maxLength() != null
                                    && text.codePointCount(0,text.length()) > field.maxLength()) throw new InvalidContract();
                            switch (field.valueType()) {
                                case "DATE" -> LocalDate.parse(text);
                                case "DATETIME" -> LocalDateTime.parse(text);
                                case "INSTANT" -> Instant.parse(text);
                                case "TIME" -> OffsetTime.parse(text);
                                default -> {}
                            }
                        }
                        case "INTEGER", "LONG" -> {
                            if (!(value instanceof Byte || value instanceof Short || value instanceof Integer
                                    || value instanceof Long || value instanceof BigInteger)) throw new InvalidContract();
                            if (value instanceof BigInteger integer && integer.bitLength() > 63) throw new InvalidContract();
                        }
                        case "DECIMAL", "NUMBER" -> {
                            if (!(value instanceof Number number)) throw new InvalidContract();
                            BigDecimal decimal = new BigDecimal(number.toString());
                            if (field.scale() != null && decimal.remainder(BigDecimal.ONE.scaleByPowerOfTen(-field.scale())).signum() != 0)
                                throw new InvalidContract();
                            if (field.precision() != null) {
                                BigDecimal maximum=BigDecimal.TEN.pow(field.precision()-field.scale()).subtract(BigDecimal.ONE.scaleByPowerOfTen(-field.scale()));
                                if (decimal.abs().compareTo(maximum)>0) throw new InvalidContract();
                            }
                        }
                        case "BOOLEAN" -> { if (!(value instanceof Boolean)) throw new InvalidContract(); }
                        case "BINARY" -> {
                            byte[] bytes;
                            if (value instanceof byte[] binary) bytes=binary;
                            else if (value instanceof String text && text.matches("(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?"))
                                bytes=Base64.getDecoder().decode(text);
                            else throw new InvalidContract();
                            if (field.maxLength()!=null && bytes.length>field.maxLength()) throw new InvalidContract();
                        }
                        default -> throw new InvalidContract();
                    }
                } catch (IllegalArgumentException | java.time.format.DateTimeParseException e) {
                    throw new InvalidContract();
                }
            }
            default -> throw new InvalidContract();
        }
    }

    @SuppressWarnings("unchecked")
    private static void bind(List<Field> fields, Map<String,List<Field>> tree, Map<String,Object> values, Map<String,Object> canonical) {
        for (var field : fields) {
            if (canonical.containsKey(field.id())) values.put(field.name(), canonical.get(field.id()));
            if (field.nodeKind().equals("OBJECT") && values.get(field.name()) instanceof Map<?,?> nested) {
                var copy = new LinkedHashMap<>((Map<String,Object>) nested);
                bind(tree.getOrDefault(field.id(), List.of()), tree, copy, canonical);
                values.put(field.name(), Collections.unmodifiableMap(copy));
            }
        }
    }
}
