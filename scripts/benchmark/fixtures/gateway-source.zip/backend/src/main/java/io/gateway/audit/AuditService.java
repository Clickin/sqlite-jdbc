package io.gateway.audit;

import io.gateway.persistence.PlatformMapper;
import io.gateway.persistence.PlatformStore;
import jakarta.inject.Singleton;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Singleton
public final class AuditService {
    private final PlatformStore store;
    public AuditService(PlatformStore store) { this.store = store; }

    public record SecurityContext(String principalId, String clientObjectId, String observedClientVersionId,
                                  String publicGrantId, String publicTokenRecordId, String transport,
                                  String mcpToolVersionId, String requiredActionId) {}
    public record Event(String executionId, String executionStageId, String eventType, String actorSubjectId,
                        String callerServiceId, String authorityDecisionId, String outcome, String reasonCode,
                        SecurityContext security) {}

    public String append(Event event, List<AuditProjection.Parameter> parameters) {
        Objects.requireNonNull(event);
        safeCode(event.eventType());
        safeCode(event.outcome());
        if (event.reasonCode() != null) safeCode(event.reasonCode());
        Objects.requireNonNull(event.actorSubjectId());
        Objects.requireNonNull(event.callerServiceId());
        String id = UUID.randomUUID().toString();
        long now = System.currentTimeMillis();
        return store.write(session -> {
            Mapper mapper = session.getMapper(Mapper.class);
            mapper.event(id, now, event);
            for (AuditProjection.Parameter parameter : parameters) mapper.parameter(id, parameter);
            return id;
        });
    }

    public String record(String eventType, String actor, String outcome, String reasonCode) {
        return append(new Event(null, null, eventType, actor, "gateway", null, outcome, reasonCode, null), List.of());
    }

    private static void safeCode(String code) {
        if (code == null || !code.matches("[A-Z][A-Z0-9_.-]{0,127}"))
            throw new IllegalArgumentException("AUDIT_CODE_INVALID");
    }

    public interface Mapper extends PlatformMapper {
        @Insert("""
            INSERT INTO audit_event(id,execution_id,execution_stage_id,event_type,occurred_at,
                actor_subject_id,caller_service_id,authority_decision_id,outcome,reason_code,
                principal_id,client_object_id,observed_client_version_id,public_grant_id,
                public_token_record_id,transport,mcp_tool_version_id,required_action_id)
            VALUES(#{id},#{event.executionId},#{event.executionStageId},#{event.eventType},#{now},
                #{event.actorSubjectId},#{event.callerServiceId},#{event.authorityDecisionId},#{event.outcome},#{event.reasonCode},
                #{event.security.principalId},#{event.security.clientObjectId},#{event.security.observedClientVersionId},
                #{event.security.publicGrantId},#{event.security.publicTokenRecordId},#{event.security.transport},
                #{event.security.mcpToolVersionId},#{event.security.requiredActionId})
            """)
        void event(@Param("id") String id, @Param("now") long now, @Param("event") Event event);

        @Insert("""
            INSERT INTO audit_parameter(id,audit_event_id,parent_parameter_id,parameter_name,ordinal,port,field_id,
                value_type,string_value,integer_value,decimal_text,boolean_value,exclusion_reason)
            VALUES(#{p.id},#{eventId},#{p.parentParameterId},#{p.parameterName},#{p.ordinal},#{p.port},#{p.fieldId},
                #{p.valueType},#{p.stringValue},#{p.integerValue},#{p.decimalText},#{p.booleanValue},#{p.exclusionReason})
            """)
        void parameter(@Param("eventId") String eventId, @Param("p") AuditProjection.Parameter parameter);
    }
}
