package io.gateway.oauth;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public final class Secrets {
    private static final SecureRandom RANDOM=new SecureRandom();
    private Secrets() {}
    public static String random(String type) { byte[] bytes=new byte[32]; RANDOM.nextBytes(bytes); return type+"_"+Base64.getUrlEncoder().withoutPadding().encodeToString(bytes); }
    public static String digest(String raw) {
        try { return Base64.getUrlEncoder().withoutPadding().encodeToString(MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.UTF_8))); }
        catch (java.security.NoSuchAlgorithmException e) { throw new IllegalStateException(e); }
    }
    public static boolean matches(String raw,String digest) { return raw!=null && digest!=null && MessageDigest.isEqual(digest(raw).getBytes(StandardCharsets.US_ASCII),digest.getBytes(StandardCharsets.US_ASCII)); }
    public record Ciphertext(byte[] cipher,byte[] nonce,byte[] tag) {}
    public static Ciphertext encrypt(byte[] key,String id,String value) {
        if(value==null) return new Ciphertext(null,null,null);
        try {
            byte[] nonce=new byte[12]; RANDOM.nextBytes(nonce);
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,nonce)); cipher.updateAAD(id.getBytes(StandardCharsets.UTF_8));
            byte[] encrypted=cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
            return new Ciphertext(Arrays.copyOf(encrypted,encrypted.length-16),nonce,Arrays.copyOfRange(encrypted,encrypted.length-16,encrypted.length));
        } catch (Exception e) { throw new IllegalStateException("State encryption failed"); }
    }
    public static String decrypt(byte[] key,String id,byte[] encrypted,byte[] nonce,byte[] tag) {
        if(encrypted==null) return null;
        try {
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,nonce)); cipher.updateAAD(id.getBytes(StandardCharsets.UTF_8));
            byte[] combined=Arrays.copyOf(encrypted,encrypted.length+tag.length); System.arraycopy(tag,0,combined,encrypted.length,tag.length);
            return new String(cipher.doFinal(combined),StandardCharsets.UTF_8);
        } catch (Exception e) { throw new IllegalStateException("State decryption failed"); }
    }
    public record PasswordHash(byte[] digest,byte[] salt,int iterations,int keyLength) {}
    public static PasswordHash hash(char[] secret) {
        if(secret.length<32 || secret.length>1024) throw new IllegalArgumentException("Client secret requires 32 to 1024 characters");
        byte[] salt=new byte[32]; RANDOM.nextBytes(salt); return new PasswordHash(derive(secret,salt,600000,256),salt,600000,256);
    }
    public static boolean verify(char[] secret,byte[] digest,byte[] salt,int iterations,int keyLength) {
        if(iterations<100000 || iterations>2000000 || keyLength!=256 || salt==null || salt.length<16) return false;
        return MessageDigest.isEqual(derive(secret,salt,iterations,keyLength),digest);
    }
    private static byte[] derive(char[] secret,byte[] salt,int iterations,int keyLength) {
        PBEKeySpec spec=new PBEKeySpec(secret,salt,iterations,keyLength);
        try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(); }
        catch(Exception e) { throw new IllegalStateException("Client secret KDF unavailable"); }
        finally { spec.clearPassword(); }
    }
}
