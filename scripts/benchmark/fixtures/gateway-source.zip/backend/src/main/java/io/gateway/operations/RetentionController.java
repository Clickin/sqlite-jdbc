package io.gateway.operations;

import io.gateway.management.ManagementAccess;
import io.micronaut.http.*;
import io.micronaut.http.annotation.*;
import java.util.List;
import java.util.Map;

@Controller("/management/retention")
public final class RetentionController {
    private final RetentionService retention;
    private final ManagementAccess access;
    public RetentionController(RetentionService retention,ManagementAccess access) { this.retention=retention;this.access=access; }
    @Get public HttpResponse<List<RetentionService.Policy>> policies(HttpRequest<?> request) {
        access.authorize(request,"config.manage",false);
        return secure(retention.policies());
    }
    @Put("/{dataset}") public HttpResponse<RetentionService.Policy> update(HttpRequest<?> request,String dataset,@Body RetentionService.Update update) {
        var context=access.authorize(request,"config.manage",true);
        return access.mutate(context,()->secure(retention.update(context.principal(),dataset,update)));
    }
    @Post("/cleanup") public HttpResponse<Map<String,Integer>> cleanup(HttpRequest<?> request) {
        var context=access.authorize(request,"config.manage",true);
        return access.mutate(context,()->secure(retention.cleanupNow()));
    }
    private static <T> HttpResponse<T> secure(T body) { return HttpResponse.ok(body).header(HttpHeaders.CACHE_CONTROL,"no-store"); }
}
