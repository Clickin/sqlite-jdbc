package io.gateway.management;

import io.gateway.authorization.*;
import io.gateway.oauth.BrowserSessionService;
import io.micronaut.http.HttpRequest;
import jakarta.inject.Singleton;
import io.gateway.definitions.DefinitionRepository;
import io.gateway.definitions.Definitions.Detail;
import io.gateway.persistence.PlatformStore;
import java.util.function.Supplier;

@Singleton
public final class ManagementAccess {
    private final AuthorizationService authorization;
    private final BrowserSessionService sessions;
    private final PlatformStore store;
    public ManagementAccess(AuthorizationService authorization,BrowserSessionService sessions,PlatformStore store) { this.authorization=authorization; this.sessions=sessions; this.store=store; }
    public AuthorizedContext authorize(HttpRequest<?> request,String action,boolean mutation) {
        if(!request.getHeaders().getAll("Authorization").isEmpty()) throw AccessDenied.denied();
        long cookies=request.getHeaders().getAll("Cookie").stream().flatMap(h->java.util.Arrays.stream(h.split(";"))).map(String::trim).filter(v->v.startsWith(BrowserSessionService.COOKIE_NAME+"=")).count();
        if(cookies!=1) throw AccessDenied.denied();
        String cookie=request.getCookies().findCookie(BrowserSessionService.COOKIE_NAME).map(c->c.getValue()).orElse(null);
        if(mutation) {
            if(request.getHeaders().getAll("Origin").size()!=1||request.getHeaders().getAll("X-CSRF-Token").size()!=1) throw AccessDenied.denied();
            sessions.requireCsrf(cookie,request.getHeaders().get("Origin"),request.getHeaders().get("X-CSRF-Token"));
        }
        return authorization.authorizeManagement(cookie,action);
    }
    public AuthorizedContext definition(HttpRequest<?> request,String id,String version,Detail candidate) {
        return authorize(request,store.read(s->DefinitionRepository.managementAction(s,id,version,candidate)),true);
    }
    public <T> T mutate(AuthorizedContext context,Supplier<T> work) {
        return store.withWriteGuard((s,before)->authorization.recheckManagement(s,context,before),work);
    }
    public <T> T mutateDefinition(AuthorizedContext context,String id,String version,Detail candidate,Supplier<T> work) {
        return store.withWriteGuard((s,before)->{
            authorization.recheckManagement(s,context,before);
            String required=DefinitionRepository.managementAction(s,id,version,candidate);
            if(!required.equals(context.action())&&!("config.manage".equals(required)&&"security.manage".equals(context.action())))throw AccessDenied.denied();
        },work);
    }
}
