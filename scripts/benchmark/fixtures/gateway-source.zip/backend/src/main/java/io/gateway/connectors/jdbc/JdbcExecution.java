package io.gateway.connectors.jdbc;

import io.gateway.runtime.Cancellation;
import io.gateway.definitions.Definitions.OutBinding;
import java.io.*;
import java.lang.reflect.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.*;
import java.time.temporal.TemporalAccessor;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.mapping.*;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.type.*;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/** Request-local budgets and cancellation. MyBatis remains the sole application SQL executor. */
final class JdbcExecution {
    private static final ThreadLocal<JdbcExecution> CURRENT = new ThreadLocal<>();
    private static final Set<String> VALUE_GETTERS = Set.of("getObject", "getString", "getNString", "getBytes",
            "getBoolean", "getByte", "getShort", "getInt", "getLong", "getFloat", "getDouble", "getBigDecimal",
            "getDate", "getTime", "getTimestamp");
    private static final Set<String> PURE_OGNL = Set.of("ASTConst","ASTProperty","ASTChain","ASTAnd","ASTOr","ASTNot",
        "ASTEq","ASTNotEq","ASTLess","ASTLessEq","ASTGreater","ASTGreaterEq","ASTAdd","ASTSubtract",
        "ASTMultiply","ASTDivide","ASTRemainder","ASTNegate","ASTIn","ASTNotIn","ASTList","ASTTest","ASTMethod");
    private static final Set<String> PURE_METHODS = Set.of("size","isEmpty","contains","containsKey","equals","equalsIgnoreCase",
        "startsWith","endsWith","length","trim","toLowerCase","toUpperCase","substring");
    private static final Set<String> VALUE_TYPES = Set.of("map","hashmap","linkedhashmap","list","arraylist","collection","set","hashset",
        "string","object","int","integer","long","short","byte","char","character","boolean","float","double","decimal","bigdecimal","biginteger",
        "date","resultset","java.lang.string","java.lang.object","java.lang.integer","java.lang.long","java.lang.short","java.lang.byte",
        "java.lang.character","java.lang.boolean","java.lang.float","java.lang.double","java.math.bigdecimal","java.math.biginteger",
        "java.util.map","java.util.hashmap","java.util.linkedhashmap","java.util.list","java.util.arraylist","java.util.collection","java.util.set","java.util.hashset",
        "java.util.date","java.sql.date","java.sql.time","java.sql.timestamp","java.sql.blob","java.sql.clob","java.sql.nclob","java.sql.sqlxml","java.sql.resultset",
        "java.time.localdate","java.time.localdatetime","java.time.offsetdatetime","java.time.localtime","java.time.offsettime","java.time.instant");
    private static final Set<String> RESERVED_BINDINGS = Set.of("authorized","_parameter","_databaseId");
    private static final Set<String> REFLECTION_PROPERTIES = Set.of("class","classloader","declaringclass","protectiondomain");
    private static final Set<String> XML_LANGUAGES = Set.of("xml","raw","org.apache.ibatis.scripting.xmltags.XMLLanguageDriver","org.apache.ibatis.scripting.defaults.RawLanguageDriver");
    private static final List<String> TYPE_ATTRIBUTES = List.of("type","resultType","parameterType","javaType","ofType");
    private static final List<String> BINDING_ATTRIBUTES = List.of("name","item","index");
    private static final List<String> EXPRESSION_ATTRIBUTES = List.of("test","collection","value");
    private final Cancellation cancellation;
    private final long deadline;
    private final int maxRows;
    private final long maxBytes;
    private final boolean write;
    private final boolean autoCommit;
    private final List<OutBinding> outBindings;
    private final AtomicBoolean cancelled = new AtomicBoolean();
    private final List<StatementLease> statements = new ArrayList<>();
    private final IdentityHashMap<ResultSet, ResultSet> resultSets = new IdentityHashMap<>();
    private long bytes;
    private int rows;
    private int handlerDepth;
    private byte[] binaryBuffer;
    private char[] textBuffer;
    boolean attempted;
    boolean effectConfirmed;

    JdbcExecution(Cancellation cancellation, int timeoutMs, int maxRows, long maxBytes, boolean write, boolean autoCommit,
                  List<OutBinding> outBindings) {
        this.cancellation = cancellation;
        this.deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(Math.min(timeoutMs, cancellation.remainingMillis()));
        this.maxRows = maxRows;
        this.maxBytes = maxBytes;
        this.write = write;
        this.autoCommit = autoCommit;
        this.outBindings = outBindings;
    }
    static void bind(JdbcExecution state) { CURRENT.set(state); }
    static void unbind() { CURRENT.remove(); }
    long remainingMillis() {
        check();
        return Math.max(1, TimeUnit.NANOSECONDS.toMillis(deadline - System.nanoTime()));
    }
    void check() {
        cancellation.check();
        if (cancelled.get() || System.nanoTime() - deadline >= 0) {
            requestCancel();
            throw JdbcResources.invalid("JDBC_DEADLINE_OR_CANCELLED");
        }
    }
    void requestCancel() {
        if (cancelled.compareAndSet(false, true)) {
            // Driver cancellation may itself block; do not stall the deadline scheduler or return its connection early.
            Thread.ofVirtual().name("jdbc-cancel").start(() -> {
                List<StatementLease> snapshot;
                synchronized (statements) { snapshot = List.copyOf(statements); }
                for (StatementLease statement : snapshot) statement.cancel();
            });
        }
    }

    private void validateOutParameters(BoundSql bound) {
        if (outBindings.isEmpty()) return;
        Map<String, ParameterMapping> mapped = new HashMap<>();
        for (ParameterMapping parameter : bound.getParameterMappings()) if (parameter.getMode() != ParameterMode.IN)
            mapped.put(parameter.getProperty(), parameter);
        for (OutBinding binding : outBindings) {
            ParameterMapping parameter = mapped.get(binding.parameterName());
            if (parameter == null || binding.resultMapName() != null && !binding.resultMapName().equals(parameter.getResultMapId()))
                throw JdbcResources.invalid("JDBC_OUT_PARAMETER_MISMATCH");
        }
    }

    @Intercepts({
        @Signature(type = StatementHandler.class, method = "prepare", args = {Connection.class, Integer.class}),
        @Signature(type = StatementHandler.class, method = "query", args = {Statement.class, org.apache.ibatis.session.ResultHandler.class}),
        @Signature(type = StatementHandler.class, method = "update", args = {Statement.class})
    })
    public static final class Guard implements Interceptor {
        @Override public Object intercept(Invocation invocation) throws Throwable {
            JdbcExecution state = CURRENT.get();
            if (state == null) throw JdbcResources.invalid("JDBC_REQUEST_CONTEXT_MISSING");
            state.check();
            if (!invocation.getMethod().getName().equals("prepare")) {
                state.handlerDepth++;
                try {
                    Object result = invocation.proceed();
                    if (state.handlerDepth == 1 && state.write && state.autoCommit) state.effectConfirmed = true;
                    return result;
                } finally { state.handlerDepth--; }
            }
            if (!state.attempted) state.validateOutParameters(((StatementHandler) invocation.getTarget()).getBoundSql());
            Statement statement = (Statement) invocation.proceed();
            StatementLease lease = state.new StatementLease(statement);
            try {
                int seconds = (int) Math.min(Integer.MAX_VALUE, Math.max(1, (state.remainingMillis() + 999) / 1000));
                int existing = statement.getQueryTimeout();
                statement.setQueryTimeout(existing > 0 ? Math.min(existing, seconds) : seconds);
                synchronized (state.statements) { state.statements.add(lease); }
                state.check();
                Class<?> api = statement instanceof CallableStatement ? CallableStatement.class : PreparedStatement.class;
                return Proxy.newProxyInstance(JdbcExecution.class.getClassLoader(), new Class<?>[]{api}, lease);
            } catch (Throwable failure) {
                lease.close();
                throw failure;
            }
        }
    }

    private final class StatementLease implements InvocationHandler {
        private final Statement statement;
        private boolean closed;
        StatementLease(Statement statement) { this.statement = statement; }
        synchronized void cancel() {
            if (!closed) try { statement.cancel(); } catch (Exception ignored) { /* best effort, ownership unchanged */ }
        }
        synchronized void close() throws SQLException {
            if (!closed) { closed = true; statement.close(); }
        }
        @Override public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            String name = method.getName();
            if (name.equals("close")) { close(); return null; }
            if (name.equals("toString")) return "RegisteredJdbcStatement";
            if (name.startsWith("execute")) {
                check();
                attempted = true;
                Object result = call(statement, method, args);
                if (write && autoCommit && !(statement instanceof CallableStatement)
                        && !(result instanceof ResultSet) && !Boolean.TRUE.equals(result)) effectConfirmed = true;
                return result instanceof ResultSet rs ? wrap(rs) : result;
            }
            if ((name.equals("getString") || name.equals("getNString")) && statement instanceof CallableStatement callable)
                return text(args[0] instanceof Integer index ? callable.getCharacterStream(index) : callable.getCharacterStream((String) args[0]));
            Object result = call(statement, method, args);
            if (result instanceof ResultSet rs) return wrap(rs);
            if (name.startsWith("get") && isValueGetter(name)) return fetched(result);
            return result;
        }
    }

    private ResultSet wrap(ResultSet rs) {
        ResultSet existing = resultSets.get(rs);
        if (existing != null) return existing;
        ResultSet wrapped = (ResultSet) Proxy.newProxyInstance(JdbcExecution.class.getClassLoader(), new Class<?>[]{ResultSet.class},
                new InvocationHandler() {
                    private boolean closed;
                    @Override public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                        String name = method.getName();
                        if (name.equals("toString")) return "RegisteredJdbcResultSet";
                        if (name.equals("close")) {
                            if (!closed) { closed = true; rs.close(); }
                            return null;
                        }
                        if (name.equals("next")) {
                            check();
                            boolean next = rs.next();
                            if (next && ++rows > maxRows) throw JdbcResources.invalid("JDBC_RESULT_ROW_LIMIT");
                            return next;
                        }
                        if (name.equals("getString") || name.equals("getNString"))
                            return text(args[0] instanceof Integer index ? rs.getCharacterStream(index) : rs.getCharacterStream((String) args[0]));
                        if (name.equals("getBytes"))
                            return binary(args[0] instanceof Integer index ? rs.getBinaryStream(index) : rs.getBinaryStream((String) args[0]));
                        Object result = call(rs, method, args);
                        if (isValueGetter(name)) return fetched(result);
                        return result;
                    }
                });
        resultSets.put(rs, wrapped);
        resultSets.put(wrapped, wrapped);
        return wrapped;
    }

    private static boolean isValueGetter(String name) {
        return VALUE_GETTERS.contains(name);
    }

    private Object fetched(Object value) throws Exception {
        if (value instanceof ResultSet rs) return wrap(rs);
        if (value instanceof Blob || value instanceof Clob || value instanceof SQLXML || value instanceof java.sql.Array)
            return materialize(value);
        accountScalar(value);
        return value;
    }

    private void account(long count) {
        if (count < 0 || count > maxBytes - bytes) throw JdbcResources.invalid("JDBC_RESULT_BYTE_LIMIT");
        bytes += count;
    }
    private void accountScalar(Object value) {
        if (value == null) { account(1); return; }
        if (value instanceof byte[] data) { account(data.length); return; }
        if (value instanceof CharSequence text) {
            long size = 0;
            for (int i = 0; i < text.length(); i++) {
                char c = text.charAt(i);
                if (c <= 0x7f) size++;
                else if (c <= 0x7ff) size += 2;
                else if (Character.isHighSurrogate(c) && i + 1 < text.length() && Character.isLowSurrogate(text.charAt(i + 1))) { size += 4; i++; }
                else size += 3;
            }
            account(size);
        } else if (value instanceof Number || value instanceof Boolean || value instanceof java.util.Date || value instanceof TemporalAccessor)
            account(value.toString().length());
    }

    Object materialize(Object value) throws Exception { return materialize(value, 0); }
    private Object materialize(Object value, int depth) throws Exception {
        check();
        if (depth > 64) throw JdbcResources.invalid("JDBC_RESULT_DEPTH_LIMIT");
        if (value == null || value instanceof String || value instanceof Boolean || value instanceof Byte || value instanceof Short
                || value instanceof Integer || value instanceof Long || value instanceof Float || value instanceof Double
                || value instanceof BigDecimal || value instanceof BigInteger)
            return value;
        if (value instanceof TemporalAccessor || value instanceof UUID) return value.toString();
        if (value instanceof java.util.Date date) return (date instanceof Timestamp timestamp ? timestamp.toLocalDateTime()
                : date instanceof java.sql.Date sqlDate ? sqlDate.toLocalDate()
                : date instanceof Time time ? time.toLocalTime() : date.toInstant()).toString();
        if (value instanceof byte[]) return value;
        if (value instanceof Blob blob) {
            try { return binary(blob.getBinaryStream()); } finally { blob.free(); }
        }
        if (value instanceof Clob clob) {
            try { return text(clob.getCharacterStream()); } finally { clob.free(); }
        }
        if (value instanceof SQLXML xml) {
            try { return text(xml.getCharacterStream()); } finally { xml.free(); }
        }
        if (value instanceof java.sql.Array array) {
            try { return materialize(array.getArray(), depth + 1); } finally { array.free(); }
        }
        if (value instanceof ResultSet rs) {
            try (ResultSet bounded = wrap(rs)) {
                List<Object> result = new ArrayList<>();
                ResultSetMetaData meta = bounded.getMetaData();
                while (bounded.next()) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    for (int i = 1; i <= meta.getColumnCount(); i++) row.put(meta.getColumnLabel(i), materialize(bounded.getObject(i), depth + 1));
                    result.add(row);
                }
                return result;
            }
        }
        if (value instanceof Map<?, ?> map) {
            Map<Object, Object> result = null;
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                if (!(entry.getKey() instanceof String)) throw JdbcResources.invalid("JDBC_RESULT_MEMBER_INVALID");
                Object detached = materialize(entry.getValue(), depth + 1);
                if (detached != entry.getValue()) {
                    if (result == null) result = new LinkedHashMap<>(map);
                    result.put(entry.getKey(), detached);
                }
            }
            return result == null ? map : result;
        }
        if (value instanceof List<?> list) {
            if (list.size() > maxRows) throw JdbcResources.invalid("JDBC_RESULT_ROW_LIMIT");
            List<Object> result = null;
            for (int i = 0; i < list.size(); i++) {
                Object detached = materialize(list.get(i), depth + 1);
                if (detached != list.get(i)) {
                    if (result == null) result = new ArrayList<>(list);
                    result.set(i, detached);
                }
            }
            return result == null ? list : result;
        }
        if (value instanceof Iterable<?> list) {
            List<Object> result = new ArrayList<>();
            for (Object item : list) {
                if (result.size() >= maxRows) throw JdbcResources.invalid("JDBC_RESULT_ROW_LIMIT");
                result.add(materialize(item, depth + 1));
            }
            return result;
        }
        if (value instanceof Object[] array) return materialize(Arrays.asList(array), depth + 1);
        throw JdbcResources.invalid("JDBC_RESULT_TYPE_UNSUPPORTED");
    }

    private byte[] binary(InputStream input) throws IOException {
        if (input == null) { account(1); return null; }
        try (input; ByteArrayOutputStream result = new ByteArrayOutputStream()) {
            if (binaryBuffer == null) binaryBuffer = new byte[(int) Math.min(8192, maxBytes)];
            byte[] buffer = binaryBuffer;
            int count;
            while ((count = input.read(buffer)) != -1) {
                check();
                account(count);
                result.write(buffer, 0, count);
            }
            return result.toByteArray();
        }
    }
    private String text(Reader reader) throws IOException {
        if (reader == null) { account(1); return null; }
        try (reader) {
            StringBuilder result = new StringBuilder();
            if (textBuffer == null) textBuffer = new char[(int) Math.min(4096, maxBytes)];
            char[] buffer = textBuffer;
            int count;
            boolean highSurrogate = false;
            while ((count = reader.read(buffer)) != -1) {
                check();
                long encodedBytes = 0;
                for (int i = 0; i < count; i++) {
                    char c = buffer[i];
                    encodedBytes += highSurrogate && Character.isLowSurrogate(c) ? 1 : c <= 0x7f ? 1 : c <= 0x7ff ? 2 : 3;
                    highSurrogate = Character.isHighSurrogate(c);
                }
                account(encodedBytes);
                result.append(buffer, 0, count);
            }
            return result.toString();
        }
    }

    static void registerLobHandlers(Configuration configuration) {
        TypeHandlerRegistry registry = configuration.getTypeHandlerRegistry();
        for (Class<?> type : List.of(Blob.class, Clob.class, NClob.class, SQLXML.class)) registry.register(type, LobHandler.class);
        registry.register(byte[].class, JdbcType.BLOB, LobHandler.class);
        registry.register(String.class, JdbcType.CLOB, LobHandler.class);
        registry.register(String.class, JdbcType.NCLOB, LobHandler.class);
        for (JdbcType type : List.of(JdbcType.BLOB, JdbcType.CLOB, JdbcType.NCLOB, JdbcType.SQLXML))
            registry.register(type, new LobHandler());
    }
    public static final class LobHandler extends BaseTypeHandler<Object> {
        @Override public void setNonNullParameter(PreparedStatement statement, int i, Object parameter, JdbcType jdbcType) throws SQLException {
            if (parameter instanceof byte[] data) statement.setBytes(i, data);
            else if (parameter instanceof String text) statement.setString(i, text);
            else statement.setObject(i, parameter);
        }
        @Override public Object getNullableResult(ResultSet rs, String name) throws SQLException { return rs.getObject(name); }
        @Override public Object getNullableResult(ResultSet rs, int index) throws SQLException { return rs.getObject(index); }
        @Override public Object getNullableResult(CallableStatement statement, int index) throws SQLException { return statement.getObject(index); }
    }

    @SuppressWarnings("unchecked")
    static Map<String, Object> copyParameters(Map<String, Object> source) { return (Map<String, Object>) mutable(source); }
    private static Object mutable(Object value) {
        if (value instanceof Map<?, ?> map) {
            Map<String, Object> copy = new LinkedHashMap<>();
            map.forEach((key, item) -> copy.put((String) key, mutable(item)));
            return copy;
        }
        if (value instanceof List<?> list) {
            List<Object> copy = new ArrayList<>(list.size());
            for (Object item : list) copy.add(mutable(item));
            return copy;
        }
        if (value instanceof byte[] bytes) return bytes.clone();
        return value;
    }

    static void validateMapperXml(String xml) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
        factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
        factory.setExpandEntityReferences(false);
        var builder = factory.newDocumentBuilder();
        builder.setEntityResolver((publicId, systemId) -> { throw new SAXException("EXTERNAL_ENTITY_FORBIDDEN"); });
        builder.setErrorHandler(new org.xml.sax.helpers.DefaultHandler() {
            @Override public void error(org.xml.sax.SAXParseException e) throws SAXException { throw new SAXException("INVALID_MAPPER_XML"); }
            @Override public void fatalError(org.xml.sax.SAXParseException e) throws SAXException { throw new SAXException("INVALID_MAPPER_XML"); }
        });
        var document = builder.parse(new InputSource(new StringReader(xml)));
        var type = document.getDoctype();
        if (type != null && (type.getInternalSubset() != null && !type.getInternalSubset().isBlank()
                || !Set.of("https://mybatis.org/dtd/mybatis-3-mapper.dtd", "http://mybatis.org/dtd/mybatis-3-mapper.dtd").contains(type.getSystemId())))
            throw JdbcResources.invalid("JDBC_MAPPER_DTD_FORBIDDEN");
        if (!document.getDocumentElement().getTagName().equals("mapper")) throw JdbcResources.invalid("JDBC_MAPPER_ROOT_INVALID");
        String namespace=document.getDocumentElement().getAttribute("namespace");
        try {Class.forName(namespace,false,JdbcExecution.class.getClassLoader());throw JdbcResources.invalid("JDBC_CLASS_NAMESPACE_FORBIDDEN");}
        catch(ClassNotFoundException expected){ /* Data-defined namespaces never load Java mappers. */ }
        rejectSubstitutions(document.getDocumentElement());
    }

    private static void rejectSubstitutions(org.w3c.dom.Node node) {
        if(node instanceof org.w3c.dom.Element element) {
            if(element.getTagName().equals("cache")||element.getTagName().equals("cache-ref"))
                throw JdbcResources.invalid("JDBC_RESULT_CACHE_FORBIDDEN");
            for(String attribute:TYPE_ATTRIBUTES)if(element.hasAttribute(attribute)) {
                validateJavaType(element.getAttribute(attribute));
            }
            if(element.hasAttribute("lang")&&!XML_LANGUAGES.contains(element.getAttribute("lang")))
                throw JdbcResources.invalid("JDBC_LANGUAGE_FORBIDDEN");
            if(element.hasAttribute("typeHandler")&&!element.getAttribute("typeHandler").startsWith("org.apache.ibatis.type."))
                throw JdbcResources.invalid("JDBC_TYPE_HANDLER_FORBIDDEN");
            for(String attribute:BINDING_ATTRIBUTES)if((element.getTagName().equals("bind")||element.getTagName().equals("foreach"))&&RESERVED_BINDINGS.contains(element.getAttribute(attribute)))
                throw JdbcResources.invalid("JDBC_AUTHORIZED_BINDING_IMMUTABLE");
            for(String attribute:EXPRESSION_ATTRIBUTES)if(element.hasAttribute(attribute)&&
                    (element.getTagName().equals("if")||element.getTagName().equals("when")||element.getTagName().equals("foreach")||element.getTagName().equals("bind"))) {
                try {
                    String expression=element.getAttribute(attribute);
                    if(expression.length()>4096)throw JdbcResources.invalid("JDBC_EXPRESSION_LIMIT");
                    validateExpression((org.apache.ibatis.ognl.Node)org.apache.ibatis.ognl.Ognl.parseExpression(expression),0);
                }catch(org.apache.ibatis.ognl.OgnlException malformed){throw JdbcResources.invalid("JDBC_EXPRESSION_INVALID");}
            }
        }
        if(node.getNodeType()==org.w3c.dom.Node.TEXT_NODE||node.getNodeType()==org.w3c.dom.Node.CDATA_SECTION_NODE)
            new org.apache.ibatis.parsing.GenericTokenParser("#{","}",expression->{
                var parameters=new org.apache.ibatis.builder.ParameterExpression(expression);
                if(parameters.containsKey("javaType"))validateJavaType(parameters.get("javaType"));
                if(parameters.containsKey("typeHandler")&&!parameters.get("typeHandler").startsWith("org.apache.ibatis.type."))
                    throw JdbcResources.invalid("JDBC_TYPE_HANDLER_FORBIDDEN");
                return "";
            }).parse(node.getNodeValue());
        if (node.getNodeValue() != null && node.getNodeValue().contains("${"))
            throw JdbcResources.invalid("JDBC_LITERAL_SUBSTITUTION_FORBIDDEN");
        var attributes = node.getAttributes();
        if (attributes != null) for (int i = 0; i < attributes.getLength(); i++) rejectSubstitutions(attributes.item(i));
        for (var child = node.getFirstChild(); child != null; child = child.getNextSibling()) rejectSubstitutions(child);
    }
    private static void validateJavaType(String value) {
        String type=value.toLowerCase(Locale.ROOT).replace("[]","");
        if(type.startsWith("_"))type=type.substring(1);
        if(!VALUE_TYPES.contains(type))throw JdbcResources.invalid("JDBC_JAVA_TYPE_FORBIDDEN");
    }

    private static void validateExpression(org.apache.ibatis.ognl.Node node,int depth) {
        if(depth>32||!PURE_OGNL.contains(node.getClass().getSimpleName()))throw JdbcResources.invalid("JDBC_EXPRESSION_FORBIDDEN");
        if(node instanceof org.apache.ibatis.ognl.ASTMethod method&&!PURE_METHODS.contains(method.getMethodName()))
            throw JdbcResources.invalid("JDBC_EXPRESSION_FORBIDDEN");
        if(node instanceof org.apache.ibatis.ognl.ASTProperty property&&node.jjtGetNumChildren()>0) {
            var key=node.jjtGetChild(0);
            if(property.isIndexedAccess()&&!(key instanceof org.apache.ibatis.ognl.ASTConst))
                throw JdbcResources.invalid("JDBC_DYNAMIC_PROPERTY_FORBIDDEN");
            if(key instanceof org.apache.ibatis.ognl.ASTConst constant&&constant.getValue() instanceof String name
                    &&REFLECTION_PROPERTIES.contains(name.toLowerCase(Locale.ROOT)))
                throw JdbcResources.invalid("JDBC_REFLECTION_FORBIDDEN");
        }
        for(int i=0;i<node.jjtGetNumChildren();i++)validateExpression(node.jjtGetChild(i),depth+1);
    }

    private static Object call(Object target, Method method, Object[] args) throws Throwable {
        try { return method.invoke(target, args); } catch (InvocationTargetException failure) { throw failure.getCause(); }
    }
}
