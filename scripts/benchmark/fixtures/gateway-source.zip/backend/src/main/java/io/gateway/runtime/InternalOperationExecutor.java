package io.gateway.runtime;

import io.gateway.definitions.DefinitionRepository;
import io.gateway.definitions.Definitions.*;
import io.gateway.persistence.PlatformStore;
import jakarta.inject.Singleton;
import java.time.Instant;
import java.util.*;

/** Server-only identity/permission/resolver adapter; no HTTP bypass flag maps to this class. */
@Singleton
public final class InternalOperationExecutor {
    public enum InternalPurpose { IDENTITY, PERMISSION, RESOLVER }
    private static final ThreadLocal<Boolean> ENTERED=ThreadLocal.withInitial(()->false);
    private final PlatformStore store;
    private final DefinitionRepository definitions;
    private final RuntimeRegistry runtimes;
    private final WorkflowRunner runner;
    public InternalOperationExecutor(PlatformStore store,DefinitionRepository definitions,RuntimeRegistry runtimes,WorkflowRunner runner){this.store=store;this.definitions=definitions;this.runtimes=runtimes;this.runner=runner;}
    public Map<String,Object> execute(String operationId,String converterId,Map<String,Object> parameters,InternalPurpose purpose){
        Objects.requireNonNull(purpose);if(ENTERED.get())throw new ExecutionFailure("AUTHORITY_RECURSION",ExecutionFailure.Outcome.FAILED_BEFORE_EFFECT);
        ENTERED.set(true);
        try{
            ResolvedGraph graph=store.read(session->{ResolvedGraph operation=definitions.resolve(session,operationId);if(converterId==null)return operation;ResolvedGraph converter=definitions.resolve(session,converterId);Map<String,Saved> combined=new HashMap<>(operation.definitions());combined.putAll(converter.definitions());return new ResolvedGraph(operationId,combined);});
            Detail operation=graph.require(operationId).detail();int timeout=switch(operation){case JdbcOperation o->o.timeoutMs();case HttpOperation o->o.timeoutMs();default->throw new IllegalArgumentException("AUTHORITY_OPERATION_REQUIRED");};
            Cancellation cancellation=new Cancellation(Instant.now().plusMillis(timeout));
            try(RuntimeRegistry.Lease lease=runtimes.acquire(graph)){
                Payload input=Payload.of(parameters);runner.validate(graph,WorkflowRunner.inputContract(operation),input);
                Payload value=lease.get().execute(operationId,input,cancellation);runner.validate(graph,WorkflowRunner.outputContract(operation),value);
                if(converterId!=null){Converter converter=(Converter)graph.require(converterId).detail();if(!converter.inputContractObjectId().equals(WorkflowRunner.outputContract(operation)))throw new IllegalArgumentException("AUTHORITY_CONTRACT_MISMATCH");value=lease.get().convert(converterId,value);runner.validate(graph,converter.outputContractObjectId(),value);}
                return value.object();
            }
        }finally{ENTERED.remove();}
    }
}
