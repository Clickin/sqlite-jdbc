package io.gateway.persistence;

/** Marker for statically registered metadata mappers, never runtime source mappers. */
public interface PlatformMapper {}
