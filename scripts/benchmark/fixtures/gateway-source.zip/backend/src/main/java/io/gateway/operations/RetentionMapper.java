package io.gateway.operations;

import io.gateway.persistence.PlatformMapper;
import org.apache.ibatis.annotations.*;
import java.util.List;
import java.util.Map;

public interface RetentionMapper extends PlatformMapper {
    @Select("SELECT p.*,o.id AS object_id,o.current_version_id,o.generation,o.revision_counter FROM config_object o JOIN retention_policy_version p ON p.version_id=o.current_version_id WHERE o.kind='RETENTION_POLICY' AND o.enabled=TRUE ORDER BY p.dataset") List<Map<String,Object>> policies();
    @Select("SELECT * FROM config_object WHERE kind='RETENTION_POLICY' AND logical_key=#{key}") Map<String,Object> object(String key);
    @Insert("INSERT INTO config_object(id,kind,logical_key,created_at,created_by) VALUES(#{id},'RETENTION_POLICY',#{key},#{now},#{actor})") void insertObject(Map<String,Object> row);
    @Insert("INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name) VALUES(#{id},#{object},'RETENTION_POLICY',#{revision},#{now},#{actor},'RETENTION_POLICY_CHANGED',#{dataset})") void insertVersion(Map<String,Object> row);
    @Insert("INSERT INTO retention_policy_version(version_id,dataset,retention_days,cleanup_enabled,cleanup_interval,batch_limit) VALUES(#{id},#{dataset},#{days},#{enabled},#{interval},#{limit})") void insertPolicy(Map<String,Object> row);
    @Update("UPDATE config_object SET current_version_id=#{version},revision_counter=revision_counter+1,generation=generation+1 WHERE id=#{id} AND generation=#{expected}") int head(@Param("id") String id,@Param("version") String version,@Param("expected") long expected);
    @Insert("INSERT INTO configuration_change(id,object_id,before_version_id,after_version_id,before_generation,after_generation,actor_subject_id,reason,changed_at) VALUES(#{id},#{object},#{before},#{after},#{generation},#{next},#{actor},'RETENTION_POLICY_CHANGED',#{now})") void change(Map<String,Object> row);
    enum Dataset {
        AUDIT("SELECT id FROM audit_event WHERE occurred_at < #{cutoff} ORDER BY occurred_at,id LIMIT #{limit}"),
        GENERATED_RESULT("SELECT r.id FROM generated_result r JOIN generated_result_revision v ON v.id=r.current_revision_id WHERE v.created_at < #{cutoff} ORDER BY v.created_at,r.id LIMIT #{limit}"),
        REFERENCE("SELECT r.id FROM source_reference r WHERE r.created_at < #{cutoff} AND NOT EXISTS(SELECT 1 FROM result_reference x WHERE x.reference_id=r.id) ORDER BY r.created_at,r.id LIMIT #{limit}"),
        ACCESS("SELECT id FROM oauth_access_token WHERE expires_at < #{cutoff} OR revoked_at IS NOT NULL ORDER BY id LIMIT #{limit}"),
        CODE("SELECT id FROM oauth_authorization_code WHERE expires_at < #{cutoff} OR revoked_at IS NOT NULL ORDER BY id LIMIT #{limit}"),
        REQUEST("SELECT r.id FROM oauth_authorization_request r WHERE r.expires_at < #{cutoff} AND NOT EXISTS(SELECT 1 FROM oauth_authorization_code c WHERE c.request_id=r.id) ORDER BY r.id LIMIT #{limit}"),
        SESSION("SELECT s.id FROM auth_session s WHERE (s.idle_expires_at < #{cutoff} OR s.absolute_expires_at < #{cutoff} OR s.revoked_at IS NOT NULL) AND NOT EXISTS(SELECT 1 FROM oauth_authorization_request r WHERE r.auth_session_id=s.id) ORDER BY s.id LIMIT #{limit}"),
        FAMILY("SELECT f.id FROM oauth_refresh_family f WHERE (f.absolute_expires_at < #{cutoff} OR f.revoked_at IS NOT NULL) AND NOT EXISTS(SELECT 1 FROM oauth_access_token a WHERE a.family_id=f.id) ORDER BY f.id LIMIT #{limit}"),
        GRANT("SELECT g.id FROM oauth_grant g WHERE (g.expires_at < #{cutoff} OR g.revoked_at IS NOT NULL) AND NOT EXISTS(SELECT 1 FROM oauth_access_token a WHERE a.grant_id=g.id) AND NOT EXISTS(SELECT 1 FROM oauth_authorization_code c WHERE c.grant_id=g.id) AND NOT EXISTS(SELECT 1 FROM oauth_refresh_family f WHERE f.grant_id=g.id) ORDER BY g.id LIMIT #{limit}");
        final String sql; Dataset(String sql){this.sql=sql;}
    }
    @SelectProvider(type=Sql.class,method="candidates") List<String> candidates(@Param("dataset") Dataset dataset,@Param("cutoff") long cutoff,@Param("limit") int limit);
    enum Step {
        AUDIT_PARAMETERS("DELETE FROM audit_parameter WHERE audit_event_id=#{id}"), AUDIT("DELETE FROM audit_event WHERE id=#{id}"),
        RESULT_HEAD("UPDATE generated_result SET current_revision_id=NULL WHERE id=#{id}"),
        RESULT_LINKS("DELETE FROM result_reference WHERE result_revision_id IN (SELECT id FROM generated_result_revision WHERE result_id=#{id})"),
        RESULT_VALUES("DELETE FROM result_value WHERE result_revision_id IN (SELECT id FROM generated_result_revision WHERE result_id=#{id})"),
        REVISIONS("DELETE FROM generated_result_revision WHERE result_id=#{id}"), RESULT_TARGETS("DELETE FROM result_target WHERE result_id=#{id}"), RESULT("DELETE FROM generated_result WHERE id=#{id}"),
        REF_PARAMETERS("DELETE FROM reference_parameter WHERE reference_id=#{id}"), WEB("DELETE FROM web_reference WHERE reference_id=#{id}"), TOOL("DELETE FROM tool_reference WHERE reference_id=#{id}"), REF_TARGETS("DELETE FROM reference_target WHERE reference_id=#{id}"), REFERENCE("DELETE FROM source_reference WHERE id=#{id}"),
        ACCESS_SCOPES("DELETE FROM oauth_token_scope WHERE access_token_id=#{id}"), ACCESS("DELETE FROM oauth_access_token WHERE id=#{id}"), CODE("DELETE FROM oauth_authorization_code WHERE id=#{id}"),
        REQUEST_SCOPES("DELETE FROM oauth_request_scope WHERE request_id=#{id}"), REQUEST_RULES("DELETE FROM oauth_request_rule WHERE request_id=#{id}"), REQUEST("DELETE FROM oauth_authorization_request WHERE id=#{id}"), SESSION("DELETE FROM auth_session WHERE id=#{id}"),
        FAMILY_HEAD("UPDATE oauth_refresh_family SET current_token_id=NULL WHERE id=#{id}"), REFRESH_SCOPES("DELETE FROM oauth_refresh_scope WHERE refresh_token_id IN (SELECT id FROM oauth_refresh_token WHERE family_id=#{id})"), REFRESH("DELETE FROM oauth_refresh_token WHERE family_id=#{id}"), FAMILY("DELETE FROM oauth_refresh_family WHERE id=#{id}"),
        GRANT_SCOPES("DELETE FROM oauth_grant_scope WHERE grant_id=#{id}"), GRANT_RULES("DELETE FROM oauth_grant_rule WHERE grant_id=#{id}"), GRANT("DELETE FROM oauth_grant WHERE id=#{id}");
        final String sql; Step(String sql){this.sql=sql;}
    }
    @UpdateProvider(type=Sql.class,method="step") int step(@Param("step") Step step,@Param("id") String id);
    final class Sql {
        public static String candidates(Map<String,Object> values) { return ((Dataset)values.get("dataset")).sql; }
        public static String step(Map<String,Object> values) { return ((Step)values.get("step")).sql; }
    }
}
