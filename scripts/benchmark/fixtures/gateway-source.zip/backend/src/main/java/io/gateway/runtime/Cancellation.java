package io.gateway.runtime;

import java.time.Instant;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

/** Request lifetime; cancellation is best effort and never promises remote rollback. */
public final class Cancellation {
    private final Instant deadline;
    private final AtomicBoolean cancelled = new AtomicBoolean();
    private final CopyOnWriteArrayList<Runnable> callbacks = new CopyOnWriteArrayList<>();
    public Cancellation(Instant deadline) { this.deadline = java.util.Objects.requireNonNull(deadline); }
    public boolean isCancelled() { return cancelled.get() || !Instant.now().isBefore(deadline) || Thread.currentThread().isInterrupted(); }
    public long remainingMillis() { check(); return Math.max(1, java.time.Duration.between(Instant.now(), deadline).toMillis()); }
    public void check() { if (isCancelled()) { cancel(); throw new ExecutionFailure("CANCELLED", ExecutionFailure.Outcome.FAILED_BEFORE_EFFECT); } }
    public AutoCloseable onCancel(Runnable callback) {
        callbacks.add(callback);
        if (isCancelled() && callbacks.remove(callback)) callback.run();
        return () -> callbacks.remove(callback);
    }
    public void cancel() {
        if (cancelled.compareAndSet(false, true)) {
            for (Runnable callback : callbacks) { try { callback.run(); } catch (RuntimeException ignored) { /* cancellation remains best effort */ } }
            callbacks.clear();
        }
    }
}
