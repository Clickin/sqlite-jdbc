package io.gateway;

import io.gateway.authorization.*;
import io.micronaut.context.annotation.Value;
import io.micronaut.http.*;
import io.micronaut.http.annotation.*;
import java.util.Map;

@Controller("/api/workflows")
public final class WorkflowController {
    private final AuthorizationService authorization;
    private final GatewayExecutionService gateway;
    private final String resource;
    public WorkflowController(AuthorizationService authorization,GatewayExecutionService gateway,@Value("${gateway.oauth.rest-resource:}")String resource) {
        this.authorization=authorization;this.gateway=gateway;this.resource=resource;
    }
    @Post(uri="/{key}/execute",consumes=MediaType.APPLICATION_JSON,produces=MediaType.APPLICATION_JSON)
    public HttpResponse<Map<String,Object>> execute(String key,HttpRequest<?> request,@Body Map<String,Object> arguments) {
        if(resource.isBlank())throw AccessDenied.denied();
        var principal=authorization.authenticateBearer(request.getHeaders().getAll(HttpHeaders.AUTHORIZATION),resource);
        var cancellation=gateway.cancellation();
        try(var lifetime=new RequestLifetime(request,cancellation)) {
            var result=gateway.execute(principal,key,arguments,"REST",cancellation);
            int status=result.get("error") instanceof Map<?,?> error && error.get("httpStatus") instanceof Number code?code.intValue():200;
            return HttpResponse.<Map<String,Object>>status(HttpStatus.valueOf(status)).body(result).header(HttpHeaders.CACHE_CONTROL,"no-store");
        }
    }
}
