package io.gateway.operations;

import io.gateway.persistence.PlatformMapper;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.type.JdbcType;
import java.util.*;

/** Offline-only schema inventory controls identifiers; no HTTP endpoint exposes this mapper. */
public interface TransferMapper extends PlatformMapper {
    record ImportedKey(int id,String parent,String childColumn,String parentColumn) {}
    @Select("SELECT id, \"table\" AS parent, \"from\" AS child_column, \"to\" AS parent_column FROM pragma_foreign_key_list(#{table}) ORDER BY id,seq")
    List<ImportedKey> sqliteKeys(@Param("table") String table);
    @SelectProvider(type=Sql.class,method="read") List<Map<String,Object>> rows(@Param("table") RepositoryTransfer.Table table);
    @SelectProvider(type=Sql.class,method="count") long count(@Param("table") RepositoryTransfer.Table table);
    @InsertProvider(type=Sql.class,method="insert") void insert(@Param("table") RepositoryTransfer.Table table,@Param("row") Map<String,Object> row);
    @UpdateProvider(type=Sql.class,method="head") void head(@Param("table") RepositoryTransfer.Table table,@Param("column") String column,@Param("id") Object id,@Param("value") Object value);
    final class Sql {
        static String name(String value) { if(!value.matches("[a-z_][a-z0-9_]*")) throw new IllegalArgumentException("INVALID_SCHEMA_IDENTIFIER"); return "\""+value+"\""; }
        public static String read(Map<String,Object> args) { var table=(RepositoryTransfer.Table)args.get("table"); return "SELECT "+String.join(",",table.columns().keySet().stream().map(Sql::name).toList())+" FROM "+name(table.name()); }
        public static String count(Map<String,Object> args) { return "SELECT count(*) FROM "+name(((RepositoryTransfer.Table)args.get("table")).name()); }
        public static String insert(Map<String,Object> args) {
            var table=(RepositoryTransfer.Table)args.get("table"); List<String> values=new ArrayList<>();
            for(var column:table.columns().entrySet()) values.add("#{row."+column.getKey()+",jdbcType="+JdbcType.forCode(column.getValue()).name()+"}");
            return "INSERT INTO "+name(table.name())+" ("+String.join(",",table.columns().keySet().stream().map(Sql::name).toList())+") VALUES ("+String.join(",",values)+")";
        }
        public static String head(Map<String,Object> args) {
            var table=(RepositoryTransfer.Table)args.get("table"); String column=(String)args.get("column");
            if(!Objects.equals(RepositoryTransfer.HEADS.get(table.name()),column)) throw new IllegalArgumentException("INVALID_TRANSFER_HEAD");
            return "UPDATE "+name(table.name())+" SET "+name(column)+"=#{value,jdbcType=VARCHAR} WHERE id=#{id}";
        }
    }
}
