package io.gateway.connectors.http;

import io.gateway.contracts.ContractService;
import io.gateway.definitions.Definitions;
import io.gateway.runtime.Payload;
import java.io.*;
import java.math.*;
import java.util.*;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.*;
import org.w3c.dom.*;
import org.xml.sax.*;
import tools.jackson.core.StreamReadFeature;
import tools.jackson.databind.DeserializationFeature;
import tools.jackson.databind.json.JsonMapper;

/** Registered field bindings only: no raw XML fragments, XPath, or general mapping language. */
final class WireCodec {
    private static final JsonMapper JSON = JsonMapper.builder()
            .enable(StreamReadFeature.STRICT_DUPLICATE_DETECTION)
            .enable(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)
            .enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)
            .enable(DeserializationFeature.USE_BIG_INTEGER_FOR_INTS).build();
    private static final String XSI = XMLConstants.W3C_XML_SCHEMA_INSTANCE_NS_URI;
    private final Definitions.Representation representation;
    private final ContractService validator;
    private final ContractService.Contract contract;
    private final Map<String, Definitions.Field> fields = new LinkedHashMap<>();
    private final Map<String, List<Definitions.Field>> children = new HashMap<>();
    private final Map<String, Definitions.JsonBinding> json = new HashMap<>();
    private final Map<String, Definitions.XmlBinding> xml = new HashMap<>();
    private final Map<String, Payload.Disposition> dispositions = new LinkedHashMap<>();
    private final boolean isXml;

    WireCodec(Definitions.ResolvedGraph graph, String id, String contractId, ContractService validator) {
        this.validator = validator;
        representation = (Definitions.Representation) graph.require(id).detail();
        require(Objects.equals(contractId, representation.contractObjectId()), "HTTP_REPRESENTATION_CONTRACT");
        require(representation.charset() == null || "UTF-8".equalsIgnoreCase(representation.charset()), "HTTP_CHARSET_UNSUPPORTED");
        String codec = representation.codecId().toUpperCase(Locale.ROOT);
        if (codec.contains("XAPI") || codec.contains("X-API")) throw invalid("XAPI_BLOCKED_INTERNAL_NEXUS");
        require(Set.of("JSON", "XML").contains(codec), "HTTP_CODEC_UNSUPPORTED");
        require(representation.wireProfile() == null || Set.of("DEFAULT", codec).contains(representation.wireProfile()), "HTTP_PROFILE_UNSUPPORTED");
        isXml = codec.equals("XML");
        String media = representation.mediaType();
        require(media != null && media.matches("[A-Za-z0-9!#$&^_.+-]+/[A-Za-z0-9!#$&^_.+-]+")
                && (isXml ? media.endsWith("/xml") || media.endsWith("+xml") : media.endsWith("/json") || media.endsWith("+json")), "HTTP_MEDIA_TYPE");
        Definitions.Contract definition = (Definitions.Contract) graph.require(contractId).detail();
        require(Set.of("VALUE", "XML").contains(definition.modelKind()), "HTTP_CONTRACT_UNSUPPORTED");
        contract = contract(graph, contractId);
        validator.schema(contract);
        for (var field : definition.fields()) {
            fields.put(field.id(), field);
            children.computeIfAbsent(parent(field), _ -> new ArrayList<>()).add(field);
            dispositions.put(field.id(), field.auditDisposition());
        }
        for (var binding : representation.jsonBindings()) {
            require(fields.containsKey(binding.fieldId()) && json.put(binding.fieldId(), binding) == null
                    && binding.memberName() != null && !binding.memberName().isEmpty()
                    && (binding.location() == null || "MEMBER".equals(binding.location())), "HTTP_JSON_BINDING_UNSUPPORTED");
        }
        for (var binding : representation.xmlBindings()) {
            require(fields.containsKey(binding.fieldId()) && xml.put(binding.fieldId(), binding) == null
                    && binding.localName() != null && binding.localName().matches("[A-Za-z_][A-Za-z0-9_.-]*")
                    && !binding.localName().equals("xmlns")
                    && Set.of("ELEMENT", "ATTRIBUTE", "TEXT").contains(binding.nodeKind())
                    && Set.of("OMIT", "XSI_NIL", "ERROR").contains(binding.nullPolicy()), "HTTP_XML_BINDING_UNSUPPORTED");
            var field = fields.get(binding.fieldId());
            require("ELEMENT".equals(binding.nodeKind()) || "SCALAR".equals(field.nodeKind()), "HTTP_XML_SCALAR_BINDING");
            require(!"XSI_NIL".equals(binding.nullPolicy()) || "ELEMENT".equals(binding.nodeKind()), "HTTP_XML_NULL_POLICY");
            require(!field.required() || !field.nullable() || !"OMIT".equals(binding.nullPolicy()), "HTTP_XML_NULL_POLICY");
            require(!Set.of(XMLConstants.XMLNS_ATTRIBUTE_NS_URI, XMLConstants.XML_NS_URI, XSI).contains(namespace(binding)), "HTTP_XML_RESERVED_NAMESPACE");
        }
        require(isXml ? json.isEmpty() && xml.size() == fields.size() : xml.isEmpty(), "HTTP_BINDING_CODEC");
        for (var siblings : children.values()) {
            Set<String> names = new HashSet<>();
            Set<Integer> order = new HashSet<>();
            int texts = 0;
            for (var field : siblings) {
                if (isXml) {
                    var binding = xml.get(field.id());
                    require(names.add(binding.nodeKind() + "|" + namespace(binding) + "|" + binding.localName()) && order.add(binding.ordinal()), "HTTP_XML_DUPLICATE_BINDING");
                    if (binding.nodeKind().equals("TEXT")) texts++;
                } else require(names.add(jsonName(field)), "HTTP_JSON_DUPLICATE_BINDING");
            }
            require(texts == 0 || texts == 1 && siblings.stream().noneMatch(f -> xml.get(f.id()).nodeKind().equals("ELEMENT")), "HTTP_XML_MIXED_CONTENT_UNSUPPORTED");
            siblings.sort(Comparator.comparingInt(f -> isXml ? xml.get(f.id()).ordinal() : f.ordinal()));
        }
        if (isXml) {
            require(children.getOrDefault("", List.of()).size() == 1, "HTTP_XML_ROOT_REQUIRED");
            var root = children.get("").getFirst();
            require(xml.get(root.id()).nodeKind().equals("ELEMENT") && root.required(), "HTTP_XML_ROOT_REQUIRED");
            for (var field : fields.values()) if (field.nodeKind().equals("ARRAY"))
                require(xml.get(children.get(field.id()).getFirst().id()).nodeKind().equals("ELEMENT"), "HTTP_XML_ARRAY_BINDING");
        }
    }

    static ContractService.Contract contract(Definitions.ResolvedGraph graph, String id) {
        var definition = (Definitions.Contract) graph.require(id).detail();
        return new ContractService.Contract(graph.version(id), definition.fields().stream().map(f ->
                new ContractService.Field(f.id(), f.parentFieldId(), f.memberName(), f.nodeKind(), f.valueType(), f.ordinal(),
                        f.required(), f.nullable(), f.precision(), f.scale(), f.maxLength(), f.auditDisposition().name())).toList());
    }

    String contentType() { return representation.mediaType() + "; charset=UTF-8"; }

    byte[] encode(Map<String, Object> input, int maxBytes) throws Exception {
        validator.validate(contract, input);
        var output = new LimitedOutput(maxBytes);
        if (!isXml) JSON.writeValue(output, jsonObject(children.getOrDefault("", List.of()), input, true));
        else {
            var writer = XMLOutputFactory.newFactory().createXMLStreamWriter(output, "UTF-8");
            try {
                writer.writeStartDocument("UTF-8", "1.0");
                var root = children.get("").getFirst();
                writeXml(writer, root, input.get(root.memberName()), new int[] {0});
                writer.writeEndDocument();
            } finally { writer.close(); }
        }
        return output.toByteArray();
    }

    Payload decode(byte[] bytes, int maxRows) throws Exception {
        Map<String,Object> value;
        if (!isXml) {
            Object parsed = JSON.readValue(bytes, Object.class);
            require(parsed instanceof Map<?,?>, "HTTP_JSON_OBJECT_REQUIRED");
            value = jsonObject(children.getOrDefault("", List.of()), (Map<?,?>) parsed, false);
        } else {
            var factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            factory.setXIncludeAware(false);
            factory.setExpandEntityReferences(false);
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
            factory.setAttribute("jdk.xml.maxElementDepth", "64");
            var builder = factory.newDocumentBuilder();
            builder.setEntityResolver((publicId, systemId) -> { throw new SAXException("HTTP_XML_EXTERNAL_ENTITY"); });
            builder.setErrorHandler(new ErrorHandler() {
                public void warning(SAXParseException e) throws SAXException { throw new SAXException("HTTP_XML_INVALID"); }
                public void error(SAXParseException e) throws SAXException { throw new SAXException("HTTP_XML_INVALID"); }
                public void fatalError(SAXParseException e) throws SAXException { throw new SAXException("HTTP_XML_INVALID"); }
            });
            Element element = builder.parse(new ByteArrayInputStream(bytes)).getDocumentElement();
            var root = children.get("").getFirst();
            require(matches(element, xml.get(root.id())), "HTTP_XML_ROOT_MISMATCH");
            value = new LinkedHashMap<>();
            value.put(root.memberName(), readXml(root, element));
        }
        countRows(value, maxRows, new int[] {0});
        validator.validate(contract, value);
        return new Payload(value, dispositions);
    }

    private Map<String,Object> jsonObject(List<Definitions.Field> siblings, Map<?,?> input, boolean encode) {
        var result = new LinkedHashMap<String,Object>();
        var allowed = new HashSet<String>();
        for (var field : siblings) {
            String from = encode ? field.memberName() : jsonName(field);
            String to = encode ? jsonName(field) : field.memberName();
            allowed.add(from);
            if (input.containsKey(from)) result.put(to, jsonValue(field, input.get(from), encode));
        }
        require(allowed.containsAll(input.keySet()), "HTTP_JSON_UNKNOWN_MEMBER");
        return result;
    }

    private Object jsonValue(Definitions.Field field, Object value, boolean encode) {
        if (value == null) return null;
        if (field.nodeKind().equals("OBJECT")) {
            require(value instanceof Map<?,?>, "HTTP_JSON_OBJECT_REQUIRED");
            return jsonObject(children.getOrDefault(field.id(), List.of()), (Map<?,?>) value, encode);
        }
        if (field.nodeKind().equals("ARRAY")) {
            require(value instanceof List<?>, "HTTP_JSON_ARRAY_REQUIRED");
            var item = children.get(field.id()).getFirst();
            return ((List<?>) value).stream().map(v -> jsonValue(item, v, encode)).toList();
        }
        if (!encode && "BINARY".equals(field.valueType())) {
            require(value instanceof String, "HTTP_JSON_BASE64_REQUIRED");
            return Base64.getDecoder().decode((String) value);
        }
        return value;
    }

    private void writeXml(XMLStreamWriter writer, Definitions.Field field, Object value, int[] prefix) throws Exception {
        var binding = xml.get(field.id());
        if (value == null && binding.nullPolicy().equals("OMIT")) return;
        require(value != null || binding.nullPolicy().equals("XSI_NIL"), "HTTP_XML_NULL_REJECTED");
        if (binding.nodeKind().equals("ATTRIBUTE")) {
            if (namespace(binding).isEmpty()) writer.writeAttribute(binding.localName(), scalarText(value));
            else {
                String p = "n" + prefix[0]++;
                writer.writeNamespace(p, namespace(binding));
                writer.writeAttribute(p, namespace(binding), binding.localName(), scalarText(value));
            }
            return;
        }
        if (binding.nodeKind().equals("TEXT")) { writer.writeCharacters(scalarText(value)); return; }
        writer.writeStartElement("", binding.localName(), namespace(binding));
        writer.writeDefaultNamespace(namespace(binding));
        if (value == null) {
            writer.writeNamespace("xsi", XSI);
            writer.writeAttribute("xsi", XSI, "nil", "true");
        } else if (field.nodeKind().equals("OBJECT")) {
            var map = (Map<?,?>) value;
            var nested = children.getOrDefault(field.id(), List.of());
            for (var child : nested) if (xml.get(child.id()).nodeKind().equals("ATTRIBUTE") && map.containsKey(child.memberName()))
                writeXml(writer, child, map.get(child.memberName()), prefix);
            for (var child : nested) if (!xml.get(child.id()).nodeKind().equals("ATTRIBUTE") && map.containsKey(child.memberName()))
                writeXml(writer, child, map.get(child.memberName()), prefix);
        } else if (field.nodeKind().equals("ARRAY")) {
            var child = children.get(field.id()).getFirst();
            for (var item : (List<?>) value) writeXml(writer, child, item, prefix);
        } else writer.writeCharacters(scalarText(value));
        writer.writeEndElement();
    }

    private Object readXml(Definitions.Field field, Element element) {
        var binding = xml.get(field.id());
        String nil = element.getAttributeNS(XSI, "nil");
        if (!nil.isEmpty()) {
            require(binding.nullPolicy().equals("XSI_NIL") && Set.of("true", "1").contains(nil)
                    && element.getTextContent().isEmpty() && element.getElementsByTagName("*").getLength() == 0, "HTTP_XML_INVALID_NIL");
            checkAttributes(element, Set.of(XSI + "|nil"));
            return null;
        }
        if (field.nodeKind().equals("SCALAR")) {
            checkAttributes(element, Set.of());
            require(element.getElementsByTagName("*").getLength() == 0, "HTTP_XML_SCALAR_REQUIRED");
            return scalar(field, element.getTextContent());
        }
        var nested = children.getOrDefault(field.id(), List.of());
        var byName = new HashMap<String, Definitions.Field>();
        var result = new LinkedHashMap<String,Object>();
        var attributes = new HashSet<String>();
        Definitions.Field text = null;
        for (var child : nested) {
            var b = xml.get(child.id());
            String key = namespace(b) + "|" + b.localName();
            switch (b.nodeKind()) {
                case "ATTRIBUTE" -> {
                    attributes.add(key);
                    if (element.hasAttributeNS(namespace(b).isEmpty() ? null : namespace(b), b.localName()))
                        result.put(child.memberName(), scalar(child, element.getAttributeNS(namespace(b).isEmpty() ? null : namespace(b), b.localName())));
                }
                case "TEXT" -> text = child;
                default -> byName.put(key, child);
            }
        }
        checkAttributes(element, attributes);
        var items = new ArrayList<Object>();
        StringBuilder content = new StringBuilder();
        int ordinal = Integer.MIN_VALUE;
        for (Node n = element.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (n instanceof Element childElement) {
                var child = byName.get(Objects.toString(n.getNamespaceURI(), "") + "|" + n.getLocalName());
                require(child != null, "HTTP_XML_UNKNOWN_ELEMENT");
                int next = xml.get(child.id()).ordinal();
                require(next >= ordinal, "HTTP_XML_ELEMENT_ORDER");
                ordinal = next;
                Object value = readXml(child, childElement);
                if (field.nodeKind().equals("ARRAY")) items.add(value);
                else {
                    require(!result.containsKey(child.memberName()), "HTTP_XML_DUPLICATE_ELEMENT");
                    result.put(child.memberName(), value);
                }
            } else if (n.getNodeType() == Node.TEXT_NODE || n.getNodeType() == Node.CDATA_SECTION_NODE) content.append(n.getNodeValue());
            else require(n.getNodeType() == Node.COMMENT_NODE, "HTTP_XML_NODE_UNSUPPORTED");
        }
        if (text != null) result.put(text.memberName(), scalar(text, content.toString()));
        else require(content.toString().isBlank(), "HTTP_XML_MIXED_CONTENT_UNSUPPORTED");
        return field.nodeKind().equals("ARRAY") ? items : result;
    }

    private static void checkAttributes(Element element, Set<String> allowed) {
        NamedNodeMap attributes = element.getAttributes();
        for (int i = 0; i < attributes.getLength(); i++) {
            Node attribute = attributes.item(i);
            require(XMLConstants.XMLNS_ATTRIBUTE_NS_URI.equals(attribute.getNamespaceURI())
                    || allowed.contains(Objects.toString(attribute.getNamespaceURI(), "") + "|" + attribute.getLocalName()), "HTTP_XML_UNKNOWN_ATTRIBUTE");
        }
    }

    private static Object scalar(Definitions.Field field, String text) {
        return switch (field.valueType()) {
            case "BINARY" -> Base64.getDecoder().decode(text);
            case "INTEGER", "LONG" -> new BigInteger(text);
            case "NUMBER", "DECIMAL" -> new BigDecimal(text);
            case "BOOLEAN" -> {
                require(Set.of("true", "false", "1", "0").contains(text), "HTTP_XML_BOOLEAN");
                yield text.equals("true") || text.equals("1");
            }
            default -> text;
        };
    }

    private static String scalarText(Object value) {
        if (value instanceof byte[] bytes) return Base64.getEncoder().encodeToString(bytes);
        String text = value instanceof BigDecimal d ? d.toPlainString() : value.toString();
        require(text.codePoints().allMatch(c -> c == 9 || c == 10 || c == 13 || c >= 32 && c <= 0xD7FF
                || c >= 0xE000 && c <= 0xFFFD || c >= 0x10000 && c <= 0x10FFFF), "HTTP_XML_CHARACTER");
        return text;
    }
    private String jsonName(Definitions.Field field) { return json.containsKey(field.id()) ? json.get(field.id()).memberName() : field.memberName(); }
    private static String parent(Definitions.Field field) { return Objects.toString(field.parentFieldId(), ""); }
    private static String namespace(Definitions.XmlBinding binding) { return Objects.toString(binding.namespaceUri(), ""); }
    private static boolean matches(Element element, Definitions.XmlBinding binding) {
        return namespace(binding).equals(Objects.toString(element.getNamespaceURI(), "")) && binding.localName().equals(element.getLocalName());
    }
    private static void countRows(Object value, int max, int[] total) {
        if (value instanceof List<?> list) {
            require(list.size() <= max - total[0], "HTTP_RESULT_ROWS_LIMIT");
            total[0] += list.size();
            list.forEach(v -> countRows(v, max, total));
        } else if (value instanceof Map<?,?> map) map.values().forEach(v -> countRows(v, max, total));
    }
    static void require(boolean condition, String code) { if (!condition) throw invalid(code); }
    static IllegalArgumentException invalid(String code) { return new IllegalArgumentException(code); }

    static final class LimitedOutput extends ByteArrayOutputStream {
        private final int max;
        LimitedOutput(int max) { super(Math.min(max, 8192)); this.max = max; }
        @Override public synchronized void write(int b) { require(count < max, "HTTP_REQUEST_BYTES_LIMIT"); super.write(b); }
        @Override public synchronized void write(byte[] b, int off, int len) {
            require(len <= max - count, "HTTP_REQUEST_BYTES_LIMIT"); super.write(b, off, len);
        }
    }
}
