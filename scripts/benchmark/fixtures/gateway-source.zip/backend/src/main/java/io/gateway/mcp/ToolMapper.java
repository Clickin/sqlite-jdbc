package io.gateway.mcp;

import io.gateway.persistence.PlatformMapper;
import org.apache.ibatis.annotations.*;
import java.util.List;

public interface ToolMapper extends PlatformMapper {
    record Tool(String objectId,String versionId,String name,String description,String workflowId,
                String inputVersion,String outputVersion,String securityBindingId,String targetPolicyId,
                String inputMappingId,String outputMappingId,String effectKind,long generation) {}
    record Action(String id,String key,String targetKind,String stageKey,String securityBindingId,String targetPolicyId) {}
    record TargetPolicy(String versionId,String kind,String organization,String identifierSystem,String resolverOperationId) {}
    record TargetBinding(String fieldId,String targetPart,String sourcePort) {}
    record Dependency(String objectId,String versionId,long generation) {}

    @Select("""
        SELECT o.id AS objectId,t.version_id AS versionId,t.public_name AS name,t.description,
        t.workflow_object_id AS workflowId,t.public_input_contract_version_id AS inputVersion,
        t.public_output_contract_version_id AS outputVersion,t.security_binding_object_id AS securityBindingId,
        t.target_policy_object_id AS targetPolicyId,t.input_mapping_object_id AS inputMappingId,
        t.output_mapping_object_id AS outputMappingId,t.effect_kind AS effectKind,o.generation
        FROM config_object o JOIN mcp_tool_version t ON t.version_id=o.current_version_id
        WHERE o.enabled=TRUE ORDER BY t.public_name
        """)
    List<Tool> tools();

    @Select("""
        SELECT a.id,a.action_key AS key,a.target_kind AS targetKind,'INPUT' AS stageKey,
        t.security_binding_object_id AS securityBindingId,t.target_policy_object_id AS targetPolicyId
        FROM mcp_tool_action x JOIN protected_action a ON a.id=x.action_id
        JOIN mcp_tool_version t ON t.version_id=x.tool_version_id WHERE x.tool_version_id=#{version}
        ORDER BY a.action_key
        """)
    List<Action> toolActions(@Param("version") String version);

    @Select("""
        SELECT a.id,a.action_key AS key,a.target_kind AS targetKind,w.stage_key AS stageKey,
        w.security_binding_object_id AS securityBindingId,w.target_policy_object_id AS targetPolicyId
        FROM workflow_security_binding w JOIN protected_action a ON a.id=w.required_action_id
        WHERE w.workflow_version_id=#{version} ORDER BY w.stage_key,a.action_key
        """)
    List<Action> workflowActions(@Param("version") String version);

    @Select("""
        SELECT p.version_id AS versionId,p.target_kind AS kind,p.canonical_organization AS organization,
        p.identifier_system AS identifierSystem,p.resolver_operation_object_id AS resolverOperationId
        FROM config_object o JOIN target_policy_version p ON p.version_id=o.current_version_id
        WHERE o.id=#{id} AND o.enabled=TRUE
        """)
    TargetPolicy policy(@Param("id") String id);

    @Select("""
        SELECT contract_field_id AS fieldId,target_part AS targetPart,source_port AS sourcePort FROM target_argument_binding
        WHERE target_policy_version_id=#{version} ORDER BY ordinal
        """)
    List<TargetBinding> bindings(@Param("version") String version);

    @Select("""
        SELECT s.scope_name FROM mcp_tool_scope x JOIN oauth_scope s ON s.id=x.scope_id
        WHERE x.tool_version_id=#{version} ORDER BY s.scope_name
        """)
    List<String> scopes(@Param("version") String version);

    @Select("SELECT id AS objectId,current_version_id AS versionId,generation FROM config_object WHERE id=#{id} AND enabled=TRUE")
    Dependency dependency(@Param("id") String id);

    @Select("""
        SELECT r.role_object_id FROM external_role_mapping r
        WHERE r.security_binding_version_id=#{version} ORDER BY r.role_object_id
        """)
    List<String> roles(@Param("version") String version);

    @Select("SELECT id FROM config_object WHERE kind='WORKFLOW' AND logical_key=#{key} AND enabled=TRUE")
    String workflow(@Param("key") String key);

    @Select("""
        <script>SELECT count(*) FROM config_object WHERE enabled=TRUE AND current_version_id IS NOT NULL
        AND id IN <foreach item="id" collection="ids" open="(" separator="," close=")">#{id}</foreach></script>
        """)
    int enabledDefinitions(@Param("ids") java.util.Set<String> ids);

    @Select("""
        <script>SELECT count(*) FROM credential_state s JOIN config_version v ON v.id=s.credential_version_id
        JOIN config_object o ON o.id=v.object_id WHERE o.enabled=TRUE AND s.revoked_at IS NULL
        AND v.id IN <foreach item="id" collection="versions" open="(" separator="," close=")">#{id}</foreach></script>
        """)
    int liveCredentials(@Param("versions") List<String> versions);
}
