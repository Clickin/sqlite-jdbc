package io.gateway.authorization;

/** Created from live persisted credentials, never bound from a request DTO. */
public final class AuthenticatedPrincipal {
    private final String principalId, identityProvider, subject, clientId, grantId, tokenId, sessionId, resource;
    AuthenticatedPrincipal(String principalId, String identityProvider, String subject, String clientId, String grantId, String tokenId, String sessionId, String resource) {
        this.principalId=principalId; this.identityProvider=identityProvider; this.subject=subject; this.clientId=clientId; this.grantId=grantId; this.tokenId=tokenId; this.sessionId=sessionId; this.resource=resource;
    }
    public String principalId(){ return principalId; }
    public String identityProvider(){ return identityProvider; }
    public String subject(){ return subject; }
    public String clientId(){ return clientId; }
    public String grantId(){ return grantId; }
    public String tokenId(){ return tokenId; }
    public String sessionId(){ return sessionId; }
    public String resource(){ return resource; }
    public boolean management(){ return sessionId != null && tokenId == null; }
}
