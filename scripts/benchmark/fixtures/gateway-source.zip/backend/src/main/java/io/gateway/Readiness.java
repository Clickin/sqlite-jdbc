package io.gateway;

import io.gateway.oauth.OAuthSettings;
import io.gateway.persistence.PlatformStore;
import io.micronaut.context.annotation.Context;
import io.micronaut.context.annotation.Requires;

/** Eager construction completes migration and validates finite authentication settings before serving. */
@Context
@Requires(property="micronaut.server.enabled",notEquals="false",defaultValue="true")
public final class Readiness {
    public Readiness(PlatformStore store,OAuthSettings settings) {
        java.util.Objects.requireNonNull(store);
        java.util.Objects.requireNonNull(settings);
    }
}
