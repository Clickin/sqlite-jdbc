package io.gateway.connectors.http;

import io.gateway.connectors.OperationAdapter;
import io.gateway.contracts.ContractService;
import io.gateway.credentials.CredentialService;
import io.gateway.definitions.Definitions;
import io.gateway.runtime.*;
import io.micronaut.context.annotation.Value;
import jakarta.annotation.PreDestroy;
import jakarta.inject.Singleton;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import org.apache.hc.client5.http.DnsResolver;
import org.apache.hc.client5.http.classic.methods.HttpUriRequestBase;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.impl.io.ManagedHttpClientConnectionFactory;
import org.apache.hc.client5.http.protocol.HttpClientContext;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.config.Http1Config;
import org.apache.hc.core5.http.io.entity.ByteArrayEntity;
import org.apache.hc.core5.util.Timeout;

import static io.gateway.connectors.http.WireCodec.require;
import static io.gateway.runtime.ExecutionFailure.Outcome.*;

/** Connection ownership only; immutable graph selection belongs to the runtime scope. */
@Singleton
public final class HttpResources implements AutoCloseable {
    private static final Pattern TOKEN = Pattern.compile("[!#$%&'*+.^_`|~0-9A-Za-z-]+");
    private static final Pattern PLACEHOLDER = Pattern.compile("\\{([A-Za-z_][A-Za-z0-9_-]*)}");
    private static final Set<String> RESERVED_HEADERS = Set.of("host", "content-length", "transfer-encoding", "connection", "proxy-authorization", "proxy-connection", "upgrade", "trailer", "te", "expect", "content-type", "accept-encoding");
    private static final String WRITE_ATTEMPT = "gateway.http.writeAttempt";
    private static final String CONFIRMED = "gateway.http.confirmed";
    private record ConnectionKey(URI baseUri, int poolMaxTotal, int poolMaxPerRoute, int connectTimeoutMs,
                                 int maxConcurrent, int queueTimeoutMs, String credentialVersion) {}
    private final CredentialService credentials;
    private final ContractService contracts;
    private final int maxRequestBytes;
    private final int defaultResponseBytes;
    private final int defaultRows;
    private final Map<ConnectionKey, Shared> resources = new HashMap<>();
    private final ScheduledExecutorService deadlines = Executors.newSingleThreadScheduledExecutor(Thread.ofPlatform().daemon().name("http-deadline").factory());
    private boolean closed;

    public HttpResources(CredentialService credentials, ContractService contracts,
                         @Value("${gateway.http.max-request-bytes:1048576}") int maxRequestBytes,
                         @Value("${gateway.http.max-response-bytes:8388608}") int defaultResponseBytes,
                         @Value("${gateway.http.max-result-rows:10000}") int defaultRows) {
        require(maxRequestBytes > 0 && defaultResponseBytes > 0 && defaultRows > 0, "HTTP_INVALID_LIMITS");
        this.credentials = credentials;
        this.contracts = contracts;
        this.maxRequestBytes = maxRequestBytes;
        this.defaultResponseBytes = defaultResponseBytes;
        this.defaultRows = defaultRows;
    }

    /** Management-only connection diagnostic: TCP/TLS, never HTTP or business authentication. */
    public void probe(Definitions.ResolvedGraph graph, String sourceObjectId) {
        try {
            synchronized (resources) { require(!closed, "HTTP_RESOURCES_CLOSED"); }
            var source = (Definitions.HttpSource) graph.require(sourceObjectId).detail();
            URI base = validateSource(source);
            if (source.credentialObjectId() != null) credentials.checkVersion(graph.version(source.credentialObjectId()));
            try (var socket = new Socket(Proxy.NO_PROXY)) {
                var completed = new CompletableFuture<Void>();
                Thread worker = Thread.ofVirtual().name("http-connection-probe").start(() -> {
                    try {
                        InetAddress address = registeredAddresses(base)[0];
                        if (Thread.currentThread().isInterrupted()) throw new IOException("HTTP_PROBE_CANCELLED");
                        int port = base.getPort() >= 0 ? base.getPort() : base.getScheme().equals("https") ? 443 : 80;
                        socket.connect(new InetSocketAddress(address, port), source.connectTimeoutMs());
                        if (base.getScheme().equals("https")) {
                            var factory = (SSLSocketFactory) SSLSocketFactory.getDefault();
                            try (var tls = (SSLSocket) factory.createSocket(socket, base.getHost(), port, true)) {
                                var parameters = tls.getSSLParameters();
                                parameters.setEndpointIdentificationAlgorithm("HTTPS");
                                tls.setSSLParameters(parameters);
                                tls.setSoTimeout(source.connectTimeoutMs());
                                tls.startHandshake();
                            }
                        }
                        completed.complete(null);
                    } catch (Exception ignored) {
                        completed.completeExceptionally(new ExecutionFailure("HTTP_CONNECTION_PROBE_FAILED", FAILED_BEFORE_EFFECT));
                    }
                });
                try { completed.get(source.connectTimeoutMs(), TimeUnit.MILLISECONDS); }
                finally {
                    // DNS cancellation is platform-dependent; the closed socket prevents a delayed connect.
                    worker.interrupt();
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ExecutionFailure("HTTP_CONNECTION_PROBE_CANCELLED", FAILED_BEFORE_EFFECT);
        } catch (Exception e) {
            throw new ExecutionFailure("HTTP_CONNECTION_PROBE_FAILED", FAILED_BEFORE_EFFECT);
        }
    }

    private static InetAddress[] registeredAddresses(URI base) throws UnknownHostException {
        InetAddress[] addresses = InetAddress.getAllByName(base.getHost());
        for (InetAddress address : addresses)
            require(!address.isAnyLocalAddress() && !address.isMulticastAddress() && !address.isLinkLocalAddress(), "HTTP_DESTINATION_REJECTED");
        return addresses;
    }

    public OperationAdapter prepare(Definitions.ResolvedGraph graph, Definitions.HttpOperation operation) {
        try {
            var source = (Definitions.HttpSource) graph.require(operation.sourceObjectId()).detail();
            URI base = validateSource(source);
            validateOperation(operation);
            ContractService.Contract input = WireCodec.contract(graph, operation.inputContractObjectId());
            contracts.schema(input);
            var output = WireCodec.contract(graph, operation.outputContractObjectId());
            contracts.schema(output);
            WireCodec requestCodec = operation.requestRepresentationObjectId() == null ? null
                    : new WireCodec(graph, operation.requestRepresentationObjectId(), operation.inputContractObjectId(), contracts);
            WireCodec responseCodec = operation.responseRepresentationObjectId() == null ? null
                    : new WireCodec(graph, operation.responseRepresentationObjectId(), operation.outputContractObjectId(), contracts);
            require(responseCodec != null || output.fields().isEmpty(), "HTTP_RESPONSE_REPRESENTATION_REQUIRED");
            var parameterPaths = validateParameters(operation, input);
            String credentialVersion = source.credentialObjectId() == null ? null : graph.version(source.credentialObjectId());
            require(source.authenticationKind().equals("NONE") || credentialVersion != null, "HTTP_CREDENTIAL_REQUIRED");
            for (var header : source.headers()) require(header.credentialPart() == null || credentialVersion != null, "HTTP_CREDENTIAL_REQUIRED");
            var key = new ConnectionKey(base, source.poolMaxTotal(), source.poolMaxPerRoute(), source.connectTimeoutMs(),
                    source.maxConcurrent(), source.queueTimeoutMs(), credentialVersion);
            Shared shared;
            synchronized (resources) {
                require(!closed, "HTTP_RESOURCES_CLOSED");
                shared = resources.get(key);
                if (shared == null) {
                    shared = new Shared(key, source, base);
                    resources.put(key, shared);
                }
                shared.references++;
            }
            return new Adapter(shared, source, operation, input, parameterPaths, requestCodec, responseCodec, credentialVersion);
        } catch (ExecutionFailure e) { throw e; }
        catch (Exception e) {
            String code = e instanceof IllegalArgumentException && e.getMessage()!=null && e.getMessage().matches("[A-Z_]{1,128}")
                    ? e.getMessage() : "HTTP_PREPARATION_FAILED";
            throw new ExecutionFailure(code, FAILED_BEFORE_EFFECT);
        }
    }

    private final class Adapter implements OperationAdapter {
        private final Shared shared;
        private final Definitions.HttpSource source;
        private final Definitions.HttpOperation operation;
        private final ContractService.Contract inputContract;
        private final Map<String,List<String>> parameterPaths;
        private final WireCodec requestCodec;
        private final WireCodec responseCodec;
        private final String credentialVersion;
        private final AtomicBoolean adapterClosed = new AtomicBoolean();

        Adapter(Shared shared, Definitions.HttpSource source, Definitions.HttpOperation operation,
                ContractService.Contract inputContract, Map<String,List<String>> parameterPaths,
                WireCodec requestCodec, WireCodec responseCodec, String credentialVersion) {
            this.shared = shared; this.source = source; this.operation = operation; this.inputContract = inputContract;
            this.parameterPaths = parameterPaths;
            this.requestCodec = requestCodec; this.responseCodec = responseCodec; this.credentialVersion = credentialVersion;
        }

        @Override public Payload execute(Payload input, Cancellation cancellation) {
            synchronized (resources) {
                if (closed || adapterClosed.get()) throw new ExecutionFailure("HTTP_ADAPTER_CLOSED", FAILED_BEFORE_EFFECT);
                shared.references++;
            }
            boolean acquired = false;
            HttpUriRequestBase request = null;
            ScheduledFuture<?> timer = null;
            AutoCloseable cancelRegistration = null;
            HttpClientContext context = HttpClientContext.create();
            long end = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(operation.timeoutMs());
            try {
                cancellation.check();
                Map<String,Object> body = input.object();
                if (body.containsKey("authorized")) {
                    body = new LinkedHashMap<>(body);
                    body.remove("authorized"); // Verified runner context is not part of the source wire contract.
                }
                contracts.validate(inputContract, body);
                request = new HttpUriRequestBase(operation.method(), requestUri(shared.base, operation, parameterPaths, body));
                for (var parameter : operation.parameters()) if (parameter.location().equals("HEADER")) {
                    String value = parameterValue(parameter, parameterPaths, body);
                    if (value != null) { validateHeader(parameter.wireName(), value, false); request.addHeader(parameter.wireName(), value); }
                }
                if (requestCodec != null) {
                    byte[] bytes = requestCodec.encode(body, maxRequestBytes);
                    request.setEntity(new ByteArrayEntity(bytes, ContentType.parse(requestCodec.contentType())));
                }
                if (responseCodec != null) request.setHeader("Accept", responseCodec.contentType());
                long remaining = remaining(end, cancellation);
                acquired = shared.concurrent.tryAcquire(Math.min(source.queueTimeoutMs(), remaining), TimeUnit.MILLISECONDS);
                if (!acquired) throw new ExecutionFailure("HTTP_CONCURRENCY_LIMIT", FAILED_BEFORE_EFFECT);
                // Resolve the exact selected version immediately before this request, never a cached secret.
                if (credentialVersion != null) {
                    try (var secret = credentials.resolveVersion(credentialVersion)) { credentialHeaders(request, source, secret); }
                } else credentialHeaders(request, source, null);
                long requestSize = request.getRequestUri().getBytes(StandardCharsets.UTF_8).length;
                if (request.getEntity() != null) requestSize += request.getEntity().getContentLength();
                for (var header : request.getHeaders())
                    requestSize += header.getName().length() + header.getValue().getBytes(StandardCharsets.UTF_8).length + 4L;
                require(requestSize <= maxRequestBytes, "HTTP_REQUEST_BYTES_LIMIT");
                remaining = remaining(end, cancellation);
                request.setConfig(RequestConfig.custom()
                        .setAuthenticationEnabled(false).setRedirectsEnabled(false).setExpectContinueEnabled(false)
                        .setHardCancellationEnabled(true).setProtocolUpgradeEnabled(false)
                        .setConnectionRequestTimeout(Timeout.ofMilliseconds(Math.min(source.queueTimeoutMs(), remaining)))
                        .setResponseTimeout(Timeout.ofMilliseconds(remaining)).build());
                final HttpUriRequestBase active = request;
                cancelRegistration = cancellation.onCancel(active::cancel);
                timer = deadlines.schedule(active::cancel, remaining, TimeUnit.MILLISECONDS);
                cancellation.check();
                return shared.client.execute(request, context, response -> {
                    int status = response.getCode();
                    ExecutionFailure.Outcome outcome = statusOutcome(status, operation);
                    if (outcome != SUCCEEDED) {
                        active.cancel(); // Do not drain an unbounded error body merely to salvage its connection.
                        throw new ExecutionFailure(status >= 300 && status < 400 ? "HTTP_REDIRECT_REJECTED" : "HTTP_STATUS_"+status, outcome);
                    }
                    context.setAttribute(CONFIRMED, Boolean.TRUE);
                    try {
                        long maximum = operation.maxResultBytes() == null ? defaultResponseBytes : Math.min(defaultResponseBytes, operation.maxResultBytes());
                        var encoding = response.getFirstHeader("Content-Encoding");
                        require(encoding == null || encoding.getValue().equalsIgnoreCase("identity"), "HTTP_CONTENT_ENCODING_UNSUPPORTED");
                        var entity = response.getEntity();
                        byte[] bytes;
                        if (entity == null) bytes = new byte[0];
                        else {
                            require(entity.getContentLength() < 0 || entity.getContentLength() <= maximum, "HTTP_RESPONSE_BYTES_LIMIT");
                            // The response owns this stream; cancellation precedes close on a bound failure.
                            bytes = readBounded(entity.getContent(), (int) maximum, end, cancellation);
                        }
                        remaining(end, cancellation);
                        if (responseCodec == null) { require(bytes.length == 0, "HTTP_UNEXPECTED_BODY"); return Payload.of(Map.of()); }
                        Payload decoded = responseCodec.decode(bytes, operation.maxResultRows() == null ? defaultRows : Math.min(defaultRows, operation.maxResultRows()));
                        remaining(end, cancellation);
                        return decoded;
                    } catch (Exception e) {
                        active.cancel();
                        throw new ExecutionFailure("HTTP_RESPONSE_FAILED", SUCCEEDED, true);
                    }
                });
            } catch (ExecutionFailure e) { throw e; }
            catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw transportFailure("HTTP_CANCELLED", context);
            } catch (Exception e) {
                throw transportFailure("HTTP_REQUEST_FAILED", context);
            } finally {
                if (timer != null) timer.cancel(false);
                if (cancelRegistration != null) try { cancelRegistration.close(); } catch (Exception ignored) { /* local callback removal */ }
                if (request != null) request.cancel();
                if (acquired) shared.concurrent.release();
                release(shared);
            }
        }
        @Override public void close() { if (adapterClosed.compareAndSet(false, true)) release(shared); }

        private ExecutionFailure transportFailure(String code, HttpClientContext context) {
            boolean confirmed = Boolean.TRUE.equals(context.getAttribute(CONFIRMED));
            return new ExecutionFailure(code, confirmed ? SUCCEEDED : attempted(context)
                ? operation.effect()==Definitions.Effect.READ_ONLY ? FAILED : OUTCOME_UNKNOWN : FAILED_BEFORE_EFFECT, confirmed);
        }
    }

    private static boolean attempted(HttpClientContext context) { return Boolean.TRUE.equals(context.getAttribute(WRITE_ATTEMPT)); }

    private final class Shared {
        final ConnectionKey key;
        final URI base;
        final CloseableHttpClient client;
        final Semaphore concurrent;
        int references;
        Shared(ConnectionKey key, Definitions.HttpSource source, URI base) throws IOException {
            this.key = key; this.base = base;
            concurrent = new Semaphore(source.maxConcurrent(), true);
            InetAddress[] addresses = registeredAddresses(base);
            // Pin the registered host for this connection configuration; private/loopback addresses are supported.
            DnsResolver resolver = new DnsResolver() {
                public InetAddress[] resolve(String host) throws UnknownHostException {
                    if (!base.getHost().equalsIgnoreCase(host)) throw new UnknownHostException("HTTP_UNREGISTERED_HOST");
                    return addresses.clone();
                }
                public String resolveCanonicalHostname(String host) throws UnknownHostException {
                    if (!base.getHost().equalsIgnoreCase(host)) throw new UnknownHostException("HTTP_UNREGISTERED_HOST");
                    return host;
                }
            };
            var manager = PoolingHttpClientConnectionManagerBuilder.create().setDnsResolver(resolver)
                    .setConnectionFactory(ManagedHttpClientConnectionFactory.builder().http1Config(Http1Config.custom()
                            .setMaxLineLength(Math.min(defaultResponseBytes, 8192)).setMaxHeaderCount(100).build()).build())
                    .setMaxConnTotal(source.poolMaxTotal()).setMaxConnPerRoute(source.poolMaxPerRoute())
                    .setDefaultConnectionConfig(ConnectionConfig.custom().setConnectTimeout(Timeout.ofMilliseconds(source.connectTimeoutMs())).build()).build();
            client = HttpClients.custom().setConnectionManager(manager)
                    .disableAutomaticRetries().disableRedirectHandling().disableAuthCaching().disableCookieManagement().disableContentCompression()
                    .addRequestInterceptorLast((request, entity, context) -> context.setAttribute(WRITE_ATTEMPT, Boolean.TRUE)).build();
        }
    }

    private void release(Shared shared) {
        synchronized (resources) {
            if (--shared.references == 0) {
                resources.remove(shared.key, shared);
                try { shared.client.close(); } catch (IOException ignored) { /* never expose transport diagnostics */ }
            }
        }
    }

    @PreDestroy @Override public void close() {
        synchronized (resources) { closed = true; }
        // Runtime leases own clients; shutdown must not close another request's active stream.
        deadlines.shutdown();
    }

    private static URI validateSource(Definitions.HttpSource source) {
        URI uri = URI.create(source.baseUri());
        require(Set.of("http", "https").contains(uri.getScheme()) && uri.getHost() != null && uri.getRawUserInfo() == null
                && uri.getRawQuery() == null && uri.getRawFragment() == null && uri.normalize().equals(uri)
                && !source.baseUri().contains("\\") && !hasControl(source.baseUri()), "HTTP_BASE_URI");
        require(source.tlsProfileObjectId() == null && source.proxyProfileId() == null && source.networkPolicyObjectId() == null, "HTTP_NETWORK_PROFILE_UNSUPPORTED");
        require(Set.of("NONE", "NEVER", "REJECT").contains(source.redirectPolicy()), "HTTP_REDIRECT_POLICY_UNSUPPORTED");
        require(Set.of("NONE", "BASIC", "BEARER", "HEADER").contains(source.authenticationKind()), "HTTP_AUTH_UNSUPPORTED");
        require(source.poolMaxTotal() > 0 && source.poolMaxPerRoute() > 0 && source.connectTimeoutMs() > 0
                && source.maxConcurrent() > 0 && source.queueTimeoutMs() > 0, "HTTP_SOURCE_LIMITS");
        for (var header : source.headers()) {
            require((header.literalValue() == null) != (header.credentialPart() == null), "HTTP_HEADER_BINDING");
            validateHeader(header.name(), Objects.toString(header.literalValue(), ""), true);
            require(header.credentialPart() == null || Set.of("SECRET", "USERNAME").contains(header.credentialPart()), "HTTP_CREDENTIAL_PART");
        }
        return uri.getRawPath().endsWith("/") ? uri : URI.create(uri.toASCIIString() + "/");
    }

    private static void validateOperation(Definitions.HttpOperation operation) {
        require(Set.of("GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS").contains(operation.method()), "HTTP_METHOD_UNSUPPORTED");
        require(operation.timeoutMs() > 0 && (operation.maxResultRows() == null || operation.maxResultRows() > 0)
                && (operation.maxResultBytes() == null || operation.maxResultBytes() > 0), "HTTP_OPERATION_LIMITS");
        String path = operation.relativePathTemplate();
        require(path != null && !path.startsWith("/") && !path.contains("\\") && !path.contains(":")
                && !path.contains("?") && !path.contains("#") && !path.contains("%") && !hasControl(path), "HTTP_RELATIVE_PATH");
        String skeleton = PLACEHOLDER.matcher(path).replaceAll("segment");
        require(!skeleton.contains("{") && !skeleton.contains("}"), "HTTP_PATH_TEMPLATE");
        for (String segment : skeleton.split("/", -1)) require(!segment.equals(".") && !segment.equals(".."), "HTTP_PATH_TRAVERSAL");
        URI.create(skeleton);
        Set<Integer> statuses = new HashSet<>();
        for (var status : operation.statuses()) require(status.statusCode() >= 100 && status.statusCode() <= 599
                && statuses.add(status.statusCode()) && Set.of("SUCCEEDED", "FAILED", "OUTCOME_UNKNOWN").contains(status.interpretation()), "HTTP_STATUS_MAPPING");
    }

    private static Map<String,List<String>> validateParameters(Definitions.HttpOperation operation, ContractService.Contract contract) {
        Map<String,ContractService.Field> fields = new HashMap<>();
        contract.fields().forEach(f -> fields.put(f.id(), f));
        Set<String> paths = new HashSet<>();
        Map<String,List<String>> fieldPaths = new HashMap<>();
        for (var p : operation.parameters()) {
            require(Set.of("PATH", "QUERY", "HEADER").contains(p.location()) && p.wireName() != null
                    && !p.wireName().isEmpty() && !hasControl(p.wireName())
                    && (p.inputFieldId() == null) != (p.literalScalar() == null), "HTTP_PARAMETER_BINDING");
            if (p.inputFieldId() != null) {
                var field = fields.get(p.inputFieldId());
                require(field != null && field.nodeKind().equals("SCALAR") && !"BINARY".equals(field.valueType()), "HTTP_PARAMETER_FIELD");
                var names = new ArrayDeque<String>();
                names.addFirst(field.name());
                while (field.parentId() != null) {
                    field = fields.get(field.parentId());
                    require(field != null && field.nodeKind().equals("OBJECT"), "HTTP_PARAMETER_ARRAY_UNSUPPORTED");
                    names.addFirst(field.name());
                }
                fieldPaths.put(p.inputFieldId(), List.copyOf(names));
            }
            if (p.location().equals("HEADER")) validateHeader(p.wireName(), Objects.toString(p.literalScalar(), ""), false);
            if (p.location().equals("PATH")) require(paths.add(p.wireName()) && p.required(), "HTTP_PATH_BINDING");
        }
        var matcher = PLACEHOLDER.matcher(operation.relativePathTemplate());
        Set<String> placeholders = new HashSet<>();
        while (matcher.find()) placeholders.add(matcher.group(1));
        require(paths.equals(placeholders), "HTTP_PATH_BINDING");
        return Map.copyOf(fieldPaths);
    }

    private URI requestUri(URI base, Definitions.HttpOperation operation, Map<String,List<String>> parameterPaths, Map<String,Object> body) {
        String path = operation.relativePathTemplate();
        StringBuilder query = new StringBuilder();
        for (var p : operation.parameters()) {
            if (p.location().equals("HEADER")) continue;
            String value = parameterValue(p, parameterPaths, body);
            if (value == null) continue;
            require(!hasControl(value), "HTTP_PARAMETER_CONTROL");
            if (p.location().equals("PATH")) {
                require(!value.equals(".") && !value.equals("..") && !value.contains("/") && !value.contains("\\")
                        && !value.contains("%") && !value.contains(":") && !value.contains("?") && !value.contains("#"), "HTTP_PATH_VALUE");
                path = path.replace("{" + p.wireName() + "}", encode(value));
            } else query.append(query.isEmpty() ? '?' : '&').append(encode(p.wireName())).append('=').append(encode(value));
        }
        URI result = base.resolve(path + query);
        require(Objects.equals(base.getScheme(), result.getScheme()) && Objects.equals(base.getRawAuthority(), result.getRawAuthority())
                && result.getRawUserInfo() == null && result.getRawFragment() == null && result.getRawPath().startsWith(base.getRawPath()), "HTTP_DESTINATION_REJECTED");
        require(result.toASCIIString().getBytes(StandardCharsets.US_ASCII).length <= maxRequestBytes, "HTTP_REQUEST_BYTES_LIMIT");
        return result;
    }

    private static String parameterValue(Definitions.Parameter p, Map<String,List<String>> parameterPaths, Map<String,Object> body) {
        Object value = p.literalScalar();
        if (p.inputFieldId() != null) {
            value = body;
            for (String name : parameterPaths.get(p.inputFieldId())) {
                if (value == null) break;
                require(value instanceof Map<?,?>, "HTTP_PARAMETER_OBJECT");
                value = ((Map<?,?>) value).get(name);
            }
        }
        require(value != null || !p.required(), "HTTP_PARAMETER_REQUIRED");
        require(value == null || value instanceof String || value instanceof Number || value instanceof Boolean, "HTTP_PARAMETER_SCALAR");
        return value == null ? null : value.toString();
    }

    private static void credentialHeaders(HttpUriRequestBase request, Definitions.HttpSource source, CredentialService.Secret secret) {
        for (var header : source.headers()) {
            String value = header.credentialPart() == null ? header.literalValue()
                    : header.credentialPart().equals("USERNAME") ? secret.publicUsername() : secret.utf8();
            validateHeader(header.name(), value, true);
            request.addHeader(header.name(), value);
        }
        if (source.authenticationKind().equals("BEARER")) {
            String value = "Bearer " + secret.utf8();
            validateHeader("Authorization", value, true);
            request.setHeader("Authorization", value);
        } else if (source.authenticationKind().equals("BASIC")) {
            String username = secret.publicUsername();
            require(username != null && !username.contains(":") && !hasControl(username), "HTTP_BASIC_USERNAME");
            byte[] bytes = (username + ":" + secret.utf8()).getBytes(StandardCharsets.UTF_8);
            try { request.setHeader("Authorization", "Basic " + Base64.getEncoder().encodeToString(bytes)); }
            finally { Arrays.fill(bytes, (byte) 0); }
        }
    }

    private static void validateHeader(String name, String value, boolean registered) {
        require(name != null && TOKEN.matcher(name).matches() && value != null && !hasControl(value)
                && !RESERVED_HEADERS.contains(name.toLowerCase(Locale.ROOT))
                && (registered || !name.equalsIgnoreCase("Authorization") && !name.equalsIgnoreCase("Cookie")), "HTTP_HEADER_REJECTED");
    }
    private static boolean hasControl(String value) { return value.chars().anyMatch(c -> c < 32 || c == 127); }
    private static String encode(String value) { return URLEncoder.encode(value, StandardCharsets.UTF_8).replace("+", "%20"); }
    private static long remaining(long end, Cancellation cancellation) {
        long millis = Math.min(cancellation.remainingMillis(), TimeUnit.NANOSECONDS.toMillis(end - System.nanoTime()));
        if (millis <= 0) throw new ExecutionFailure("HTTP_DEADLINE", FAILED_BEFORE_EFFECT);
        return millis;
    }
    private static byte[] readBounded(InputStream stream, int maximum, long end, Cancellation cancellation) throws IOException {
        var output = new ByteArrayOutputStream(Math.min(maximum, 8192));
        byte[] buffer = new byte[Math.min(maximum + (maximum == Integer.MAX_VALUE ? 0 : 1), 8192)];
        int count;
        while ((count = stream.read(buffer, 0, (int) Math.min(buffer.length, (long) maximum - output.size() + 1))) != -1) {
            remaining(end, cancellation);
            require(count <= maximum - output.size(), "HTTP_RESPONSE_BYTES_LIMIT");
            output.write(buffer, 0, count);
        }
        return output.toByteArray();
    }
    private static ExecutionFailure.Outcome statusOutcome(int status, Definitions.HttpOperation operation) {
        if (status >= 300 && status < 400) return operation.effect() == Definitions.Effect.READ_ONLY ? FAILED : OUTCOME_UNKNOWN;
        for (var mapping : operation.statuses()) if (mapping.statusCode() == status) return ExecutionFailure.Outcome.valueOf(mapping.interpretation());
        if (operation.statuses().isEmpty() && status >= 200 && status < 300 && status != 202) return SUCCEEDED;
        return operation.effect() == Definitions.Effect.READ_ONLY ? FAILED : OUTCOME_UNKNOWN;
    }
}
