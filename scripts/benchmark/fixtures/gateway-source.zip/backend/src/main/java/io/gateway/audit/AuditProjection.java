package io.gateway.audit;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/** Only declared, typed fields enter persistence. Never stringify an unknown source value. */
public final class AuditProjection {
    private AuditProjection() {}
    public enum Kind { OBJECT, ARRAY, STRING, INTEGER, DECIMAL, BOOLEAN, NULL, MISSING }
    public enum Disposition {
        PERSIST, OMIT_RECOVERABLE, OMIT_SECRET;
        public Disposition merge(Disposition other) { return ordinal() >= other.ordinal() ? this : other; }
    }

    public record Value(String fieldId, String name, Kind kind, Object scalar,
                        List<Value> children, Disposition disposition) {
        public Value {
            Objects.requireNonNull(kind);
            Objects.requireNonNull(disposition);
            children = children == null ? List.of() : List.copyOf(children);
            if (kind != Kind.OBJECT && kind != Kind.ARRAY && !children.isEmpty()) throw invalid();
            if ((kind == Kind.OBJECT || kind == Kind.ARRAY || kind == Kind.NULL || kind == Kind.MISSING) && scalar != null)
                throw invalid();
        }
        public Value withDisposition(Disposition inherited) {
            return new Value(fieldId, name, kind, scalar, children, disposition.merge(inherited));
        }
        /** Renaming and transformations must carry every contributing source's disposition. */
        public static Value derived(String fieldId, String name, Kind kind, Object scalar,
                                    List<Value> children, Disposition declared, List<Value> sources) {
            Disposition sensitivity = declared;
            for (Value source : sources) sensitivity = sensitivity.merge(source.sensitivity());
            return new Value(fieldId, name, kind, scalar, children, sensitivity);
        }
        public Disposition sensitivity() {
            Disposition result = disposition;
            for (Value child : children) result = result.merge(child.sensitivity());
            return result;
        }
        @Override public String toString() { return "AuditValue[redacted]"; }
    }

    public record Parameter(String id, String parentParameterId, String parameterName, int ordinal,
                            String port, String fieldId, String valueType, String stringValue,
                            Long integerValue, String decimalText, Boolean booleanValue, String exclusionReason) {
        @Override public String toString() { return "AuditParameter[redacted]"; }
    }

    public static List<Parameter> project(String port, List<Value> values) {
        if (port == null || !port.matches("[A-Z][A-Z0-9_]{0,63}")) throw invalid();
        List<Parameter> rows = new ArrayList<>();
        for (int i = 0; i < values.size(); i++) append(rows, port, values.get(i), null, i, Disposition.PERSIST, 0);
        return List.copyOf(rows);
    }

    private static void append(List<Parameter> rows, String port, Value value, String parent,
                               int ordinal, Disposition inherited, int depth) {
        if (depth > 128) throw invalid();
        Disposition effective = value.disposition.merge(inherited);
        String id = UUID.randomUUID().toString();
        if (effective != Disposition.PERSIST) {
            rows.add(new Parameter(id, parent, value.name, ordinal, port, value.fieldId,
                "EXCLUDED", null, null, null, null, effective.name()));
            return;
        }
        String text = null;
        Long integer = null;
        String decimal = null;
        Boolean bool = null;
        switch (value.kind) {
            case STRING -> { if (!(value.scalar instanceof String string)) throw invalid(); text = string; }
            case INTEGER -> {
                if (value.scalar instanceof Byte || value.scalar instanceof Short || value.scalar instanceof Integer || value.scalar instanceof Long)
                    integer = ((Number) value.scalar).longValue();
                else if (value.scalar instanceof BigInteger big) {
                    try { integer = big.longValueExact(); } catch (ArithmeticException failure) { throw invalid(); }
                } else throw invalid();
            }
            case DECIMAL -> {
                if (value.scalar instanceof BigDecimal big) decimal = big.toPlainString();
                else if (value.scalar instanceof String string && string.matches("-?(0|[1-9][0-9]*)(\\.[0-9]+)?")) decimal = string;
                else throw invalid();
            }
            case BOOLEAN -> { if (!(value.scalar instanceof Boolean booleanValue)) throw invalid(); bool = booleanValue; }
            case OBJECT, ARRAY, NULL, MISSING -> { }
        }
        rows.add(new Parameter(id, parent, value.name, ordinal, port, value.fieldId,
            value.kind.name(), text, integer, decimal, bool, null));
        for (int i = 0; i < value.children.size(); i++) append(rows, port, value.children.get(i), id, i, effective, depth + 1);
    }

    private static IllegalArgumentException invalid() { return new IllegalArgumentException("AUDIT_VALUE_INVALID"); }
}
