package io.gateway.oauth;

import io.gateway.authorization.SecurityMapper;
import io.gateway.persistence.PlatformMapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface GrantActionMapper extends PlatformMapper {
    @Select("SELECT id,action_key AS actionKey,target_kind AS targetKind,semantic_version AS semanticVersion FROM protected_action WHERE id=#{id}") SecurityMapper.Action actionById(String id);
    @Update("UPDATE config_object SET generation=generation+1 WHERE id=#{id} AND enabled=true") int bumpClient(String id);
}
