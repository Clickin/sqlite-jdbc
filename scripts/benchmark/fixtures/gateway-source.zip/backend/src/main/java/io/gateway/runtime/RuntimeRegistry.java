package io.gateway.runtime;

import io.gateway.definitions.Definitions.ResolvedGraph;
import io.micronaut.context.BeanContext;
import io.micronaut.context.annotation.Value;
import jakarta.annotation.PreDestroy;
import jakarta.inject.Singleton;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

@Singleton
public final class RuntimeRegistry {
    private final BeanContext context;
    private final int maximum;
    private final ConcurrentHashMap<String,CompletableFuture<Entry>> cache=new ConcurrentHashMap<>();
    private final ConcurrentLinkedQueue<String> insertionOrder=new ConcurrentLinkedQueue<>();
    private final AtomicBoolean stopped=new AtomicBoolean();
    public RuntimeRegistry(BeanContext context,@Value("${gateway.runtime.maximum-entries:256}") int maximum){if(maximum<1)throw new IllegalArgumentException("RUNTIME_CACHE_LIMIT");this.context=context;this.maximum=maximum;}
    public Map<String,String> capabilities(){return Map.of("jdbc.mybatis","SELECT_ONE,OPTIONAL,MANY,EXECUTE,CALL; Oracle19c real-environment verification required","http.classic","JSON/XML independent codecs; single-attempt transport","http.xapi","BLOCKED: private Clickin/xapi-java Nexus artifact unavailable");}
    public Lease acquire(ResolvedGraph graph){
        String key=graph.key();
        for(;;){if(stopped.get())throw new IllegalStateException("RUNTIME_STOPPED");CompletableFuture<Entry> future=cache.get(key);
            if(future==null){CompletableFuture<Entry> created=new CompletableFuture<>();future=cache.putIfAbsent(key,created);
                if(future==null){future=created;try{RuntimeGraph runtime=context.createBean(RuntimeGraph.class,Map.of("definitions",graph));Entry entry=new Entry(runtime);created.complete(entry);insertionOrder.add(key);if(stopped.get()){cache.remove(key,created);entry.evict();throw new IllegalStateException("RUNTIME_STOPPED");}}
                    catch(Throwable failure){created.completeExceptionally(failure);cache.remove(key,created);throw safe(failure);}}
            }
            Entry entry;try{entry=future.join();}catch(CompletionException failure){throw safe(failure.getCause());}
            Lease lease=entry.acquire();if(lease==null){cache.remove(key,future);continue;}trim();return lease;
        }
    }
    /** Applies all preparation checks outside the metadata writer; never executes a business operation. */
    public void validate(ResolvedGraph graph){try(Lease ignored=acquire(graph)){} }
    public void evict(String key){CompletableFuture<Entry> removed=cache.remove(key);if(removed!=null){insertionOrder.remove(key);removed.thenAccept(Entry::evict);}}
    private void trim(){while(cache.size()>maximum){String oldest=insertionOrder.poll();if(oldest==null)return;evict(oldest);}}
    @PreDestroy public void close(){if(stopped.compareAndSet(false,true)){for(String key:cache.keySet())evict(key);insertionOrder.clear();}}
    private RuntimeException safe(Throwable failure){
        for(Throwable cause=failure;cause!=null;cause=cause.getCause()){
            if(cause instanceof ExecutionFailure e)return e;
            if(cause instanceof IllegalArgumentException e&&e.getMessage()!=null&&e.getMessage().matches("[A-Z_]+"))return e;
        }
        return new ExecutionFailure("RUNTIME_PREPARATION_FAILED",ExecutionFailure.Outcome.FAILED_BEFORE_EFFECT);
    }
    private final class Entry {
        final RuntimeGraph runtime;int references;boolean evicted,destroyed;
        Entry(RuntimeGraph runtime){this.runtime=runtime;}
        synchronized Lease acquire(){if(evicted||destroyed)return null;references++;return new Lease(this);}
        synchronized void evict(){evicted=true;destroyIfUnused();}
        synchronized void release(){if(references<=0)throw new IllegalStateException("LEASE_UNDERFLOW");references--;destroyIfUnused();}
        private void destroyIfUnused(){if(evicted&&references==0&&!destroyed){destroyed=true;context.destroyBean(runtime);}}
    }
    public final class Lease implements AutoCloseable {
        private final Entry entry;private final AtomicBoolean returned=new AtomicBoolean();
        private Lease(Entry entry){this.entry=entry;}
        public RuntimeGraph get(){if(returned.get())throw new IllegalStateException("LEASE_RETURNED");return entry.runtime;}
        @Override public void close(){if(returned.compareAndSet(false,true))entry.release();}
    }
}
