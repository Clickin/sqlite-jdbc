package io.gateway.management;

import io.gateway.credentials.CredentialService;
import io.gateway.definitions.DefinitionRepository;
import io.gateway.definitions.DefinitionMapper;
import io.gateway.definitions.Definitions.*;
import io.gateway.persistence.PlatformStore;
import io.micronaut.context.ApplicationContext;
import io.micronaut.json.JsonMapper;
import io.micronaut.serde.annotation.Serdeable;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.*;

/** Headless, new-database-only configuration import. No web authentication bypass exists. */
public final class OfflineBootstrap {
    private OfflineBootstrap() {}
    @Serdeable public record Manifest(String operator,String securityBinding,List<Entry> entries) {}
    @Serdeable public record Entry(String name,String type,Map<String,Object> document) {}
    @Serdeable public record CredentialDocument(String logicalKey,String secretKind,String publicUsername,String secretFile,String reason) {}

    public static void main(String[] args) {
        try { run(args); }
        catch(Exception failure) { System.err.println("BOOTSTRAP_FAILED: input, key, schema or configuration validation failed; no production database was replaced."); System.exit(2); }
    }
    public static void run(String[] args) throws Exception {
        Map<String,String> options=new LinkedHashMap<>();
        for(int i=0;i<args.length;i+=2) {
            if(i+1>=args.length||!Set.of("--database","--manifest","--key-directory","--active-key-id").contains(args[i])||options.put(args[i],args[i+1])!=null) throw new IllegalArgumentException("BOOTSTRAP_ARGUMENTS_INVALID");
        }
        if(!options.containsKey("--database")||!options.containsKey("--manifest")) throw new IllegalArgumentException("DATABASE_AND_MANIFEST_REQUIRED");
        Path database=Path.of(options.get("--database")).toAbsolutePath().normalize();
        if(database.getParent()==null||!Files.isDirectory(database.getParent(),LinkOption.NOFOLLOW_LINKS)||Files.isSymbolicLink(database.getParent())) throw new IllegalArgumentException("DATABASE_PARENT_REQUIRED");
        for(String suffix:List.of("","-wal","-shm")) if(Files.exists(Path.of(database+suffix),LinkOption.NOFOLLOW_LINKS)) throw new IllegalArgumentException("NEW_DATABASE_REQUIRED");
        Path manifestPath=Path.of(options.get("--manifest")).toAbsolutePath().normalize();
        byte[] manifestBytes=readBounded(manifestPath,2*1024*1024,false);
        Path lock=database.resolveSibling(database.getFileName()+".bootstrap-lock");
        Files.createFile(lock,PosixFilePermissions.asFileAttribute(PosixFilePermissions.fromString("rw-------")));
        Path staging=database.resolveSibling("."+database.getFileName()+".bootstrap-"+UUID.randomUUID());
        String bindingId;
        try {
            Files.createFile(staging,PosixFilePermissions.asFileAttribute(PosixFilePermissions.fromString("rw-------")));
            Map<String,Object> properties=new LinkedHashMap<>();
            properties.put("gateway.database.url","jdbc:sqlite:"+staging);
            properties.put("micronaut.server.enabled",false);
            properties.put("gateway.database.reader-size",2);
            if(options.containsKey("--key-directory")) properties.put("gateway.credentials.key-directory",options.get("--key-directory"));
            if(options.containsKey("--active-key-id")) properties.put("gateway.credentials.active-key-id",options.get("--active-key-id"));
            // ApplicationContext starts DI only; no EmbeddedServer bean is requested or started.
            try(ApplicationContext context=ApplicationContext.run(properties)) {
                JsonMapper json=context.getBean(JsonMapper.class);
                Manifest manifest=json.readValue(manifestBytes,Manifest.class);
                if(manifest.operator()==null||!manifest.operator().matches("[A-Za-z0-9_.:@-]{1,128}")||manifest.entries()==null||manifest.entries().isEmpty()||manifest.entries().size()>500||manifest.securityBinding()==null) throw new IllegalArgumentException("BOOTSTRAP_MANIFEST_INVALID");
                PlatformStore store=context.getBean(PlatformStore.class);
                if(!store.read(s->s.getMapper(DefinitionMapper.class).heads().isEmpty())) throw new IllegalArgumentException("EMPTY_DATABASE_REQUIRED");
                DefinitionRepository runtime=context.getBean(DefinitionRepository.class);
                SecurityDefinitions security=context.getBean(SecurityDefinitions.class);
                Map<String,String> references=new LinkedHashMap<>();
                for(Entry entry:manifest.entries()) {
                    if(entry.name()==null||!entry.name().matches("[A-Za-z][A-Za-z0-9_.-]{0,99}")||references.containsKey(entry.name())||entry.document()==null) throw new IllegalArgumentException("BOOTSTRAP_ENTRY_INVALID");
                    Object resolved=resolve(entry.document(),references);
                    byte[] wire=json.writeValueAsBytes(resolved);
                    String id; String version=null;
                    switch(entry.type()) {
                        case "DEFINITION" -> {
                            var request=json.readValue(wire,DefinitionController.DraftRequest.class);
                            if(request.objectId()!=null) throw new IllegalArgumentException("NEW_OBJECT_REQUIRED");
                            Saved draft=runtime.draft(DefinitionController.toDraft(json,request),manifest.operator());
                            Saved applied=runtime.apply(runtime.validate(draft.object().id(),draft.version().id()),manifest.operator(),request.reason());
                            id=applied.object().id(); version=applied.version().id();
                            if(applied.detail() instanceof Contract contract) for(Field field:contract.fields()) references.put(entry.name()+".field."+field.logicalName(),field.id());
                        }
                        case "SECURITY" -> {
                            var request=json.readValue(wire,SecurityDefinitions.Draft.class);
                            if(request.objectId()!=null) throw new IllegalArgumentException("NEW_OBJECT_REQUIRED");
                            var draft=security.draft(request,manifest.operator()); var validation=security.validate(draft.object().id(),draft.version().id());
                            var applied=security.apply(draft.object().id(),draft.version().id(),validation.generation(),validation.dependencyVersions(),manifest.operator(),request.reason());
                            id=applied.object().id(); version=applied.version().id();
                        }
                        case "CREDENTIAL" -> {
                            var request=json.readValue(wire,CredentialDocument.class);
                            Path secretPath=manifestPath.getParent().resolve(request.secretFile()).normalize();
                            byte[] secret=readBounded(secretPath,65536,true);
                            try { var metadata=context.getBean(CredentialService.class).create(request.logicalKey(),request.secretKind(),request.publicUsername(),secret,manifest.operator(),request.reason()); id=metadata.objectId(); version=metadata.versionId(); }
                            finally { Arrays.fill(secret,(byte)0); }
                        }
                        case "ACTION","SCOPE","RESOURCE" -> {
                            if(!(resolved instanceof Map<?,?> input)) throw new IllegalArgumentException("CATALOGUE_DOCUMENT_REQUIRED");
                            Map<String,Object> row=new LinkedHashMap<>(); input.forEach((k,v)->row.put(k.toString(),v));
                            id=UUID.randomUUID().toString(); row.put("id",id); final String recordId=id;
                            Set<String> allowed=switch(entry.type()) { case "ACTION" -> Set.of("id","action_key","target_kind","effect_kind","semantic_version"); case "SCOPE" -> Set.of("id","scope_name","description","actions"); default -> Set.of("id","resource_uri","resource_kind","public_name"); };
                            if(!allowed.containsAll(row.keySet())) throw new IllegalArgumentException("UNSUPPORTED_CATALOGUE_COLUMN");
                            store.write(s->{
                                ManagementMapper mapper=s.getMapper(ManagementMapper.class);
                                switch(entry.type()) {
                                    case "ACTION" -> mapper.action(row);
                                    case "RESOURCE" -> mapper.resource(row);
                                    case "SCOPE" -> {
                                        Object actions=row.remove("actions"); mapper.scope(row);
                                        if(actions instanceof List<?> list) for(Object action:list) {
                                            if(!(action instanceof Map<?,?> values)||!Set.of("action_id","action_semantic_version").containsAll(values.keySet())) throw new IllegalArgumentException("SCOPE_ACTION_INVALID");
                                            Map<String,Object> child=new LinkedHashMap<>(); values.forEach((k,v)->child.put(k.toString(),v)); child.put("scope_id",recordId); mapper.scopeAction(child);
                                        }
                                    }
                                    default -> throw new IllegalArgumentException("UNSUPPORTED_ENTRY_TYPE");
                                }
                                mapper.auditMutation(UUID.randomUUID().toString(),"OFFLINE_BOOTSTRAP_ENTRY",System.currentTimeMillis(),manifest.operator(),entry.type()); return null;
                            });
                        }
                        default -> throw new IllegalArgumentException("UNSUPPORTED_ENTRY_TYPE");
                    }
                    references.put(entry.name(),id); if(version!=null) references.put(entry.name()+".version",version);
                }
                bindingId=references.get(manifest.securityBinding());
                if(bindingId==null) throw new IllegalArgumentException("SELECTED_SECURITY_BINDING_REQUIRED");
                var binding=security.get(bindingId,null);
                if(!"SECURITY_BINDING".equals(binding.detailType())) throw new IllegalArgumentException("SELECTED_SECURITY_BINDING_REQUIRED");
                security.validate(bindingId,binding.version().id());
                final String selectedBinding=bindingId;
                boolean administrator=store.read(s->{
                    ManagementMapper m=s.getMapper(ManagementMapper.class); DefinitionMapper d=s.getMapper(DefinitionMapper.class);
                    Map<String,String> actionNames=new HashMap<>(); m.actions().forEach(a->actionNames.put(a.get("id").toString(),a.get("action_key").toString()));
                    for(Map<String,Object> mapping:m.rows(ManagementMapper.Table.EXTERNAL_ROLE,d.head(selectedBinding).currentVersionId())) {
                        Set<String> managementActions=new HashSet<>();
                        var role=d.head(mapping.get("role_object_id").toString());
                        if(role!=null&&role.enabled()) for(Map<String,Object> action:m.rows(ManagementMapper.Table.ROLE_ACTION,role.currentVersionId())) managementActions.add(actionNames.get(action.get("action_id").toString()));
                        if(managementActions.containsAll(Set.of("config.manage","security.manage","client.manage","audit.read"))) return true;
                    }
                    return false;
                });
                if(!administrator) throw new IllegalArgumentException("EXPLICIT_ADMIN_EXTERNAL_ROLE_MAPPING_REQUIRED");
            }
            // SQLite checkpoints on the final clean connection close; refuse a still-live WAL.
            Path wal=Path.of(staging+"-wal");
            if(Files.exists(wal)&&Files.size(wal)>0) throw new IllegalStateException("DATABASE_CLOSE_INCOMPLETE");
            Files.move(staging,database);
            System.out.println("BOOTSTRAP_SUCCEEDED");
            System.out.println("gateway.oauth.security-binding-id="+bindingId);
            System.out.println("Identity and permission network calls were not performed. Verify the configured authority before enabling traffic.");
        } finally {
            Arrays.fill(manifestBytes,(byte)0);
            Files.deleteIfExists(staging);
            Files.deleteIfExists(Path.of(staging+"-wal"));
            Files.deleteIfExists(Path.of(staging+"-shm"));
            Files.deleteIfExists(lock);
        }
    }
    private static byte[] readBounded(Path path,int limit,boolean secret) throws Exception {
        if(!Files.isRegularFile(path,LinkOption.NOFOLLOW_LINKS)||Files.isSymbolicLink(path)||Files.size(path)>limit||Files.size(path)==0) throw new IllegalArgumentException("INPUT_FILE_INVALID");
        if(secret) {
            var permissions=Files.getPosixFilePermissions(path,LinkOption.NOFOLLOW_LINKS);
            if(permissions.stream().anyMatch(p->p.name().startsWith("GROUP_")||p.name().startsWith("OTHERS_")||p.name().endsWith("EXECUTE"))) throw new IllegalArgumentException("SECRET_FILE_MUST_BE_OWNER_ONLY");
        }
        try(var stream=Files.newInputStream(path,LinkOption.NOFOLLOW_LINKS)) { byte[] bytes=stream.readNBytes(limit+1); if(bytes.length>limit) throw new IllegalArgumentException("INPUT_TOO_LARGE"); return bytes; }
    }
    private static Object resolve(Object value,Map<String,String> references) {
        if(value instanceof String text&&text.startsWith("$")) {
            String resolved=references.get(text.substring(1)); if(resolved==null) throw new IllegalArgumentException("UNRESOLVED_BOOTSTRAP_REFERENCE"); return resolved;
        }
        if(value instanceof Map<?,?> input) { Map<String,Object> result=new LinkedHashMap<>(); input.forEach((k,v)->result.put(k.toString(),resolve(v,references))); return result; }
        if(value instanceof List<?> input) return input.stream().map(v->resolve(v,references)).toList();
        return value;
    }
}
