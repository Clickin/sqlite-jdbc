package io.gateway.mcp;

import io.gateway.authorization.*;
import io.gateway.contracts.*;
import io.gateway.definitions.*;
import io.gateway.persistence.PlatformStore;
import jakarta.inject.Singleton;
import org.apache.ibatis.session.SqlSession;
import java.util.*;

@Singleton
public final class ToolCatalog {
    public record Policy(ToolMapper.TargetPolicy definition,List<ToolMapper.TargetBinding> bindings) {
        public Policy { bindings=List.copyOf(bindings); }
    }
    public record Snapshot(ToolMapper.Tool tool,Definitions.ResolvedGraph graph,ContractService.Contract input,
                           ContractService.Contract output,List<ToolMapper.Action> actions,Map<String,Policy> policies,
                           List<String> scopes,Map<String,ToolMapper.Dependency> dependencies) {
        public Snapshot { actions=List.copyOf(new LinkedHashSet<>(actions));policies=Map.copyOf(policies);scopes=List.copyOf(scopes);dependencies=Map.copyOf(dependencies); }
    }
    private final PlatformStore store;
    private final DefinitionRepository definitions;
    private final ContractService contracts;
    private final AuthorizationService authorization;
    public ToolCatalog(PlatformStore store,DefinitionRepository definitions,ContractService contracts,AuthorizationService authorization) {
        this.store=store;this.definitions=definitions;this.contracts=contracts;this.authorization=authorization;
    }

    public List<ToolMapper.Tool> registered() { return store.read(s->s.getMapper(ToolMapper.class).tools()); }
    public List<Snapshot> visible(AuthenticatedPrincipal principal) {
        var snapshots=store.read(s->s.getMapper(ToolMapper.class).tools().stream().map(t->snapshot(s,t,null)).toList());
        var scopes=authorization.principalScopes(principal);
        return snapshots.stream().filter(s->scopes.containsAll(s.scopes())
                && s.actions().stream().allMatch(a->authorization.canList(principal,a.key()))).toList();
    }
    public Snapshot tool(String name) {
        return store.read(s->{
            var tool=s.getMapper(ToolMapper.class).tools().stream().filter(t->t.name().equals(name)).findFirst()
                    .orElseThrow(AccessDenied::denied);
            return snapshot(s,tool,null);
        });
    }
    public Snapshot workflow(String key) {
        return store.read(s->{
            String id=s.getMapper(ToolMapper.class).workflow(key);
            if(id==null)throw AccessDenied.denied();
            return snapshot(s,null,id);
        });
    }
    public void checkSecurityHeads(Snapshot snapshot) {
        boolean current=store.read(s->{
            var mapper=s.getMapper(ToolMapper.class);
            if(mapper.enabledDefinitions(snapshot.graph().definitions().keySet())!=snapshot.graph().definitions().size())return false;
            var credentials=snapshot.graph().definitions().values().stream().filter(d->d.detail() instanceof Definitions.Credential).map(d->d.version().id()).toList();
            if(!credentials.isEmpty()&&mapper.liveCredentials(credentials)!=credentials.size())return false;
            return snapshot.dependencies().values().stream().allMatch(d->d.equals(mapper.dependency(d.objectId())));
        });
        if(!current)throw new AccessDenied(AccessDenied.Outcome.DENY,"configuration_changed");
    }
    public Map<String,Object> descriptor(Snapshot snapshot) {
        var result=new LinkedHashMap<String,Object>();
        result.put("name",snapshot.tool().name());result.put("description",snapshot.tool().description());
        result.put("inputSchema",contracts.schema(snapshot.input()));
        result.put("outputSchema",envelopeSchema(contracts.schema(snapshot.output())));
        return result;
    }
    public static Map<String,Object> envelopeSchema(Map<String,Object> dataSchema) {
        var properties=new LinkedHashMap<String,Object>();
        properties.put("status",Map.of("type","string","enum",List.of("SUCCEEDED","FAILED","OUTCOME_UNKNOWN","RESPONSE_FAILED","PENDING","UNAVAILABLE")));
        properties.put("executionId",Map.of("type","string"));
        properties.put("data",dataSchema); properties.put("references",Map.of("type","array","items",Map.of("type","string")));
        properties.put("businessOutcome",Map.of("type","string"));properties.put("responseOutcome",Map.of("type","string"));
        properties.put("error",Map.of("type","object","properties",Map.of("code",Map.of("type","string"),"httpStatus",Map.of("type","integer","minimum",400,"maximum",599)),"required",List.of("code"),"additionalProperties",false));
        return Map.of("$schema","https://json-schema.org/draft/2020-12/schema","type","object","properties",properties,
                "required",List.of("status","businessOutcome","responseOutcome"),"additionalProperties",false);
    }

    private Snapshot snapshot(SqlSession session,ToolMapper.Tool tool,String workflowId) {
        var mapper=session.getMapper(ToolMapper.class);
        var graph=definitions.resolve(session,tool==null?workflowId:tool.workflowId());
        if(tool!=null) {
            var merged=new LinkedHashMap<>(graph.definitions());
            if(tool.inputMappingId()!=null)merged.putAll(definitions.resolve(session,tool.inputMappingId()).definitions());
            if(tool.outputMappingId()!=null)merged.putAll(definitions.resolve(session,tool.outputMappingId()).definitions());
            graph=new Definitions.ResolvedGraph(graph.rootObjectId(),merged);
        }
        var root=graph.require(graph.rootObjectId());
        if(!(root.detail() instanceof Definitions.Workflow workflow))throw new IllegalArgumentException("WORKFLOW_REQUIRED");
        var actions=new ArrayList<>(mapper.workflowActions(root.version().id()));
        if(tool!=null) {
            actions.addAll(mapper.toolActions(tool.versionId()));
        }
        if(actions.isEmpty())throw AccessDenied.denied();
        var policies=new LinkedHashMap<String,Policy>();
        var dependencies=new LinkedHashMap<String,ToolMapper.Dependency>();
        if(tool!=null)track(mapper,dependencies,tool.objectId());
        for(var action:actions) {
            var binding=track(mapper,dependencies,action.securityBindingId());
            for(String role:mapper.roles(binding.versionId()))track(mapper,dependencies,role);
            if(action.targetPolicyId()!=null) {
                track(mapper,dependencies,action.targetPolicyId());
                var policy=mapper.policy(action.targetPolicyId());
                if(policy==null)throw AccessDenied.denied();
                policies.put(action.targetPolicyId(),new Policy(policy,mapper.bindings(policy.versionId())));
            } else if(!action.targetKind().equals("SERVICE"))throw AccessDenied.denied();
        }
        for(var definition:graph.definitions().values()) {
            List<Definitions.ReferenceBinding> references=switch(definition.detail()) {
                case Definitions.JdbcOperation j->j.referenceBindings();
                case Definitions.HttpOperation h->h.referenceBindings();
                default->List.of();
            };
            for(var reference:references)if(reference.screenProfileObjectId()!=null)
                track(mapper,dependencies,reference.screenProfileObjectId());
        }
        ContractService.Contract input,output;
        if(tool!=null) {
            input=contract(session,tool.inputVersion());output=contract(session,tool.outputVersion());
        } else {
            var inputStage=workflow.stages().stream().filter(s->s.stageKey().equals("INPUT")).findFirst().orElseThrow();
            var inputOperation=graph.require(inputStage.operationObjectId()).detail();
            String inputObject=inputOperation instanceof Definitions.JdbcOperation j?j.inputContractObjectId():((Definitions.HttpOperation)inputOperation).inputContractObjectId();
            input=contract(session,graph.version(inputObject));
            var response=workflow.ports().stream().filter(p->p.direction().equals("RESPONSE")).findFirst();
            String outputObject;
            if(response.isPresent()) {
                var representation=(Definitions.Representation)graph.require(response.get().representationObjectId()).detail();
                outputObject=representation.contractObjectId();
            } else {
                var finalStage=workflow.stages().stream().max(Comparator.comparingInt(Definitions.Stage::stageOrder)).orElseThrow();
                var detail=graph.require(finalStage.operationObjectId()!=null?finalStage.operationObjectId():finalStage.converterObjectId()).detail();
                outputObject=switch(detail) {
                    case Definitions.JdbcOperation j->j.outputContractObjectId();
                    case Definitions.HttpOperation h->h.outputContractObjectId();
                    case Definitions.Converter c->c.outputContractObjectId();
                    default->throw new IllegalArgumentException("OUTPUT_CONTRACT_REQUIRED");
                };
            }
            output=contract(session,graph.version(outputObject));
        }
        return new Snapshot(tool,graph,input,output,actions,policies,tool==null?List.of():mapper.scopes(tool.versionId()),dependencies);
    }
    private ContractService.Contract contract(SqlSession session,String version) {
        var mapper=session.getMapper(ContractMapper.class);
        if(!"VALUE".equals(mapper.model(version)))throw new ContractService.InvalidContract();
        var contract=new ContractService.Contract(version,mapper.fields(version));contracts.schema(contract);return contract;
    }
    private static ToolMapper.Dependency track(ToolMapper mapper,Map<String,ToolMapper.Dependency> dependencies,String id) {
        if(id==null)throw AccessDenied.denied();
        var value=mapper.dependency(id);
        if(value==null || value.versionId()==null)throw AccessDenied.denied();
        dependencies.put(id,value);return value;
    }
}
