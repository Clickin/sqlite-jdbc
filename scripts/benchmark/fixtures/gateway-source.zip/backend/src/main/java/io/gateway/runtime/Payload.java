package io.gateway.runtime;

import java.util.*;

/** In-memory value payload, with non-persistence provenance surviving mappings. */
public record Payload(Object value, Map<String, Disposition> dispositions) {
    public enum Disposition { PERSIST, OMIT_RECOVERABLE, OMIT_SECRET;
        public static Disposition strongest(Disposition a, Disposition b) { return a.ordinal() >= b.ordinal() ? a : b; }
    }
    public Payload { dispositions = Map.copyOf(dispositions); value = freeze(value); }
    public static Payload of(Object value) { return new Payload(value, Map.of()); }
    public static Object freeze(Object value) {
        if (value instanceof Map<?, ?> map) {
            Map<String,Object> result = new LinkedHashMap<>();
            map.forEach((k,v) -> { if (!(k instanceof String)) throw new IllegalArgumentException("NON_STRING_MEMBER"); result.put((String)k, freeze(v)); });
            return Collections.unmodifiableMap(result);
        }
        if (value instanceof List<?> list) return Collections.unmodifiableList(list.stream().map(Payload::freeze).toList());
        if (value instanceof byte[] bytes) return bytes.clone();
        return value;
    }
    @SuppressWarnings("unchecked") public Map<String,Object> object() {
        if (!(value instanceof Map<?,?>)) throw new ExecutionFailure("OBJECT_REQUIRED", ExecutionFailure.Outcome.FAILED_BEFORE_EFFECT);
        return (Map<String,Object>) value;
    }
    @Override public String toString() { return "Payload[redacted]"; }
}
