package io.gateway.convert;

import io.gateway.definitions.Definitions.*;
import io.gateway.runtime.*;
import io.gateway.runtime.Payload.Disposition;
import java.math.*;
import java.time.*;
import java.util.*;

/** Pure registered field mapping. No expression evaluation or I/O. */
public final class ConverterEngine {
    private static final Object MISSING=new Object();
    private final Contract source,target;
    private final Map<String,Field> sourceFields,targetFields;
    private final Map<String,String> sourcePaths,targetPaths;
    private final Map<String,Rule> rules;
    public ConverterEngine(ResolvedGraph graph,Converter converter){
        source=(Contract)graph.require(converter.inputContractObjectId()).detail();target=(Contract)graph.require(converter.outputContractObjectId()).detail();
        sourceFields=index(source);targetFields=index(target);Map<String,Rule> configured=new HashMap<>();
        sourcePaths=paths(sourceFields);targetPaths=paths(targetFields);
        if(!"basic".equals(converter.implementationId()))throw new IllegalArgumentException("CONVERTER_UNAVAILABLE");
        for(Rule r:converter.rules()){
            if(!targetFields.containsKey(r.targetFieldId())||configured.put(r.targetFieldId(),r)!=null)throw new IllegalArgumentException("CONVERTER_TARGET_FIELD");
            if(r.sourceFieldId()!=null&&!sourceFields.containsKey(r.sourceFieldId()))throw new IllegalArgumentException("CONVERTER_SOURCE_FIELD");
            if(!"CONSTANT".equals(r.transformCode())&&r.sourceFieldId()==null)throw new IllegalArgumentException("CONVERTER_SOURCE_REQUIRED");
            Field targetField=targetFields.get(r.targetFieldId());
            if(!"SCALAR".equals(targetField.nodeKind())&&!"COPY".equals(r.transformCode()))throw new IllegalArgumentException("STRUCTURAL_CONVERSION_REQUIRES_COPY");
            if(r.sourceFieldId()!=null){Field sf=sourceFields.get(r.sourceFieldId());if(!"SCALAR".equals(targetField.nodeKind())&&!targetField.nodeKind().equals(sf.nodeKind()))throw new IllegalArgumentException("CONVERTER_NODE_KIND");}
            if(Set.of("CONSTANT","DEFAULT_MISSING","DEFAULT_NULL").contains(r.transformCode())&&!r.arguments().stream().anyMatch(a->a.name().equals("value")))throw new IllegalArgumentException("CONVERTER_VALUE_REQUIRED");
            for(Argument a:r.arguments())argument(a);
            validateRule(r,targetField);
        }
        rules=Map.copyOf(configured);
        for(Field field:target.fields())if("ARRAY".equals(field.nodeKind())&&!rules.containsKey(field.id()))throw new IllegalArgumentException("ARRAY_SOURCE_REQUIRED");
    }
    public Payload convert(Payload input){
        try {Map<String,Disposition> tags=new HashMap<>();Object converted=object(null,List.of(),input,tags);return new Payload(converted,tags);}
        catch(ExecutionFailure e){throw e;}catch(RuntimeException e){throw new ExecutionFailure("CONVERSION_INVALID",ExecutionFailure.Outcome.FAILED_BEFORE_EFFECT);}
    }
    private Map<String,Object> object(String parent,List<Integer> indices,Payload input,Map<String,Disposition> tags){Map<String,Object> result=new LinkedHashMap<>();for(Field f:children(target,parent)){Object v=value(f,indices,input,tags);if(v!=MISSING)result.put(f.memberName(),v);}return result;}
    private Object value(Field field,List<Integer> indices,Payload input,Map<String,Disposition> tags){
        Rule rule=rules.get(field.id());Object raw=rule==null?MISSING:sourceValue(rule.sourceFieldId(),indices,input.value());
        Disposition disposition=field.auditDisposition();
        if(rule!=null&&rule.sourceFieldId()!=null)disposition=Disposition.strongest(disposition,sensitivity(rule.sourceFieldId(),input,
            "SCALAR".equals(field.nodeKind())||children(target,field.id()).stream().noneMatch(f->hasRule(f.id()))));
        tags.merge(field.id(),disposition,Disposition::strongest);
        tags.merge("path:"+targetPaths.get(field.id()),disposition,Disposition::strongest);
        if("ARRAY".equals(field.nodeKind())){
            if(raw==MISSING||raw==null)return enforce(field,raw);
            if(!(raw instanceof List<?> list))throw new IllegalArgumentException("ARRAY_REQUIRED");
            Field element=children(target,field.id()).getFirst();List<Object> output=new ArrayList<>(list.size());
            for(int i=0;i<list.size();i++){List<Integer> nested=new ArrayList<>(indices);nested.add(i);Object v=value(element,nested,input,tags);if(v==MISSING)throw new IllegalArgumentException("ARRAY_ELEMENT_MISSING");output.add(v);}return output;
        }
        if("OBJECT".equals(field.nodeKind())){
            if(rule!=null&&(raw==null||raw==MISSING))return enforce(field,raw);
            if(children(target,field.id()).stream().noneMatch(f->hasRule(f.id()))&&rule!=null)return enforce(field,raw);
            Map<String,Object> mapped=object(field.id(),indices,input,tags);return mapped.isEmpty()&&!field.required()&&rule==null?MISSING:mapped;
        }
        Object converted=rule==null?MISSING:transform(rule,raw);
        return enforce(field,converted);
    }
    private boolean hasRule(String id){return rules.containsKey(id)||children(target,id).stream().anyMatch(f->hasRule(f.id()));}
    private static Object enforce(Field field,Object value){if(value==MISSING&&field.required())throw new IllegalArgumentException("REQUIRED_FIELD_MISSING");if(value==null&&!field.nullable())throw new IllegalArgumentException("NULL_NOT_ALLOWED");return value;}
    private Object sourceValue(String id,List<Integer> indices,Object input){if(id==null)return MISSING;List<Field> path=new ArrayList<>();Field f=sourceFields.get(id);while(f!=null){path.add(f);f=sourceFields.get(f.parentFieldId());}Collections.reverse(path);Object value=input;int array=0;
        for(Field step:path){if(value==MISSING||value==null)return value;Field parent=sourceFields.get(step.parentFieldId());if(parent!=null&&"ARRAY".equals(parent.nodeKind())){if(!(value instanceof List<?> list)||array>=indices.size()||indices.get(array)>=list.size())return MISSING;value=list.get(indices.get(array++));}else {if(!(value instanceof Map<?,?> map))throw new IllegalArgumentException("OBJECT_REQUIRED");value=map.containsKey(step.memberName())?map.get(step.memberName()):MISSING;}}
        return value;
    }
    private Disposition sensitivity(String id,Payload payload,boolean descendants){Disposition result=Disposition.PERSIST;for(Field f:source.fields())if(ancestor(f.id(),id)||descendants&&ancestor(id,f.id())){result=Disposition.strongest(result,f.auditDisposition());result=Disposition.strongest(result,payload.dispositions().getOrDefault(f.id(),Disposition.PERSIST));result=Disposition.strongest(result,payload.dispositions().getOrDefault("path:"+sourcePaths.get(f.id()),Disposition.PERSIST));}return result;}
    private boolean ancestor(String ancestor,String child){Field f=sourceFields.get(child);while(f!=null){if(f.id().equals(ancestor))return true;f=sourceFields.get(f.parentFieldId());}return false;}
    private static Object transform(Rule r,Object value){Map<String,Object> args=new HashMap<>();r.arguments().forEach(a->args.put(a.name(),argument(a)));
        if("CONSTANT".equals(r.transformCode()))return args.get("value");
        if("DEFAULT_MISSING".equals(r.transformCode()))return value==MISSING?args.get("value"):value;
        if("DEFAULT_NULL".equals(r.transformCode()))return value==null?args.get("value"):value;
        if(value==MISSING||value==null)return value;
        return switch(r.transformCode()){
            case "COPY" -> value;
            case "STRING" -> {if(!(value instanceof String||value instanceof Number||value instanceof Boolean||value instanceof LocalDate||value instanceof LocalDateTime||value instanceof OffsetDateTime))throw new IllegalArgumentException("SCALAR_REQUIRED");yield value.toString();}
            case "INTEGER" -> new BigDecimal(value.toString()).longValueExact();
            case "DECIMAL" -> new BigDecimal(value.toString());
            case "BOOLEAN" -> {if(value instanceof Boolean)yield value;if("true".equals(value))yield true;if("false".equals(value))yield false;throw new IllegalArgumentException("BOOLEAN_INVALID");}
            case "DATE" -> LocalDate.parse(value.toString()).toString();
            case "DATETIME" -> LocalDateTime.parse(value.toString()).toString();
            case "CODE_MAP" -> {String key=value.toString();if(!args.containsKey(key))throw new IllegalArgumentException("UNMAPPED_CODE");yield args.get(key);}
            default -> throw new IllegalArgumentException("UNSUPPORTED_TRANSFORM");
        };
    }
    public static Object argument(Argument a){int supplied=(a.stringValue()!=null?1:0)+(a.integerValue()!=null?1:0)+(a.decimalValue()!=null?1:0)+(a.booleanValue()!=null?1:0);if("NULL".equals(a.valueType())){if(supplied!=0)throw new IllegalArgumentException("ARGUMENT_TYPE");return null;}if(supplied!=1)throw new IllegalArgumentException("ARGUMENT_TYPE");Object result=switch(a.valueType()){case "STRING"->a.stringValue();case "INTEGER"->a.integerValue();case "DECIMAL"->a.decimalValue()==null?null:new BigDecimal(a.decimalValue());case "BOOLEAN"->a.booleanValue();default->throw new IllegalArgumentException("ARGUMENT_TYPE");};if(result==null)throw new IllegalArgumentException("ARGUMENT_TYPE");return result;}
    private void validateRule(Rule rule,Field targetField) {
        if(!"INPUT".equals(rule.sourcePort()))throw new IllegalArgumentException("UNSUPPORTED_SOURCE_PORT");
        Field sourceField=sourceFields.get(rule.sourceFieldId());
        if(sourceField!=null&&arrayDepth(sourceField,sourceFields)!=arrayDepth(targetField,targetFields))throw new IllegalArgumentException("ARRAY_SCOPE_MISMATCH");
        if(!"SCALAR".equals(targetField.nodeKind()))return;
        if(sourceField!=null&&!"SCALAR".equals(sourceField.nodeKind()))throw new IllegalArgumentException("SCALAR_SOURCE_REQUIRED");
        String wanted=scalarType(targetField.valueType());
        String actual=switch(rule.transformCode()) {
            case "COPY","DEFAULT_MISSING","DEFAULT_NULL" -> scalarType(sourceField.valueType());
            case "STRING" -> "STRING";
            case "INTEGER" -> "INTEGER";
            case "DECIMAL" -> "DECIMAL";
            case "BOOLEAN" -> "BOOLEAN";
            case "DATE" -> "DATE";
            case "DATETIME" -> "DATETIME";
            case "CONSTANT","CODE_MAP" -> wanted;
            default -> throw new IllegalArgumentException("UNSUPPORTED_TRANSFORM");
        };
        if(!wanted.equals(actual))throw new IllegalArgumentException("CONVERTER_TYPE_MISMATCH");
        if(sourceField!=null&&sourceField.nullable()&&!targetField.nullable()&&!"DEFAULT_NULL".equals(rule.transformCode()))throw new IllegalArgumentException("CONVERTER_NULLABILITY_MISMATCH");
        if(sourceField!=null&&!sourceField.required()&&targetField.required()&&!"DEFAULT_MISSING".equals(rule.transformCode()))throw new IllegalArgumentException("CONVERTER_REQUIRED_MISMATCH");
        if(Set.of("CONSTANT","DEFAULT_MISSING","DEFAULT_NULL","CODE_MAP").contains(rule.transformCode()))for(Argument argument:rule.arguments()) {
            Object value=argument(argument);
            if(value==null?!targetField.nullable():!wanted.equals(scalarType(argument.valueType())))throw new IllegalArgumentException("CONVERTER_ARGUMENT_TYPE");
        }
    }
    private static int arrayDepth(Field field,Map<String,Field> fields){int count=0;for(Field parent=fields.get(field.parentFieldId());parent!=null;parent=fields.get(parent.parentFieldId()))if("ARRAY".equals(parent.nodeKind()))count++;return count;}
    private static String scalarType(String type){return switch(type){case "TEXT"->"STRING";case "LONG"->"INTEGER";case "NUMBER"->"DECIMAL";default->type;};}
    private static Map<String,Field> index(Contract c){Map<String,Field> result=new HashMap<>();for(Field f:c.fields())if(result.put(f.id(),f)!=null)throw new IllegalArgumentException("DUPLICATE_FIELD");return Collections.unmodifiableMap(result);}
    private static Map<String,String> paths(Map<String,Field> fields){
        Map<String,String> result=new HashMap<>();
        for(Field field:fields.values()){
            Deque<String> parts=new ArrayDeque<>();
            for(Field current=field;current!=null;current=fields.get(current.parentFieldId())){
                Field parent=fields.get(current.parentFieldId());
                parts.addFirst(parent!=null&&parent.nodeKind().equals("ARRAY")?"*":current.memberName().replace("~","~0").replace("/","~1"));
            }
            result.put(field.id(),"/"+String.join("/",parts));
        }
        return Map.copyOf(result);
    }
    private static List<Field> children(Contract c,String parent){return c.fields().stream().filter(f->Objects.equals(parent,f.parentFieldId())).sorted(Comparator.comparingInt(Field::ordinal)).toList();}
}
