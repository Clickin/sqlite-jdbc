package io.gateway.management;

import io.gateway.definitions.DefinitionRepository;
import io.gateway.definitions.Definitions.*;
import io.gateway.definitions.Definitions.Head;
import io.gateway.definitions.Definitions.Header;
import io.gateway.audit.AuditService;
import io.gateway.connectors.jdbc.JdbcResources;
import io.gateway.connectors.http.HttpResources;
import io.micronaut.http.*;
import io.micronaut.http.annotation.*;
import io.micronaut.json.JsonMapper;
import io.micronaut.scheduling.TaskExecutors;
import io.micronaut.scheduling.annotation.ExecuteOn;
import io.micronaut.serde.annotation.*;
import java.io.IOException;
import java.util.*;

@Controller("/management/definitions")
@ExecuteOn(TaskExecutors.BLOCKING)
@SerdeImport(Head.class) @SerdeImport(Version.class) @SerdeImport(Validation.class)
@SerdeImport(JdbcSource.class) @SerdeImport(HttpSource.class) @SerdeImport(Header.class)
@SerdeImport(Mapper.class) @SerdeImport(MapperDocument.class)
@SerdeImport(JdbcOperation.class) @SerdeImport(HttpOperation.class) @SerdeImport(OutBinding.class)
@SerdeImport(Parameter.class) @SerdeImport(ExpectedStatus.class)
@SerdeImport(Contract.class) @SerdeImport(Field.class)
@SerdeImport(Representation.class) @SerdeImport(JsonBinding.class) @SerdeImport(XmlBinding.class)
@SerdeImport(Converter.class) @SerdeImport(Rule.class) @SerdeImport(Argument.class)
@SerdeImport(Workflow.class) @SerdeImport(Stage.class) @SerdeImport(Port.class) @SerdeImport(Credential.class)
@SerdeImport(ErrorMapping.class) @SerdeImport(ErrorRule.class)
@SerdeImport(SecurityBinding.class)
@SerdeImport(ReferenceBinding.class)
public final class DefinitionController {
    private final DefinitionRepository definitions;
    private final ManagementAccess access;
    private final JsonMapper json;
    private final JdbcResources jdbc;
    private final HttpResources http;
    private final AuditService audit;
    public DefinitionController(DefinitionRepository definitions, ManagementAccess access, JsonMapper json, JdbcResources jdbc, HttpResources http, AuditService audit) {
        this.definitions=definitions; this.access=access; this.json=json; this.jdbc=jdbc; this.http=http; this.audit=audit;
    }
    @Serdeable public record DraftRequest(String objectId,String logicalKey,String displayName,String description,String reason,String detailType,Map<String,Object> detail) {}
    @Serdeable public record VersionRequest(String versionId) {}
    @Serdeable public record ApplyRequest(String versionId,long generation,Map<String,String> dependencyVersions,String reason) {}
    @Serdeable public record RollbackRequest(String versionId,long expectedGeneration,String reason) {}
    @Serdeable public record SavedResponse(Head object,Version version,String detailType,Object detail) {}
    @Get public HttpResponse<?> list(HttpRequest<?> request) { gate(request,false); return ok(definitions.list()); }
    @Get("/{id}{?versionId}") public HttpResponse<?> get(String id,@io.micronaut.core.annotation.Nullable String versionId,HttpRequest<?> request) { gate(request,false); return ok(response(definitions.get(id,versionId))); }
    @Get("/{id}/history") public HttpResponse<?> history(String id,HttpRequest<?> request) { gate(request,false); return ok(definitions.history(id)); }
    @Get("/{id}/dependencies") public HttpResponse<?> dependencies(String id,HttpRequest<?> request) {
        gate(request,false);
        return ok(definitions.resolve(id).definitions().values().stream().map(DefinitionController::response).toList());
    }
    @Post("/{id}/probe") public HttpResponse<?> probe(String id,HttpRequest<?> request) {
        var context=access.definition(request,id,null,null);
        return access.mutateDefinition(context,id,null,null,()->{
        String actor=context.principalId();
        var graph=definitions.resolve(id);
        var source=graph.require(id).detail();
        if(!(source instanceof JdbcSource)&&!(source instanceof HttpSource)) throw new IllegalArgumentException("DATASOURCE_REQUIRED");
        audit.record("DATASOURCE_PROBE",actor,"PENDING","CONNECTION_ONLY");
        try {
            if(source instanceof JdbcSource) jdbc.probe(graph,id); else http.probe(graph,id);
            audit.record("DATASOURCE_PROBE",actor,"SUCCEEDED","CONNECTION_ONLY");
            return ok(Map.of("status","CONNECTED","businessExecuted",false));
        } catch(RuntimeException failure) {
            audit.record("DATASOURCE_PROBE",actor,"FAILED","CONNECTION_UNAVAILABLE");
            throw failure;
        }
        });
    }
    @Post public HttpResponse<?> draft(@Body DraftRequest body,HttpRequest<?> request) throws IOException {
        Draft draft=toDraft(json,body);
        var context=access.definition(request,body.objectId(),null,draft.detail());
        return access.mutateDefinition(context,body.objectId(),null,draft.detail(),()->ok(response(definitions.draft(draft,context.principalId()))));
    }
    static Draft toDraft(JsonMapper json,DraftRequest body) throws IOException {
        if(body.detail()==null) throw new IllegalArgumentException("DEFINITION_DETAIL_REQUIRED");
        Class<? extends Detail> type=switch(Objects.requireNonNull(body.detailType())) {
            case "JdbcSource" -> JdbcSource.class; case "HttpSource" -> HttpSource.class;
            case "Mapper" -> Mapper.class; case "JdbcOperation" -> JdbcOperation.class; case "HttpOperation" -> HttpOperation.class;
            case "Contract" -> Contract.class; case "Representation" -> Representation.class; case "Converter" -> Converter.class; case "Workflow" -> Workflow.class;
            default -> throw new IllegalArgumentException("UNSUPPORTED_DEFINITION_TYPE");
        };
        Detail detail;
        try { detail=json.readValue(json.writeValueAsBytes(body.detail()),type); }
        catch(IOException malformed){ throw new IllegalArgumentException("INVALID_DEFINITION_DETAIL"); }
        return new Draft(body.objectId(),body.logicalKey(),body.displayName(),body.description(),body.reason(),detail);
    }
    @Post("/{id}/validate") public HttpResponse<?> validate(String id,@Body VersionRequest body,HttpRequest<?> request) {
        gate(request,true); return ok(definitions.validate(id,body.versionId()));
    }
    @Post("/{id}/apply") public HttpResponse<?> apply(String id,@Body ApplyRequest body,HttpRequest<?> request) {
        var context=access.definition(request,id,body.versionId(),null);
        return access.mutateDefinition(context,id,body.versionId(),null,()->ok(response(definitions.apply(new Validation(id,body.versionId(),body.generation(),body.dependencyVersions()),context.principalId(),body.reason()))));
    }
    @Post("/{id}/rollback") public HttpResponse<?> rollback(String id,@Body RollbackRequest body,HttpRequest<?> request) {
        var context=access.definition(request,id,body.versionId(),null);
        return access.mutateDefinition(context,id,body.versionId(),null,()->ok(response(definitions.rollback(id,body.versionId(),body.expectedGeneration(),context.principalId(),body.reason()))));
    }
    private void gate(HttpRequest<?> request,boolean mutation) {
        access.authorize(request,"config.manage",mutation);
    }
    private static SavedResponse response(Saved saved) { return new SavedResponse(saved.object(),saved.version(),saved.detail().getClass().getSimpleName(),saved.detail()); }
    private static HttpResponse<?> ok(Object body) { return HttpResponse.ok(body).header("Cache-Control","no-store").header("Referrer-Policy","no-referrer"); }
}
