package io.gateway;

import io.gateway.authorization.AuthorizedContext;
import io.gateway.persistence.PlatformMapper;
import org.apache.ibatis.annotations.*;
import java.util.Map;

public interface ExecutionMapper extends PlatformMapper {
    @Insert("""
        INSERT INTO execution(id,trace_id,workflow_version_id,actor_subject_id,caller_service_id,started_at,
          business_outcome,response_outcome,principal_id,client_object_id,public_grant_id,public_token_record_id,transport,mcp_tool_version_id,required_action_id)
        VALUES(#{id},#{id},#{workflowVersion},#{subject},#{caller},#{now},'RUNNING','PENDING',#{principal},#{client},#{grant},#{token},#{transport},#{toolVersion},#{actionId})
        """)
    void start(Map<String,Object> row);

    @Insert("INSERT INTO execution_dependency(execution_id,role_or_path,config_version_id) VALUES(#{execution},#{path},#{version})")
    void dependency(@Param("execution")String execution,@Param("path")String path,@Param("version")String version);

    @Insert("""
        INSERT INTO execution_target(execution_id,stage_key,action_id,target_kind,organization,identifier_system,
          patient_identifier,encounter_identifier,document_identifier,decision_id,outcome)
        VALUES(#{execution},#{stage},#{actionId},#{context.target.targetKind},#{context.target.organization},#{context.target.identifierSystem},
          #{context.target.patientIdentifier},#{context.target.encounterIdentifier},#{context.target.documentIdentifier},#{context.decisionId},'ALLOW')
        """)
    void target(@Param("execution")String execution,@Param("stage")String stage,@Param("actionId")String actionId,@Param("context")AuthorizedContext context);

    @Update("""
        UPDATE execution SET business_outcome=#{business},response_outcome=#{response},error_code=#{code},finished_at=#{now}
        WHERE id=#{id}
        """)
    void finish(@Param("id")String id,@Param("business")String business,@Param("response")String response,@Param("code")String code,@Param("now")long now);

    @Select("SELECT business_outcome AS businessOutcome,response_outcome AS responseOutcome,error_code AS errorCode,CASE WHEN finished_at IS NULL THEN 'INCOMPLETE' ELSE 'COMPLETE' END AS completionState FROM execution WHERE id=#{id} AND principal_id=#{principal}")
    Map<String,Object> status(@Param("id")String id,@Param("principal")String principal);

    @Insert("""
        INSERT INTO execution_stage(id,execution_id,stage_key,operation_version_id,started_at,effect_kind,business_outcome)
        VALUES(#{id},#{execution},#{stage},#{operation},#{now},#{effect},'RUNNING')
        """)
    void startStage(@Param("id")String id,@Param("execution")String execution,@Param("stage")String stage,
                    @Param("operation")String operation,@Param("effect")String effect,@Param("now")long now);
    @Update("UPDATE execution_stage SET business_outcome='SUCCEEDED',finished_at=#{now} WHERE id=#{id}")
    void finishStage(@Param("id")String id,@Param("now")long now);
    @Update("""
        UPDATE execution_stage SET business_outcome=CASE WHEN effect_kind='READ_ONLY' THEN #{readOutcome} ELSE #{business} END,
            error_code=#{code},finished_at=#{now} WHERE execution_id=#{id} AND finished_at IS NULL
        """)
    void finishActiveStages(@Param("id")String id,@Param("business")String business,@Param("readOutcome")String readOutcome,
                            @Param("code")String code,@Param("now")long now);
}
