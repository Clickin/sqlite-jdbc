package io.gateway.credentials;

import io.gateway.audit.AuditService;
import io.gateway.persistence.PlatformStore;
import io.micronaut.context.annotation.Value;
import io.micronaut.serde.annotation.Serdeable;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermission;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Set;
import java.util.UUID;

@Singleton
public final class CredentialService {
    private static final SecureRandom RANDOM = new SecureRandom();
    private final PlatformStore store;
    private final AuditService audit;
    private final Path keyDirectory;
    private final String activeKeyId;

    @Inject
    public CredentialService(PlatformStore store, AuditService audit,
                             @Value("${gateway.credentials.key-directory:}") String keyDirectory,
                             @Value("${gateway.credentials.active-key-id:}") String activeKeyId) {
        this.store = store;
        this.audit = audit;
        this.keyDirectory = keyDirectory.isBlank() ? null : Path.of(keyDirectory).toAbsolutePath().normalize();
        this.activeKeyId = activeKeyId;
    }

    @Serdeable
    public record Metadata(String objectId, String versionId, long revision, long generation,
                           String secretKind, String publicUsername, String keyId, Long revokedAt) {}

    public Metadata create(String logicalKey, String secretKind, String publicUsername, byte[] secret,
                           String actor, String reason) {
        validate(logicalKey, secretKind, secret, actor, reason);
        String objectId = UUID.randomUUID().toString();
        String versionId = UUID.randomUUID().toString();
        Encrypted encrypted = encrypt(objectId, versionId, secretKind, activeKeyId, secret);
        long now = System.currentTimeMillis();
        return store.write(session -> {
            CredentialMapper mapper = session.getMapper(CredentialMapper.class);
            mapper.createObject(objectId, logicalKey, now, actor);
            insert(mapper, objectId, versionId, 1, logicalKey, secretKind, publicUsername, actor, reason, now, encrypted);
            if (mapper.apply(objectId, versionId, 0) != 1) throw failure("CREDENTIAL_CONFLICT");
            mapper.change(UUID.randomUUID().toString(), objectId, null, versionId, 0, 1, actor, reason, now);
            audit.record("CREDENTIAL_CREATED", actor, "SUCCEEDED", null);
            return new Metadata(objectId, versionId, 1, 1, secretKind, publicUsername, encrypted.keyId, null);
        });
    }

    public Metadata replace(String objectId, long expectedGeneration, String secretKind, String publicUsername,
                            byte[] secret, String actor, String reason) {
        validate(objectId, secretKind, secret, actor, reason);
        String versionId = UUID.randomUUID().toString();
        Encrypted encrypted = encrypt(objectId, versionId, secretKind, activeKeyId, secret);
        long now = System.currentTimeMillis();
        return store.write(session -> {
            CredentialMapper mapper = session.getMapper(CredentialMapper.class);
            CredentialMapper.Head previous = mapper.head(objectId);
            if (previous == null || previous.generation() != expectedGeneration) throw failure("CREDENTIAL_CONFLICT");
            if (mapper.increment(objectId, expectedGeneration, previous.revisionCounter()) != 1) throw failure("CREDENTIAL_CONFLICT");
            long revision = Math.addExact(previous.revisionCounter(), 1);
            insert(mapper, objectId, versionId, revision, previous.logicalKey(), secretKind, publicUsername, actor, reason, now, encrypted);
            if (mapper.apply(objectId, versionId, expectedGeneration) != 1) throw failure("CREDENTIAL_CONFLICT");
            mapper.change(UUID.randomUUID().toString(), objectId, previous.versionId(), versionId,
                expectedGeneration, expectedGeneration + 1, actor, reason, now);
            audit.record("CREDENTIAL_REPLACED", actor, "SUCCEEDED", null);
            return new Metadata(objectId, versionId, revision, expectedGeneration + 1, secretKind, publicUsername, encrypted.keyId, null);
        });
    }

    private static void insert(CredentialMapper mapper, String objectId, String versionId, long revision,
                               String logicalKey, String kind, String username, String actor, String reason,
                               long now, Encrypted cipher) {
        mapper.version(versionId, objectId, revision, now, actor, reason, logicalKey);
        mapper.detail(versionId, kind, username);
        mapper.cipher(versionId, cipher.keyId, cipher.nonce, cipher.ciphertext, cipher.tag, now);
        mapper.state(versionId);
    }

    public Metadata metadata(String objectId) {
        Metadata metadata = store.read(session -> session.getMapper(CredentialMapper.class).metadata(objectId));
        if (metadata == null) throw failure("CREDENTIAL_NOT_FOUND");
        return metadata;
    }

    public void checkVersion(String versionId) {
        if (store.read(session -> session.getMapper(CredentialMapper.class).available(versionId)) != 1)
            throw failure("CREDENTIAL_UNAVAILABLE");
    }

    public Secret resolve(String objectId) {
        CredentialMapper.Row row = store.read(session -> session.getMapper(CredentialMapper.class).current(objectId));
        verifyAvailable(row);
        return decrypt(row);
    }

    public Secret resolveVersion(String versionId) { return decrypt(available(versionId)); }

    private CredentialMapper.Row available(String versionId) {
        CredentialMapper.Row row = store.read(session -> session.getMapper(CredentialMapper.class).versionRow(versionId));
        verifyAvailable(row);
        return row;
    }

    private static void verifyAvailable(CredentialMapper.Row row) {
        if (row == null || !row.enabled() || row.revokedAt() != null) throw failure("CREDENTIAL_UNAVAILABLE");
    }

    public void revoke(String versionId, String actor) {
        if (actor == null || actor.isBlank()) throw failure("CREDENTIAL_INPUT_INVALID");
        store.write(session -> {
            CredentialMapper mapper = session.getMapper(CredentialMapper.class);
            if (mapper.exists(versionId) != 1) throw failure("CREDENTIAL_NOT_FOUND");
            if (mapper.revoke(versionId, System.currentTimeMillis(), actor) == 1)
                audit.record("CREDENTIAL_REVOKED", actor, "SUCCEEDED", null);
            return null;
        });
    }

    public void reencrypt(String versionId, String targetKeyId, String actor) {
        if (actor == null || actor.isBlank()) throw failure("CREDENTIAL_INPUT_INVALID");
        CredentialMapper.Row row = available(versionId);
        Encrypted encrypted;
        try (Secret secret = decrypt(row)) {
            encrypted = encrypt(row.objectId(), versionId, row.secretKind(), targetKeyId, secret.bytes());
        }
        long now = System.currentTimeMillis();
        store.write(session -> {
            CredentialMapper mapper = session.getMapper(CredentialMapper.class);
            if (mapper.reencrypt(versionId, row.cipherGeneration(), encrypted.keyId, encrypted.nonce,
                    encrypted.ciphertext, encrypted.tag, now) != 1) throw failure("CREDENTIAL_CONFLICT");
            audit.record("CREDENTIAL_REENCRYPTED", actor, "SUCCEEDED", null);
            return null;
        });
    }

    private Encrypted encrypt(String objectId, String versionId, String kind, String keyId, byte[] plaintext) {
        byte[] key = readKey(keyId);
        byte[] nonce = new byte[12];
        RANDOM.nextBytes(nonce);
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, nonce));
            cipher.updateAAD(aad(objectId, versionId, kind));
            byte[] encrypted = cipher.doFinal(plaintext);
            try {
                return new Encrypted(keyId, nonce, Arrays.copyOf(encrypted, encrypted.length - 16),
                    Arrays.copyOfRange(encrypted, encrypted.length - 16, encrypted.length));
            } finally { Arrays.fill(encrypted, (byte) 0); }
        } catch (GeneralSecurityException failure) {
            throw failure("CREDENTIAL_ENCRYPTION_FAILED");
        } finally { Arrays.fill(key, (byte) 0); }
    }

    private Secret decrypt(CredentialMapper.Row row) {
        byte[] key = readKey(row.keyId());
        byte[] combined = Arrays.copyOf(row.ciphertext(), row.ciphertext().length + row.authenticationTag().length);
        System.arraycopy(row.authenticationTag(), 0, combined, row.ciphertext().length, row.authenticationTag().length);
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, row.nonce()));
            cipher.updateAAD(aad(row.objectId(), row.versionId(), row.secretKind()));
            return new Secret(row.versionId(), row.publicUsername(), cipher.doFinal(combined));
        } catch (GeneralSecurityException failure) {
            throw failure("CREDENTIAL_DECRYPTION_FAILED");
        } finally {
            Arrays.fill(key, (byte) 0);
            Arrays.fill(combined, (byte) 0);
        }
    }

    private byte[] readKey(String keyId) {
        if (keyDirectory == null || keyId == null || !keyId.matches("[A-Za-z0-9_-]{1,64}")) throw failure("CREDENTIAL_KEY_UNAVAILABLE");
        Path keyFile = keyDirectory.resolve(keyId + ".key");
        try {
            if (!Files.isRegularFile(keyFile, LinkOption.NOFOLLOW_LINKS) || Files.size(keyFile) != 32)
                throw failure("CREDENTIAL_KEY_UNAVAILABLE");
            Set<PosixFilePermission> permissions = Files.getPosixFilePermissions(keyFile, LinkOption.NOFOLLOW_LINKS);
            if (permissions.stream().anyMatch(permission -> permission != PosixFilePermission.OWNER_READ))
                throw failure("CREDENTIAL_KEY_PERMISSIONS_INVALID");
            byte[] key = Files.readAllBytes(keyFile);
            if (key.length != 32) { Arrays.fill(key, (byte) 0); throw failure("CREDENTIAL_KEY_UNAVAILABLE"); }
            return key;
        } catch (java.io.IOException | UnsupportedOperationException failure) {
            throw failure("CREDENTIAL_KEY_UNAVAILABLE");
        }
    }

    private static byte[] aad(String objectId, String versionId, String kind) {
        return ("gateway-credential-v1\u0000" + objectId + "\u0000" + versionId + "\u0000" + kind).getBytes(StandardCharsets.UTF_8);
    }

    private static void validate(String id, String kind, byte[] secret, String actor, String reason) {
        if (id == null || id.isBlank() || id.length() > 256 || kind == null || !kind.matches("[A-Z][A-Z0-9_]{0,63}")
            || secret == null || secret.length == 0 || secret.length > 1_048_576 || actor == null || actor.isBlank()
            || reason == null || reason.isBlank()) throw failure("CREDENTIAL_INPUT_INVALID");
    }

    private record Encrypted(String keyId, byte[] nonce, byte[] ciphertext, byte[] tag) {}
    private static CredentialException failure(String code) { return new CredentialException(code); }
    public static final class CredentialException extends RuntimeException {
        public CredentialException(String code) { super(code, null, false, false); }
    }
    public static final class Secret implements AutoCloseable {
        private final String versionId;
        private final String username;
        private byte[] plaintext;
        private Secret(String versionId, String username, byte[] plaintext) {
            this.versionId = versionId; this.username = username; this.plaintext = plaintext;
        }
        public String versionId() { return versionId; }
        public String publicUsername() { return username; }
        public byte[] bytes() {
            if (plaintext == null) throw failure("CREDENTIAL_SECRET_CLOSED");
            return plaintext;
        }
        public String utf8() { return new String(bytes(), StandardCharsets.UTF_8); }
        @Override public void close() { if (plaintext != null) { Arrays.fill(plaintext, (byte) 0); plaintext = null; } }
        @Override public String toString() { return "Secret[redacted]"; }
    }
}
