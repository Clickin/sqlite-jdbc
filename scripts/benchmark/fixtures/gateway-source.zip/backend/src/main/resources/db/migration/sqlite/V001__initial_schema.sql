-- Initial unreleased PLAN v2 schema. All state shares this database; no configuration JSON blobs.

CREATE TABLE config_object (
  id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL CHECK(kind IN ('DATASOURCE','CREDENTIAL','MAPPER','OPERATION','CONTRACT','REPRESENTATION','CONVERTER','WORKFLOW','SECURITY_BINDING','SCREEN_PROFILE','RETENTION_POLICY','ROLE','TARGET_POLICY','OAUTH_CLIENT','OAUTH_POLICY','MCP_TOOL','TLS_PROFILE','NETWORK_POLICY','ERROR_MAPPING')),
  logical_key TEXT NOT NULL,
  current_version_id TEXT,
  revision_counter INTEGER NOT NULL DEFAULT 0 CHECK(revision_counter >= 0),
  generation INTEGER NOT NULL DEFAULT 0 CHECK(generation >= 0),
  enabled INTEGER NOT NULL DEFAULT TRUE CHECK(enabled IN (0,1)),
  created_at INTEGER NOT NULL,
  created_by TEXT NOT NULL,
  UNIQUE(kind,logical_key), UNIQUE(id,kind),
  FOREIGN KEY(id,current_version_id) REFERENCES config_version(object_id,id)
) STRICT;

CREATE TABLE config_version (
  id TEXT PRIMARY KEY NOT NULL,
  object_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  revision INTEGER NOT NULL CHECK(revision > 0),
  created_at INTEGER NOT NULL,
  created_by TEXT NOT NULL,
  change_reason TEXT NOT NULL,
  display_name TEXT NOT NULL,
  description TEXT,
  UNIQUE(object_id,revision), UNIQUE(object_id,id), UNIQUE(id,kind),
  FOREIGN KEY(object_id,kind) REFERENCES config_object(id,kind)
) STRICT;

CREATE TABLE configuration_change (
  id TEXT PRIMARY KEY NOT NULL,
  object_id TEXT NOT NULL REFERENCES config_object(id),
  before_version_id TEXT,
  after_version_id TEXT NOT NULL,
  before_generation INTEGER NOT NULL,
  after_generation INTEGER NOT NULL CHECK(after_generation > before_generation),
  actor_subject_id TEXT NOT NULL,
  reason TEXT NOT NULL,
  changed_at INTEGER NOT NULL,
  FOREIGN KEY(object_id,before_version_id) REFERENCES config_version(object_id,id),
  FOREIGN KEY(object_id,after_version_id) REFERENCES config_version(object_id,id)
) STRICT;

CREATE TABLE datasource_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'DATASOURCE' CHECK(kind = 'DATASOURCE'),
  provider_id TEXT NOT NULL CHECK(provider_id IN ('jdbc.mybatis','http.classic','http.json','http.xml','http.xapi')),
  max_concurrent INTEGER NOT NULL CHECK(max_concurrent > 0),
  queue_timeout_ms INTEGER NOT NULL CHECK(queue_timeout_ms > 0),
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE credential_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'CREDENTIAL' CHECK(kind = 'CREDENTIAL'),
  secret_kind TEXT NOT NULL,
  public_username TEXT,
  certificate_subject TEXT,
  certificate_issuer TEXT,
  certificate_serial TEXT,
  certificate_not_before_ms INTEGER,
  certificate_not_after_ms INTEGER,
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE credential_cipher (
  credential_version_id TEXT PRIMARY KEY NOT NULL REFERENCES credential_version(version_id),
  key_id TEXT NOT NULL,
  nonce BLOB NOT NULL CHECK(length(nonce) = 12),
  ciphertext BLOB NOT NULL,
  authentication_tag BLOB NOT NULL CHECK(length(authentication_tag) = 16),
  cipher_generation INTEGER NOT NULL CHECK(cipher_generation > 0),
  encrypted_at INTEGER NOT NULL,
  UNIQUE(key_id,nonce)
) STRICT;

CREATE TABLE credential_state (
  credential_version_id TEXT PRIMARY KEY NOT NULL REFERENCES credential_version(version_id),
  revoked_at INTEGER,
  revoked_by TEXT,
  CHECK((revoked_at IS NULL AND revoked_by IS NULL) OR (revoked_at IS NOT NULL AND revoked_by IS NOT NULL))
) STRICT;

CREATE TABLE jdbc_datasource_version (
  version_id TEXT PRIMARY KEY NOT NULL REFERENCES datasource_version(version_id),
  jdbc_url TEXT NOT NULL,
  driver_profile_id TEXT NOT NULL,
  credential_object_id TEXT REFERENCES config_object(id),
  pool_min_idle INTEGER NOT NULL CHECK(pool_min_idle >= 0),
  pool_max_size INTEGER NOT NULL CHECK(pool_max_size > 0 AND pool_max_size >= pool_min_idle),
  acquire_timeout_ms INTEGER NOT NULL CHECK(acquire_timeout_ms > 0),
  read_only_policy INTEGER NOT NULL CHECK(read_only_policy IN (0,1))
) STRICT;

CREATE TABLE tls_profile_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'TLS_PROFILE' CHECK(kind = 'TLS_PROFILE'),
  trust_credential_object_id TEXT REFERENCES config_object(id),
  client_credential_object_id TEXT REFERENCES config_object(id),
  verify_hostname INTEGER NOT NULL DEFAULT TRUE CHECK(verify_hostname IN (0,1)),
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE network_policy_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'NETWORK_POLICY' CHECK(kind = 'NETWORK_POLICY'),
  allow_http INTEGER NOT NULL DEFAULT FALSE CHECK(allow_http IN (0,1)),
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE network_policy_host (
  network_policy_version_id TEXT NOT NULL REFERENCES network_policy_version(version_id),
  host_name TEXT NOT NULL,
  port INTEGER NOT NULL CHECK(port BETWEEN 1 AND 65535),
  PRIMARY KEY(network_policy_version_id,host_name,port)
) STRICT;

CREATE TABLE http_datasource_version (
  version_id TEXT PRIMARY KEY NOT NULL REFERENCES datasource_version(version_id),
  base_uri TEXT NOT NULL,
  authentication_kind TEXT NOT NULL,
  credential_object_id TEXT REFERENCES config_object(id),
  tls_profile_object_id TEXT REFERENCES config_object(id),
  proxy_profile_id TEXT,
  network_policy_object_id TEXT REFERENCES config_object(id),
  pool_max_total INTEGER NOT NULL CHECK(pool_max_total > 0),
  pool_max_per_route INTEGER NOT NULL CHECK(pool_max_per_route > 0 AND pool_max_per_route <= pool_max_total),
  connect_timeout_ms INTEGER NOT NULL CHECK(connect_timeout_ms > 0),
  redirect_policy TEXT NOT NULL CHECK(redirect_policy = 'NEVER')
) STRICT;

CREATE TABLE http_source_header (
  datasource_version_id TEXT NOT NULL REFERENCES http_datasource_version(version_id),
  ordinal INTEGER NOT NULL CHECK(ordinal >= 0),
  header_name TEXT NOT NULL,
  literal_value TEXT,
  credential_part TEXT,
  PRIMARY KEY(datasource_version_id,ordinal),
  CHECK((literal_value IS NULL) <> (credential_part IS NULL)),
  CHECK(literal_value IS NULL OR lower(header_name) NOT IN ('authorization','proxy-authorization','cookie','set-cookie'))
) STRICT;

CREATE TABLE mapper_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'MAPPER' CHECK(kind = 'MAPPER'),
  database_profile TEXT NOT NULL,
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE mapper_document (
  id TEXT PRIMARY KEY NOT NULL,
  mapper_version_id TEXT NOT NULL REFERENCES mapper_version(version_id),
  resource_name TEXT NOT NULL,
  xml_text TEXT NOT NULL,
  ordinal INTEGER NOT NULL CHECK(ordinal >= 0),
  UNIQUE(mapper_version_id,resource_name), UNIQUE(mapper_version_id,ordinal)
) STRICT;

CREATE TABLE mapper_import (
  mapper_version_id TEXT NOT NULL REFERENCES mapper_version(version_id),
  imported_mapper_object_id TEXT NOT NULL REFERENCES config_object(id),
  ordinal INTEGER NOT NULL CHECK(ordinal >= 0),
  PRIMARY KEY(mapper_version_id,imported_mapper_object_id), UNIQUE(mapper_version_id,ordinal)
) STRICT;

CREATE TABLE contract_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'CONTRACT' CHECK(kind = 'CONTRACT'),
  model_kind TEXT NOT NULL CHECK(model_kind IN ('VALUE','TABLES','XML')),
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE contract_field (
  id TEXT PRIMARY KEY NOT NULL,
  contract_object_id TEXT NOT NULL REFERENCES config_object(id),
  logical_name TEXT NOT NULL,
  UNIQUE(contract_object_id,logical_name), UNIQUE(contract_object_id,id)
) STRICT;

CREATE TABLE contract_field_version (
  contract_version_id TEXT NOT NULL REFERENCES contract_version(version_id),
  field_id TEXT NOT NULL REFERENCES contract_field(id),
  parent_field_id TEXT,
  member_name TEXT,
  node_kind TEXT NOT NULL CHECK(node_kind IN ('OBJECT','ARRAY','SCALAR','TABLE','COLUMN')),
  value_type TEXT,
  ordinal INTEGER NOT NULL CHECK(ordinal >= 0),
  required INTEGER NOT NULL CHECK(required IN (0,1)),
  nullable INTEGER NOT NULL CHECK(nullable IN (0,1)),
  precision INTEGER CHECK(precision > 0),
  scale INTEGER,
  max_length INTEGER CHECK(max_length >= 0),
  audit_disposition TEXT NOT NULL CHECK(audit_disposition IN ('PERSIST','OMIT_RECOVERABLE','OMIT_SECRET')),
  PRIMARY KEY(contract_version_id,field_id),
  FOREIGN KEY(contract_version_id,parent_field_id) REFERENCES contract_field_version(contract_version_id,field_id),
  CHECK(parent_field_id IS NULL OR parent_field_id <> field_id),
  CHECK((node_kind IN ('OBJECT','ARRAY','TABLE') AND value_type IS NULL) OR (node_kind IN ('SCALAR','COLUMN') AND value_type IS NOT NULL))
) STRICT;

CREATE UNIQUE INDEX contract_sibling_name ON contract_field_version (contract_version_id,COALESCE(parent_field_id,''),member_name);

CREATE UNIQUE INDEX contract_sibling_order ON contract_field_version (contract_version_id,COALESCE(parent_field_id,''),ordinal);

CREATE TABLE operation_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'OPERATION' CHECK(kind = 'OPERATION'),
  source_object_id TEXT NOT NULL REFERENCES config_object(id),
  input_contract_object_id TEXT REFERENCES config_object(id),
  output_contract_object_id TEXT REFERENCES config_object(id),
  effect_kind TEXT NOT NULL CHECK(effect_kind IN ('READ_ONLY','WRITE','UNKNOWN')),
  timeout_ms INTEGER NOT NULL CHECK(timeout_ms > 0),
  max_result_rows INTEGER CHECK(max_result_rows > 0),
  max_result_bytes INTEGER CHECK(max_result_bytes > 0),
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE operation_reference_binding (
  operation_version_id TEXT NOT NULL REFERENCES operation_version(version_id),
  ordinal INTEGER NOT NULL CHECK(ordinal >= 0),
  reference_kind TEXT NOT NULL CHECK(reference_kind IN ('WEB_LINK','TOOL_REFERENCE')),
  output_url_field_id TEXT REFERENCES contract_field(id),
  origin_record_field_id TEXT REFERENCES contract_field(id),
  screen_profile_object_id TEXT REFERENCES config_object(id),
  display_name TEXT NOT NULL,
  PRIMARY KEY(operation_version_id,ordinal),
  CHECK((reference_kind='WEB_LINK' AND output_url_field_id IS NOT NULL AND screen_profile_object_id IS NULL)
    OR (reference_kind='TOOL_REFERENCE' AND screen_profile_object_id IS NOT NULL AND output_url_field_id IS NULL))
) STRICT;

CREATE TABLE jdbc_operation_version (
  version_id TEXT PRIMARY KEY NOT NULL REFERENCES operation_version(version_id),
  mapper_object_id TEXT NOT NULL REFERENCES config_object(id),
  statement_id TEXT NOT NULL,
  execution_mode TEXT NOT NULL CHECK(execution_mode IN ('SELECT_ONE','OPTIONAL','MANY','EXECUTE','CALL')),
  transaction_mode TEXT NOT NULL CHECK(transaction_mode IN ('READ_ONLY','LOCAL_WRITE','NONE'))
) STRICT;

CREATE TABLE jdbc_out_binding (
  operation_version_id TEXT NOT NULL REFERENCES jdbc_operation_version(version_id),
  out_parameter_name TEXT NOT NULL,
  output_field_id TEXT NOT NULL REFERENCES contract_field(id),
  result_map_name TEXT,
  ordinal INTEGER NOT NULL CHECK(ordinal >= 0),
  PRIMARY KEY(operation_version_id,out_parameter_name), UNIQUE(operation_version_id,ordinal)
) STRICT;

CREATE TABLE http_operation_version (
  version_id TEXT PRIMARY KEY NOT NULL REFERENCES operation_version(version_id),
  method TEXT NOT NULL CHECK(method IN ('GET','POST','PUT','PATCH','DELETE','HEAD','OPTIONS')),
  relative_path_template TEXT NOT NULL,
  request_representation_object_id TEXT REFERENCES config_object(id),
  response_representation_object_id TEXT REFERENCES config_object(id)
) STRICT;

CREATE TABLE http_parameter_binding (
  id TEXT PRIMARY KEY NOT NULL,
  operation_version_id TEXT NOT NULL REFERENCES http_operation_version(version_id),
  location TEXT NOT NULL CHECK(location IN ('PATH','QUERY','HEADER')),
  ordinal INTEGER NOT NULL CHECK(ordinal >= 0),
  wire_name TEXT NOT NULL,
  input_field_id TEXT REFERENCES contract_field(id),
  literal_scalar TEXT,
  required INTEGER NOT NULL CHECK(required IN (0,1)),
  UNIQUE(operation_version_id,location,ordinal),
  CHECK((input_field_id IS NULL) <> (literal_scalar IS NULL)),
  CHECK(location <> 'HEADER' OR literal_scalar IS NULL OR lower(wire_name) NOT IN ('authorization','proxy-authorization','cookie','set-cookie'))
) STRICT;

CREATE TABLE http_expected_status (
  operation_version_id TEXT NOT NULL REFERENCES http_operation_version(version_id),
  status_code INTEGER NOT NULL CHECK(status_code BETWEEN 100 AND 599),
  interpretation TEXT NOT NULL,
  PRIMARY KEY(operation_version_id,status_code)
) STRICT;

CREATE TABLE representation_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'REPRESENTATION' CHECK(kind = 'REPRESENTATION'),
  contract_object_id TEXT NOT NULL REFERENCES config_object(id),
  codec_id TEXT NOT NULL,
  wire_profile TEXT NOT NULL,
  media_type TEXT NOT NULL,
  charset TEXT NOT NULL,
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE json_field_binding (
  representation_version_id TEXT NOT NULL REFERENCES representation_version(version_id),
  field_id TEXT NOT NULL REFERENCES contract_field(id),
  member_name TEXT NOT NULL,
  location TEXT,
  PRIMARY KEY(representation_version_id,field_id)
) STRICT;

CREATE TABLE xml_field_binding (
  representation_version_id TEXT NOT NULL REFERENCES representation_version(version_id),
  field_id TEXT NOT NULL REFERENCES contract_field(id),
  namespace_uri TEXT NOT NULL,
  local_name TEXT NOT NULL,
  node_kind TEXT NOT NULL CHECK(node_kind IN ('ATTRIBUTE','ELEMENT','TEXT')),
  ordinal INTEGER NOT NULL CHECK(ordinal >= 0),
  null_policy TEXT NOT NULL,
  PRIMARY KEY(representation_version_id,field_id)
) STRICT;

CREATE TABLE xapi_field_binding (
  representation_version_id TEXT NOT NULL REFERENCES representation_version(version_id),
  field_id TEXT NOT NULL REFERENCES contract_field(id),
  binding_kind TEXT NOT NULL CHECK(binding_kind IN ('VARIABLE','DATASET','COLUMN')),
  dataset_id TEXT,
  column_name TEXT,
  column_type TEXT,
  column_size INTEGER CHECK(column_size >= 0),
  PRIMARY KEY(representation_version_id,field_id)
) STRICT;

CREATE TABLE converter_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'CONVERTER' CHECK(kind = 'CONVERTER'),
  implementation_id TEXT NOT NULL,
  input_contract_object_id TEXT NOT NULL REFERENCES config_object(id),
  output_contract_object_id TEXT NOT NULL REFERENCES config_object(id),
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE conversion_rule (
  id TEXT PRIMARY KEY NOT NULL,
  converter_version_id TEXT NOT NULL REFERENCES converter_version(version_id),
  source_port TEXT NOT NULL,
  source_field_id TEXT REFERENCES contract_field(id),
  target_field_id TEXT NOT NULL REFERENCES contract_field(id),
  transform_code TEXT NOT NULL,
  ordinal INTEGER NOT NULL CHECK(ordinal >= 0),
  UNIQUE(converter_version_id,target_field_id), UNIQUE(converter_version_id,ordinal)
) STRICT;

CREATE TABLE conversion_argument (
  conversion_rule_id TEXT NOT NULL REFERENCES conversion_rule(id),
  argument_name TEXT NOT NULL,
  value_type TEXT NOT NULL,
  string_value TEXT,
  integer_value INTEGER,
  decimal_value TEXT,
  boolean_value INTEGER CHECK(boolean_value IN (0,1)),
  PRIMARY KEY(conversion_rule_id,argument_name),
  CHECK((value_type = 'STRING' AND string_value IS NOT NULL AND integer_value IS NULL AND decimal_value IS NULL AND boolean_value IS NULL) OR (value_type = 'INTEGER' AND string_value IS NULL AND integer_value IS NOT NULL AND decimal_value IS NULL AND boolean_value IS NULL) OR (value_type = 'DECIMAL' AND string_value IS NULL AND integer_value IS NULL AND decimal_value IS NOT NULL AND boolean_value IS NULL) OR (value_type = 'BOOLEAN' AND string_value IS NULL AND integer_value IS NULL AND decimal_value IS NULL AND boolean_value IS NOT NULL) OR (value_type IN ('OBJECT','ARRAY','NULL','MISSING') AND string_value IS NULL AND integer_value IS NULL AND decimal_value IS NULL AND boolean_value IS NULL))
) STRICT;

CREATE TABLE workflow_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'WORKFLOW' CHECK(kind = 'WORKFLOW'),
  error_mapping_object_id TEXT REFERENCES config_object(id),
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE workflow_stage (
  workflow_version_id TEXT NOT NULL REFERENCES workflow_version(version_id),
  stage_key TEXT NOT NULL CHECK(stage_key IN ('INPUT','CONVERT','OUTPUT')),
  stage_order INTEGER NOT NULL CHECK(stage_order BETWEEN 0 AND 2),
  operation_object_id TEXT REFERENCES config_object(id),
  converter_object_id TEXT REFERENCES config_object(id),
  PRIMARY KEY(workflow_version_id,stage_key), UNIQUE(workflow_version_id,stage_order),
  CHECK((stage_key='CONVERT' AND converter_object_id IS NOT NULL AND operation_object_id IS NULL) OR (stage_key IN ('INPUT','OUTPUT') AND operation_object_id IS NOT NULL AND converter_object_id IS NULL))
) STRICT;

CREATE TABLE workflow_port (
  workflow_version_id TEXT NOT NULL REFERENCES workflow_version(version_id),
  direction TEXT NOT NULL CHECK(direction IN ('REQUEST','RESPONSE','ERROR')),
  representation_object_id TEXT NOT NULL REFERENCES config_object(id),
  status_code INTEGER CHECK(status_code BETWEEN 100 AND 599),
  PRIMARY KEY(workflow_version_id,direction)
) STRICT;

CREATE TABLE workflow_binding (
  workflow_version_id TEXT NOT NULL REFERENCES workflow_version(version_id),
  destination_port TEXT NOT NULL,
  converter_object_id TEXT NOT NULL REFERENCES config_object(id),
  PRIMARY KEY(workflow_version_id,destination_port)
) STRICT;

CREATE TABLE api_route (
  id TEXT PRIMARY KEY NOT NULL,
  method TEXT NOT NULL,
  canonical_path TEXT NOT NULL,
  workflow_object_id TEXT NOT NULL REFERENCES config_object(id),
  enabled INTEGER NOT NULL CHECK(enabled IN (0,1)),
  generation INTEGER NOT NULL CHECK(generation > 0),
  UNIQUE(method,canonical_path)
) STRICT;

CREATE TABLE security_binding_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'SECURITY_BINDING' CHECK(kind = 'SECURITY_BINDING'),
  identity_operation_object_id TEXT NOT NULL REFERENCES config_object(id),
  identity_converter_object_id TEXT NOT NULL REFERENCES config_object(id),
  authorization_operation_object_id TEXT NOT NULL REFERENCES config_object(id),
  authorization_converter_object_id TEXT NOT NULL REFERENCES config_object(id),
  roles_operation_object_id TEXT REFERENCES config_object(id),
  roles_converter_object_id TEXT REFERENCES config_object(id),
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE protected_action (
  id TEXT PRIMARY KEY NOT NULL,
  action_key TEXT NOT NULL UNIQUE,
  target_kind TEXT NOT NULL CHECK(target_kind IN ('SERVICE','PATIENT','ENCOUNTER','DOCUMENT')),
  effect_kind TEXT NOT NULL CHECK(effect_kind IN ('READ_ONLY','WRITE','UNKNOWN')),
  semantic_version INTEGER NOT NULL CHECK(semantic_version > 0),
  UNIQUE(id,semantic_version), UNIQUE(id,semantic_version,target_kind)
) STRICT;

CREATE TABLE role_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'ROLE' CHECK(kind = 'ROLE'),
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE role_action (
  role_version_id TEXT NOT NULL REFERENCES role_version(version_id),
  action_id TEXT NOT NULL REFERENCES protected_action(id),
  action_semantic_version INTEGER NOT NULL,
  PRIMARY KEY(role_version_id,action_id),
  FOREIGN KEY(action_id,action_semantic_version) REFERENCES protected_action(id,semantic_version)
) STRICT;

CREATE TABLE external_role_mapping (
  security_binding_version_id TEXT NOT NULL REFERENCES security_binding_version(version_id),
  external_role_code TEXT NOT NULL,
  role_object_id TEXT NOT NULL REFERENCES config_object(id),
  PRIMARY KEY(security_binding_version_id,external_role_code,role_object_id)
) STRICT;

CREATE TABLE target_policy_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'TARGET_POLICY' CHECK(kind = 'TARGET_POLICY'),
  target_kind TEXT NOT NULL CHECK(target_kind IN ('SERVICE','PATIENT','ENCOUNTER','DOCUMENT')),
  canonical_organization TEXT NOT NULL,
  identifier_system TEXT NOT NULL,
  resolver_operation_object_id TEXT REFERENCES config_object(id),
  resolver_converter_object_id TEXT REFERENCES config_object(id),
  require_parent_patient INTEGER NOT NULL CHECK(require_parent_patient IN (0,1)),
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE target_argument_binding (
  target_policy_version_id TEXT NOT NULL REFERENCES target_policy_version(version_id),
  source_port TEXT NOT NULL CHECK(source_port IN ('REQUEST','CONTEXT','STORED_RESULT','REFERENCE','SOURCE_OUTPUT','TARGET_OUTPUT')),
  contract_field_id TEXT REFERENCES contract_field(id),
  target_part TEXT NOT NULL CHECK(target_part IN ('PATIENT','ENCOUNTER','DOCUMENT')),
  ordinal INTEGER NOT NULL CHECK(ordinal >= 0),
  PRIMARY KEY(target_policy_version_id,ordinal)
) STRICT;

CREATE TABLE workflow_security_binding (
  workflow_version_id TEXT NOT NULL REFERENCES workflow_version(version_id),
  stage_key TEXT NOT NULL DEFAULT 'INPUT',
  security_binding_object_id TEXT NOT NULL REFERENCES config_object(id),
  required_action_id TEXT NOT NULL REFERENCES protected_action(id),
  target_policy_object_id TEXT REFERENCES config_object(id),
  PRIMARY KEY(workflow_version_id,stage_key,required_action_id)
) STRICT;

CREATE TABLE principal_ref (
  id TEXT PRIMARY KEY NOT NULL,
  identity_provider_object_id TEXT NOT NULL REFERENCES config_object(id),
  subject_key TEXT NOT NULL,
  blocked INTEGER NOT NULL DEFAULT FALSE CHECK(blocked IN (0,1)),
  security_generation INTEGER NOT NULL DEFAULT 1 CHECK(security_generation > 0),
  created_at INTEGER NOT NULL,
  UNIQUE(identity_provider_object_id,subject_key)
) STRICT;

CREATE TABLE oauth_resource (
  id TEXT PRIMARY KEY NOT NULL,
  resource_uri TEXT NOT NULL UNIQUE,
  resource_kind TEXT NOT NULL CHECK(resource_kind IN ('MCP','REST')),
  public_name TEXT NOT NULL,
  active INTEGER NOT NULL CHECK(active IN (0,1))
) STRICT;

CREATE TABLE oauth_scope (
  id TEXT PRIMARY KEY NOT NULL,
  scope_name TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL
) STRICT;

CREATE TABLE oauth_scope_action (
  scope_id TEXT NOT NULL REFERENCES oauth_scope(id),
  action_id TEXT NOT NULL REFERENCES protected_action(id),
  action_semantic_version INTEGER NOT NULL,
  PRIMARY KEY(scope_id,action_id),
  FOREIGN KEY(action_id,action_semantic_version) REFERENCES protected_action(id,semantic_version)
) STRICT;

CREATE TABLE oauth_client_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'OAUTH_CLIENT' CHECK(kind = 'OAUTH_CLIENT'),
  client_type TEXT NOT NULL CHECK(client_type IN ('PUBLIC_NATIVE','CONFIDENTIAL_WEB')),
  token_endpoint_auth_method TEXT NOT NULL CHECK(token_endpoint_auth_method IN ('none','client_secret_basic')),
  display_name TEXT NOT NULL,
  require_pkce_s256 INTEGER NOT NULL CHECK(require_pkce_s256) CHECK(require_pkce_s256 IN (0,1)),
  refresh_enabled INTEGER NOT NULL CHECK(refresh_enabled IN (0,1)),
  CHECK((client_type='PUBLIC_NATIVE' AND token_endpoint_auth_method='none') OR (client_type='CONFIDENTIAL_WEB' AND token_endpoint_auth_method='client_secret_basic')),
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE oauth_client_redirect (
  client_version_id TEXT NOT NULL REFERENCES oauth_client_version(version_id),
  redirect_uri TEXT NOT NULL,
  native_loopback_port_policy INTEGER NOT NULL CHECK(native_loopback_port_policy IN (0,1)),
  ordinal INTEGER NOT NULL CHECK(ordinal >= 0),
  PRIMARY KEY(client_version_id,redirect_uri), UNIQUE(client_version_id,ordinal)
) STRICT;

CREATE TABLE oauth_client_scope (
  client_version_id TEXT NOT NULL REFERENCES oauth_client_version(version_id),
  scope_id TEXT NOT NULL REFERENCES oauth_scope(id),
  PRIMARY KEY(client_version_id,scope_id)
) STRICT;

CREATE TABLE oauth_client_resource (
  client_version_id TEXT NOT NULL REFERENCES oauth_client_version(version_id),
  resource_id TEXT NOT NULL REFERENCES oauth_resource(id),
  PRIMARY KEY(client_version_id,resource_id)
) STRICT;

CREATE TABLE oauth_client_action (
  client_version_id TEXT NOT NULL REFERENCES oauth_client_version(version_id),
  action_id TEXT NOT NULL REFERENCES protected_action(id),
  action_semantic_version INTEGER NOT NULL,
  PRIMARY KEY(client_version_id,action_id),
  FOREIGN KEY(action_id,action_semantic_version) REFERENCES protected_action(id,semantic_version)
) STRICT;

CREATE TABLE oauth_client_secret (
  id TEXT PRIMARY KEY NOT NULL,
  client_object_id TEXT NOT NULL REFERENCES config_object(id),
  secret_digest BLOB NOT NULL,
  kdf_id TEXT NOT NULL CHECK(kdf_id='PBKDF2_SHA256'),
  salt BLOB NOT NULL,
  iterations INTEGER NOT NULL CHECK(iterations >= 600000),
  key_length INTEGER NOT NULL CHECK(key_length >= 256),
  created_at INTEGER NOT NULL,
  expires_at INTEGER,
  revoked_at INTEGER,
  CHECK(expires_at IS NULL OR expires_at > created_at)
) STRICT;

CREATE TABLE auth_session (
  id TEXT PRIMARY KEY NOT NULL,
  session_digest TEXT NOT NULL UNIQUE,
  principal_id TEXT REFERENCES principal_ref(id),
  authenticated_at INTEGER NOT NULL,
  idle_expires_at INTEGER NOT NULL CHECK(idle_expires_at > authenticated_at),
  absolute_expires_at INTEGER NOT NULL CHECK(absolute_expires_at >= idle_expires_at),
  revoked_at INTEGER,
  session_generation INTEGER NOT NULL CHECK(session_generation > 0),
  csrf_digest TEXT NOT NULL,
  session_kind TEXT NOT NULL CHECK(session_kind IN ('USER','MANAGEMENT','PREAUTH')),
  CHECK(session_kind='PREAUTH' OR principal_id IS NOT NULL)
) STRICT;

CREATE TABLE oauth_authorization_request (
  id TEXT PRIMARY KEY NOT NULL,
  client_object_id TEXT NOT NULL REFERENCES config_object(id),
  observed_client_version_id TEXT NOT NULL REFERENCES oauth_client_version(version_id),
  observed_client_generation INTEGER NOT NULL,
  observed_principal_generation INTEGER,
  resource_id TEXT NOT NULL REFERENCES oauth_resource(id),
  redirect_uri TEXT NOT NULL,
  pkce_challenge TEXT NOT NULL,
  pkce_method TEXT NOT NULL CHECK(pkce_method='S256'),
  opaque_state_cipher BLOB,
  state_key_id TEXT,
  state_nonce BLOB,
  state_tag BLOB,
  auth_session_id TEXT REFERENCES auth_session(id),
  request_binding_digest TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL CHECK(expires_at > created_at),
  status TEXT NOT NULL CHECK(status IN ('OPEN','COMPLETED','REJECTED','EXPIRED')),
  UNIQUE(id,client_object_id,resource_id,redirect_uri),
  FOREIGN KEY(client_object_id,observed_client_version_id) REFERENCES config_version(object_id,id),
  CHECK((opaque_state_cipher IS NULL AND state_key_id IS NULL AND state_nonce IS NULL AND state_tag IS NULL) OR (opaque_state_cipher IS NOT NULL AND state_key_id IS NOT NULL AND state_nonce IS NOT NULL AND state_tag IS NOT NULL AND length(state_nonce)=12 AND length(state_tag)=16))
) STRICT;

CREATE TABLE oauth_request_scope (
  request_id TEXT NOT NULL REFERENCES oauth_authorization_request(id),
  scope_id TEXT NOT NULL REFERENCES oauth_scope(id),
  PRIMARY KEY(request_id,scope_id)
) STRICT;

CREATE TABLE oauth_request_rule (
  id TEXT PRIMARY KEY NOT NULL,
  request_id TEXT NOT NULL REFERENCES oauth_authorization_request(id),
  action_id TEXT NOT NULL REFERENCES protected_action(id),
  action_semantic_version INTEGER NOT NULL,
  target_kind TEXT NOT NULL CHECK(target_kind IN ('SERVICE','PATIENT','ENCOUNTER','DOCUMENT')),
  organization TEXT,
  identifier_system TEXT,
  patient_identifier TEXT,
  encounter_identifier TEXT,
  document_identifier TEXT,
  FOREIGN KEY(action_id,action_semantic_version,target_kind) REFERENCES protected_action(id,semantic_version,target_kind),
  CHECK((target_kind='SERVICE' AND organization IS NULL AND identifier_system IS NULL AND patient_identifier IS NULL AND encounter_identifier IS NULL AND document_identifier IS NULL) OR
  (target_kind IN ('PATIENT','ENCOUNTER','DOCUMENT') AND length(organization)>0 AND length(identifier_system)>0 AND length(patient_identifier)>0 AND organization IS NOT NULL AND identifier_system IS NOT NULL AND patient_identifier IS NOT NULL AND
  ((target_kind='PATIENT' AND encounter_identifier IS NULL AND document_identifier IS NULL) OR (target_kind='ENCOUNTER' AND encounter_identifier IS NOT NULL AND length(encounter_identifier)>0 AND document_identifier IS NULL) OR (target_kind='DOCUMENT' AND document_identifier IS NOT NULL AND length(document_identifier)>0))))
) STRICT;

CREATE TABLE oauth_grant (
  id TEXT PRIMARY KEY NOT NULL,
  principal_id TEXT NOT NULL REFERENCES principal_ref(id),
  client_object_id TEXT NOT NULL REFERENCES config_object(id),
  resource_id TEXT NOT NULL REFERENCES oauth_resource(id),
  purpose_code TEXT NOT NULL,
  authenticated_at INTEGER NOT NULL,
  issued_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL CHECK(expires_at > issued_at),
  revoked_at INTEGER,
  revoke_reason TEXT,
  local_security_generation INTEGER NOT NULL CHECK(local_security_generation > 0),
  UNIQUE(id,client_object_id,resource_id), UNIQUE(id,client_object_id,principal_id,resource_id)
) STRICT;

CREATE TABLE oauth_grant_rule (
  id TEXT PRIMARY KEY NOT NULL,
  grant_id TEXT NOT NULL REFERENCES oauth_grant(id),
  action_id TEXT NOT NULL REFERENCES protected_action(id),
  action_semantic_version INTEGER NOT NULL,
  target_kind TEXT NOT NULL CHECK(target_kind IN ('SERVICE','PATIENT','ENCOUNTER','DOCUMENT')),
  organization TEXT,
  identifier_system TEXT,
  patient_identifier TEXT,
  encounter_identifier TEXT,
  document_identifier TEXT,
  issued_authority_decision_id TEXT,
  FOREIGN KEY(action_id,action_semantic_version,target_kind) REFERENCES protected_action(id,semantic_version,target_kind),
  CHECK((target_kind='SERVICE' AND organization IS NULL AND identifier_system IS NULL AND patient_identifier IS NULL AND encounter_identifier IS NULL AND document_identifier IS NULL) OR
  (target_kind IN ('PATIENT','ENCOUNTER','DOCUMENT') AND length(organization)>0 AND length(identifier_system)>0 AND length(patient_identifier)>0 AND organization IS NOT NULL AND identifier_system IS NOT NULL AND patient_identifier IS NOT NULL AND
  ((target_kind='PATIENT' AND encounter_identifier IS NULL AND document_identifier IS NULL) OR (target_kind='ENCOUNTER' AND encounter_identifier IS NOT NULL AND length(encounter_identifier)>0 AND document_identifier IS NULL) OR (target_kind='DOCUMENT' AND document_identifier IS NOT NULL AND length(document_identifier)>0))))
) STRICT;

CREATE UNIQUE INDEX grant_rule_identity ON oauth_grant_rule (grant_id,action_id,target_kind,COALESCE(organization,''),COALESCE(identifier_system,''),COALESCE(patient_identifier,''),COALESCE(encounter_identifier,''),COALESCE(document_identifier,''));

CREATE TABLE oauth_grant_scope (
  grant_id TEXT NOT NULL REFERENCES oauth_grant(id),
  scope_id TEXT NOT NULL REFERENCES oauth_scope(id),
  PRIMARY KEY(grant_id,scope_id)
) STRICT;

CREATE TABLE oauth_authorization_code (
  id TEXT PRIMARY KEY NOT NULL,
  code_digest TEXT NOT NULL UNIQUE,
  request_id TEXT NOT NULL UNIQUE,
  grant_id TEXT NOT NULL,
  client_object_id TEXT NOT NULL,
  resource_id TEXT NOT NULL,
  redirect_uri TEXT NOT NULL,
  pkce_challenge TEXT NOT NULL,
  pkce_method TEXT NOT NULL CHECK(pkce_method='S256'),
  issued_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL CHECK(expires_at > issued_at),
  consumed_at INTEGER,
  revoked_at INTEGER,
  FOREIGN KEY(request_id,client_object_id,resource_id,redirect_uri) REFERENCES oauth_authorization_request(id,client_object_id,resource_id,redirect_uri),
  FOREIGN KEY(grant_id,client_object_id,resource_id) REFERENCES oauth_grant(id,client_object_id,resource_id)
) STRICT;

CREATE TABLE oauth_refresh_family (
  id TEXT PRIMARY KEY NOT NULL,
  grant_id TEXT NOT NULL REFERENCES oauth_grant(id),
  current_token_id TEXT,
  created_at INTEGER NOT NULL,
  absolute_expires_at INTEGER NOT NULL CHECK(absolute_expires_at > created_at),
  revoked_at INTEGER,
  UNIQUE(id,grant_id),
  FOREIGN KEY(id,current_token_id) REFERENCES oauth_refresh_token(family_id,id)
) STRICT;

CREATE TABLE oauth_refresh_token (
  id TEXT PRIMARY KEY NOT NULL,
  family_id TEXT NOT NULL REFERENCES oauth_refresh_family(id),
  token_digest TEXT NOT NULL UNIQUE,
  predecessor_id TEXT UNIQUE,
  issued_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL CHECK(expires_at > issued_at),
  consumed_at INTEGER,
  revoked_at INTEGER,
  UNIQUE(family_id,id),
  FOREIGN KEY(family_id,predecessor_id) REFERENCES oauth_refresh_token(family_id,id),
  CHECK(predecessor_id IS NULL OR predecessor_id <> id)
) STRICT;

CREATE TABLE oauth_access_token (
  id TEXT PRIMARY KEY NOT NULL,
  token_digest TEXT NOT NULL UNIQUE,
  grant_id TEXT NOT NULL,
  family_id TEXT,
  client_object_id TEXT NOT NULL,
  principal_id TEXT NOT NULL,
  resource_id TEXT NOT NULL,
  issued_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL CHECK(expires_at > issued_at),
  revoked_at INTEGER,
  FOREIGN KEY(grant_id,client_object_id,principal_id,resource_id) REFERENCES oauth_grant(id,client_object_id,principal_id,resource_id),
  FOREIGN KEY(family_id,grant_id) REFERENCES oauth_refresh_family(id,grant_id)
) STRICT;

CREATE TABLE oauth_token_scope (
  access_token_id TEXT NOT NULL REFERENCES oauth_access_token(id),
  scope_id TEXT NOT NULL REFERENCES oauth_scope(id),
  PRIMARY KEY(access_token_id,scope_id)
) STRICT;

CREATE TABLE oauth_refresh_scope (
  refresh_token_id TEXT NOT NULL REFERENCES oauth_refresh_token(id),
  scope_id TEXT NOT NULL REFERENCES oauth_scope(id),
  PRIMARY KEY(refresh_token_id,scope_id)
) STRICT;

CREATE TABLE oauth_policy_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'OAUTH_POLICY' CHECK(kind = 'OAUTH_POLICY'),
  code_lifetime_ms INTEGER NOT NULL CHECK(code_lifetime_ms BETWEEN 1000 AND 600000),
  access_lifetime_ms INTEGER NOT NULL CHECK(access_lifetime_ms BETWEEN 1000 AND 86400000),
  refresh_lifetime_ms INTEGER NOT NULL CHECK(refresh_lifetime_ms BETWEEN 1000 AND 7776000000),
  session_idle_lifetime_ms INTEGER NOT NULL CHECK(session_idle_lifetime_ms BETWEEN 1000 AND 86400000),
  session_absolute_lifetime_ms INTEGER NOT NULL CHECK(session_absolute_lifetime_ms BETWEEN session_idle_lifetime_ms AND 604800000),
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE mcp_tool_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'MCP_TOOL' CHECK(kind = 'MCP_TOOL'),
  public_name TEXT NOT NULL,
  description TEXT NOT NULL,
  workflow_object_id TEXT NOT NULL REFERENCES config_object(id),
  public_input_contract_version_id TEXT NOT NULL REFERENCES contract_version(version_id),
  public_output_contract_version_id TEXT NOT NULL REFERENCES contract_version(version_id),
  security_binding_object_id TEXT NOT NULL REFERENCES config_object(id),
  target_policy_object_id TEXT REFERENCES config_object(id),
  input_mapping_object_id TEXT REFERENCES config_object(id),
  output_mapping_object_id TEXT REFERENCES config_object(id),
  effect_kind TEXT NOT NULL CHECK(effect_kind IN ('READ_ONLY','WRITE','UNKNOWN')),
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE mcp_tool_scope (
  tool_version_id TEXT NOT NULL REFERENCES mcp_tool_version(version_id),
  scope_id TEXT NOT NULL REFERENCES oauth_scope(id),
  PRIMARY KEY(tool_version_id,scope_id)
) STRICT;

CREATE TABLE mcp_tool_action (
  tool_version_id TEXT NOT NULL REFERENCES mcp_tool_version(version_id),
  action_id TEXT NOT NULL REFERENCES protected_action(id),
  PRIMARY KEY(tool_version_id,action_id)
) STRICT;

CREATE TABLE execution (
  id TEXT PRIMARY KEY NOT NULL,
  trace_id TEXT NOT NULL,
  workflow_version_id TEXT REFERENCES workflow_version(version_id),
  actor_subject_id TEXT NOT NULL,
  caller_service_id TEXT NOT NULL,
  started_at INTEGER NOT NULL,
  finished_at INTEGER,
  business_outcome TEXT NOT NULL,
  response_outcome TEXT NOT NULL,
  error_code TEXT,
  principal_id TEXT REFERENCES principal_ref(id),
  client_object_id TEXT REFERENCES config_object(id),
  observed_client_version_id TEXT REFERENCES config_version(id),
  public_grant_id TEXT,
  public_token_record_id TEXT,
  transport TEXT CHECK(transport IN ('REST','XAPI','MCP','CONSOLE','INTERNAL')),
  mcp_tool_version_id TEXT REFERENCES mcp_tool_version(version_id),
  required_action_id TEXT REFERENCES protected_action(id)
) STRICT;

CREATE TABLE execution_dependency (
  execution_id TEXT NOT NULL REFERENCES execution(id),
  role_or_path TEXT NOT NULL,
  config_version_id TEXT NOT NULL REFERENCES config_version(id),
  PRIMARY KEY(execution_id,role_or_path)
) STRICT;

CREATE TABLE execution_stage (
  id TEXT PRIMARY KEY NOT NULL,
  execution_id TEXT NOT NULL REFERENCES execution(id),
  stage_key TEXT NOT NULL,
  operation_version_id TEXT REFERENCES operation_version(version_id),
  started_at INTEGER NOT NULL,
  finished_at INTEGER,
  effect_kind TEXT NOT NULL CHECK(effect_kind IN ('READ_ONLY','WRITE','UNKNOWN')),
  business_outcome TEXT NOT NULL,
  error_code TEXT,
  UNIQUE(execution_id,id)
) STRICT;

CREATE TABLE audit_event (
  id TEXT PRIMARY KEY NOT NULL,
  execution_id TEXT REFERENCES execution(id),
  execution_stage_id TEXT,
  event_type TEXT NOT NULL,
  occurred_at INTEGER NOT NULL,
  actor_subject_id TEXT NOT NULL,
  caller_service_id TEXT NOT NULL,
  authority_decision_id TEXT,
  outcome TEXT NOT NULL,
  reason_code TEXT,
  principal_id TEXT REFERENCES principal_ref(id),
  client_object_id TEXT REFERENCES config_object(id),
  observed_client_version_id TEXT REFERENCES config_version(id),
  public_grant_id TEXT,
  public_token_record_id TEXT,
  transport TEXT CHECK(transport IN ('REST','XAPI','MCP','CONSOLE','INTERNAL')),
  mcp_tool_version_id TEXT REFERENCES mcp_tool_version(version_id),
  required_action_id TEXT REFERENCES protected_action(id),
  FOREIGN KEY(execution_id,execution_stage_id) REFERENCES execution_stage(execution_id,id),
  CHECK(execution_stage_id IS NULL OR execution_id IS NOT NULL)
) STRICT;

CREATE TABLE audit_parameter (
  id TEXT PRIMARY KEY NOT NULL,
  audit_event_id TEXT NOT NULL REFERENCES audit_event(id),
  parent_parameter_id TEXT,
  parameter_name TEXT,
  ordinal INTEGER NOT NULL CHECK(ordinal >= 0),
  port TEXT NOT NULL,
  field_id TEXT REFERENCES contract_field(id),
  value_type TEXT NOT NULL,
  string_value TEXT,
  integer_value INTEGER,
  decimal_text TEXT,
  boolean_value INTEGER CHECK(boolean_value IN (0,1)),
  exclusion_reason TEXT CHECK(exclusion_reason IN ('OMIT_RECOVERABLE','OMIT_SECRET')),
  UNIQUE(audit_event_id,id),
  FOREIGN KEY(audit_event_id,parent_parameter_id) REFERENCES audit_parameter(audit_event_id,id),
  CHECK((value_type = 'STRING' AND string_value IS NOT NULL AND integer_value IS NULL AND decimal_text IS NULL AND boolean_value IS NULL) OR (value_type = 'INTEGER' AND string_value IS NULL AND integer_value IS NOT NULL AND decimal_text IS NULL AND boolean_value IS NULL) OR (value_type = 'DECIMAL' AND string_value IS NULL AND integer_value IS NULL AND decimal_text IS NOT NULL AND boolean_value IS NULL) OR (value_type = 'BOOLEAN' AND string_value IS NULL AND integer_value IS NULL AND decimal_text IS NULL AND boolean_value IS NOT NULL) OR (value_type IN ('OBJECT','ARRAY','NULL','MISSING','EXCLUDED') AND string_value IS NULL AND integer_value IS NULL AND decimal_text IS NULL AND boolean_value IS NULL)),
  CHECK((value_type='EXCLUDED' AND exclusion_reason IS NOT NULL) OR (value_type<>'EXCLUDED' AND exclusion_reason IS NULL))
) STRICT;

CREATE TABLE authorization_check (
  id TEXT PRIMARY KEY NOT NULL,
  execution_id TEXT REFERENCES execution(id),
  action_id TEXT NOT NULL REFERENCES protected_action(id),
  target_kind TEXT NOT NULL CHECK(target_kind IN ('SERVICE','PATIENT','ENCOUNTER','DOCUMENT')),
  organization TEXT,
  identifier_system TEXT,
  patient_identifier TEXT,
  encounter_identifier TEXT,
  document_identifier TEXT,
  outcome TEXT NOT NULL CHECK(outcome IN ('ALLOW','DENY','PENDING','UNAVAILABLE')),
  authority_decision_id TEXT,
  checked_at INTEGER NOT NULL,
  reason_code TEXT,
  CHECK((target_kind='SERVICE' AND organization IS NULL AND identifier_system IS NULL AND patient_identifier IS NULL AND encounter_identifier IS NULL AND document_identifier IS NULL) OR
  (target_kind IN ('PATIENT','ENCOUNTER','DOCUMENT') AND length(organization)>0 AND length(identifier_system)>0 AND length(patient_identifier)>0 AND organization IS NOT NULL AND identifier_system IS NOT NULL AND patient_identifier IS NOT NULL AND
  ((target_kind='PATIENT' AND encounter_identifier IS NULL AND document_identifier IS NULL) OR (target_kind='ENCOUNTER' AND encounter_identifier IS NOT NULL AND length(encounter_identifier)>0 AND document_identifier IS NULL) OR (target_kind='DOCUMENT' AND document_identifier IS NOT NULL AND length(document_identifier)>0))))
) STRICT;

CREATE TABLE execution_target (
  execution_id TEXT NOT NULL REFERENCES execution(id),
  stage_key TEXT NOT NULL,
  action_id TEXT NOT NULL REFERENCES protected_action(id),
  target_kind TEXT NOT NULL CHECK(target_kind IN ('SERVICE','PATIENT','ENCOUNTER','DOCUMENT')),
  organization TEXT,
  identifier_system TEXT,
  patient_identifier TEXT,
  encounter_identifier TEXT,
  document_identifier TEXT,
  decision_id TEXT,
  outcome TEXT NOT NULL CHECK(outcome IN ('ALLOW','DENY','PENDING','UNAVAILABLE')),
  CHECK((target_kind='SERVICE' AND organization IS NULL AND identifier_system IS NULL AND patient_identifier IS NULL AND encounter_identifier IS NULL AND document_identifier IS NULL) OR
  (target_kind IN ('PATIENT','ENCOUNTER','DOCUMENT') AND length(organization)>0 AND length(identifier_system)>0 AND length(patient_identifier)>0 AND organization IS NOT NULL AND identifier_system IS NOT NULL AND patient_identifier IS NOT NULL AND
  ((target_kind='PATIENT' AND encounter_identifier IS NULL AND document_identifier IS NULL) OR (target_kind='ENCOUNTER' AND encounter_identifier IS NOT NULL AND length(encounter_identifier)>0 AND document_identifier IS NULL) OR (target_kind='DOCUMENT' AND document_identifier IS NOT NULL AND length(document_identifier)>0))))
) STRICT;

CREATE UNIQUE INDEX execution_target_identity ON execution_target (execution_id,stage_key,action_id,target_kind,COALESCE(organization,''),COALESCE(identifier_system,''),COALESCE(patient_identifier,''),COALESCE(encounter_identifier,''),COALESCE(document_identifier,''));

CREATE TABLE generated_result (
  id TEXT PRIMARY KEY NOT NULL,
  owner_scope TEXT NOT NULL,
  caller_service_id TEXT NOT NULL,
  owner_principal_id TEXT NOT NULL REFERENCES principal_ref(id),
  owner_client_object_id TEXT NOT NULL REFERENCES config_object(id),
  public_grant_id TEXT,
  current_revision_id TEXT,
  revision_counter INTEGER NOT NULL DEFAULT 0 CHECK(revision_counter >= 0),
  FOREIGN KEY(id,current_revision_id) REFERENCES generated_result_revision(result_id,id)
) STRICT;

CREATE TABLE generated_result_revision (
  id TEXT PRIMARY KEY NOT NULL,
  result_id TEXT NOT NULL REFERENCES generated_result(id),
  revision INTEGER NOT NULL CHECK(revision > 0),
  output_contract_version_id TEXT NOT NULL REFERENCES contract_version(version_id),
  external_generation_id TEXT,
  submitted_model TEXT,
  source_execution_id TEXT REFERENCES execution(id),
  created_at INTEGER NOT NULL,
  UNIQUE(result_id,revision), UNIQUE(result_id,id)
) STRICT;

CREATE TABLE result_value (
  id TEXT PRIMARY KEY NOT NULL,
  result_revision_id TEXT NOT NULL REFERENCES generated_result_revision(id),
  parent_value_id TEXT,
  contract_field_id TEXT NOT NULL REFERENCES contract_field(id),
  node_kind TEXT NOT NULL CHECK(node_kind IN ('OBJECT','ARRAY','SCALAR','TABLE','COLUMN')),
  ordinal INTEGER NOT NULL CHECK(ordinal >= 0),
  value_type TEXT NOT NULL,
  text_value TEXT,
  integer_value INTEGER,
  decimal_text TEXT,
  boolean_value INTEGER CHECK(boolean_value IN (0,1)),
  UNIQUE(result_revision_id,id),
  FOREIGN KEY(result_revision_id,parent_value_id) REFERENCES result_value(result_revision_id,id),
  CHECK((value_type = 'STRING' AND text_value IS NOT NULL AND integer_value IS NULL AND decimal_text IS NULL AND boolean_value IS NULL) OR (value_type = 'INTEGER' AND text_value IS NULL AND integer_value IS NOT NULL AND decimal_text IS NULL AND boolean_value IS NULL) OR (value_type = 'DECIMAL' AND text_value IS NULL AND integer_value IS NULL AND decimal_text IS NOT NULL AND boolean_value IS NULL) OR (value_type = 'BOOLEAN' AND text_value IS NULL AND integer_value IS NULL AND decimal_text IS NULL AND boolean_value IS NOT NULL) OR (value_type IN ('OBJECT','ARRAY','NULL','MISSING') AND text_value IS NULL AND integer_value IS NULL AND decimal_text IS NULL AND boolean_value IS NULL)),
  CHECK(value_type IN ('NULL','MISSING') OR (node_kind IN ('OBJECT','TABLE') AND value_type='OBJECT') OR (node_kind='ARRAY' AND value_type='ARRAY') OR (node_kind IN ('SCALAR','COLUMN') AND value_type IN ('STRING','INTEGER','DECIMAL','BOOLEAN')))
) STRICT;

CREATE UNIQUE INDEX result_value_order ON result_value (result_revision_id,COALESCE(parent_value_id,''),ordinal);

CREATE TABLE source_reference (
  id TEXT PRIMARY KEY NOT NULL,
  reference_kind TEXT NOT NULL CHECK(reference_kind IN ('WEB_LINK','TOOL_REFERENCE')),
  owner_scope TEXT NOT NULL,
  owner_principal_id TEXT NOT NULL REFERENCES principal_ref(id),
  owner_client_object_id TEXT NOT NULL REFERENCES config_object(id),
  public_grant_id TEXT,
  source_execution_id TEXT REFERENCES execution(id),
  created_at INTEGER NOT NULL,
  UNIQUE(id,reference_kind)
) STRICT;

CREATE TABLE web_reference (
  reference_id TEXT PRIMARY KEY NOT NULL,
  reference_kind TEXT NOT NULL DEFAULT 'WEB_LINK' CHECK(reference_kind='WEB_LINK'),
  original_url TEXT NOT NULL,
  display_name TEXT NOT NULL,
  origin_record_id TEXT,
  FOREIGN KEY(reference_id,reference_kind) REFERENCES source_reference(id,reference_kind)
) STRICT;

CREATE TABLE screen_profile_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'SCREEN_PROFILE' CHECK(kind = 'SCREEN_PROFILE'),
  adapter_id TEXT NOT NULL,
  screen_code TEXT NOT NULL,
  allowed_launch_profile TEXT NOT NULL,
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE screen_parameter_binding (
  screen_profile_version_id TEXT NOT NULL REFERENCES screen_profile_version(version_id),
  tool_parameter_name TEXT NOT NULL,
  screen_parameter_name TEXT NOT NULL,
  value_type TEXT NOT NULL,
  ordinal INTEGER NOT NULL CHECK(ordinal >= 0),
  PRIMARY KEY(screen_profile_version_id,tool_parameter_name), UNIQUE(screen_profile_version_id,ordinal)
) STRICT;

CREATE TABLE tool_reference (
  reference_id TEXT PRIMARY KEY NOT NULL,
  reference_kind TEXT NOT NULL DEFAULT 'TOOL_REFERENCE' CHECK(reference_kind='TOOL_REFERENCE'),
  operation_object_id TEXT NOT NULL REFERENCES config_object(id),
  observed_operation_version_id TEXT NOT NULL REFERENCES operation_version(version_id),
  observed_datasource_version_id TEXT NOT NULL REFERENCES datasource_version(version_id),
  screen_profile_object_id TEXT NOT NULL REFERENCES config_object(id),
  observed_screen_profile_version_id TEXT REFERENCES screen_profile_version(version_id),
  origin_record_id TEXT,
  FOREIGN KEY(reference_id,reference_kind) REFERENCES source_reference(id,reference_kind),
  FOREIGN KEY(operation_object_id,observed_operation_version_id) REFERENCES config_version(object_id,id),
  FOREIGN KEY(screen_profile_object_id,observed_screen_profile_version_id) REFERENCES config_version(object_id,id)
) STRICT;

CREATE TABLE reference_parameter (
  id TEXT PRIMARY KEY NOT NULL,
  reference_id TEXT NOT NULL REFERENCES source_reference(id),
  parent_parameter_id TEXT,
  parameter_name TEXT,
  ordinal INTEGER NOT NULL CHECK(ordinal >= 0),
  port TEXT NOT NULL,
  field_id TEXT REFERENCES contract_field(id),
  value_type TEXT NOT NULL,
  string_value TEXT,
  integer_value INTEGER,
  decimal_text TEXT,
  boolean_value INTEGER CHECK(boolean_value IN (0,1)),
  exclusion_reason TEXT CHECK(exclusion_reason IN ('OMIT_RECOVERABLE','OMIT_SECRET')),
  UNIQUE(reference_id,id),
  FOREIGN KEY(reference_id,parent_parameter_id) REFERENCES reference_parameter(reference_id,id),
  CHECK((value_type = 'STRING' AND string_value IS NOT NULL AND integer_value IS NULL AND decimal_text IS NULL AND boolean_value IS NULL) OR (value_type = 'INTEGER' AND string_value IS NULL AND integer_value IS NOT NULL AND decimal_text IS NULL AND boolean_value IS NULL) OR (value_type = 'DECIMAL' AND string_value IS NULL AND integer_value IS NULL AND decimal_text IS NOT NULL AND boolean_value IS NULL) OR (value_type = 'BOOLEAN' AND string_value IS NULL AND integer_value IS NULL AND decimal_text IS NULL AND boolean_value IS NOT NULL) OR (value_type IN ('OBJECT','ARRAY','NULL','MISSING','EXCLUDED') AND string_value IS NULL AND integer_value IS NULL AND decimal_text IS NULL AND boolean_value IS NULL)),
  CHECK((value_type='EXCLUDED' AND exclusion_reason IS NOT NULL) OR (value_type<>'EXCLUDED' AND exclusion_reason IS NULL))
) STRICT;

CREATE TABLE result_reference (
  result_revision_id TEXT NOT NULL REFERENCES generated_result_revision(id),
  result_value_id TEXT,
  reference_id TEXT NOT NULL REFERENCES source_reference(id),
  ordinal INTEGER NOT NULL CHECK(ordinal >= 0),
  PRIMARY KEY(result_revision_id,ordinal),
  FOREIGN KEY(result_revision_id,result_value_id) REFERENCES result_value(result_revision_id,id)
) STRICT;

CREATE TABLE result_target (
  result_id TEXT NOT NULL REFERENCES generated_result(id),
  action_id TEXT NOT NULL REFERENCES protected_action(id),
  target_kind TEXT NOT NULL CHECK(target_kind IN ('SERVICE','PATIENT','ENCOUNTER','DOCUMENT')),
  organization TEXT,
  identifier_system TEXT,
  patient_identifier TEXT,
  encounter_identifier TEXT,
  document_identifier TEXT,
  CHECK((target_kind='SERVICE' AND organization IS NULL AND identifier_system IS NULL AND patient_identifier IS NULL AND encounter_identifier IS NULL AND document_identifier IS NULL) OR
  (target_kind IN ('PATIENT','ENCOUNTER','DOCUMENT') AND length(organization)>0 AND length(identifier_system)>0 AND length(patient_identifier)>0 AND organization IS NOT NULL AND identifier_system IS NOT NULL AND patient_identifier IS NOT NULL AND
  ((target_kind='PATIENT' AND encounter_identifier IS NULL AND document_identifier IS NULL) OR (target_kind='ENCOUNTER' AND encounter_identifier IS NOT NULL AND length(encounter_identifier)>0 AND document_identifier IS NULL) OR (target_kind='DOCUMENT' AND document_identifier IS NOT NULL AND length(document_identifier)>0))))
) STRICT;

CREATE UNIQUE INDEX result_target_identity ON result_target (result_id,action_id,target_kind,COALESCE(organization,''),COALESCE(identifier_system,''),COALESCE(patient_identifier,''),COALESCE(encounter_identifier,''),COALESCE(document_identifier,''));

CREATE TABLE reference_target (
  reference_id TEXT NOT NULL REFERENCES source_reference(id),
  action_id TEXT NOT NULL REFERENCES protected_action(id),
  target_kind TEXT NOT NULL CHECK(target_kind IN ('SERVICE','PATIENT','ENCOUNTER','DOCUMENT')),
  organization TEXT,
  identifier_system TEXT,
  patient_identifier TEXT,
  encounter_identifier TEXT,
  document_identifier TEXT,
  CHECK((target_kind='SERVICE' AND organization IS NULL AND identifier_system IS NULL AND patient_identifier IS NULL AND encounter_identifier IS NULL AND document_identifier IS NULL) OR
  (target_kind IN ('PATIENT','ENCOUNTER','DOCUMENT') AND length(organization)>0 AND length(identifier_system)>0 AND length(patient_identifier)>0 AND organization IS NOT NULL AND identifier_system IS NOT NULL AND patient_identifier IS NOT NULL AND
  ((target_kind='PATIENT' AND encounter_identifier IS NULL AND document_identifier IS NULL) OR (target_kind='ENCOUNTER' AND encounter_identifier IS NOT NULL AND length(encounter_identifier)>0 AND document_identifier IS NULL) OR (target_kind='DOCUMENT' AND document_identifier IS NOT NULL AND length(document_identifier)>0))))
) STRICT;

CREATE UNIQUE INDEX reference_target_identity ON reference_target (reference_id,action_id,target_kind,COALESCE(organization,''),COALESCE(identifier_system,''),COALESCE(patient_identifier,''),COALESCE(encounter_identifier,''),COALESCE(document_identifier,''));

CREATE TABLE retention_policy_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'RETENTION_POLICY' CHECK(kind = 'RETENTION_POLICY'),
  dataset TEXT NOT NULL CHECK(dataset IN ('AUDIT','GENERATED_RESULT')),
  retention_days INTEGER CHECK(retention_days > 0),
  cleanup_enabled INTEGER NOT NULL CHECK(cleanup_enabled IN (0,1)),
  cleanup_interval INTEGER CHECK(cleanup_interval > 0),
  batch_limit INTEGER CHECK(batch_limit > 0),
  CHECK(NOT cleanup_enabled OR (retention_days IS NOT NULL AND cleanup_interval IS NOT NULL AND batch_limit IS NOT NULL)),
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE error_mapping_version (
  version_id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL DEFAULT 'ERROR_MAPPING' CHECK(kind = 'ERROR_MAPPING'),
  FOREIGN KEY(version_id,kind) REFERENCES config_version(id,kind)
) STRICT;

CREATE TABLE error_mapping_rule (
  error_mapping_version_id TEXT NOT NULL REFERENCES error_mapping_version(version_id),
  remote_code TEXT NOT NULL,
  public_code TEXT NOT NULL,
  status_code INTEGER NOT NULL CHECK(status_code BETWEEN 400 AND 599),
  PRIMARY KEY(error_mapping_version_id,remote_code)
) STRICT;

CREATE INDEX config_version_object_id_idx ON config_version (object_id);

CREATE INDEX configuration_change_object_id_changed_at_idx ON configuration_change (object_id,changed_at);

CREATE INDEX credential_cipher_key_id_idx ON credential_cipher (key_id);

CREATE INDEX execution_started_at_idx ON execution (started_at);

CREATE INDEX execution_principal_id_client_object_id_idx ON execution (principal_id,client_object_id);

CREATE INDEX audit_event_occurred_at_idx ON audit_event (occurred_at);

CREATE INDEX audit_event_execution_id_idx ON audit_event (execution_id);

CREATE INDEX audit_parameter_audit_event_id_idx ON audit_parameter (audit_event_id);

CREATE INDEX reference_parameter_reference_id_idx ON reference_parameter (reference_id);

CREATE INDEX result_value_result_revision_id_idx ON result_value (result_revision_id);

CREATE INDEX result_reference_reference_id_idx ON result_reference (reference_id);

CREATE INDEX source_reference_source_execution_id_idx ON source_reference (source_execution_id);

CREATE INDEX generated_result_revision_created_at_idx ON generated_result_revision (created_at);

CREATE INDEX oauth_access_token_expires_at_idx ON oauth_access_token (expires_at);

CREATE INDEX oauth_access_token_grant_id_idx ON oauth_access_token (grant_id);

CREATE INDEX oauth_authorization_code_expires_at_idx ON oauth_authorization_code (expires_at);

CREATE INDEX oauth_authorization_request_expires_at_idx ON oauth_authorization_request (expires_at);

CREATE INDEX oauth_refresh_token_expires_at_idx ON oauth_refresh_token (expires_at);

CREATE INDEX oauth_refresh_family_grant_id_idx ON oauth_refresh_family (grant_id);

CREATE INDEX oauth_grant_principal_id_client_object_id_idx ON oauth_grant (principal_id,client_object_id);

CREATE INDEX auth_session_absolute_expires_at_idx ON auth_session (absolute_expires_at);

CREATE INDEX oauth_client_secret_client_object_id_idx ON oauth_client_secret (client_object_id);

CREATE INDEX role_action_action_id_idx ON role_action (action_id);

CREATE INDEX external_role_mapping_role_object_id_idx ON external_role_mapping (role_object_id);

CREATE INDEX mcp_tool_scope_scope_id_idx ON mcp_tool_scope (scope_id);

CREATE INDEX mcp_tool_action_action_id_idx ON mcp_tool_action (action_id);

CREATE TRIGGER config_version_immutable BEFORE UPDATE ON config_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER datasource_version_immutable BEFORE UPDATE ON datasource_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER credential_version_immutable BEFORE UPDATE ON credential_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER jdbc_datasource_version_immutable BEFORE UPDATE ON jdbc_datasource_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER tls_profile_version_immutable BEFORE UPDATE ON tls_profile_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER network_policy_version_immutable BEFORE UPDATE ON network_policy_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER network_policy_host_immutable BEFORE UPDATE ON network_policy_host FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER http_datasource_version_immutable BEFORE UPDATE ON http_datasource_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER http_source_header_immutable BEFORE UPDATE ON http_source_header FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER mapper_version_immutable BEFORE UPDATE ON mapper_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER mapper_document_immutable BEFORE UPDATE ON mapper_document FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER mapper_import_immutable BEFORE UPDATE ON mapper_import FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER contract_version_immutable BEFORE UPDATE ON contract_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER contract_field_immutable BEFORE UPDATE ON contract_field FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER contract_field_version_immutable BEFORE UPDATE ON contract_field_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER operation_version_immutable BEFORE UPDATE ON operation_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER jdbc_operation_version_immutable BEFORE UPDATE ON jdbc_operation_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER jdbc_out_binding_immutable BEFORE UPDATE ON jdbc_out_binding FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER operation_reference_binding_immutable BEFORE UPDATE ON operation_reference_binding FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER http_operation_version_immutable BEFORE UPDATE ON http_operation_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER http_parameter_binding_immutable BEFORE UPDATE ON http_parameter_binding FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER http_expected_status_immutable BEFORE UPDATE ON http_expected_status FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER representation_version_immutable BEFORE UPDATE ON representation_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER json_field_binding_immutable BEFORE UPDATE ON json_field_binding FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER xml_field_binding_immutable BEFORE UPDATE ON xml_field_binding FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER xapi_field_binding_immutable BEFORE UPDATE ON xapi_field_binding FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER converter_version_immutable BEFORE UPDATE ON converter_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER conversion_rule_immutable BEFORE UPDATE ON conversion_rule FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER conversion_argument_immutable BEFORE UPDATE ON conversion_argument FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER workflow_version_immutable BEFORE UPDATE ON workflow_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER workflow_stage_immutable BEFORE UPDATE ON workflow_stage FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER workflow_port_immutable BEFORE UPDATE ON workflow_port FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER workflow_binding_immutable BEFORE UPDATE ON workflow_binding FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER security_binding_version_immutable BEFORE UPDATE ON security_binding_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER protected_action_immutable BEFORE UPDATE ON protected_action FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER role_version_immutable BEFORE UPDATE ON role_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER role_action_immutable BEFORE UPDATE ON role_action FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER external_role_mapping_immutable BEFORE UPDATE ON external_role_mapping FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER target_policy_version_immutable BEFORE UPDATE ON target_policy_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER target_argument_binding_immutable BEFORE UPDATE ON target_argument_binding FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER workflow_security_binding_immutable BEFORE UPDATE ON workflow_security_binding FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER oauth_scope_immutable BEFORE UPDATE ON oauth_scope FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER oauth_scope_action_immutable BEFORE UPDATE ON oauth_scope_action FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER oauth_client_version_immutable BEFORE UPDATE ON oauth_client_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER oauth_client_redirect_immutable BEFORE UPDATE ON oauth_client_redirect FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER oauth_client_scope_immutable BEFORE UPDATE ON oauth_client_scope FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER oauth_client_resource_immutable BEFORE UPDATE ON oauth_client_resource FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER oauth_client_action_immutable BEFORE UPDATE ON oauth_client_action FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER oauth_request_scope_immutable BEFORE UPDATE ON oauth_request_scope FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER oauth_request_rule_immutable BEFORE UPDATE ON oauth_request_rule FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER oauth_grant_rule_immutable BEFORE UPDATE ON oauth_grant_rule FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER oauth_grant_scope_immutable BEFORE UPDATE ON oauth_grant_scope FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER oauth_token_scope_immutable BEFORE UPDATE ON oauth_token_scope FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER oauth_policy_version_immutable BEFORE UPDATE ON oauth_policy_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER mcp_tool_version_immutable BEFORE UPDATE ON mcp_tool_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER mcp_tool_scope_immutable BEFORE UPDATE ON mcp_tool_scope FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER mcp_tool_action_immutable BEFORE UPDATE ON mcp_tool_action FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER execution_dependency_immutable BEFORE UPDATE ON execution_dependency FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER screen_profile_version_immutable BEFORE UPDATE ON screen_profile_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER screen_parameter_binding_immutable BEFORE UPDATE ON screen_parameter_binding FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER retention_policy_version_immutable BEFORE UPDATE ON retention_policy_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER error_mapping_version_immutable BEFORE UPDATE ON error_mapping_version FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER error_mapping_rule_immutable BEFORE UPDATE ON error_mapping_rule FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable semantic row'); END;

CREATE TRIGGER contract_field_owner BEFORE INSERT ON contract_field_version FOR EACH ROW
WHEN NOT EXISTS (SELECT 1 FROM config_version v JOIN contract_field f ON f.contract_object_id=v.object_id WHERE v.id=NEW.contract_version_id AND f.id=NEW.field_id)
BEGIN SELECT RAISE(ABORT, 'contract field owner mismatch'); END;

CREATE TRIGGER token_scope_subset BEFORE INSERT ON oauth_token_scope FOR EACH ROW
WHEN NOT EXISTS (SELECT 1 FROM oauth_access_token t JOIN oauth_grant_scope s ON s.grant_id=t.grant_id WHERE t.id=NEW.access_token_id AND s.scope_id=NEW.scope_id)
BEGIN SELECT RAISE(ABORT, 'token scope exceeds grant'); END;

CREATE TRIGGER tool_name_identity BEFORE INSERT ON mcp_tool_version FOR EACH ROW
WHEN NOT EXISTS (SELECT 1 FROM config_version v JOIN config_object o ON o.id=v.object_id WHERE v.id=NEW.version_id AND o.logical_key=NEW.public_name)
BEGIN SELECT RAISE(ABORT, 'tool name identity mismatch'); END;

CREATE TRIGGER audit_event_immutable BEFORE UPDATE ON audit_event FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable audit event'); END;
CREATE TRIGGER audit_parameter_immutable BEFORE UPDATE ON audit_parameter FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable audit parameter'); END;
CREATE TRIGGER oauth_refresh_scope_immutable BEFORE UPDATE ON oauth_refresh_scope FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'immutable refresh scope'); END;

CREATE TRIGGER issued_grant_rule_sealed BEFORE INSERT ON oauth_grant_rule FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM oauth_authorization_code WHERE grant_id=NEW.grant_id)
  OR EXISTS (SELECT 1 FROM oauth_access_token WHERE grant_id=NEW.grant_id)
BEGIN SELECT RAISE(ABORT, 'issued grant cannot expand'); END;

CREATE TRIGGER issued_grant_scope_sealed BEFORE INSERT ON oauth_grant_scope FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM oauth_authorization_code WHERE grant_id=NEW.grant_id)
  OR EXISTS (SELECT 1 FROM oauth_access_token WHERE grant_id=NEW.grant_id)
BEGIN SELECT RAISE(ABORT, 'issued grant cannot expand'); END;


-- Published semantic children cannot be added or removed, including historical rollback versions.

CREATE INDEX configuration_change_after_idx ON configuration_change(after_version_id);

CREATE INDEX configuration_change_before_idx ON configuration_change(before_version_id);

CREATE TRIGGER config_version_published_insert BEFORE INSERT ON config_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.id OR before_version_id=NEW.id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER config_version_published_delete BEFORE DELETE ON config_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.id OR before_version_id=OLD.id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER datasource_version_published_insert BEFORE INSERT ON datasource_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER datasource_version_published_delete BEFORE DELETE ON datasource_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER jdbc_datasource_version_published_insert BEFORE INSERT ON jdbc_datasource_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER jdbc_datasource_version_published_delete BEFORE DELETE ON jdbc_datasource_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER http_datasource_version_published_insert BEFORE INSERT ON http_datasource_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER http_datasource_version_published_delete BEFORE DELETE ON http_datasource_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER credential_version_published_insert BEFORE INSERT ON credential_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER credential_version_published_delete BEFORE DELETE ON credential_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER credential_cipher_published_insert BEFORE INSERT ON credential_cipher FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.credential_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.credential_version_id OR before_version_id=NEW.credential_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER credential_cipher_published_delete BEFORE DELETE ON credential_cipher FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.credential_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.credential_version_id OR before_version_id=OLD.credential_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER credential_state_published_insert BEFORE INSERT ON credential_state FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.credential_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.credential_version_id OR before_version_id=NEW.credential_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER credential_state_published_delete BEFORE DELETE ON credential_state FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.credential_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.credential_version_id OR before_version_id=OLD.credential_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER tls_profile_version_published_insert BEFORE INSERT ON tls_profile_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER tls_profile_version_published_delete BEFORE DELETE ON tls_profile_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER network_policy_version_published_insert BEFORE INSERT ON network_policy_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER network_policy_version_published_delete BEFORE DELETE ON network_policy_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER network_policy_host_published_insert BEFORE INSERT ON network_policy_host FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.network_policy_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.network_policy_version_id OR before_version_id=NEW.network_policy_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER network_policy_host_published_delete BEFORE DELETE ON network_policy_host FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.network_policy_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.network_policy_version_id OR before_version_id=OLD.network_policy_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER http_source_header_published_insert BEFORE INSERT ON http_source_header FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.datasource_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.datasource_version_id OR before_version_id=NEW.datasource_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER http_source_header_published_delete BEFORE DELETE ON http_source_header FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.datasource_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.datasource_version_id OR before_version_id=OLD.datasource_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER mapper_version_published_insert BEFORE INSERT ON mapper_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER mapper_version_published_delete BEFORE DELETE ON mapper_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER mapper_document_published_insert BEFORE INSERT ON mapper_document FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.mapper_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.mapper_version_id OR before_version_id=NEW.mapper_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER mapper_document_published_delete BEFORE DELETE ON mapper_document FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.mapper_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.mapper_version_id OR before_version_id=OLD.mapper_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER mapper_import_published_insert BEFORE INSERT ON mapper_import FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.mapper_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.mapper_version_id OR before_version_id=NEW.mapper_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER mapper_import_published_delete BEFORE DELETE ON mapper_import FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.mapper_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.mapper_version_id OR before_version_id=OLD.mapper_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER contract_version_published_insert BEFORE INSERT ON contract_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER contract_version_published_delete BEFORE DELETE ON contract_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER contract_field_version_published_insert BEFORE INSERT ON contract_field_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.contract_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.contract_version_id OR before_version_id=NEW.contract_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER contract_field_version_published_delete BEFORE DELETE ON contract_field_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.contract_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.contract_version_id OR before_version_id=OLD.contract_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER operation_version_published_insert BEFORE INSERT ON operation_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER operation_version_published_delete BEFORE DELETE ON operation_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER operation_reference_binding_published_insert BEFORE INSERT ON operation_reference_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.operation_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.operation_version_id OR before_version_id=NEW.operation_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER operation_reference_binding_published_delete BEFORE DELETE ON operation_reference_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.operation_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.operation_version_id OR before_version_id=OLD.operation_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER jdbc_operation_version_published_insert BEFORE INSERT ON jdbc_operation_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER jdbc_operation_version_published_delete BEFORE DELETE ON jdbc_operation_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER jdbc_out_binding_published_insert BEFORE INSERT ON jdbc_out_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.operation_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.operation_version_id OR before_version_id=NEW.operation_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER jdbc_out_binding_published_delete BEFORE DELETE ON jdbc_out_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.operation_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.operation_version_id OR before_version_id=OLD.operation_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER http_operation_version_published_insert BEFORE INSERT ON http_operation_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER http_operation_version_published_delete BEFORE DELETE ON http_operation_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER http_parameter_binding_published_insert BEFORE INSERT ON http_parameter_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.operation_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.operation_version_id OR before_version_id=NEW.operation_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER http_parameter_binding_published_delete BEFORE DELETE ON http_parameter_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.operation_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.operation_version_id OR before_version_id=OLD.operation_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER http_expected_status_published_insert BEFORE INSERT ON http_expected_status FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.operation_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.operation_version_id OR before_version_id=NEW.operation_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER http_expected_status_published_delete BEFORE DELETE ON http_expected_status FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.operation_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.operation_version_id OR before_version_id=OLD.operation_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER representation_version_published_insert BEFORE INSERT ON representation_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER representation_version_published_delete BEFORE DELETE ON representation_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER json_field_binding_published_insert BEFORE INSERT ON json_field_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.representation_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.representation_version_id OR before_version_id=NEW.representation_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER json_field_binding_published_delete BEFORE DELETE ON json_field_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.representation_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.representation_version_id OR before_version_id=OLD.representation_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER xml_field_binding_published_insert BEFORE INSERT ON xml_field_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.representation_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.representation_version_id OR before_version_id=NEW.representation_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER xml_field_binding_published_delete BEFORE DELETE ON xml_field_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.representation_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.representation_version_id OR before_version_id=OLD.representation_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER xapi_field_binding_published_insert BEFORE INSERT ON xapi_field_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.representation_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.representation_version_id OR before_version_id=NEW.representation_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER xapi_field_binding_published_delete BEFORE DELETE ON xapi_field_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.representation_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.representation_version_id OR before_version_id=OLD.representation_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER converter_version_published_insert BEFORE INSERT ON converter_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER converter_version_published_delete BEFORE DELETE ON converter_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER conversion_rule_published_insert BEFORE INSERT ON conversion_rule FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.converter_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.converter_version_id OR before_version_id=NEW.converter_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER conversion_rule_published_delete BEFORE DELETE ON conversion_rule FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.converter_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.converter_version_id OR before_version_id=OLD.converter_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER workflow_version_published_insert BEFORE INSERT ON workflow_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER workflow_version_published_delete BEFORE DELETE ON workflow_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER workflow_stage_published_insert BEFORE INSERT ON workflow_stage FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.workflow_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.workflow_version_id OR before_version_id=NEW.workflow_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER workflow_stage_published_delete BEFORE DELETE ON workflow_stage FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.workflow_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.workflow_version_id OR before_version_id=OLD.workflow_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER workflow_port_published_insert BEFORE INSERT ON workflow_port FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.workflow_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.workflow_version_id OR before_version_id=NEW.workflow_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER workflow_port_published_delete BEFORE DELETE ON workflow_port FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.workflow_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.workflow_version_id OR before_version_id=OLD.workflow_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER workflow_binding_published_insert BEFORE INSERT ON workflow_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.workflow_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.workflow_version_id OR before_version_id=NEW.workflow_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER workflow_binding_published_delete BEFORE DELETE ON workflow_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.workflow_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.workflow_version_id OR before_version_id=OLD.workflow_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER security_binding_version_published_insert BEFORE INSERT ON security_binding_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER security_binding_version_published_delete BEFORE DELETE ON security_binding_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER role_version_published_insert BEFORE INSERT ON role_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER role_version_published_delete BEFORE DELETE ON role_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER role_action_published_insert BEFORE INSERT ON role_action FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.role_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.role_version_id OR before_version_id=NEW.role_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER role_action_published_delete BEFORE DELETE ON role_action FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.role_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.role_version_id OR before_version_id=OLD.role_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER external_role_mapping_published_insert BEFORE INSERT ON external_role_mapping FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.security_binding_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.security_binding_version_id OR before_version_id=NEW.security_binding_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER external_role_mapping_published_delete BEFORE DELETE ON external_role_mapping FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.security_binding_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.security_binding_version_id OR before_version_id=OLD.security_binding_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER target_policy_version_published_insert BEFORE INSERT ON target_policy_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER target_policy_version_published_delete BEFORE DELETE ON target_policy_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER target_argument_binding_published_insert BEFORE INSERT ON target_argument_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.target_policy_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.target_policy_version_id OR before_version_id=NEW.target_policy_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER target_argument_binding_published_delete BEFORE DELETE ON target_argument_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.target_policy_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.target_policy_version_id OR before_version_id=OLD.target_policy_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER workflow_security_binding_published_insert BEFORE INSERT ON workflow_security_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.workflow_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.workflow_version_id OR before_version_id=NEW.workflow_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER workflow_security_binding_published_delete BEFORE DELETE ON workflow_security_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.workflow_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.workflow_version_id OR before_version_id=OLD.workflow_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER oauth_client_version_published_insert BEFORE INSERT ON oauth_client_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER oauth_client_version_published_delete BEFORE DELETE ON oauth_client_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER oauth_client_redirect_published_insert BEFORE INSERT ON oauth_client_redirect FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.client_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.client_version_id OR before_version_id=NEW.client_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER oauth_client_redirect_published_delete BEFORE DELETE ON oauth_client_redirect FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.client_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.client_version_id OR before_version_id=OLD.client_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER oauth_client_scope_published_insert BEFORE INSERT ON oauth_client_scope FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.client_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.client_version_id OR before_version_id=NEW.client_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER oauth_client_scope_published_delete BEFORE DELETE ON oauth_client_scope FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.client_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.client_version_id OR before_version_id=OLD.client_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER oauth_client_resource_published_insert BEFORE INSERT ON oauth_client_resource FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.client_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.client_version_id OR before_version_id=NEW.client_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER oauth_client_resource_published_delete BEFORE DELETE ON oauth_client_resource FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.client_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.client_version_id OR before_version_id=OLD.client_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER oauth_client_action_published_insert BEFORE INSERT ON oauth_client_action FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.client_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.client_version_id OR before_version_id=NEW.client_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER oauth_client_action_published_delete BEFORE DELETE ON oauth_client_action FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.client_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.client_version_id OR before_version_id=OLD.client_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER oauth_policy_version_published_insert BEFORE INSERT ON oauth_policy_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER oauth_policy_version_published_delete BEFORE DELETE ON oauth_policy_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER mcp_tool_version_published_insert BEFORE INSERT ON mcp_tool_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER mcp_tool_version_published_delete BEFORE DELETE ON mcp_tool_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER mcp_tool_scope_published_insert BEFORE INSERT ON mcp_tool_scope FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.tool_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.tool_version_id OR before_version_id=NEW.tool_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER mcp_tool_scope_published_delete BEFORE DELETE ON mcp_tool_scope FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.tool_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.tool_version_id OR before_version_id=OLD.tool_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER mcp_tool_action_published_insert BEFORE INSERT ON mcp_tool_action FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.tool_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.tool_version_id OR before_version_id=NEW.tool_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER mcp_tool_action_published_delete BEFORE DELETE ON mcp_tool_action FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.tool_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.tool_version_id OR before_version_id=OLD.tool_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER screen_profile_version_published_insert BEFORE INSERT ON screen_profile_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER screen_profile_version_published_delete BEFORE DELETE ON screen_profile_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER screen_parameter_binding_published_insert BEFORE INSERT ON screen_parameter_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.screen_profile_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.screen_profile_version_id OR before_version_id=NEW.screen_profile_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER screen_parameter_binding_published_delete BEFORE DELETE ON screen_parameter_binding FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.screen_profile_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.screen_profile_version_id OR before_version_id=OLD.screen_profile_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER retention_policy_version_published_insert BEFORE INSERT ON retention_policy_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER retention_policy_version_published_delete BEFORE DELETE ON retention_policy_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER error_mapping_version_published_insert BEFORE INSERT ON error_mapping_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.version_id OR before_version_id=NEW.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER error_mapping_version_published_delete BEFORE DELETE ON error_mapping_version FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.version_id OR before_version_id=OLD.version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER error_mapping_rule_published_insert BEFORE INSERT ON error_mapping_rule FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=NEW.error_mapping_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=NEW.error_mapping_version_id OR before_version_id=NEW.error_mapping_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER error_mapping_rule_published_delete BEFORE DELETE ON error_mapping_rule FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=OLD.error_mapping_version_id) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=OLD.error_mapping_version_id OR before_version_id=OLD.error_mapping_version_id)
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER conversion_argument_published_insert BEFORE INSERT ON conversion_argument FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=(SELECT converter_version_id FROM conversion_rule WHERE id=NEW.conversion_rule_id)) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=(SELECT converter_version_id FROM conversion_rule WHERE id=NEW.conversion_rule_id) OR before_version_id=(SELECT converter_version_id FROM conversion_rule WHERE id=NEW.conversion_rule_id))
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER conversion_argument_published_delete BEFORE DELETE ON conversion_argument FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM config_object WHERE current_version_id=(SELECT converter_version_id FROM conversion_rule WHERE id=OLD.conversion_rule_id)) OR EXISTS (SELECT 1 FROM configuration_change WHERE after_version_id=(SELECT converter_version_id FROM conversion_rule WHERE id=OLD.conversion_rule_id) OR before_version_id=(SELECT converter_version_id FROM conversion_rule WHERE id=OLD.conversion_rule_id))
BEGIN SELECT RAISE(ABORT, 'published revision is immutable'); END;

CREATE TRIGGER configuration_change_immutable BEFORE UPDATE ON configuration_change FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'configuration history is immutable'); END;

CREATE TRIGGER configuration_change_no_delete BEFORE DELETE ON configuration_change FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'configuration history is immutable'); END;

CREATE TRIGGER oauth_grant_rule_issued_no_delete BEFORE DELETE ON oauth_grant_rule FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM oauth_authorization_code WHERE grant_id=OLD.grant_id) OR EXISTS (SELECT 1 FROM oauth_access_token WHERE grant_id=OLD.grant_id)
BEGIN SELECT RAISE(ABORT, 'issued grant is immutable'); END;

CREATE TRIGGER oauth_grant_scope_issued_no_delete BEFORE DELETE ON oauth_grant_scope FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM oauth_authorization_code WHERE grant_id=OLD.grant_id) OR EXISTS (SELECT 1 FROM oauth_access_token WHERE grant_id=OLD.grant_id)
BEGIN SELECT RAISE(ABORT, 'issued grant is immutable'); END;
