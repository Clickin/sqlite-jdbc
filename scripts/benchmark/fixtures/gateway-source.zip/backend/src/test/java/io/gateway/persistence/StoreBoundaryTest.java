package io.gateway.persistence;

import com.zaxxer.hikari.HikariDataSource;
import com.zaxxer.hikari.metrics.IMetricsTracker;
import io.gateway.GatewayFixture;
import io.gateway.audit.AuditService;
import io.gateway.definitions.DefinitionMapper;
import io.gateway.mcp.Mcp2026Adapter;
import io.gateway.oauth.SecurityFixture;
import io.gateway.oauth.SyntheticAuthority;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import tools.jackson.databind.json.JsonMapper;
import static org.junit.jupiter.api.Assertions.*;

class StoreBoundaryTest {
    @TempDir Path directory;

    @Test void concurrentWritersAndNestedAuditUseOnePhysicalLeaseAndRollbackTogether() throws Exception {
        try (var store = new PlatformStore(directory.resolve("platform.db"));
             var workers = Executors.newVirtualThreadPerTaskExecutor()) {
            var writer = store.write(s -> (HikariDataSource) s.getConfiguration().getEnvironment().getDataSource());
            var acquired = new AtomicInteger();
            writer.setMetricsTrackerFactory((name, stats) -> new IMetricsTracker() {
                @Override public void recordConnectionAcquiredNanos(long elapsed) { acquired.incrementAndGet(); }
            });
            var start = new CyclicBarrier(12);
            var audits = new AuditService(store);
            List<Future<?>> requests = new ArrayList<>();
            for (int i = 0; i < 12; i++) {
                String id = "scope-" + i;
                requests.add(workers.submit(() -> {
                    start.await(10, TimeUnit.SECONDS);
                    store.write(s -> {
                        assertEquals(1, writer.getHikariPoolMXBean().getActiveConnections());
                        int beforeAudit = acquired.get();
                        s.getMapper(PlatformStoreTest.Fixture.class).scope(id, "serialized");
                        store.write(nested -> { assertSame(s.getConnection(), nested.getConnection()); return null; });
                        audits.record("SERIALIZED_WRITE", "fixture", "SUCCEEDED", null);
                        assertEquals(beforeAudit, acquired.get(), "Nested audit cannot acquire another writer");
                        return null;
                    });
                    return null;
                }));
            }
            for (var request : requests) request.get(10, TimeUnit.SECONDS);
            assertEquals(12, acquired.get());
            assertEquals(0, writer.getHikariPoolMXBean().getActiveConnections());
            assertEquals(12, store.read(s -> s.getMapper(PlatformStoreTest.Fixture.class).auditCount()).intValue());
            assertThrows(IllegalStateException.class, () -> store.write(s -> {
                s.getMapper(PlatformStoreTest.Fixture.class).scope("rollback", "not committed");
                audits.record("ROLLED_BACK_WRITE", "fixture", "SUCCEEDED", null);
                throw new IllegalStateException("deliberate transaction failure");
            }));
            assertEquals(13, acquired.get());
            assertEquals(12, store.read(s -> s.getMapper(PlatformStoreTest.Fixture.class).scopeCount()).intValue());
            assertEquals(12, store.read(s -> s.getMapper(PlatformStoreTest.Fixture.class).auditCount()).intValue());
        }
    }

    @Test void repeatedActiveHeadQueryKeepsItsSnapshotButNextRequestSeesCommittedHead() throws Exception {
        try (var store = new PlatformStore(directory.resolve("platform.db"));
             var workers = Executors.newVirtualThreadPerTaskExecutor()) {
            store.write(s -> {
                var m = s.getMapper(SecurityFixture.FixtureMapper.class);
                m.execute("INSERT INTO config_object(id,kind,logical_key,created_at,created_by) VALUES('head','CONTRACT','head',1,'fixture')");
                m.execute("INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name) VALUES('head-v1','head','CONTRACT',1,1,'fixture','initial','first'),('head-v2','head','CONTRACT',2,2,'fixture','replace','second')");
                m.execute("UPDATE config_object SET current_version_id='head-v1',revision_counter=2,generation=1 WHERE id='head'");
                return null;
            });
            var read = new CountDownLatch(1);
            var committed = new CountDownLatch(1);
            var pending = workers.submit(() -> store.read(s -> {
                var mapper = s.getMapper(DefinitionMapper.class);
                var first = mapper.head("head");
                read.countDown();
                await(committed);
                return List.of(first, mapper.head("head"));
            }));
            try {
                assertTrue(read.await(10, TimeUnit.SECONDS));
                store.write(s -> { assertEquals(1, s.getMapper(DefinitionMapper.class).cas("head", "head-v2", 1)); return null; });
            } finally { committed.countDown(); }
            var snapshot = pending.get(10, TimeUnit.SECONDS);
            assertEquals(List.of("head-v1", "head-v1"), snapshot.stream().map(h -> h.currentVersionId()).toList());
            for (int request = 0; request < 3; request++) {
                var current = store.read(s -> s.getMapper(DefinitionMapper.class).head("head"));
                assertEquals("head-v2", current.currentVersionId());
                assertEquals(2, current.generation());
            }
        }
    }

    @Test void remoteAuthorityAndHttpWaitsHoldNeitherPlatformPool() throws Exception {
        try (var fixture = new GatewayFixture(directory, -1);
             var workers = Executors.newVirtualThreadPerTaskExecutor();
             var http = HttpClient.newHttpClient()) {
            var security = new SecurityFixture(fixture.store, directory, false);
            var token = security.token("A");
            var reader = fixture.store.read(s -> (HikariDataSource) s.getConfiguration().getEnvironment().getDataSource());
            var writer = fixture.store.write(s -> (HikariDataSource) s.getConfiguration().getEnvironment().getDataSource());
            var authorityEntered = new CountDownLatch(1);
            var authorityRelease = new CountDownLatch(1);
            var httpEntered = new CountDownLatch(1);
            var httpRelease = new CountDownLatch(1);
            fixture.server.getApplicationContext().getBean(SyntheticAuthority.class).beforeDecision = () -> {
                authorityEntered.countDown(); await(authorityRelease);
            };
            fixture.source.removeContext("/labs");
            fixture.source.createContext("/labs", exchange -> {
                fixture.sourceCalls.incrementAndGet(); httpEntered.countDown(); await(httpRelease);
                byte[] body = "{\"answer\":\"confirmed\",\"recordText\":\"not retained\"}".getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type", "application/json");
                exchange.sendResponseHeaders(200, body.length);
                try (var output = exchange.getResponseBody()) { output.write(body); }
            });
            var meta = Map.of(Mcp2026Adapter.PROTOCOL, "2026-07-28", Mcp2026Adapter.CAPABILITIES, Map.of());
            String body = JsonMapper.builder().build().writeValueAsString(Map.of("jsonrpc", "2.0", "id", 1, "method", "tools/call",
                    "params", Map.of("_meta", meta, "name", "lab-tool", "arguments", Map.of("patientId", "A", "documentId", "DA"))));
            var request = HttpRequest.newBuilder(fixture.server.getURI().resolve("/mcp"))
                    .header("Content-Type", "application/json").header("Accept", "application/json, text/event-stream")
                    .header("MCP-Protocol-Version", "2026-07-28").header("Mcp-Method", "tools/call").header("Mcp-Name", "lab-tool")
                    .header("Authorization", "Bearer " + token.get("access_token")).POST(HttpRequest.BodyPublishers.ofString(body)).build();
            var pending = workers.submit(() -> http.send(request, HttpResponse.BodyHandlers.ofString()));
            try {
                assertTrue(authorityEntered.await(10, TimeUnit.SECONDS));
                idle(reader, writer);
                assertEquals(0, fixture.sourceCalls.get());
                authorityRelease.countDown();
                assertTrue(httpEntered.await(10, TimeUnit.SECONDS));
                idle(reader, writer);
                // A different request can still commit while the clinical source is blocked.
                new AuditService(fixture.store).record("DURING_REMOTE_WAIT", "fixture", "SUCCEEDED", null);
                idle(reader, writer);
                httpRelease.countDown();
                var response = pending.get(10, TimeUnit.SECONDS);
                assertEquals(200, response.statusCode(), response.body());
                assertTrue(response.body().contains("confirmed"), response.body());
                assertEquals(1, fixture.sourceCalls.get());
            } finally { authorityRelease.countDown(); httpRelease.countDown(); }
        }
    }

    @Test
    @org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable(named="GATEWAY_TEST_POSTGRES_URL", matches=".+")
    void replicaUrlOverrideCannotMoveAuthenticationOrHeadReadsOffPrimary() {
        String url = System.getenv("GATEWAY_TEST_POSTGRES_URL");
        String secondaryRequested = url + (url.contains("?") ? "&" : "?") + "targetServerType=secondary";
        try (var store = new PlatformStore(secondaryRequested,
                System.getenv().getOrDefault("GATEWAY_TEST_POSTGRES_USER", ""),
                System.getenv().getOrDefault("GATEWAY_TEST_POSTGRES_PASSWORD", ""), 2, 5000)) {
            boolean readerReplica=store.read(s -> s.getMapper(PrimaryFixture.class).inRecovery());
            boolean writerReplica=store.write(s -> s.getMapper(PrimaryFixture.class).inRecovery());
            assertFalse(readerReplica);assertFalse(writerReplica);
        }
    }

    public interface PrimaryFixture extends PlatformMapper {
        @org.apache.ibatis.annotations.Select("SELECT pg_is_in_recovery()") boolean inRecovery();
    }

    private static void idle(HikariDataSource reader, HikariDataSource writer) {
        assertEquals(0, reader.getHikariPoolMXBean().getActiveConnections(), "No platform reader across remote I/O");
        assertEquals(0, writer.getHikariPoolMXBean().getActiveConnections(), "No platform writer across remote I/O");
    }
    private static void await(CountDownLatch latch) {
        try { if (!latch.await(10, TimeUnit.SECONDS)) throw new AssertionError("barrier timeout"); }
        catch (InterruptedException failure) { Thread.currentThread().interrupt(); throw new AssertionError(failure); }
    }
}
