package io.gateway;

import io.gateway.mcp.Mcp2026Adapter;
import io.gateway.oauth.*;
import io.gateway.definitions.DefinitionRepository;
import io.gateway.definitions.Definitions.*;
import io.gateway.management.SecurityDefinitions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import tools.jackson.databind.json.JsonMapper;
import java.net.URI;
import java.net.http.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class GatewayHttpTest {
    @TempDir Path directory;
    private final JsonMapper json=JsonMapper.builder().build();
    private final HttpClient client=HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1).followRedirects(HttpClient.Redirect.NEVER).build();
    private URI base;
    private record Browser(String cookie,String csrf) {}
    @SuppressWarnings("unchecked") private Map<String,Object> object(HttpResponse<String> response){return json.readValue(response.body(),Map.class);}
    private HttpResponse<String> send(String path,String method,String body,Map<String,String> headers)throws Exception {
        var request=HttpRequest.newBuilder(base.resolve(path)).method(method,body==null?HttpRequest.BodyPublishers.noBody():HttpRequest.BodyPublishers.ofString(body));
        headers.forEach(request::header);return client.send(request.build(),HttpResponse.BodyHandlers.ofString());
    }
    private Browser login()throws Exception { return login("USER"); }
    private Browser login(String kind)throws Exception {
        var session=send("/auth/session","GET",null,Map.of());assertEquals(200,session.statusCode());
        String cookie=session.headers().firstValue("set-cookie").orElseThrow().split(";",2)[0];
        String csrf=(String)object(session).get("csrfToken");
        var logged=send("/auth/session/login","POST",json.writeValueAsString(Map.of("credential",kind.equals("MANAGEMENT")?"synthetic-admin":"synthetic-doctor","sessionKind",kind)),
                Map.of("Cookie",cookie,"Origin",SecurityFixture.ISSUER,"X-CSRF-Token",csrf,"Content-Type","application/json"));
        assertEquals(200,logged.statusCode(),logged.body());
        String fresh=logged.headers().firstValue("set-cookie").orElseThrow().split(";",2)[0];assertNotEquals(cookie,fresh);
        return new Browser(fresh,(String)object(logged).get("csrfToken"));
    }
    @SuppressWarnings("unchecked") private Map<String,Object> authorize()throws Exception {
        var browser=login();
        var params=SecurityFixture.authorizeParameters("public",SecurityFixture.REDIRECT,"clinical.read");
        var flat=new LinkedHashMap<String,String>();params.forEach((k,v)->flat.put(k,v.getFirst()));
        var authorize=send("/oauth/authorize?"+SecurityFixture.form(flat),"GET",null,Map.of("Cookie",browser.cookie()));
        assertEquals(303,authorize.statusCode(),authorize.body());
        String location=authorize.headers().firstValue("location").orElseThrow();
        String requestId=new com.nimbusds.oauth2.sdk.http.HTTPRequest(com.nimbusds.oauth2.sdk.http.HTTPRequest.Method.GET,URI.create(location)).getQueryStringParameters().get("request_id").getFirst();
        var consent=send("/auth/requests/"+requestId+"/consent","POST",json.writeValueAsString(Map.of("purpose","synthetic-care","approve",true,
            "actionTargets",List.of(Map.of("action","clinical.lab.read","target",SecurityFixture.patient("A"))))),
            Map.of("Cookie",browser.cookie(),"Origin",SecurityFixture.ISSUER,"X-CSRF-Token",browser.csrf(),"Content-Type","application/json"));
        assertEquals(200,consent.statusCode(),consent.body());
        String redirect=(String)object(consent).get("redirectUri");
        var query=new com.nimbusds.oauth2.sdk.http.HTTPRequest(com.nimbusds.oauth2.sdk.http.HTTPRequest.Method.GET,URI.create(redirect)).getQueryStringParameters();
        assertEquals(SecurityFixture.ISSUER,query.get("iss").getFirst());
        assertEquals("synthetic-state-sentinel",query.get("state").getFirst());
        var code=new SecurityFixture.Code(query.get("code").getFirst(),"public",SecurityFixture.VERIFIER,SecurityFixture.REDIRECT,requestId);
        var response=send("/oauth/token","POST",SecurityFixture.exchangeForm(code),Map.of("Content-Type","application/x-www-form-urlencoded"));
        assertEquals(200,response.statusCode(),response.body());assertEquals("no-store",response.headers().firstValue("cache-control").orElseThrow());
        var token=object(response);
        var replay=send("/oauth/token","POST",SecurityFixture.exchangeForm(code),Map.of("Content-Type","application/x-www-form-urlencoded"));
        assertEquals(400,replay.statusCode());
        return token;
    }
    private HttpResponse<String> rpc(String method,Map<String,Object> arguments,String token,String name)throws Exception {
        var params=new LinkedHashMap<String,Object>();params.put("_meta",Map.of(Mcp2026Adapter.PROTOCOL,"2026-07-28",Mcp2026Adapter.CAPABILITIES,Map.of()));
        if(method.equals("tools/call")){params.put("name",name);params.put("arguments",arguments);}
        var headers=new LinkedHashMap<>(Map.of("Content-Type","application/json","Accept","application/json, text/event-stream","MCP-Protocol-Version","2026-07-28","Mcp-Method",method,"Authorization","Bearer "+token));
        if(method.equals("tools/call"))headers.put("Mcp-Name",name);
        return send("/mcp","POST",json.writeValueAsString(Map.of("jsonrpc","2.0","id",1,"method",method,"params",params)),headers);
    }
    @Test void browserCodePkceToStatelessToolsEnforcesCurrentAuthorityBeforeBody()throws Exception {
        String access;
        try(var fixture=new GatewayFixture(directory,-1)) {
            base=fixture.server.getURI();
            var thread=send("/test/runtime","GET",null,Map.of());assertEquals(true,object(thread).get("virtual"));
            var unauth=send("/mcp","POST","{}",Map.of("Content-Type","application/json"));assertEquals(401,unauth.statusCode());
            assertTrue(unauth.headers().firstValue("www-authenticate").orElseThrow().contains("oauth-protected-resource/mcp"));
            var token=authorize();access=(String)token.get("access_token");
            var discovery=rpc("server/discover",Map.of(),access,null);assertEquals(200,discovery.statusCode(),discovery.body());assertTrue(discovery.body().contains("supportedVersions"));
            var list=rpc("tools/list",Map.of(),access,null);assertEquals(200,list.statusCode(),list.body());assertTrue(list.body().contains("lab-tool"));
            assertEquals(0,fixture.sourceCalls.get());
            var denied=rpc("tools/call",Map.of("patientId","A","documentId","DB"),access,"lab-tool");assertEquals(403,denied.statusCode(),denied.body());assertEquals(0,fixture.sourceCalls.get());
            var allowed=rpc("tools/call",Map.of("patientId","A","documentId","DA"),access,"lab-tool");
            assertEquals(200,allowed.statusCode(),allowed.body());assertTrue(allowed.body().contains("SUCCEEDED"),allowed.body());assertTrue(allowed.body().contains("합성 정상 결과"));assertEquals(1,fixture.sourceCalls.get());
            assertTrue(allowed.headers().firstValue("mcp-session-id").isEmpty());
            fixture.server.getApplicationContext().getBean(SyntheticAuthority.class).outcome="DENY";
            assertEquals(403,rpc("tools/call",Map.of("patientId","A","documentId","DA"),access,"lab-tool").statusCode());assertEquals(1,fixture.sourceCalls.get());
            var rest=send("/api/workflows/lab-workflow/execute","POST","{\"patientId\":\"A\",\"documentId\":\"DA\"}",Map.of("Content-Type","application/json","Authorization","Bearer "+access));assertEquals(403,rest.statusCode());
            var revoked=send("/oauth/revoke","POST",SecurityFixture.form(Map.of("client_id","public","token",access)),Map.of("Content-Type","application/x-www-form-urlencoded"));assertEquals(200,revoked.statusCode());
            assertEquals(401,rpc("tools/list",Map.of(),access,null).statusCode());
            assertEquals(405,send("/mcp","GET",null,Map.of()).statusCode());
        }
        String physical=new String(Files.readAllBytes(directory.resolve("platform.db")),StandardCharsets.ISO_8859_1);
        assertFalse(physical.contains("RECOVERABLE_SENTINEL_NEVER_PERSIST"));assertFalse(physical.contains(access));assertFalse(physical.contains(SecurityFixture.VERIFIER));
    }
    @Test void emergencySourceDisableDuringAuthorityPreventsNewClinicalIo()throws Exception {
        try(var fixture=new GatewayFixture(directory,-1)){
            base=fixture.server.getURI();
            String token=(String)authorize().get("access_token");
            var once=new java.util.concurrent.atomic.AtomicBoolean();
            fixture.server.getApplicationContext().getBean(SyntheticAuthority.class).beforeDecision=()->{
                if(once.compareAndSet(false,true))fixture.store.write(s->{
                    s.getMapper(SecurityFixture.FixtureMapper.class).execute("UPDATE config_object SET enabled=false WHERE id='"+fixture.datasource.object().id()+"'");
                    return null;
                });
            };
            var denied=rpc("tools/call",Map.of("patientId","A","documentId","DA"),token,"lab-tool");
            assertEquals(403,denied.statusCode(),denied.body());
            assertEquals(0,fixture.sourceCalls.get());
        }
    }
    @Test void publishedMcpContractRejectsIncompatibleInternalRevisionBeforeApply()throws Exception {
        try(var fixture=new GatewayFixture(directory,-1)){
            var repository=fixture.server.getApplicationContext().getBean(io.gateway.definitions.DefinitionRepository.class);
            var original=(io.gateway.definitions.Definitions.Contract)fixture.output.detail();
            var fields=original.fields().stream().map(f->f.id().equals("answer-field")?
                new io.gateway.definitions.Definitions.Field(f.id(),f.logicalName(),f.parentFieldId(),f.memberName(),f.nodeKind(),"INTEGER",f.ordinal(),f.required(),f.nullable(),null,null,null,f.auditDisposition()):f).toList();
            var draft=repository.draft(new io.gateway.definitions.Definitions.Draft(fixture.output.object().id(),"lab-output","Changed",null,"synthetic breaking change",
                new io.gateway.definitions.Definitions.Contract("VALUE",fields)),"fixture");
            assertThrows(IllegalArgumentException.class,()->repository.validate(draft.object().id(),draft.version().id()));
            assertEquals(fixture.output.version().id(),repository.get(fixture.output.object().id(),null).version().id());
            assertEquals(fixture.workflow.version().id(),repository.get(fixture.workflow.object().id(),null).version().id());
            assertEquals(0,fixture.sourceCalls.get());
        }
    }
    @Test void incompatibleNewToolIsRejectedBeforePublicationOrSourceCall()throws Exception {
        try(var fixture=new GatewayFixture(directory,-1)) {
            var app=fixture.server.getApplicationContext();
            var definitions=app.getBean(SecurityDefinitions.class);
            var repository=app.getBean(DefinitionRepository.class);
            var incompatible=publish(repository,"incompatible-public",new Contract("VALUE",List.of()));
            for(String pin:List.of("public_input_contract_version_id","public_output_contract_version_id")) {
                String name=pin.startsWith("public_input")?"invalid-input-tool":"invalid-output-tool";
                var detail=new LinkedHashMap<>(definitions.get("lab-tool",null).detail());
                detail.put("public_name",name);detail.put(pin,incompatible.version().id());
                var draft=definitions.draft(new SecurityDefinitions.Draft(null,name,name,null,"test","MCP_TOOL",detail),"fixture");
                assertEquals("PINNED_PUBLIC_CONTRACT_INCOMPATIBLE",assertThrows(IllegalArgumentException.class,
                    ()->definitions.validate(draft.object().id(),draft.version().id())).getMessage());
                assertEquals("PINNED_PUBLIC_CONTRACT_INCOMPATIBLE",assertThrows(IllegalArgumentException.class,
                    ()->definitions.apply(draft.object().id(),draft.version().id(),draft.object().generation(),Map.of(),"fixture","test")).getMessage());
                assertNull(definitions.list().stream().filter(h->h.id().equals(draft.object().id())).findFirst().orElseThrow().currentVersionId());
            }
            assertEquals(0,fixture.sourceCalls.get());
        }
    }
    @Test void disabledToolCannotBeReenabledAgainstChangedWorkflowContract()throws Exception {
        try(var fixture=new GatewayFixture(directory,-1)) {
            base=fixture.server.getURI();var browser=login("MANAGEMENT");
            var headers=Map.of("Cookie",browser.cookie(),"Origin",SecurityFixture.ISSUER,"X-CSRF-Token",browser.csrf(),"Content-Type","application/json");
            var disabled=send("/management/objects/lab-tool/enabled","POST","{\"enabled\":false,\"generation\":1,\"reason\":\"test\"}",headers);
            assertEquals(200,disabled.statusCode(),disabled.body());
            var repository=fixture.server.getApplicationContext().getBean(DefinitionRepository.class);
            var original=(Contract)fixture.output.detail();
            var fields=original.fields().stream().map(f->f.id().equals("answer-field")?
                new Field(f.id(),f.logicalName(),f.parentFieldId(),f.memberName(),f.nodeKind(),"INTEGER",f.ordinal(),f.required(),f.nullable(),null,null,null,f.auditDisposition()):f).toList();
            var draft=repository.draft(new Draft(fixture.output.object().id(),"lab-output","Changed",null,"test",new Contract("VALUE",fields)),"fixture");
            var validation=repository.validate(draft.object().id(),draft.version().id());
            assertEquals("PINNED_PUBLIC_CONTRACT_INCOMPATIBLE",assertThrows(IllegalArgumentException.class,()->fixture.store.withWriteGuard((session,before)->{
                if(before)session.getMapper(io.gateway.management.ManagementMapper.class).enabled("lab-tool",2,true);
            },()->repository.apply(validation,"fixture","test"))).getMessage());
            repository.apply(repository.validate(draft.object().id(),draft.version().id()),"fixture","test");
            var enabled=send("/management/objects/lab-tool/enabled","POST","{\"enabled\":true,\"generation\":2,\"reason\":\"test\"}",headers);
            assertEquals(400,enabled.statusCode(),enabled.body());
            var head=fixture.server.getApplicationContext().getBean(SecurityDefinitions.class).get("lab-tool",null).object();
            assertFalse(head.enabled());assertEquals(2,head.generation());
            repository.rollback(fixture.output.object().id(),fixture.output.version().id(),repository.get(fixture.output.object().id(),null).object().generation(),"fixture","test");
            var restored=send("/management/objects/lab-tool/enabled","POST","{\"enabled\":true,\"generation\":2,\"reason\":\"test\"}",headers);
            assertEquals(200,restored.statusCode(),restored.body());
            assertEquals(0,fixture.sourceCalls.get());
        }
    }
    @Test void mappedPublicToolPinsStayStableAndTransitiveChangesRequireRevalidation()throws Exception {
        try(var fixture=new GatewayFixture(directory,-1)) {
            base=fixture.server.getURI();
            var app=fixture.server.getApplicationContext();var repository=app.getBean(DefinitionRepository.class);
            var definitions=app.getBean(SecurityDefinitions.class);
            var input=(Contract)fixture.input.detail();var output=(Contract)fixture.output.detail();
            var publicOutput=publish(repository,"mapped-public-output",new Contract("VALUE",output.fields().stream().map(f->
                new Field("public-"+f.id(),f.logicalName(),null,"public_"+f.memberName(),f.nodeKind(),f.valueType(),f.ordinal(),f.required(),f.nullable(),f.precision(),f.scale(),f.maxLength(),f.auditDisposition())).toList()));
            var inputMapping=publish(repository,"tool-input-mapping",new Converter("basic",fixture.input.object().id(),fixture.input.object().id(),
                input.fields().stream().map(f->new Rule("INPUT",f.id(),f.id(),"COPY",List.of())).toList()));
            var outputMapping=publish(repository,"tool-output-mapping",new Converter("basic",fixture.output.object().id(),publicOutput.object().id(),
                output.fields().stream().map(f->new Rule("INPUT",f.id(),"public-"+f.id(),"COPY",List.of())).toList()));
            var detail=new LinkedHashMap<>(definitions.get("lab-tool",null).detail());
            detail.put("public_name","mapped-tool");detail.put("public_output_contract_version_id",publicOutput.version().id());
            detail.put("input_mapping_object_id",inputMapping.object().id());detail.put("output_mapping_object_id",outputMapping.object().id());
            var invalidMapping=new LinkedHashMap<>(detail);
            invalidMapping.put("public_name","invalid-mapping-tool");invalidMapping.put("output_mapping_object_id",inputMapping.object().id());
            var invalid=definitions.draft(new SecurityDefinitions.Draft(null,"invalid-mapping-tool","Invalid mapping",null,"test","MCP_TOOL",invalidMapping),"fixture");
            assertEquals("PINNED_PUBLIC_CONTRACT_INCOMPATIBLE",assertThrows(IllegalArgumentException.class,
                ()->definitions.validate(invalid.object().id(),invalid.version().id())).getMessage());
            var draft=definitions.draft(new SecurityDefinitions.Draft(null,"mapped-tool","Mapped",null,"test","MCP_TOOL",detail),"fixture");
            var validation=definitions.validate(draft.object().id(),draft.version().id());
            assertEquals(fixture.datasource.version().id(),validation.dependencyVersions().get(fixture.datasource.object().id()));
            var source=repository.draft(new Draft(fixture.datasource.object().id(),"lab-source","Republished",null,"test",fixture.datasource.detail()),"fixture");
            repository.apply(repository.validate(source.object().id(),source.version().id()),"fixture","test");
            assertEquals("STALE_VALIDATION",assertThrows(IllegalStateException.class,()->definitions.apply(draft.object().id(),draft.version().id(),
                validation.generation(),validation.dependencyVersions(),"fixture","test")).getMessage());
            var current=definitions.validate(draft.object().id(),draft.version().id());
            definitions.apply(draft.object().id(),draft.version().id(),current.generation(),current.dependencyVersions(),"fixture","test");
            // The public contract is pinned: changing an unrelated public definition head is not a republish.
            var separatePin=publish(repository,"separate-public-output",new Contract("VALUE",output.fields().stream().map(f->
                new Field("pinned-"+f.id(),f.logicalName(),f.parentFieldId(),f.memberName(),f.nodeKind(),f.valueType(),f.ordinal(),f.required(),f.nullable(),f.precision(),f.scale(),f.maxLength(),f.auditDisposition())).toList()));
            var pinDetail=new LinkedHashMap<>(definitions.get("lab-tool",null).detail());
            pinDetail.put("public_name","pinned-tool");pinDetail.put("public_output_contract_version_id",separatePin.version().id());
            var pinned=definitions.draft(new SecurityDefinitions.Draft(null,"pinned-tool","Pinned",null,"test","MCP_TOOL",pinDetail),"fixture");
            var pinnedValidation=definitions.validate(pinned.object().id(),pinned.version().id());
            definitions.apply(pinned.object().id(),pinned.version().id(),pinnedValidation.generation(),pinnedValidation.dependencyVersions(),"fixture","test");
            var changedPin=repository.draft(new Draft(separatePin.object().id(),"separate-public-output","Changed head",null,"test",new Contract("VALUE",List.of())),"fixture");
            repository.apply(repository.validate(changedPin.object().id(),changedPin.version().id()),"fixture","test");
            assertEquals(separatePin.version().id(),definitions.get(pinned.object().id(),null).detail().get("public_output_contract_version_id"));
            assertEquals(0,fixture.sourceCalls.get());
            String token=(String)authorize().get("access_token");
            var mapped=rpc("tools/call",Map.of("patientId","A","documentId","DA"),token,"mapped-tool");
            assertEquals(200,mapped.statusCode(),mapped.body());assertTrue(mapped.body().contains("\"public_answer\":\"합성 정상 결과\""),mapped.body());
            assertEquals(1,fixture.sourceCalls.get());
            var pinnedCall=rpc("tools/call",Map.of("patientId","A","documentId","DA"),token,"pinned-tool");
            assertEquals(200,pinnedCall.statusCode(),pinnedCall.body());assertTrue(pinnedCall.body().contains("SUCCEEDED"),pinnedCall.body());
            assertEquals(2,fixture.sourceCalls.get());
        }
    }
    private static Saved publish(DefinitionRepository repository,String key,Detail detail) {
        var draft=repository.draft(new Draft(null,key,key,null,"test",detail),"fixture");
        return repository.apply(repository.validate(draft.object().id(),draft.version().id()),"fixture","test");
    }
}
