package io.gateway;

import com.nimbusds.oauth2.sdk.http.HTTPRequest;
import io.gateway.oauth.*;
import io.gateway.persistence.PlatformStore;
import io.micronaut.context.ApplicationContext;
import io.micronaut.runtime.server.EmbeddedServer;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.function.BooleanSupplier;
import java.util.regex.Pattern;
import org.apache.hc.client5.http.classic.methods.HttpUriRequestBase;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static io.gateway.oauth.SecurityFixture.*;
import static org.junit.jupiter.api.Assertions.*;

class OAuthProtocolEdgesHttpTest {
    @TempDir Path directory;
    private static final Map<String,String> FORM=Map.of("Content-Type","application/x-www-form-urlencoded");

    @Test void protectedResourceDiscoveryAndHostileAuthorityHeadersKeepCanonicalPkceFlow() throws Exception {
        try(var fixture=new GatewayFixture(directory,-1);var http=new GatewayHttpClient(fixture.server.getURI())) {
            var challenge=http.send("/mcp","POST","{}",Map.of("Content-Type","application/json"));
            assertEquals(401,challenge.statusCode());
            var metadataLink=Pattern.compile("resource_metadata=\"([^\"]+)\"").matcher(challenge.headers().firstValue("www-authenticate").orElseThrow());
            assertTrue(metadataLink.find());URI prm=URI.create(metadataLink.group(1));
            assertEquals(ISSUER+"/.well-known/oauth-protected-resource/mcp",prm.toString());
            var resource=http.send(prm.getRawPath(),"GET",null,Map.of());assertEquals(200,resource.statusCode());
            assertEquals(Map.of("resource",RESOURCE,"authorization_servers",List.of(ISSUER),"bearer_methods_supported",List.of("header")),http.object(resource));
            String issuer=((List<?>)http.object(resource).get("authorization_servers")).getFirst().toString();
            var metadata=http.send(URI.create(issuer+"/.well-known/oauth-authorization-server").getRawPath(),"GET",null,Map.of());
            assertEquals(200,metadata.statusCode());var as=http.object(metadata);
            assertEquals(ISSUER,as.get("issuer"));assertEquals(ISSUER+"/oauth/authorize",as.get("authorization_endpoint"));
            assertEquals(ISSUER+"/oauth/token",as.get("token_endpoint"));assertEquals(ISSUER+"/oauth/revoke",as.get("revocation_endpoint"));
            assertEquals(List.of("S256"),as.get("code_challenge_methods_supported"));assertEquals(List.of("code"),as.get("response_types_supported"));
            assertEquals(List.of("authorization_code","refresh_token"),as.get("grant_types_supported"));
            assertEquals(List.of("none","client_secret_basic"),as.get("token_endpoint_auth_methods_supported"));
            assertEquals(List.of("none","client_secret_basic"),as.get("revocation_endpoint_auth_methods_supported"));
            assertEquals(true,as.get("authorization_response_iss_parameter_supported"));
            assertFalse(as.containsKey("registration_endpoint"));assertFalse(as.containsKey("dpop_signing_alg_values_supported"));assertFalse(as.containsKey("mtls_endpoint_aliases"));

            var browser=http.login("USER");String state="host-bound-state-sentinel";
            var parameters=authorizeParameters("public",REDIRECT,"clinical.read");parameters.put("state",List.of(state));
            var authorize=hostile(fixture,URI.create(as.get("authorization_endpoint").toString()).getRawPath()+"?"+flatForm(parameters),"GET",null,Map.of("Cookie",browser.cookie()));
            assertEquals(303,authorize.status());URI consentLocation=URI.create(authorize.location());
            assertEquals(ISSUER+"/auth/consent",consentLocation.getScheme()+"://"+consentLocation.getAuthority()+consentLocation.getPath());
            String request=query(authorize.location()).get("request_id").getFirst();
            var callback=hostile(fixture,"/auth/requests/"+request+"/consent","POST",consentBody(http,"A"),consentHeaders(browser));
            assertEquals(200,callback.status());
            @SuppressWarnings("unchecked") var consent=(Map<String,Object>)http.json.readValue(callback.body(),Map.class);
            String redirect=consent.get("redirectUri").toString();
            assertTrue(redirect.startsWith(REDIRECT+"?"));var response=query(redirect);
            assertEquals(List.of(ISSUER),response.get("iss"));assertEquals(List.of(state),response.get("state"));assertFalse(redirect.contains("attacker.invalid"));
            var code=new Code(response.get("code").getFirst(),"public",VERIFIER,REDIRECT,request);
            var token=http.send(URI.create(as.get("token_endpoint").toString()).getRawPath(),"POST",exchangeForm(code),FORM);
            assertEquals(200,token.statusCode());String access=http.object(token).get("access_token").toString();
            var revoke=http.send(URI.create(as.get("revocation_endpoint").toString()).getRawPath(),"POST",form(Map.of("client_id","public","token",access)),FORM);
            assertEquals(200,revoke.statusCode());assertEquals(401,http.call(access,Map.of("patientId","A","documentId","DA")).statusCode());

            var mixed=authorizeParameters("public",REDIRECT,"clinical.read");mixed.put("iss",List.of("https://attacker.invalid"));
            var rejected=hostile(fixture,"/oauth/authorize?"+flatForm(mixed),"GET",null,Map.of("Cookie",browser.cookie()));
            assertEquals(303,rejected.status());var error=query(rejected.location());
            assertEquals(List.of("invalid_request"),error.get("error"));assertEquals(List.of(ISSUER),error.get("iss"));
            assertEquals(List.of("synthetic-state-sentinel"),error.get("state"));assertFalse(rejected.location().contains("attacker.invalid"));
            assertEquals(0,fixture.sourceCalls.get());
        }
    }

    @Test void consentRequiresItsOwnOriginAndCsrfEvenWithCorrectPkceAndSession() throws Exception {
        try(var fixture=new GatewayFixture(directory,-1);var http=new GatewayHttpClient(fixture.server.getURI())) {
            var browser=http.login("USER");String request=begin(http,browser);
            for(String invalid:List.of("missing-origin","foreign-origin","missing-csrf","wrong-csrf")) {
                var headers=new LinkedHashMap<>(consentHeaders(browser));
                switch(invalid) {
                    case "missing-origin"->headers.remove("Origin");
                    case "foreign-origin"->headers.put("Origin","https://attacker.invalid");
                    case "missing-csrf"->headers.remove("X-CSRF-Token");
                    case "wrong-csrf"->headers.put("X-CSRF-Token","forged-csrf");
                }
                var denied=http.send("/auth/requests/"+request+"/consent","POST",consentBody(http,"A"),headers);
                assertEquals(403,denied.statusCode(),invalid);
                assertEquals(200,http.send("/auth/requests/"+request,"GET",null,Map.of("Cookie",browser.cookie())).statusCode());
            }
            assertEquals(0,count(fixture.store,"SELECT COUNT(*) FROM oauth_grant"));
            assertEquals(0,count(fixture.store,"SELECT COUNT(*) FROM oauth_authorization_code"));
            var callback=http.send("/auth/requests/"+request+"/consent","POST",consentBody(http,"A"),consentHeaders(browser));
            assertEquals(200,callback.statusCode());assertTrue(query(http.object(callback).get("redirectUri").toString()).containsKey("code"));
            assertEquals(0,fixture.sourceCalls.get());
        }
    }

    @Test void discardedTokenAndRefreshResponsesCannotBeRecoveredOrTriggerBusinessReplay() throws Exception {
        try(var fixture=new GatewayFixture(directory,-1);var http=new GatewayHttpClient(fixture.server.getURI())) {
            var lost=code(http);discardResponse(fixture,exchangeForm(lost),()->count(fixture.store,"SELECT COUNT(*) FROM oauth_access_token")==1);
            var retry=http.send("/oauth/token","POST",exchangeForm(lost),FORM);
            assertEquals(400,retry.statusCode());assertEquals("invalid_grant",http.object(retry).get("error"));
            assertEquals(1,count(fixture.store,"SELECT COUNT(*) FROM oauth_access_token"));
            assertEquals(405,http.send("/oauth/token?"+form(Map.of("code",lost.value(),"client_id","public")),"GET",null,Map.of()).statusCode());

            var normal=http.send("/oauth/token","POST",exchangeForm(code(http)),FORM);assertEquals(200,normal.statusCode());
            var tokens=http.object(normal);String refresh=tokens.get("refresh_token").toString();
            String rotate=form(Map.of("grant_type","refresh_token","client_id","public","refresh_token",refresh,"resource",RESOURCE));
            discardResponse(fixture,rotate,()->count(fixture.store,"SELECT COUNT(*) FROM oauth_access_token")==3);
            var refreshRetry=http.send("/oauth/token","POST",rotate,FORM);
            assertEquals(400,refreshRetry.statusCode());assertEquals("invalid_grant",http.object(refreshRetry).get("error"));
            assertEquals(3,count(fixture.store,"SELECT COUNT(*) FROM oauth_access_token"));
            assertEquals(2,count(fixture.store,"SELECT COUNT(*) FROM oauth_access_token WHERE revoked_at IS NOT NULL"));
            assertEquals(401,http.call(tokens.get("access_token").toString(),Map.of("patientId","A","documentId","DA")).statusCode());

            var admin=http.login("MANAGEMENT");var headers=Map.of("Cookie",admin.cookie());
            var records=http.send("/management/security/tokens","GET",null,headers);assertEquals(200,records.statusCode());
            @SuppressWarnings("unchecked") var rows=(List<Map<String,Object>>)http.json.readValue(records.body(),List.class);
            assertEquals(3,rows.size());
            for(var row:rows) {
                assertFalse(row.containsKey("access_token"));assertFalse(row.containsKey("refresh_token"));assertFalse(row.containsKey("token_digest"));
                assertEquals(404,http.send("/management/security/tokens/"+row.get("id"),"GET",null,headers).statusCode());
            }
            assertFalse(records.body().contains(refresh));assertFalse(records.body().contains(tokens.get("access_token").toString()));
            assertEquals(0,fixture.sourceCalls.get());assertEquals(0,count(fixture.store,"SELECT COUNT(*) FROM execution"));
        }
    }

    @Test void actualServerStartupRejectsMissingMandatorySettingsKeysAndUnboundedLifetimes() throws Exception {
        Files.writeString(directory.resolve("state.key"),Base64.getEncoder().encodeToString(new byte[32]));
        var configured=new LinkedHashMap<>(SecurityFixture.properties(directory));
        configured.put("micronaut.server.port",-1);configured.put("micronaut.server.host","127.0.0.1");
        for(String property:SecurityFixture.properties(directory).keySet()) {
            if(!property.startsWith("gateway.oauth."))continue;
            var missing=new LinkedHashMap<>(configured);missing.remove(property);
            assertStartupRejected(missing);
        }
        for(Object key:List.of(directory.resolve("missing.key").toString(),directory.resolve("short.key").toString())) {
            Files.writeString(directory.resolve("short.key"),Base64.getEncoder().encodeToString(new byte[16]));
            var invalid=new LinkedHashMap<>(configured);invalid.put("gateway.oauth.state-key-file",key);assertStartupRejected(invalid);
        }
        for(long lifetime:List.of(0L,-1L,Long.MAX_VALUE)) {
            var invalid=new LinkedHashMap<>(configured);invalid.put("gateway.oauth.access-ttl-seconds",lifetime);assertStartupRejected(invalid);
        }
        // No test environment/authority replacement: complete config on an empty store must not create a default administrator.
        try(var app=ApplicationContext.builder().deduceEnvironment(false).environmentPropertySource(false).properties(configured).start()) {
            var server=app.getBean(EmbeddedServer.class).start();
            try(var http=new GatewayHttpClient(server.getURI())) {
                var pre=http.send("/auth/session","GET",null,Map.of());assertEquals(200,pre.statusCode());
                String cookie=pre.headers().firstValue("set-cookie").orElseThrow().split(";",2)[0];
                var headers=Map.of("Cookie",cookie,"Origin",ISSUER,"X-CSRF-Token",http.object(pre).get("csrfToken").toString(),"Content-Type","application/json");
                for(String credential:List.of("admin","admin:admin","synthetic-admin")) {
                    var login=http.send("/auth/session/login","POST",http.json.writeValueAsString(Map.of("credential",credential,"sessionKind","MANAGEMENT")),headers);
                    assertEquals(503,login.statusCode());
                }
                assertEquals(false,http.object(http.send("/auth/session","GET",null,Map.of("Cookie",cookie))).get("authenticated"));
                var management=http.send("/management/security/tokens","GET",null,Map.of("Cookie",cookie));
                assertEquals("DENY",http.object(management).get("outcome"));
                var store=app.getBean(PlatformStore.class);
                assertEquals(0,count(store,"SELECT COUNT(*) FROM principal_ref"));assertEquals(0,count(store,"SELECT COUNT(*) FROM oauth_access_token"));
            }
        }
    }

    private static void assertStartupRejected(Map<String,Object> properties) {
        try(var app=ApplicationContext.builder().deduceEnvironment(false).environmentPropertySource(false).properties(properties).build()) {
            assertThrows(RuntimeException.class,()->{app.start();app.getBean(EmbeddedServer.class).start();});
        }
    }
    private static long count(PlatformStore store,String sql){return store.read(s->s.getMapper(SecurityFixture.FixtureMapper.class).count(sql));}
    private static String begin(GatewayHttpClient http,GatewayHttpClient.Browser browser) throws Exception {
        var response=http.send("/oauth/authorize?"+flatForm(authorizeParameters("public",REDIRECT,"clinical.read")),"GET",null,Map.of("Cookie",browser.cookie()));
        assertEquals(303,response.statusCode());return query(response.headers().firstValue("location").orElseThrow()).get("request_id").getFirst();
    }
    private static Code code(GatewayHttpClient http) throws Exception {
        var browser=http.login("USER");String request=begin(http,browser);
        var consent=http.send("/auth/requests/"+request+"/consent","POST",consentBody(http,"A"),consentHeaders(browser));
        assertEquals(200,consent.statusCode());return new Code(query(http.object(consent).get("redirectUri").toString()).get("code").getFirst(),"public",VERIFIER,REDIRECT,request);
    }
    private static String consentBody(GatewayHttpClient http,String patient){return http.json.writeValueAsString(new OAuthService.Consent("synthetic-care",List.of(new OAuthService.ActionTarget("clinical.lab.read",patient(patient))),true));}
    private static Map<String,String> consentHeaders(GatewayHttpClient.Browser browser){return Map.of("Cookie",browser.cookie(),"Origin",ISSUER,"X-CSRF-Token",browser.csrf(),"Content-Type","application/json");}
    private static String flatForm(Map<String,List<String>> values){var flat=new LinkedHashMap<String,String>();values.forEach((key,value)->flat.put(key,value.getFirst()));return form(flat);}
    private static Map<String,List<String>> query(String uri){return new HTTPRequest(HTTPRequest.Method.GET,URI.create(uri)).getQueryStringParameters();}
    private record Wire(int status,String location,String body) {}
    private static Wire hostile(GatewayFixture fixture,String path,String method,String body,Map<String,String> headers) throws Exception {
        try(var client=HttpClients.custom().disableAutomaticRetries().disableRedirectHandling().build()) {
            var request=new HttpUriRequestBase(method,fixture.server.getURI().resolve(path));headers.forEach(request::setHeader);
            request.setHeader("Host","attacker.invalid");request.setHeader("X-Forwarded-Host","attacker.invalid");request.setHeader("X-Forwarded-Proto","http");
            request.setHeader("Forwarded","host=attacker.invalid;proto=http");if(body!=null)request.setEntity(new StringEntity(body,ContentType.APPLICATION_JSON));
            return client.execute(request,response->new Wire(response.getCode(),response.getFirstHeader("Location")==null?null:response.getFirstHeader("Location").getValue(),response.getEntity()==null?"":EntityUtils.toString(response.getEntity(),StandardCharsets.UTF_8)));
        }
    }
    private static void discardResponse(GatewayFixture fixture,String body,BooleanSupplier committed) throws Exception {
        try(var socket=new Socket("127.0.0.1",fixture.server.getPort())) {
            byte[] bytes=body.getBytes(StandardCharsets.UTF_8);
            socket.getOutputStream().write(("POST /oauth/token HTTP/1.1\r\nHost: 127.0.0.1:"+fixture.server.getPort()+"\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: "+bytes.length+"\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
            socket.getOutputStream().write(bytes);socket.getOutputStream().flush();
            long deadline=System.nanoTime()+Duration.ofSeconds(10).toNanos();
            while(!committed.getAsBoolean()&&System.nanoTime()<deadline)Thread.sleep(10);
            assertTrue(committed.getAsBoolean(),"Issuance must commit before the client discards its unread response");
            // Deliberately close without reading a status line or token body; the client cannot recover that response.
        }
    }
}
