package io.gateway.operations;

import io.gateway.authorization.AccessDenied;
import io.gateway.oauth.SecurityFixture;
import io.gateway.results.ResultMapper;
import io.gateway.results.ResultModels.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import java.util.*;
import static io.gateway.operations.ResultsOperationsTest.*;
import static org.junit.jupiter.api.Assertions.*;

class ResultRevisionBindingTest {
    @TempDir Path directory;

    @Test void reorderedRepeatedItemsKeepTheirOwnReferencesAndRetainPriorRevisionBindings() throws Exception {
        try(var fixture=new SecurityFixture(directory)) {
            seedRepeatedContract(fixture);
            var service=service(fixture);var principal=principal(fixture,"public","A");
            execution(fixture,principal,"execution","A");
            String alpha=service.recordWebReference(principal,"execution",new WebObservation("https://records.example/notes/alpha","Alpha",null));
            String beta=service.recordWebReference(principal,"execution",new WebObservation("https://records.example/notes/beta","Beta",null));
            var first=service.create(principal,request(false,alpha,beta));
            var firstRead=service.read(principal,first.id());
            assertEquals(Map.of("items",List.of(Map.of("code","alpha","text","반복 항목"),Map.of("code","beta","text","반복 항목"))),firstRead.data());
            assertBindings(firstRead.values(),firstRead.references(),Map.of("alpha",alpha,"beta",beta));
            var revised=service.revise(principal,first.id(),new ReviseResult(first.revisionId(),request(true,alpha,beta)));
            var current=service.read(principal,first.id());
            assertEquals(2,current.revision());assertEquals(revised.revisionId(),current.revisionId());
            assertNotEquals(first.revisionId(),current.revisionId());
            assertEquals(Map.of("items",List.of(Map.of("code","beta","text","반복 항목"),Map.of("code","alpha","text","반복 항목"))),current.data());
            assertBindings(current.values(),current.references(),Map.of("alpha",alpha,"beta",beta));
            var oldIds=new HashSet<>(firstRead.values().stream().map(StoredValue::id).toList());
            assertTrue(current.values().stream().noneMatch(v->oldIds.contains(v.id())),"Each revision owns new occurrence IDs, never the old positional IDs");
            // There is no public historical-revision route: inspect retained typed rows, not a fabricated API.
            var retainedValues=fixture.store.read(s->s.getMapper(ResultMapper.class).values(first.revisionId()));
            var retainedReferences=fixture.store.read(s->s.getMapper(ResultMapper.class).references(first.revisionId()));
            assertEquals(new HashSet<>(firstRead.values()),new HashSet<>(retainedValues));
            assertEquals(firstRead.references(),retainedReferences);
            assertBindings(retainedValues,retainedReferences,Map.of("alpha",alpha,"beta",beta));
            assertEquals("https://records.example/notes/alpha",service.resolve(principal,alpha).directUrl());
            assertEquals("https://records.example/notes/beta",service.resolve(principal,beta).directUrl());
            var bad=request(true,alpha,beta);
            var missingKey=new CreateResult(bad.executionId(),bad.outputContractVersionId(),bad.externalGenerationId(),bad.submittedModel(),bad.values(),List.of(new ReferenceInput(alpha,"removed-item",0)));
            assertThrows(IllegalArgumentException.class,()->service.revise(principal,first.id(),new ReviseResult(current.revisionId(),missingKey)));
            assertEquals(current.revisionId(),service.read(principal,first.id()).revisionId());
            fixture.authority.outcome="DENY";
            assertThrows(AccessDenied.class,()->service.read(principal,first.id()));
            assertThrows(AccessDenied.class,()->service.resolve(principal,alpha));
            fixture.authority.outcome="ALLOW";
            assertBindings(service.read(principal,first.id()).values(),current.references(),Map.of("alpha",alpha,"beta",beta));
        }
    }

    private static CreateResult request(boolean reversed,String alpha,String beta) {
        var values=new ArrayList<ValueInput>();
        values.add(value("items",null,"items",0,"ARRAY",null));
        for(String code:reversed?List.of("beta","alpha"):List.of("alpha","beta")) {
            int ordinal=code.equals(reversed?"beta":"alpha")?0:1;
            values.add(value(code,"items","item",ordinal,"OBJECT",null));
            values.add(value(code+"-code",code,"code",0,"STRING",code));
            values.add(value(code+"-text",code,"text",1,"STRING","반복 항목"));
        }
        // Citation order stays fixed while the repeated item order changes.
        return new CreateResult("execution","repeated-contract-v1","synthetic-generation",null,values,List.of(new ReferenceInput(alpha,"alpha-text",0),new ReferenceInput(beta,"beta-text",1)));
    }
    private static ValueInput value(String key,String parent,String field,int ordinal,String type,String text) {
        return new ValueInput(key,parent,field,ordinal,type,text,null,null,null);
    }
    private static void assertBindings(List<StoredValue> values,List<StoredReference> references,Map<String,String> expected) {
        var byId=new HashMap<String,StoredValue>();values.forEach(v->byId.put(v.id(),v));
        var actual=new HashMap<String,String>();
        for(var reference:references) {
            var text=byId.get(reference.resultValueId());assertNotNull(text);
            assertEquals("text",text.fieldId());assertEquals("반복 항목",text.textValue());
            var item=byId.get(text.parentValueId());assertNotNull(item);assertEquals("item",item.fieldId());
            String code=values.stream().filter(v->item.id().equals(v.parentValueId())&&v.fieldId().equals("code")).findFirst().orElseThrow().textValue();
            assertNull(actual.put(code,reference.referenceId()),"No two citations may silently collapse onto the same item");
        }
        assertEquals(expected,actual);
    }
    private static void seedRepeatedContract(SecurityFixture fixture) {
        object(fixture,"repeated-contract","CONTRACT");
        fixture.sql("INSERT INTO contract_version(version_id,model_kind) VALUES('repeated-contract-v1','VALUE')");
        for(String field:List.of("items","item","code","text"))fixture.sql("INSERT INTO contract_field(id,contract_object_id,logical_name) VALUES('"+field+"','repeated-contract','"+field+"')");
        fixture.sql("INSERT INTO contract_field_version(contract_version_id,field_id,parent_field_id,member_name,node_kind,value_type,ordinal,required,nullable,audit_disposition) VALUES"
                +"('repeated-contract-v1','items',NULL,'items','ARRAY',NULL,0,true,false,'PERSIST'),"
                +"('repeated-contract-v1','item','items',NULL,'OBJECT',NULL,0,true,false,'PERSIST'),"
                +"('repeated-contract-v1','code','item','code','SCALAR','STRING',0,true,false,'PERSIST'),"
                +"('repeated-contract-v1','text','item','text','SCALAR','STRING',1,true,false,'PERSIST')");
        fixture.sql("UPDATE config_object SET current_version_id='repeated-contract-v1',revision_counter=1,generation=1 WHERE id='repeated-contract'");
    }
}
