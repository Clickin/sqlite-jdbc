package io.gateway.mcp;

import org.junit.jupiter.api.Test;
import java.nio.charset.StandardCharsets;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class Mcp2026AdapterTest {
    private final Mcp2026Adapter adapter=new Mcp2026Adapter();
    private static Map<String,List<String>> headers(String name) {
        return Map.of("mcp-protocol-version",List.of("2026-07-28"),"MCP-METHOD",List.of("tools/call"),
                "mcp-name",List.of(name),"Accept",List.of("application/json, text/event-stream"));
    }
    private String body(String name) {
        return adapter.serialize(Map.of("jsonrpc","2.0","id",7,"method","tools/call","params",Map.of(
            "name",name,"arguments",Map.of("patient","A"),"_meta",Map.of(
                Mcp2026Adapter.PROTOCOL,"2026-07-28",Mcp2026Adapter.CAPABILITIES,Map.of()))));
    }
    @Test void independentPostsDecodeHeaderOnceAndDoNotCreateSession() {
        String name="검사조회";
        String encoded="=?base64?"+Base64.getEncoder().encodeToString(name.getBytes(StandardCharsets.UTF_8))+"?=";
        assertEquals(name,adapter.request(body(name),headers(encoded)).parameters().get("name"));
        assertEquals("tools/call",adapter.request(body("lab"),headers("lab")).rpc().method());
        String sentinel="=?base64?literal?=";
        String escaped="=?base64?"+Base64.getEncoder().encodeToString(sentinel.getBytes(StandardCharsets.UTF_8))+"?=";
        assertEquals(sentinel,adapter.request(body(sentinel),headers(escaped)).parameters().get("name"));
        var result=adapter.result(7,Map.of("content",List.of(),"isError",false));
        assertEquals("complete",((Map<?,?>)result.get("result")).get("resultType"));
    }
    @Test void headersMetadataDuplicateKeysAndVersionsFailBeforeDispatch() {
        var mismatch=assertThrows(Mcp2026Adapter.ProtocolFailure.class,()->adapter.request(body("lab"),headers("other")));
        assertEquals(-32020,mismatch.code); assertEquals(400,mismatch.status);
        var absent=new HashMap<>(headers("lab")); absent.remove("mcp-name");
        assertEquals(-32020,assertThrows(Mcp2026Adapter.ProtocolFailure.class,()->adapter.request(body("lab"),absent)).code);
        String noCapabilities=body("lab").replace("\"io.modelcontextprotocol/clientCapabilities\":{}","\"notCapabilities\":{}");
        assertEquals(-32602,assertThrows(Mcp2026Adapter.ProtocolFailure.class,()->adapter.request(noCapabilities,headers("lab"))).code);
        String duplicate=body("lab").replace("\"jsonrpc\":\"2.0\"","\"jsonrpc\":\"2.0\",\"jsonrpc\":\"2.0\"");
        assertEquals(-32700,assertThrows(Mcp2026Adapter.ProtocolFailure.class,()->adapter.request(duplicate,headers("lab"))).code);
        var oldHeaders=new HashMap<>(headers("lab"));oldHeaders.put("mcp-protocol-version",List.of("2025-11-25"));
        var old=assertThrows(Mcp2026Adapter.ProtocolFailure.class,()->adapter.request(body("lab").replace("2026-07-28","2025-11-25"),oldHeaders));
        assertEquals(-32022,old.code);assertEquals(List.of("2026-07-28"),old.data.get("supported"));
        assertThrows(Mcp2026Adapter.ProtocolFailure.class,()->adapter.request(body("lab")+" {}",headers("lab")));
    }
}
