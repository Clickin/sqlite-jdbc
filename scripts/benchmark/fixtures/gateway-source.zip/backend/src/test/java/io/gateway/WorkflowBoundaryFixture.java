package io.gateway;

import io.gateway.definitions.DefinitionRepository;
import io.gateway.definitions.Definitions.*;
import io.gateway.oauth.*;
import io.gateway.persistence.PlatformStore;
import io.gateway.runtime.Payload;
import io.micronaut.context.ApplicationContext;
import io.micronaut.runtime.server.EmbeddedServer;
import java.nio.file.*;
import java.sql.DriverManager;
import java.util.*;

/** Synthetic registered MyBatis source -> basic converter -> loopback HTTP write target. */
final class WorkflowBoundaryFixture implements AutoCloseable {
    static final String REST_RESOURCE=SecurityFixture.ISSUER+"/api";
    static final String RAW_TEXT="WORKFLOW_RECOVERABLE_BODY_NEVER_PERSIST";
    static final Map<String,Object> ARGUMENTS=Map.of("patientId","A","documentId","DA");
    static final List<String> ACTIONS=List.of("clinical.lab.read","clinical.order.write");
    final EmbeddedServer server;
    final PlatformStore store;
    final SyntheticAuthority authority;

    WorkflowBoundaryFixture(Path directory,String targetUri,long timeout,boolean seed)throws Exception {
        this(directory,targetUri,timeout,seed,Map.of());
    }
    WorkflowBoundaryFixture(Path directory,String targetUri,long timeout,boolean seed,Map<String,Object> overrides)throws Exception {
        Files.createDirectories(directory);
        Path key=directory.resolve("state.key");
        if(!Files.exists(key))Files.writeString(key,Base64.getEncoder().encodeToString(new byte[32]));
        var properties=new HashMap<>(SecurityFixture.properties(directory));
        properties.put("micronaut.server.port",-1);properties.put("micronaut.server.host","127.0.0.1");
        properties.put("gateway.oauth.rest-resource",REST_RESOURCE);
        properties.put("gateway.execution.timeout-ms",timeout);
        properties.putAll(overrides);
        server=ApplicationContext.run(EmbeddedServer.class,properties,"test");
        store=server.getApplicationContext().getBean(PlatformStore.class);
        authority=server.getApplicationContext().getBean(SyntheticAuthority.class);
        // Console configuration privilege alone is not clinical authority; grant both explicitly in this fixture.
        authority.administratorRoles=Set.of("administrator","clinician");
        try {if(seed)seed(directory,targetUri);}
        catch(Exception|Error failure){server.close();throw failure;}
    }

    private void seed(Path directory,String targetUri)throws Exception {
        SecurityFixture.seed(store);
        String sourceUrl="jdbc:sqlite:"+directory.resolve("clinical.db").toAbsolutePath();
        try(var connection=DriverManager.getConnection(sourceUrl);var statement=connection.createStatement()) {
            statement.execute("CREATE TABLE synthetic_record(patient_id TEXT,document_id TEXT,record_text TEXT)");
            statement.execute("INSERT INTO synthetic_record VALUES('A','DA','"+RAW_TEXT+"')");
        }
        var repository=server.getApplicationContext().getBean(DefinitionRepository.class);
        var input=publish(repository,"write-input",new Contract("VALUE",List.of(
                field("request-patient","patientId",0,"PERSIST"),field("request-document","documentId",1,"PERSIST"))));
        var sourceOutput=publish(repository,"source-output",new Contract("VALUE",List.of(
                field("source-patient","patientId",0,"PERSIST"),field("source-document","documentId",1,"PERSIST"),field("source-text","recordText",2,"OMIT_RECOVERABLE"))));
        var targetInput=publish(repository,"target-input",new Contract("VALUE",List.of(
                field("target-patient","patientId",0,"PERSIST"),field("target-document","documentId",1,"PERSIST"),field("target-text","orderText",2,"OMIT_RECOVERABLE"))));
        var output=publish(repository,"write-output",new Contract("VALUE",List.of(field("receipt","receipt",0,"PERSIST"))));
        var source=publish(repository,"jdbc-source",new JdbcSource(sourceUrl,"SQLITE",null,0,1,1000,true,4,1000));
        String xml="""
                <?xml version="1.0"?>
                <!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "https://mybatis.org/dtd/mybatis-3-mapper.dtd">
                <mapper namespace="workflow"><select id="read" resultType="map">
                SELECT patient_id AS patientId,document_id AS documentId,record_text AS recordText
                FROM synthetic_record WHERE patient_id=#{patientId} AND document_id=#{documentId}
                </select></mapper>
                """;
        var mapper=publish(repository,"registered-mapper",new Mapper("SQLITE",List.of(new MapperDocument("workflow.xml",xml)),List.of()));
        var read=publish(repository,"source-read",new JdbcOperation(source.object().id(),input.object().id(),sourceOutput.object().id(),Effect.READ_ONLY,
                5000,1,4096L,mapper.object().id(),"workflow.read","SELECT_ONE","READ_ONLY",List.of(),List.of()));
        var converter=publish(repository,"registered-converter",new Converter("basic",sourceOutput.object().id(),targetInput.object().id(),List.of(
                new Rule("INPUT","source-patient","target-patient","COPY",List.of()),
                new Rule("INPUT","source-document","target-document","COPY",List.of()),
                new Rule("INPUT","source-text","target-text","COPY",List.of()))));
        var target=publish(repository,"http-target",new HttpSource(targetUri,"NONE",null,null,null,null,2,2,1000,"NEVER",4,1000,List.of()));
        var request=publish(repository,"target-json-request",new Representation(targetInput.object().id(),"json","DEFAULT","application/json","UTF-8",List.of(),List.of()));
        var response=publish(repository,"target-json-response",new Representation(output.object().id(),"json","DEFAULT","application/json","UTF-8",List.of(),List.of()));
        var write=publish(repository,"target-write",new HttpOperation(target.object().id(),targetInput.object().id(),output.object().id(),Effect.WRITE,
                10000,1,4096L,"POST","write",request.object().id(),response.object().id(),List.of(),List.of(new ExpectedStatus(200,"SUCCEEDED")),List.of()));
        store.write(s->{var m=s.getMapper(SecurityFixture.FixtureMapper.class);
            m.execute("INSERT INTO oauth_resource VALUES('rest-resource','"+REST_RESOURCE+"','REST','Workflow fixture',true)");
            // Publish a new revision; immutable public-v1 child rows are never changed.
            m.execute("INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name) VALUES('public-v2','public','OAUTH_CLIENT',2,2,'fixture','REST resource','Synthetic client')");
            m.execute("INSERT INTO oauth_client_version SELECT 'public-v2',kind,client_type,token_endpoint_auth_method,display_name,require_pkce_s256,refresh_enabled FROM oauth_client_version WHERE version_id='public-v1'");
            m.execute("INSERT INTO oauth_client_redirect SELECT 'public-v2',redirect_uri,native_loopback_port_policy,ordinal FROM oauth_client_redirect WHERE client_version_id='public-v1'");
            m.execute("INSERT INTO oauth_client_scope SELECT 'public-v2',scope_id FROM oauth_client_scope WHERE client_version_id='public-v1'");
            m.execute("INSERT INTO oauth_client_action SELECT 'public-v2',action_id,action_semantic_version FROM oauth_client_action WHERE client_version_id='public-v1'");
            m.execute("INSERT INTO oauth_client_resource VALUES('public-v2','mcp-resource'),('public-v2','rest-resource')");
            m.execute("UPDATE config_object SET current_version_id='public-v2',revision_counter=2,generation=2 WHERE id='public'");
            for(String policy:List.of("read-policy","write-policy")) {
                object(m,policy,"TARGET_POLICY");
                m.execute("INSERT INTO target_policy_version(version_id,target_kind,canonical_organization,identifier_system,require_parent_patient) VALUES('"+policy+"-v1','DOCUMENT','synthetic-hospital','synthetic-mrn',true)");
                m.execute("INSERT INTO target_argument_binding VALUES('"+policy+"-v1','REQUEST','request-patient','PATIENT',0),('"+policy+"-v1','REQUEST','request-document','DOCUMENT',1)");
                if(policy.equals("write-policy"))m.execute("INSERT INTO target_argument_binding VALUES('write-policy-v1','CONTEXT','target-patient','PATIENT',2),('write-policy-v1','CONTEXT','target-document','DOCUMENT',3)");
                activate(m,policy);
            }
            return null;
        });
        var workflow=publish(repository,"write-workflow",new Workflow(null,List.of(new Stage("INPUT",0,read.object().id(),null),
                new Stage("CONVERT",1,null,converter.object().id()),new Stage("OUTPUT",2,write.object().id(),null)),List.of(),List.of(
                new SecurityBinding("INPUT","security","clinical.lab.read","read-policy"),
                new SecurityBinding("OUTPUT","security","clinical.order.write","write-policy"))));
        store.write(s->{var m=s.getMapper(SecurityFixture.FixtureMapper.class);object(m,"lab-tool","MCP_TOOL");
            m.execute("INSERT INTO mcp_tool_version(version_id,public_name,description,workflow_object_id,public_input_contract_version_id,public_output_contract_version_id,security_binding_object_id,target_policy_object_id,effect_kind) VALUES('lab-tool-v1','lab-tool','Synthetic write workflow','"+workflow.object().id()+"','"+input.version().id()+"','"+output.version().id()+"','security','read-policy','WRITE')");
            m.execute("INSERT INTO mcp_tool_action VALUES('lab-tool-v1','clinical.lab.read'),('lab-tool-v1','clinical.order.write')");
            m.execute("INSERT INTO mcp_tool_scope VALUES('lab-tool-v1','read'),('lab-tool-v1','write')");activate(m,"lab-tool");return null;
        });
    }
    void sql(String sql){store.write(s->{s.getMapper(SecurityFixture.FixtureMapper.class).execute(sql);return null;});}
    long count(String sql){return store.read(s->s.getMapper(SecurityFixture.FixtureMapper.class).count(sql));}
    private static Field field(String id,String member,int ordinal,String disposition){return new Field(id,member,null,member,"SCALAR","STRING",ordinal,true,false,null,null,1024,Payload.Disposition.valueOf(disposition));}
    private static Saved publish(DefinitionRepository repository,String key,Detail detail){var draft=repository.draft(new Draft(null,key,key,null,"synthetic boundary fixture",detail),"fixture");return repository.apply(repository.validate(draft.object().id(),draft.version().id()),"fixture","synthetic boundary fixture");}
    private static void object(SecurityFixture.FixtureMapper m,String id,String kind){m.execute("INSERT INTO config_object(id,kind,logical_key,created_at,created_by) VALUES('"+id+"','"+kind+"','"+id+"',1,'fixture')");m.execute("INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name) VALUES('"+id+"-v1','"+id+"','"+kind+"',1,1,'fixture','synthetic','Synthetic')");}
    private static void activate(SecurityFixture.FixtureMapper m,String id){m.execute("UPDATE config_object SET current_version_id='"+id+"-v1',revision_counter=1,generation=1 WHERE id='"+id+"'");}
    @Override public void close(){server.close();}
    public static void main(String[] args)throws Exception {
        var overrides=new HashMap<String,Object>();
        if(args.length>3){overrides.put("gateway.oauth.issuer",args[3]);overrides.put("gateway.oauth.public-origin",args[3]);}
        if(args.length>4)overrides.put("micronaut.server.port",Integer.parseInt(args[4]));
        long timeout=args.length>5?Long.parseLong(args[5]):30000;
        try(var fixture=new WorkflowBoundaryFixture(Path.of(args[0]),args[1],timeout,Boolean.parseBoolean(args[2]),overrides)) {
            System.out.println("WORKFLOW_BOUNDARY_READY "+fixture.server.getURI());System.out.flush();
            System.in.read();
        } catch(Exception|Error failure) {
            String code=failure instanceof PlatformStore.StoreException?" "+failure.getMessage():"";
            System.err.println("WORKFLOW_BOUNDARY_FAILED "+failure.getClass().getSimpleName()+code);
            System.err.flush();System.exit(1);
        }
    }
}
