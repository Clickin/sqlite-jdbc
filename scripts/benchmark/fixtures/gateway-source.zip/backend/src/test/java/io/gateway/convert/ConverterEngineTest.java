package io.gateway.convert;

import io.gateway.definitions.Definitions.*;
import io.gateway.runtime.*;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

final class ConverterEngineTest {
    private Field field(String id,String parent,String member,String kind,String type,int order,boolean nullable,Payload.Disposition disposition){return new Field(id,id,parent,member,kind,type,order,true,nullable,null,null,null,disposition);}
    private Saved saved(String id,Detail detail){return new Saved(new Head(id,detail.kind().name(),id,id+"-v",1,1,true),new Version(id+"-v",id,detail.kind().name(),1,0,"fixture","fixture",id,null),detail);}
    private Rule rule(String from,String to,String transform,Argument... args){return new Rule("INPUT",from,to,transform,List.of(args));}
    @Test void listRenameExactNumbersNullDefaultsAndSensitivitySurvive(){
        Payload.Disposition persist=Payload.Disposition.PERSIST,omit=Payload.Disposition.OMIT_RECOVERABLE;
        Contract input=new Contract("VALUE",List.of(field("rows",null,"rows","ARRAY",null,0,false,persist),field("row","rows",null,"OBJECT",null,0,false,persist),field("text","row","recordText","SCALAR","STRING",0,false,omit),field("amount","row","amount","SCALAR","STRING",1,false,persist),field("optional","row","optional","SCALAR","STRING",2,true,persist)));
        Contract output=new Contract("VALUE",List.of(field("items",null,"items","ARRAY",null,0,false,persist),field("item","items",null,"OBJECT",null,0,false,persist),field("renamed","item","renamed","SCALAR","STRING",0,false,persist),field("decimal","item","decimal","SCALAR","DECIMAL",1,false,persist),field("defaulted","item","defaulted","SCALAR","STRING",2,false,persist)));
        Converter converter=new Converter("basic","input","output",List.of(rule("rows","items","COPY"),rule("text","renamed","COPY"),rule("amount","decimal","DECIMAL"),rule("optional","defaulted","DEFAULT_NULL",new Argument("value","STRING","fallback",null,null,null))));
        ResolvedGraph graph=new ResolvedGraph("converter",Map.of("input",saved("input",input),"output",saved("output",output),"converter",saved("converter",converter)));
        Map<String,Object> first=new LinkedHashMap<>();first.put("recordText","NEVER_PERSIST_SENTINEL");first.put("amount","12345678901234567890.123456789");first.put("optional",null);
        Payload result=new ConverterEngine(graph,converter).convert(Payload.of(Map.of("rows",List.of(first))));
        var rows=(List<?>)result.object().get("items");var row=(Map<?,?>)rows.getFirst();assertEquals("NEVER_PERSIST_SENTINEL",row.get("renamed"));assertEquals(new BigDecimal("12345678901234567890.123456789"),row.get("decimal"));assertEquals("fallback",row.get("defaulted"));assertEquals(omit,result.dispositions().get("renamed"));assertFalse(result.toString().contains("SENTINEL"));
        var publicFields=output.fields().stream().map(f->new io.gateway.contracts.ContractService.Field(
            "public-"+f.id(),f.parentFieldId()==null?null:"public-"+f.parentFieldId(),f.memberName(),f.nodeKind(),f.valueType(),
            f.ordinal(),f.required(),f.nullable(),f.precision(),f.scale(),f.maxLength(),f.auditDisposition().name())).toList();
        var publicContract=new io.gateway.contracts.ContractService.Contract("public-contract",publicFields);
        new io.gateway.contracts.ContractService(null).validate(publicContract,result.object());
        var projected=io.gateway.audit.AuditProjection.project("RESPONSE",io.gateway.contracts.ContractAudit.values(publicContract,result));
        assertTrue(projected.stream().noneMatch(p->"NEVER_PERSIST_SENTINEL".equals(p.stringValue())));
        assertEquals("OMIT_RECOVERABLE",projected.stream().filter(p->"renamed".equals(p.parameterName())).findFirst().orElseThrow().exclusionReason());
        assertEquals("12345678901234567890.123456789",projected.stream().filter(p->"decimal".equals(p.parameterName())).findFirst().orElseThrow().decimalText());
        assertEquals("fallback",projected.stream().filter(p->"defaulted".equals(p.parameterName())).findFirst().orElseThrow().stringValue());
        first.put("amount","not-a-number");ExecutionFailure failure=assertThrows(ExecutionFailure.class,()->new ConverterEngine(graph,converter).convert(Payload.of(Map.of("rows",List.of(first)))));assertFalse(failure.toString().contains("not-a-number"));
    }
    @Test void integerOverflowAndUnmappedCodesRejectWithoutCoercion(){
        Contract in=new Contract("VALUE",List.of(field("in",null,"value","SCALAR","STRING",0,false,Payload.Disposition.PERSIST)));Contract out=new Contract("VALUE",List.of(field("out",null,"value","SCALAR","INTEGER",0,false,Payload.Disposition.PERSIST)));
        Converter converter=new Converter("basic","input","output",List.of(rule("in","out","INTEGER")));
        ResolvedGraph graph=new ResolvedGraph("converter",Map.of("input",saved("input",in),"output",saved("output",out),"converter",saved("converter",converter)));
        ConverterEngine engine=new ConverterEngine(graph,converter);assertThrows(ExecutionFailure.class,()->engine.convert(Payload.of(Map.of("value","9223372036854775808"))));assertThrows(ExecutionFailure.class,()->engine.convert(Payload.of(Map.of("value","1.5"))));assertEquals(42L,engine.convert(Payload.of(Map.of("value","42"))).object().get("value"));
    }
}
