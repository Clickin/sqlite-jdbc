package io.gateway.contracts;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class ContractServiceTest {
    private final ContractService service = new ContractService(null);
    private static ContractService.Field field(String id,String parent,String name,String kind,String type,boolean required,boolean nullable) {
        return new ContractService.Field(id,parent,name,kind,type,0,required,nullable,null,null,null,"PERSIST");
    }
    @Test void nestedListsDatesNullAndUnknownSecurityFieldsUseOneContract() {
        var contract = new ContractService.Contract("v1",List.of(
            field("p",null,"patient","SCALAR","STRING",true,false),
            field("a",null,"values","ARRAY",null,true,false),
            field("e","a","item","OBJECT",null,true,false),
            field("d","e","date","SCALAR","DATE",true,false),
            field("n","e","number","SCALAR","DECIMAL",false,true)));
        var values = new HashMap<String,Object>();
        values.put("patient","A");
        values.put("values",List.of(Map.of("date","2024-02-29","number",new BigDecimal("0.1234567890123456789"))));
        service.validate(contract,values);
        var schema=service.schema(contract);
        assertEquals(false,schema.get("additionalProperties"));
        assertThrows(ContractService.InvalidContract.class,()->service.validate(contract,Map.of("patient","A","values",List.of(Map.of("date","2023-02-29")))));
        values.put("authorized",Map.of("patient","B"));
        assertThrows(ContractService.InvalidContract.class,()->service.validate(contract,values));
        values.remove("authorized");
        assertEquals("A",service.value(contract,values,"p"));
        assertEquals("B",service.bindCanonical(contract,values,Map.of("p","B")).get("patient"));
        assertEquals("A",values.get("patient"));
    }
    @Test void recursiveAndUnsupportedContractCannotPublish() {
        var cyclic = new ContractService.Contract("bad",List.of(
            field("a","b","a","OBJECT",null,true,false),field("b","a","b","OBJECT",null,true,false)));
        assertThrows(ContractService.InvalidContract.class,()->service.schema(cyclic));
        var unsupported = new ContractService.Contract("bad",List.of(field("a",null,"xml","XML",null,true,false)));
        assertThrows(ContractService.InvalidContract.class,()->service.schema(unsupported));
    }
}
