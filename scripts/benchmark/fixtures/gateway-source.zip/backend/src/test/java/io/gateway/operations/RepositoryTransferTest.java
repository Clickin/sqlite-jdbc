package io.gateway.operations;

import io.gateway.audit.AuditService;
import io.gateway.credentials.CredentialMapper;
import io.gateway.credentials.CredentialService;
import io.gateway.oauth.*;
import io.gateway.persistence.PlatformStore;
import io.gateway.results.ResultModels.ReferenceInput;
import io.gateway.results.ResultModels.WebObservation;
import io.gateway.results.ResultModels.ReviseResult;
import io.gateway.results.ResultModels.CreateResult;
import io.gateway.results.ResultModels.ValueInput;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class RepositoryTransferTest {
    @TempDir Path directory;
    private static final String EXACT_DECIMAL="12345678901234567890.12345678901234567890";
    private static final Map<String,String> TEMPORAL_VALUES=Map.of(
        "date","2024-02-29","localTime","2024-02-29T23:59:58.123456789",
        "offsetTime","23:59:58.123456789+09:30","instant","2024-02-29T23:59:58.123456789+09:30");
    @Test void sqliteRepositoryTransfer() throws Exception { exercise(false); }
    @Test
    @EnabledIfEnvironmentVariable(named="GATEWAY_TEST_TRANSFER_POSTGRES_URL",matches=".+")
    void postgresRepositoryTransfer() throws Exception { exercise(true); }
    private void exercise(boolean postgres) throws Exception {
        Path sourcePath=Files.createDirectory(directory.resolve("source"));
        Path targetPath=Files.createDirectory(directory.resolve("target"));
        var targetStore=postgres
            ? new PlatformStore(System.getenv("GATEWAY_TEST_TRANSFER_POSTGRES_URL"),System.getenv().getOrDefault("GATEWAY_TEST_POSTGRES_USER",""),System.getenv().getOrDefault("GATEWAY_TEST_POSTGRES_PASSWORD",""),1,5000)
            : new PlatformStore(targetPath.resolve("platform.db"));
        try(var source=new SecurityFixture(sourcePath);var target=new SecurityFixture(targetStore,targetPath,false)) {
            seedTypedValues(source);
            Path key=sourcePath.resolve("transfer.key");
            byte[] keyBytes=new byte[32]; new java.security.SecureRandom().nextBytes(keyBytes);
            Files.write(key,keyBytes); Files.setPosixFilePermissions(key,PosixFilePermissions.fromString("r--------"));
            Arrays.fill(keyBytes,(byte)0);
            var credentials=new CredentialService(source.store,new AuditService(source.store),sourcePath.toString(),"transfer");
            byte[] secret={0,1,127,-1,-128,13,10};
            var credential=credentials.create("transfer-credential","PASSWORD","합성 사용자",secret,"fixture","transfer");
            var cipher=source.store.read(s->s.getMapper(CredentialMapper.class).versionRow(credential.versionId()));
            var token=source.token("A");
            var rotated=source.refresh((String)token.get("refresh_token"));
            source.sql("UPDATE flyway_schema_history SET description='source history must not transfer'");
            source.sql("CREATE TABLE transfer_column_order(id TEXT PRIMARY KEY,enabled INTEGER NOT NULL,label TEXT)");
            target.sql("CREATE TABLE transfer_column_order(label TEXT,enabled "+(postgres?"BOOLEAN":"INTEGER")+" NOT NULL,id TEXT PRIMARY KEY)");
            source.sql("INSERT INTO transfer_column_order VALUES('column-order',true,'한글 순서')");
            var principal=ResultsOperationsTest.principal(source,"public","A");
            ResultsOperationsTest.execution(source,principal,"execution","A");
            var service=ResultsOperationsTest.service(source);
            String reference=service.recordWebReference(principal,"execution",new WebObservation("https://records.example/synthetic","note",null));
            var content=typedRequest(reference,EXACT_DECIMAL);
            var first=service.create(principal,content);
            var saved=service.revise(principal,first.id(),new ReviseResult(first.revisionId(),content));
            assertEquals(expectedValues(EXACT_DECIMAL),saved.data());
            if(!postgres) {
                target.sql("CREATE TRIGGER fail_transfer BEFORE INSERT ON web_reference BEGIN SELECT RAISE(ABORT,'SYNTHETIC_VALUE_MUST_NOT_ESCAPE'); END");
                var failure=assertThrows(IllegalStateException.class,()->RepositoryTransfer.transfer(source.store,target.store));
                assertEquals("TRANSFER_INSERT_FAILED:web_reference",failure.getMessage());
                assertNull(failure.getCause());
                assertEquals(0,target.count("SELECT count(*) FROM config_object"));
                assertEquals(0,target.count("SELECT count(*) FROM generated_result"));
                target.sql("DROP TRIGGER fail_transfer");
            }
            var report=RepositoryTransfer.transfer(source.store,target.store);
            assertEquals(1L,report.rows().get("generated_result"));
            assertEquals(2L,report.rows().get("generated_result_revision"));
            assertFalse(report.rows().containsKey("flyway_schema_history"));
            assertEquals(saved,ResultsOperationsTest.service(target).read(principal,saved.id()));
            assertEquals("https://records.example/synthetic",ResultsOperationsTest.service(target).resolve(principal,reference).directUrl());
            assertEquals(1,target.count("SELECT count(*) FROM flyway_schema_history WHERE success=true AND description<>'source history must not transfer'"));
            assertEquals(1,target.count("SELECT count(*) FROM transfer_column_order WHERE id='column-order' AND enabled=true AND label='한글 순서'"));
            assertEquals(1,target.count("SELECT count(*) FROM contract_field_version WHERE contract_version_id='nested-contract-v1' AND field_id='nested-child' AND parent_field_id='nested-root' AND required=true AND nullable=false"));
            assertEquals(1,target.count("SELECT count(*) FROM audit_parameter WHERE id='typed-integer' AND parent_parameter_id='typed-root' AND ordinal=2 AND integer_value=9223372036854775807"));
            assertEquals(1,target.count("SELECT count(*) FROM audit_parameter WHERE id='typed-decimal' AND decimal_text='12345678901234567890.12345678901234567890'"));
            assertEquals(1,target.count("SELECT count(*) FROM audit_parameter WHERE id='typed-true' AND boolean_value=true"));
            assertEquals(1,target.count("SELECT count(*) FROM audit_parameter WHERE id='typed-false' AND boolean_value=false"));
            assertEquals(1,target.count("SELECT count(*) FROM audit_parameter WHERE id='typed-null' AND value_type='NULL' AND string_value IS NULL"));
            var transferred=target.store.read(s->s.getMapper(CredentialMapper.class).versionRow(credential.versionId()));
            assertTrue(Arrays.equals(cipher.nonce(),transferred.nonce()),"nonce preserved");
            assertTrue(Arrays.equals(cipher.ciphertext(),transferred.ciphertext()),"ciphertext preserved");
            assertTrue(Arrays.equals(cipher.authenticationTag(),transferred.authenticationTag()),"authentication tag preserved");
            var targetCredentials=new CredentialService(target.store,new AuditService(target.store),sourcePath.toString(),"transfer");
            assertEquals(credential,targetCredentials.metadata(credential.objectId()));
            try(var resolved=targetCredentials.resolve(credential.objectId())) { assertTrue(Arrays.equals(secret,resolved.bytes()),"credential still resolves"); }
            var originalPrincipal=source.authenticate(rotated);var transferredPrincipal=target.authenticate(rotated);
            assertEquals(originalPrincipal.principalId(),transferredPrincipal.principalId());
            assertEquals(originalPrincipal.clientId(),transferredPrincipal.clientId());
            assertEquals(originalPrincipal.grantId(),transferredPrincipal.grantId());
            assertEquals(originalPrincipal.resource(),transferredPrincipal.resource());
            assertEquals("Bearer",target.refresh((String)rotated.get("refresh_token")).get("token_type"));
            assertThrows(IllegalStateException.class,()->RepositoryTransfer.transfer(source.store,target.store));
            assertEquals(saved.revisionId(),ResultsOperationsTest.service(target).read(principal,saved.id()).revisionId());
            var targetResults=ResultsOperationsTest.service(target);
            var changed=targetResults.revise(principal,saved.id(),new ReviseResult(saved.revisionId(),typedRequest(reference,"-"+EXACT_DECIMAL)));
            assertEquals(3,changed.revision());
            assertEquals(expectedValues("-"+EXACT_DECIMAL),targetResults.read(principal,saved.id()).data());
            assertEquals(List.of("summary","result-amount","result-date","result-localTime","result-offsetTime","result-instant"),
                changed.values().stream().map(v->v.fieldId()).toList());
            assertThrows(IllegalStateException.class,()->targetResults.revise(principal,saved.id(),new ReviseResult(saved.revisionId(),content)));
            assertEquals(changed,targetResults.read(principal,saved.id()));
        }
    }
    private static CreateResult typedRequest(String reference,String amount) {
        var values=new ArrayList<ValueInput>();
        values.add(new ValueInput("summary",null,"summary",0,"STRING","합성 요약",null,null,null));
        values.add(new ValueInput("amount",null,"result-amount",1,"DECIMAL",null,null,amount,null));
        int ordinal=2;
        for(String name:List.of("date","localTime","offsetTime","instant"))
            values.add(new ValueInput(name,null,"result-"+name,ordinal++,"STRING",TEMPORAL_VALUES.get(name),null,null,null));
        return new CreateResult("execution","result-contract-v1","synthetic-generation","submitted-model-not-observed",values,List.of(new ReferenceInput(reference,null,0)));
    }
    private static Map<String,Object> expectedValues(String amount) {
        var values=new LinkedHashMap<String,Object>(TEMPORAL_VALUES);
        values.put("summary","합성 요약");values.put("amount",new BigDecimal(amount));return values;
    }
    private static void seedTypedValues(SecurityFixture fixture) {
        ResultsOperationsTest.object(fixture,"result-contract","CONTRACT");
        fixture.sql("INSERT INTO contract_version(version_id,model_kind) VALUES('result-contract-v1','VALUE')");
        fixture.sql("INSERT INTO contract_field(id,contract_object_id,logical_name) VALUES('summary','result-contract','summary')");
        fixture.sql("INSERT INTO contract_field_version(contract_version_id,field_id,member_name,node_kind,value_type,ordinal,required,nullable,audit_disposition) VALUES('result-contract-v1','summary','summary','SCALAR','STRING',0,true,false,'PERSIST')");
        fixture.sql("INSERT INTO contract_field(id,contract_object_id,logical_name) VALUES('result-amount','result-contract','amount')");
        fixture.sql("INSERT INTO contract_field_version(contract_version_id,field_id,member_name,node_kind,value_type,ordinal,required,nullable,precision,scale,audit_disposition) VALUES('result-contract-v1','result-amount','amount','SCALAR','DECIMAL',1,true,false,40,20,'PERSIST')");
        var temporalTypes=Map.of("date","DATE","localTime","DATETIME","offsetTime","TIME","instant","INSTANT");
        int ordinal=2;
        for(String name:List.of("date","localTime","offsetTime","instant")) {
            fixture.sql("INSERT INTO contract_field(id,contract_object_id,logical_name) VALUES('result-"+name+"','result-contract','"+name+"')");
            fixture.sql("INSERT INTO contract_field_version(contract_version_id,field_id,member_name,node_kind,value_type,ordinal,required,nullable,audit_disposition) VALUES('result-contract-v1','result-"+name+"','"+name+"','SCALAR','"+temporalTypes.get(name)+"',"+ordinal+++",true,false,'PERSIST')");
        }
        fixture.sql("UPDATE config_object SET current_version_id='result-contract-v1',revision_counter=1,generation=1 WHERE id='result-contract'");
        ResultsOperationsTest.object(fixture,"nested-contract","CONTRACT");
        fixture.store.write(session->{
            var sql=session.getMapper(SecurityFixture.FixtureMapper.class);
            sql.execute("PRAGMA defer_foreign_keys=ON");
            sql.execute("INSERT INTO contract_version(version_id,model_kind) VALUES('nested-contract-v1','VALUE')");
            sql.execute("INSERT INTO contract_field(id,contract_object_id,logical_name) VALUES('nested-root','nested-contract','root'),('nested-child','nested-contract','child')");
            // Deliberately store children first: transfer must order composite self-FKs, not rely on SELECT row order.
            sql.execute("INSERT INTO contract_field_version(contract_version_id,field_id,parent_field_id,member_name,node_kind,value_type,ordinal,required,nullable,audit_disposition) VALUES('nested-contract-v1','nested-child','nested-root','child','SCALAR','STRING',0,true,false,'PERSIST')");
            sql.execute("INSERT INTO contract_field_version(contract_version_id,field_id,member_name,node_kind,ordinal,required,nullable,audit_disposition) VALUES('nested-contract-v1','nested-root','root','OBJECT',0,true,false,'PERSIST')");
            sql.execute("UPDATE config_object SET current_version_id='nested-contract-v1',revision_counter=1,generation=1 WHERE id='nested-contract'");
            sql.execute("INSERT INTO audit_event(id,event_type,occurred_at,actor_subject_id,caller_service_id,outcome) VALUES('typed-event','TRANSFER_FIXTURE',9223372036854775807,'fixture','fixture','SUCCEEDED')");
            sql.execute("INSERT INTO audit_parameter(id,audit_event_id,parent_parameter_id,ordinal,port,value_type,boolean_value) VALUES('typed-true','typed-event','typed-root',0,'INPUT','BOOLEAN',true),('typed-false','typed-event','typed-root',1,'INPUT','BOOLEAN',false)");
            sql.execute("INSERT INTO audit_parameter(id,audit_event_id,parent_parameter_id,ordinal,port,value_type,integer_value) VALUES('typed-integer','typed-event','typed-root',2,'INPUT','INTEGER',9223372036854775807)");
            sql.execute("INSERT INTO audit_parameter(id,audit_event_id,parent_parameter_id,ordinal,port,value_type,decimal_text) VALUES('typed-decimal','typed-event','typed-root',3,'INPUT','DECIMAL','12345678901234567890.12345678901234567890')");
            sql.execute("INSERT INTO audit_parameter(id,audit_event_id,parent_parameter_id,ordinal,port,value_type) VALUES('typed-null','typed-event','typed-root',4,'INPUT','NULL')");
            sql.execute("INSERT INTO audit_parameter(id,audit_event_id,ordinal,port,value_type) VALUES('typed-root','typed-event',0,'INPUT','OBJECT')");
            return null;
        });
    }
}
