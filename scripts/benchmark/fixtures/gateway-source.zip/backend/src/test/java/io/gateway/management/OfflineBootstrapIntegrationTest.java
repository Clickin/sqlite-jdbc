package io.gateway.management;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import io.gateway.authorization.AccessDenied;
import io.gateway.authorization.CanonicalTarget;
import io.gateway.definitions.DefinitionRepository;
import io.gateway.definitions.Definitions.*;
import io.gateway.identity.ConfiguredAuthority;
import io.gateway.oauth.OAuthSettings;
import io.gateway.persistence.PlatformMapper;
import io.gateway.persistence.PlatformStore;
import io.gateway.runtime.InternalOperationExecutor;
import io.gateway.runtime.Payload.Disposition;
import io.micronaut.context.ApplicationContext;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import org.apache.ibatis.annotations.Select;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import tools.jackson.databind.json.JsonMapper;
import static org.junit.jupiter.api.Assertions.*;

/** Only loopback services, disposable keys and synthetic credentials; no authority replacement. */
public final class OfflineBootstrapIntegrationTest {
    private static final JsonMapper JSON=JsonMapper.builder().build();
    private static final String CREDENTIAL="synthetic-submitted-credential";
    private static final String SERVICE_SECRET="synthetic-source-service-secret";
    private static final String SUBJECT="synthetic-authority-subject";
    private static final String ADMIN="synthetic-external-administrator";
    private static final String ORIGIN="https://bootstrap.example";
    @TempDir Path directory;

    @Test void successfulManifestPublishesUsableConfiguredAuthorityAndNeverOverwritesIt() throws Exception {
        try(var sources=new Sources()) {
            var manifest=manifest(sources.identityUri(),sources.permissionUri());
            Path input=writeInputs(directory,manifest);
            Path database=directory.resolve("platform.db");
            String printed=bootstrap(arguments(database,input,directory));
            assertTrue(printed.contains("BOOTSTRAP_SUCCEEDED"));
            String binding=printed.lines().filter(line->line.startsWith("gateway.oauth.security-binding-id="))
                .findFirst().orElseThrow().substring("gateway.oauth.security-binding-id=".length());
            UUID.fromString(binding);
            assertFalse(printed.contains(SERVICE_SECRET));
            assertEquals(0,sources.calls.get(),"Offline import must not call the remote authority");
            assertEquals(PosixFilePermissions.fromString("rw-------"),Files.getPosixFilePermissions(database));
            assertNoStaging(directory,database);
            byte[] original=Files.readAllBytes(database);
            assertEquals("NEW_DATABASE_REQUIRED",assertThrows(IllegalArgumentException.class,
                ()->OfflineBootstrap.run(arguments(database,input,directory))).getMessage());
            assertArrayEquals(original,Files.readAllBytes(database));

            try(var app=ApplicationContext.builder().deduceEnvironment(false).properties(Map.of(
                "micronaut.server.enabled",false,"gateway.database.url","jdbc:sqlite:"+database,
                "gateway.database.reader-size",2,"gateway.credentials.key-directory",directory.toString(),
                "gateway.credentials.active-key-id","synthetic")).start()) {
                var store=app.getBean(PlatformStore.class);
                sources.store.set(store);
                assertEquals("ok",store.read(s->s.getMapper(IntegrityMapper.class).integrity()));
                assertTrue(store.read(s->s.getMapper(IntegrityMapper.class).foreignKeys()).isEmpty());
                var repository=app.getBean(DefinitionRepository.class);
                var heads=repository.list();
                Set<String> expected=new TreeSet<>();
                manifest.entries().stream().filter(e->Set.of("DEFINITION","SECURITY","CREDENTIAL").contains(e.type()))
                    .forEach(e->expected.add(e.document().get("logicalKey").toString()));
                assertEquals(expected,new TreeSet<>(heads.stream().map(Head::logicalKey).toList()));
                for(var head:heads) {
                    assertNotNull(head.currentVersionId(),head.logicalKey());
                    assertEquals(1,head.generation(),head.logicalKey());
                    assertEquals(head.currentVersionId(),repository.history(head.id()).getFirst().id());
                }
                var security=app.getBean(SecurityDefinitions.class).get(binding,null);
                assertEquals("SECURITY_BINDING",security.detailType());
                var identityOperation=(HttpOperation)repository.get(security.detail().get("identity_operation_object_id").toString(),null).detail();
                var permissionOperation=(HttpOperation)repository.get(security.detail().get("authorization_operation_object_id").toString(),null).detail();
                assertNotEquals(identityOperation.sourceObjectId(),permissionOperation.sourceObjectId());
                assertEquals(sources.identityUri(),((HttpSource)repository.get(identityOperation.sourceObjectId(),null).detail()).baseUri());
                assertEquals(sources.permissionUri(),((HttpSource)repository.get(permissionOperation.sourceObjectId(),null).detail()).baseUri());
                assertEquals(Set.of("config.manage","security.manage","client.manage","audit.read"),
                    store.read(s->s.getMapper(IntegrityMapper.class).administratorActions(binding)));
                assertEquals(Set.of("config.manage","security.manage","client.manage","audit.read"),
                    store.read(s->s.getMapper(IntegrityMapper.class).scopeActions()));
                assertEquals(ORIGIN+"/mcp",store.read(s->s.getMapper(IntegrityMapper.class).resource()));

                // OAuthSettings is intentionally excluded from headless DI, not replaced with an ALLOW authority.
                var settings=new OAuthSettings(ORIGIN,ORIGIN+"/mcp",ORIGIN,binding,60,300,600,1200,120,300,600,
                    directory.resolve("state.key").toString());
                var authority=new ConfiguredAuthority(store,app.getBean(InternalOperationExecutor.class),settings);
                var identity=authority.authenticate(CREDENTIAL);
                assertEquals(SUBJECT,identity.subject());
                assertNotEquals(CREDENTIAL,identity.subject());
                assertEquals(security.detail().get("identity_operation_object_id"),identity.providerId());
                assertTrue(identity.active());
                assertThrows(AccessDenied.class,()->authority.authenticate("wrong-synthetic-credential"));
                assertEquals(Set.of(ADMIN),authority.roles(identity.providerId(),identity.subject()));
                sources.roles.set(List.of("synthetic-reader"));
                assertEquals(Set.of("synthetic-reader"),authority.roles(identity.providerId(),identity.subject()));
                var decision=authority.decide(identity.providerId(),identity.subject(),"config.manage",CanonicalTarget.service());
                assertEquals("ALLOW",decision.outcome());
                assertEquals("synthetic-permission-reference",decision.decisionId());
                assertEquals(Set.of("synthetic-reader"),decision.roles());
                sources.outcome.set("DENY");
                assertEquals("DENY",authority.decide(identity.providerId(),identity.subject(),"config.manage",CanonicalTarget.service()).outcome());
                sources.permissionUnavailable.set(true);
                var unavailable=assertThrows(AccessDenied.class,()->authority.decide(identity.providerId(),identity.subject(),"config.manage",CanonicalTarget.service()));
                assertEquals(AccessDenied.Outcome.UNAVAILABLE,unavailable.outcome());
                assertNull(sources.failure.get());
                assertEquals(7,sources.calls.get());
                assertEquals(7,sources.writerCommits.get(),"The single platform writer must remain available while remote calls are in flight");
                long remoteWriterEvents=store.read(s->s.getMapper(IntegrityMapper.class).remoteWriterEvents());
                assertEquals(7L,remoteWriterEvents);
            }
        }
    }

    @Test void failedImportPublishesNothingAndRemovesPartialDatabaseAndLock() throws Exception {
        var valid=manifest("http://127.0.0.1:9","http://127.0.0.1:10");
        for(boolean unmappedAdministrator:List.of(false,true)) {
            var entries=new ArrayList<>(valid.entries());
            if(unmappedAdministrator) {
                var last=entries.removeLast();
                var document=new LinkedHashMap<>(last.document());
                var detail=new LinkedHashMap<>(object(document.get("detail")));
                detail.put("roleMappings",List.of());document.put("detail",detail);
                entries.add(new OfflineBootstrap.Entry(last.name(),last.type(),document));
            } else entries.add(new OfflineBootstrap.Entry("unresolved","RESOURCE",Map.of("resource_uri","$does-not-exist")));
            Path input=writeInputs(directory,new OfflineBootstrap.Manifest(valid.operator(),valid.securityBinding(),entries));
            Path database=directory.resolve(unmappedAdministrator?"unmapped.db":"unresolved.db");
            String expected=unmappedAdministrator?"EXPLICIT_ADMIN_EXTERNAL_ROLE_MAPPING_REQUIRED":"UNRESOLVED_BOOTSTRAP_REFERENCE";
            assertEquals(expected,assertThrows(IllegalArgumentException.class,()->OfflineBootstrap.run(arguments(database,input,directory))).getMessage());
            assertFalse(Files.exists(database));
            assertNoStaging(directory,database);
        }
    }

    public interface IntegrityMapper extends PlatformMapper {
        @Select("PRAGMA integrity_check") String integrity();
        @Select("PRAGMA foreign_key_check") List<Map<String,Object>> foreignKeys();
        @Select("SELECT a.action_key FROM config_object b JOIN external_role_mapping m ON m.security_binding_version_id=b.current_version_id JOIN config_object r ON r.id=m.role_object_id JOIN role_action ra ON ra.role_version_id=r.current_version_id JOIN protected_action a ON a.id=ra.action_id WHERE b.id=#{binding}") Set<String> administratorActions(String binding);
        @Select("SELECT a.action_key FROM oauth_scope s JOIN oauth_scope_action sa ON sa.scope_id=s.id JOIN protected_action a ON a.id=sa.action_id WHERE s.scope_name='synthetic-management'") Set<String> scopeActions();
        @Select("SELECT resource_uri FROM oauth_resource WHERE public_name='Synthetic MCP'") String resource();
        @Select("SELECT COUNT(*) FROM audit_event WHERE event_type='SYNTHETIC_REMOTE_WRITER'") long remoteWriterEvents();
    }

    /** Generates the same bounded typed manifest for a separate invocation of the actual CLI. */
    public static void main(String[] args) throws Exception {
        if(args.length!=1)throw new IllegalArgumentException("Synthetic output directory required");
        Path directory=Path.of(args[0]).toAbsolutePath();Files.createDirectories(directory);
        System.out.println(writeInputs(directory,manifest("http://127.0.0.1:9","http://127.0.0.1:10")));
    }

    static OfflineBootstrap.Manifest manifest(String identityUri,String permissionUri) {
        var entries=new ArrayList<OfflineBootstrap.Entry>();
        var actions=new ArrayList<Map<String,Object>>();
        for(String action:List.of("config.manage","security.manage","client.manage","audit.read")) {
            entries.add(new OfflineBootstrap.Entry(action,"ACTION",Map.of("action_key",action,"target_kind","SERVICE","effect_kind","READ_ONLY","semantic_version",1)));
            actions.add(Map.of("action_id","$"+action,"action_semantic_version",1));
        }
        entries.add(new OfflineBootstrap.Entry("scope","SCOPE",Map.of("scope_name","synthetic-management","description","Synthetic administrator fixture","actions",actions)));
        entries.add(new OfflineBootstrap.Entry("resource","RESOURCE",Map.of("resource_uri",ORIGIN+"/mcp","resource_kind","MCP","public_name","Synthetic MCP")));
        entries.add(new OfflineBootstrap.Entry("credential","CREDENTIAL",object(new OfflineBootstrap.CredentialDocument("synthetic-service-credential","TOKEN",null,"service.secret","synthetic fixture"))));
        definition(entries,"identity-source",new HttpSource(identityUri,"BEARER","$credential",null,null,null,2,2,1000,"NEVER",2,1000,List.of()));
        definition(entries,"permission-source",new HttpSource(permissionUri,"BEARER","$credential",null,null,null,2,2,1000,"NEVER",2,1000,List.of()));
        operation(entries,"identity","identity-source",contract("identity-input",new String[]{"credential"},new String[]{"STRING"},false),
            contract("identity-raw",new String[]{"externalSubject","enabled"},new String[]{"STRING","BOOLEAN"},false),
            contract("identity-output",new String[]{"subject","active"},new String[]{"STRING","BOOLEAN"},false));
        operation(entries,"roles","permission-source",contract("roles-input",new String[]{"subject","identityProvider"},new String[]{"STRING","STRING"},false),
            contract("roles-raw",new String[]{"enabled","externalRoles"},new String[]{"BOOLEAN","ARRAY"},true),
            contract("roles-output",new String[]{"active","roles"},new String[]{"BOOLEAN","ARRAY"},true));
        operation(entries,"permission","permission-source",contract("permission-input",new String[]{"subject","identityProvider","action","targetKind"},new String[]{"STRING","STRING","STRING","STRING"},false),
            contract("permission-raw",new String[]{"verdict","reference","externalRoles"},new String[]{"STRING","STRING","ARRAY"},true),
            contract("permission-output",new String[]{"outcome","decisionId","roles"},new String[]{"STRING","STRING","ARRAY"},true));
        entries.add(new OfflineBootstrap.Entry("administrator","SECURITY",object(new SecurityDefinitions.Draft(null,"synthetic-administrator","Synthetic administrator",null,"synthetic fixture","ROLE",Map.of("actions",actions)))));
        entries.add(new OfflineBootstrap.Entry("authority","SECURITY",object(new SecurityDefinitions.Draft(null,"synthetic-authority","Synthetic authority",null,"synthetic fixture","SECURITY_BINDING",Map.of(
            "identity_operation_object_id","$identity-operation","identity_converter_object_id","$identity-converter",
            "authorization_operation_object_id","$permission-operation","authorization_converter_object_id","$permission-converter",
            "roles_operation_object_id","$roles-operation","roles_converter_object_id","$roles-converter",
            "roleMappings",List.of(Map.of("external_role_code",ADMIN,"role_object_id","$administrator")))))));
        return new OfflineBootstrap.Manifest("synthetic-bootstrap-operator","authority",List.copyOf(entries));
    }

    private static void operation(List<OfflineBootstrap.Entry> entries,String name,String source,Contract input,Contract raw,Contract output) {
        definition(entries,name+"-input",input);definition(entries,name+"-raw",raw);definition(entries,name+"-output",output);
        definition(entries,name+"-request",new Representation("$"+name+"-input","json","DEFAULT","application/json","UTF-8",List.of(),List.of()));
        definition(entries,name+"-response",new Representation("$"+name+"-raw","json","DEFAULT","application/json","UTF-8",List.of(),List.of()));
        definition(entries,name+"-operation",new HttpOperation("$"+source,"$"+name+"-input","$"+name+"-raw",Effect.READ_ONLY,3000,256,16384L,"POST",name,
            "$"+name+"-request","$"+name+"-response",List.of(),List.of(new ExpectedStatus(200,"SUCCEEDED")),List.of()));
        var rules=new ArrayList<Rule>();
        for(int i=0;i<raw.fields().size();i++)rules.add(new Rule("INPUT","$"+name+"-raw.field."+raw.fields().get(i).logicalName(),
            "$"+name+"-output.field."+output.fields().get(i).logicalName(),"COPY",List.of()));
        definition(entries,name+"-converter",new Converter("basic","$"+name+"-raw","$"+name+"-output",rules));
    }

    private static Contract contract(String name,String[] members,String[] types,boolean array) {
        var fields=new ArrayList<Field>();
        for(int i=0;i<members.length;i++)fields.add(new Field(name+"-"+i,members[i],null,members[i],types[i].equals("ARRAY")?"ARRAY":"SCALAR",
            types[i].equals("ARRAY")?null:types[i],i,true,false,null,null,types[i].equals("STRING")?1024:null,
            members[i].equals("credential")?Disposition.OMIT_SECRET:Disposition.PERSIST));
        if(array)fields.add(new Field(name+"-item","roleItem",name+"-"+(members.length-1),null,"SCALAR","STRING",0,true,false,null,null,256,Disposition.PERSIST));
        return new Contract("VALUE",fields);
    }
    private static void definition(List<OfflineBootstrap.Entry> entries,String name,Detail detail) {
        entries.add(new OfflineBootstrap.Entry(name,"DEFINITION",object(new DefinitionController.DraftRequest(null,name,name,null,"synthetic fixture",detail.getClass().getSimpleName(),object(detail)))));
    }
    @SuppressWarnings("unchecked") private static Map<String,Object> object(Object value) { return JSON.convertValue(value,Map.class); }
    private static Path writeInputs(Path directory,OfflineBootstrap.Manifest manifest) throws Exception {
        Path key=directory.resolve("synthetic.key");
        if(!Files.exists(key))Files.write(key,new byte[32],StandardOpenOption.CREATE_NEW);
        Files.setPosixFilePermissions(key,PosixFilePermissions.fromString("r--------"));
        Files.writeString(directory.resolve("service.secret"),SERVICE_SECRET);
        Files.setPosixFilePermissions(directory.resolve("service.secret"),PosixFilePermissions.fromString("rw-------"));
        Files.writeString(directory.resolve("state.key"),Base64.getEncoder().encodeToString(new byte[32]));
        Files.setPosixFilePermissions(directory.resolve("state.key"),PosixFilePermissions.fromString("rw-------"));
        byte[] bytes=JSON.writeValueAsBytes(manifest);
        if(bytes.length>2*1024*1024||manifest.entries().size()>500)throw new AssertionError("Synthetic manifest exceeded CLI bounds");
        Path input=directory.resolve("bootstrap.json");Files.write(input,bytes);
        Files.setPosixFilePermissions(input,PosixFilePermissions.fromString("rw-------"));
        return input;
    }
    private static String[] arguments(Path database,Path input,Path keys) {
        return new String[]{"--database",database.toString(),"--manifest",input.toString(),"--key-directory",keys.toString(),"--active-key-id","synthetic"};
    }
    private static String bootstrap(String[] args) throws Exception {
        var bytes=new ByteArrayOutputStream();PrintStream previous=System.out;
        try(var capture=new PrintStream(bytes,true,StandardCharsets.UTF_8)) {System.setOut(capture);OfflineBootstrap.run(args);}
        finally {System.setOut(previous);}
        return bytes.toString(StandardCharsets.UTF_8);
    }
    private static void assertNoStaging(Path directory,Path database) throws Exception {
        for(String suffix:List.of("-wal","-shm",".bootstrap-lock"))assertFalse(Files.exists(Path.of(database+suffix)),suffix);
        try(var paths=Files.list(directory)){assertFalse(paths.anyMatch(p->p.getFileName().toString().startsWith("."+database.getFileName()+".bootstrap-")));}
    }

    private static final class Sources implements AutoCloseable {
        final HttpServer identity,permission;
        final ExecutorService executor=Executors.newVirtualThreadPerTaskExecutor();
        final AtomicReference<PlatformStore> store=new AtomicReference<>();
        final AtomicReference<List<String>> roles=new AtomicReference<>(List.of(ADMIN));
        final AtomicReference<String> outcome=new AtomicReference<>("ALLOW");
        final AtomicBoolean permissionUnavailable=new AtomicBoolean();
        final AtomicInteger calls=new AtomicInteger(),writerCommits=new AtomicInteger();
        final AtomicReference<Throwable> failure=new AtomicReference<>();
        Sources() throws Exception {
            identity=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
            permission=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
            identity.createContext("/identity",exchange->handle(exchange,"identity"));
            permission.createContext("/roles",exchange->handle(exchange,"roles"));
            permission.createContext("/permission",exchange->handle(exchange,"permission"));
            identity.setExecutor(executor);permission.setExecutor(executor);identity.start();permission.start();
        }
        String identityUri(){return "http://127.0.0.1:"+identity.getAddress().getPort();}
        String permissionUri(){return "http://127.0.0.1:"+permission.getAddress().getPort();}
        private void handle(HttpExchange exchange,String purpose) {
            calls.incrementAndGet();
            try {
                assertEquals("POST",exchange.getRequestMethod());
                assertEquals("Bearer "+SERVICE_SECRET,exchange.getRequestHeaders().getFirst("Authorization"));
                var request=JSON.readValue(exchange.getRequestBody().readNBytes(16385),Map.class);
                // This second thread must commit through the same one-connection writer before replying.
                store.get().write(s->{s.getMapper(ManagementMapper.class).auditMutation(UUID.randomUUID().toString(),"SYNTHETIC_REMOTE_WRITER",
                    System.currentTimeMillis(),"synthetic-source","WRITER_AVAILABLE");return null;});
                writerCommits.incrementAndGet();
                Map<String,Object> response;
                if(purpose.equals("identity"))response=Map.of("externalSubject",SUBJECT,"enabled",CREDENTIAL.equals(request.get("credential")));
                else {
                    assertEquals(SUBJECT,request.get("subject"));
                    UUID.fromString(request.get("identityProvider").toString());
                    if(purpose.equals("roles"))response=Map.of("enabled",true,"externalRoles",roles.get());
                    else {
                        assertEquals("config.manage",request.get("action"));assertEquals("SERVICE",request.get("targetKind"));
                        if(permissionUnavailable.get()){send(exchange,503,Map.of("unavailable",true));return;}
                        response=Map.of("verdict",outcome.get(),"reference","synthetic-permission-reference","externalRoles",roles.get());
                    }
                }
                send(exchange,200,response);
            } catch(Throwable problem) {
                failure.compareAndSet(null,problem);
                try {send(exchange,500,Map.of("failure",true));}catch(Exception ignored){exchange.close();}
            }
        }
        private static void send(HttpExchange exchange,int status,Map<String,Object> value) throws Exception {
            byte[] bytes=JSON.writeValueAsBytes(value);exchange.getResponseHeaders().set("Content-Type","application/json");
            exchange.sendResponseHeaders(status,bytes.length);try(var body=exchange.getResponseBody()){body.write(bytes);}
        }
        @Override public void close(){identity.stop(0);permission.stop(0);executor.close();}
    }
}
