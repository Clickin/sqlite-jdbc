package io.gateway.operations;

import io.gateway.audit.*;
import io.gateway.authorization.*;
import io.gateway.contracts.ContractService;
import io.gateway.oauth.*;
import io.gateway.results.*;
import io.gateway.results.ResultModels.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class ResultsOperationsTest {
    @TempDir Path directory;
    @Test void resultScopeIncludesUncitedExecutionTargetsAndCurrentGrantNotOldProvenance() throws Exception {
        try(var fixture=new SecurityFixture(directory)) {
            seed(fixture); var service=service(fixture);
            var onlyA=principal(fixture,"public","A"); execution(fixture,onlyA,"execution","A","B");
            assertThrows(AccessDenied.class,()->service.create(onlyA,request("execution",List.of())));
            assertTrue(service.list(onlyA).isEmpty());
            var both=principal(fixture,"public","A","B");
            var result=service.create(both,request("execution",List.of()));
            assertEquals(Set.of("A","B"),new HashSet<>(result.targets().stream().map(CanonicalTarget::patientIdentifier).toList()));
            assertEquals(Map.of("summary","합성 요약"),result.data());
            fixture.sql("UPDATE oauth_grant SET revoked_at=1 WHERE id='"+both.grantId()+"'");
            assertThrows(AccessDenied.class,()->service.read(both,result.id()));
            var renewed=principal(fixture,"public","A","B");
            assertEquals(result.revisionId(),service.read(renewed,result.id()).revisionId());
            fixture.authority.outcome="DENY";
            assertThrows(AccessDenied.class,()->service.read(renewed,result.id()));
            fixture.authority.outcome="ALLOW";
            var otherClient=principal(fixture,"confidential","A","B");
            assertThrows(AccessDenied.class,()->service.read(otherClient,result.id()));
            var revised=service.revise(renewed,result.id(),new ReviseResult(result.revisionId(),request("execution",List.of())));
            assertEquals(2,revised.revision());
            assertThrows(IllegalStateException.class,()->service.revise(renewed,result.id(),new ReviseResult(result.revisionId(),request("execution",List.of()))));
            fixture.sql("CREATE TRIGGER fail_result_audit BEFORE INSERT ON audit_event WHEN NEW.event_type='RESULT_SAVED' BEGIN SELECT RAISE(ABORT,'fixture'); END");
            assertThrows(RuntimeException.class,()->service.create(renewed,request("execution",List.of())));
            assertEquals(List.of(result.id()),service.list(renewed).stream().map(ResultSummary::id).toList());
        }
    }
    @Test void toolReferenceKeepsEffectiveArgumentsAndOmissionsWithoutRerunningBusiness() throws Exception {
        try(var fixture=new SecurityFixture(directory)) {
            seed(fixture); var service=service(fixture); var principal=principal(fixture,"public","A"); execution(fixture,principal,"execution","A");
            object(fixture,"source","DATASOURCE"); fixture.sql("INSERT INTO datasource_version(version_id,provider_id,max_concurrent,queue_timeout_ms) VALUES('source-v1','http.json',1,1000)");
            object(fixture,"operation","OPERATION"); fixture.sql("INSERT INTO operation_version(version_id,source_object_id,effect_kind,timeout_ms) VALUES('operation-v1','source','WRITE',1000)");
            object(fixture,"screen","SCREEN_PROFILE"); fixture.sql("INSERT INTO screen_profile_version(version_id,adapter_id,screen_code,allowed_launch_profile) VALUES('screen-v1','registered-hospital','NOTE','read-note')");
            fixture.sql("INSERT INTO screen_parameter_binding VALUES('screen-v1','effective.date','visit_date','STRING',0)");
            fixture.sql("UPDATE config_object SET current_version_id=id || '-v1',revision_counter=1,generation=1 WHERE id IN ('source','operation','screen')");
            fixture.sql("INSERT INTO execution_dependency VALUES('execution','operation','operation-v1'),('execution','source','source-v1')");
            var original=List.of(value("date","today",AuditProjection.Disposition.PERSIST),value("recordText","RECOVERABLE_SENTINEL",AuditProjection.Disposition.OMIT_RECOVERABLE));
            var effective=List.of(value("date","2026-09-25",AuditProjection.Disposition.PERSIST),value("token","SECRET_SENTINEL",AuditProjection.Disposition.OMIT_SECRET));
            String reference=service.recordToolReference(principal,"execution",new ToolObservation("operation","operation-v1","source-v1","screen","screen-v1","synthetic-record",original,effective));
            var result=service.create(principal,request("execution",List.of(new ReferenceInput(reference,"summary",0))));
            fixture.sql("INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name) VALUES('screen-v2','screen','SCREEN_PROFILE',2,2,'fixture','fixture','New screen')");
            fixture.sql("INSERT INTO screen_profile_version(version_id,adapter_id,screen_code,allowed_launch_profile) VALUES('screen-v2','new-hospital','NEW_NOTE','new-note')");
            fixture.sql("INSERT INTO screen_parameter_binding VALUES('screen-v2','effective.date','new_date','STRING',0)");
            fixture.sql("UPDATE config_object SET current_version_id='screen-v2',revision_counter=2,generation=2 WHERE id='screen'");
            var metadata=service.resolve(principal,reference);
            assertEquals(Map.of("visit_date","2026-09-25"),metadata.parameters());
            assertEquals("METADATA_ONLY",metadata.supportStatus());
            assertEquals("registered-hospital",metadata.adapterId());
            assertEquals("NOTE",metadata.screenCode());
            assertEquals("read-note",metadata.launchProfile());
            String pinned=service.recordToolReference(principal,"execution",new ToolObservation("operation","operation-v1","source-v1","screen",null,"synthetic-record",original,effective));
            fixture.sql("UPDATE config_object SET current_version_id='screen-v1' WHERE id='screen'");
            assertEquals(Map.of("new_date","2026-09-25"),service.resolve(principal,pinned).parameters());
            fixture.sql("UPDATE tool_reference SET observed_screen_profile_version_id=NULL WHERE reference_id='"+pinned+"'");
            assertThrows(AccessDenied.class,()->service.resolve(principal,pinned));
            assertEquals(0,fixture.count("SELECT count(*) FROM reference_parameter WHERE string_value IN ('SECRET_SENTINEL','RECOVERABLE_SENTINEL')"));
            assertEquals(1,fixture.count("SELECT count(*) FROM execution"));
            var retention=new RetentionService(fixture.store,fixture.authorization,new AuditService(fixture.store));
            assertEquals(Map.of("AUDIT",0,"GENERATED_RESULT",0),retention.cleanupNow());
            var admin=fixture.authorization.authorizeManagement(fixture.login("MANAGEMENT").cookie(),"config.manage").principal();
            retention.update(admin,"AUDIT",new RetentionService.Update(1L,true,1L,100,0));
            retention.cleanup(System.currentTimeMillis()+2*86400000L,true);
            assertEquals(Map.of("visit_date","2026-09-25"),service.resolve(principal,reference).parameters());
            assertEquals(reference,service.read(principal,result.id()).references().getFirst().referenceId());
            fixture.sql("UPDATE config_object SET enabled=false WHERE id='screen'");
            assertThrows(AccessDenied.class,()->service.resolve(principal,reference));
        }
    }
    @Test void directLinksAreAllowlistedAndSharedReferencesSurviveUntilLastResultExpires() throws Exception {
        try(var fixture=new SecurityFixture(directory)) {
            seed(fixture); var service=service(fixture); var principal=principal(fixture,"public","A"); execution(fixture,principal,"execution","A");
            assertThrows(IllegalArgumentException.class,()->service.recordWebReference(principal,"execution",new WebObservation("https://unregistered.example/note","note",null)));
            assertThrows(IllegalArgumentException.class,()->service.recordWebReference(principal,"execution",new WebObservation("https://records.example/note?token=secret","note",null)));
            String reference=service.recordWebReference(principal,"execution",new WebObservation("https://records.example/note/SYNTHETIC","note",null));
            var first=service.create(principal,request("execution",List.of(new ReferenceInput(reference,null,0))));
            var second=service.create(principal,request("execution",List.of(new ReferenceInput(reference,null,0))));
            assertEquals("https://records.example/note/SYNTHETIC",service.resolve(principal,reference).directUrl());
            var retention=new RetentionService(fixture.store,fixture.authorization,new AuditService(fixture.store));
            var admin=fixture.authorization.authorizeManagement(fixture.login("MANAGEMENT").cookie(),"config.manage").principal();
            retention.update(admin,"GENERATED_RESULT",new RetentionService.Update(1L,true,1L,1,0));
            retention.cleanup(System.currentTimeMillis()+2*86400000L,true);
            assertEquals(1,service.list(principal).size());
            assertEquals(reference,service.resolve(principal,reference).id());
            retention.cleanup(System.currentTimeMillis()+2*86400000L,true);
            assertTrue(service.list(principal).isEmpty());
            assertThrows(AccessDenied.class,()->service.resolve(principal,reference));
            assertNotEquals(first.id(),second.id());
        }
    }
    @Test void broadenedQueryAllowlistCannotPersistAuthenticationOrSecretParameters() throws Exception {
        try(var fixture=new SecurityFixture(directory)) {
            var keys=List.of("refresh_token","client_secret","ACCESS_TOKEN","id.token","client-secret","api_key","authorization","password","X-Amz-Signature","X-Goog-Credential","session_id","client_assertion","refresh%5Ftoken");
            var service=new ResultService(fixture.store,fixture.authorization,new ContractService(fixture.store),new AuditService(fixture.store),"https://records.example","document,"+String.join(",",keys));
            var principal=principal(fixture,"public","A"); execution(fixture,principal,"execution","A");
            for(String key:keys) {
                String url="https://records.example/note?"+key+"=SECRET_SENTINEL";
                assertThrows(IllegalArgumentException.class,()->service.validateWebReferenceCandidate(url),key);
                assertThrows(IllegalArgumentException.class,()->service.recordWebReference(principal,"execution",new WebObservation(url,"note",null)),key);
            }
            for(String query:List.of("document=note;refresh_token=SECRET_SENTINEL","document=note&client%5Fsecret=SECRET_SENTINEL","refresh%255Ftoken=SECRET_SENTINEL")) {
                assertThrows(IllegalArgumentException.class,()->service.recordWebReference(principal,"execution",new WebObservation("https://records.example/note?"+query,"note",null)));
            }
            assertThrows(IllegalArgumentException.class,()->service.validateWebReferenceCandidate("https://user:SECRET_SENTINEL@records.example/note"));
            assertThrows(IllegalArgumentException.class,()->service.validateWebReferenceCandidate("https://records.example/note#SECRET_SENTINEL"));
            assertEquals(0,fixture.count("SELECT count(*) FROM source_reference"));
            assertEquals(0,fixture.count("SELECT count(*) FROM web_reference"));
            assertEquals(0,fixture.count("SELECT count(*) FROM audit_event WHERE event_type='REFERENCE_RECORDED'"));
            String reference=service.recordWebReference(principal,"execution",new WebObservation("https://records.example/note?document=SYNTHETIC","note",null));
            assertEquals("https://records.example/note?document=SYNTHETIC",service.resolve(principal,reference).directUrl());
        }
    }
    @Test void repeatedExecutionTargetsPreserveEveryDistinctReferenceTarget() throws Exception {
        try(var fixture=new SecurityFixture(directory)) {
            var service=service(fixture); var principal=principal(fixture,"public","A","B"); execution(fixture,principal,"execution","A","B");
            fixture.sql("INSERT INTO execution_target(execution_id,stage_key,action_id,target_kind,organization,identifier_system,patient_identifier,outcome) VALUES('execution','OUTPUT','clinical.order.write','PATIENT','synthetic-hospital','synthetic-mrn','A','ALLOW')");
            String reference=service.recordWebReference(principal,"execution",new WebObservation("https://records.example/note/SYNTHETIC","note",null));
            var targets=fixture.store.read(s->s.getMapper(ResultMapper.class).referenceTargets(reference));
            assertEquals(2,targets.size());
            assertEquals(Set.of("A","B"),new HashSet<>(targets.stream().map(CanonicalTarget::patientIdentifier).toList()));
            assertEquals(reference,service.resolve(principal,reference).id());
            var onlyA=principal(fixture,"public","A");
            assertThrows(AccessDenied.class,()->service.resolve(onlyA,reference));
        }
    }
    @Test void restoreRevocationAndBoundedAuthCleanupDoNotDestroyResultOwnership() throws Exception {
        try(var fixture=new SecurityFixture(directory)) {
            seed(fixture); var service=service(fixture); var original=principal(fixture,"public","A");
            execution(fixture,original,"execution","A");
            var saved=service.create(original,request("execution",List.of()));
            var retention=new RetentionService(fixture.store,fixture.authorization,new AuditService(fixture.store));
            retention.cleanupAuthentication();
            assertEquals(saved.id(),service.read(original,saved.id()).id());
            fixture.oauth.invalidateForRestore();
            assertThrows(AccessDenied.class,()->service.read(original,saved.id()));
            retention.cleanupAuthentication();
            assertEquals(0,fixture.count("SELECT count(*) FROM oauth_access_token"));
            assertEquals(0,fixture.count("SELECT count(*) FROM oauth_refresh_token"));
            assertEquals(0,fixture.count("SELECT count(*) FROM oauth_grant"));
            var current=principal(fixture,"public","A");
            assertEquals(saved.revisionId(),service.read(current,saved.id()).revisionId());
        }
    }
    static ResultService service(SecurityFixture fixture) { return new ResultService(fixture.store,fixture.authorization,new ContractService(fixture.store),new AuditService(fixture.store),"https://records.example",""); }
    static AuthenticatedPrincipal principal(SecurityFixture fixture,String client,String... patients) {
        List<OAuthService.ActionTarget> rules=new ArrayList<>();
        for(String patient:patients) for(String action:List.of("result.create","result.read","reference.read","reference.resolve")) rules.add(new OAuthService.ActionTarget(action,SecurityFixture.patient(patient)));
        return fixture.authenticate(fixture.exchange(fixture.code(client,fixture.login("USER"),rules,"clinical.read clinical.write")));
    }
    static CreateResult request(String execution,List<ReferenceInput> references) { return new CreateResult(execution,"result-contract-v1","synthetic-generation","submitted-model-not-observed",List.of(new ValueInput("summary",null,"summary",0,"STRING","합성 요약",null,null,null)),references); }
    static AuditProjection.Value value(String name,String value,AuditProjection.Disposition disposition) { return new AuditProjection.Value(null,name,AuditProjection.Kind.STRING,value,List.of(),disposition); }
    static void seed(SecurityFixture fixture) {
        object(fixture,"result-contract","CONTRACT"); fixture.sql("INSERT INTO contract_version(version_id,model_kind) VALUES('result-contract-v1','VALUE')");
        fixture.sql("INSERT INTO contract_field(id,contract_object_id,logical_name) VALUES('summary','result-contract','summary')");
        fixture.sql("INSERT INTO contract_field_version(contract_version_id,field_id,member_name,node_kind,value_type,ordinal,required,nullable,audit_disposition) VALUES('result-contract-v1','summary','summary','SCALAR','STRING',0,true,false,'PERSIST')");
        fixture.sql("UPDATE config_object SET current_version_id='result-contract-v1',revision_counter=1,generation=1 WHERE id='result-contract'");
    }
    static void object(SecurityFixture fixture,String id,String kind) {
        fixture.sql("INSERT INTO config_object(id,kind,logical_key,created_at,created_by) VALUES('"+id+"','"+kind+"','"+id+"',1,'fixture')");
        fixture.sql("INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name) VALUES('"+id+"-v1','"+id+"','"+kind+"',1,1,'fixture','fixture','Synthetic')");
    }
    static void execution(SecurityFixture fixture,AuthenticatedPrincipal principal,String id,String... patients) {
        fixture.sql("INSERT INTO execution(id,trace_id,actor_subject_id,caller_service_id,started_at,finished_at,business_outcome,response_outcome,principal_id,client_object_id,public_grant_id) VALUES('"+id+"','trace','"+principal.subject()+"','"+principal.clientId()+"',1,2,'SUCCEEDED','SUCCEEDED','"+principal.principalId()+"','"+principal.clientId()+"','"+principal.grantId()+"')");
        for(String patient:patients) fixture.sql("INSERT INTO execution_target(execution_id,stage_key,action_id,target_kind,organization,identifier_system,patient_identifier,outcome) VALUES('"+id+"','SOURCE','clinical.lab.read','PATIENT','synthetic-hospital','synthetic-mrn','"+patient+"','ALLOW')");
    }
}
