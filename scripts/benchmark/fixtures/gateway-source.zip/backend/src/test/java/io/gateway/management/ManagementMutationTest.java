package io.gateway.management;

import io.gateway.authorization.AccessDenied;
import io.gateway.credentials.CredentialService;
import io.gateway.definitions.*;
import io.gateway.definitions.Definitions.*;
import io.gateway.oauth.*;
import io.gateway.persistence.PlatformStore;
import io.micronaut.context.ApplicationContext;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.cookie.Cookie;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermission;
import java.util.*;
import java.util.concurrent.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

public final class ManagementMutationTest {
    @TempDir Path directory;

    @Test void sensitiveTransitiveDefinitionsAndWorkflowBindingsRequireSecurityManagement() throws Exception {
        Files.writeString(directory.resolve("state.key"),Base64.getEncoder().encodeToString(new byte[32]));
        Files.write(directory.resolve("active.key"),new byte[32]);
        Files.setPosixFilePermissions(directory.resolve("active.key"),Set.of(PosixFilePermission.OWNER_READ));
        var properties=new HashMap<String,Object>(SecurityFixture.properties(directory));
        properties.put("micronaut.server.enabled",false);properties.put("gateway.credentials.key-directory",directory.toString());properties.put("gateway.credentials.active-key-id","active");
        try(var app=ApplicationContext.run(properties,"test")) {
            var store=app.getBean(PlatformStore.class);var f=new SecurityFixture(store,directory,true);
            var repository=app.getBean(DefinitionRepository.class);var access=new ManagementAccess(f.authorization,f.sessions,store);
            var credentials=app.getBean(CredentialService.class);
            var credential=credentials.create("authority-password","PASSWORD","synthetic",new byte[]{1},"fixture","test");
            var contract=publish(repository,"authority-contract",new Contract("VALUE",List.of()));
            var source=publish(repository,"authority-source",new JdbcSource("jdbc:sqlite:"+directory.resolve("source.db"),"SQLITE",credential.objectId(),0,2,1000,true,2,1000));
            var imported=publish(repository,"authority-import",mapper("imported",List.of()));
            var mapper=publish(repository,"authority-mapper",mapper("authority",List.of(imported.object().id())));
            var operation=publish(repository,"authority-operation",new JdbcOperation(source.object().id(),contract.object().id(),contract.object().id(),Effect.READ_ONLY,1000,10,4096L,mapper.object().id(),"authority.read","SELECT_ONE","READ_ONLY",List.of(),List.of()));
            var converter=publish(repository,"authority-converter",new Converter("basic",contract.object().id(),contract.object().id(),List.of()));
            // The synthetic authority ignores implementation details; the actual metadata closure must not.
            f.sql("INSERT INTO config_object(id,kind,logical_key,created_at,created_by) VALUES('extra-security','SECURITY_BINDING','extra-security',1,'fixture')");
            f.sql("INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name) VALUES('extra-security-v1','extra-security','SECURITY_BINDING',1,1,'fixture','test','Test')");
            f.sql("INSERT INTO security_binding_version(version_id,identity_operation_object_id,identity_converter_object_id,authorization_operation_object_id,authorization_converter_object_id,roles_operation_object_id,roles_converter_object_id) VALUES('extra-security-v1','"+operation.object().id()+"','"+converter.object().id()+"','"+operation.object().id()+"','"+converter.object().id()+"','"+operation.object().id()+"','"+converter.object().id()+"')");
            f.sql("UPDATE config_object SET current_version_id='extra-security-v1',revision_counter=1,generation=1 WHERE id='extra-security'");
            var workflow=publish(repository,"business-workflow",new Workflow(null,List.of(new Stage("INPUT",0,operation.object().id(),null)),List.of(),List.of(new SecurityBinding("INPUT","security","config.manage",null))));
            var ordinary=publish(repository,"business-mapper",mapper("business",List.of()));
            restrictRole(f,Set.of("config.manage","client.manage"));
            var browser=f.login("MANAGEMENT");var request=request(browser);var context=access.authorize(request,"config.manage",true);
            for(var saved:List.of(imported,mapper,source,operation,converter,contract)) {
                assertThrows(AccessDenied.class,()->access.definition(request,saved.object().id(),null,saved.detail()));
                long revisions=repository.history(saved.object().id()).size();
                assertThrows(AccessDenied.class,()->access.mutateDefinition(context,saved.object().id(),null,saved.detail(),()->repository.draft(new Draft(saved.object().id(),saved.object().logicalKey(),"Hostile",null,"test",saved.detail()),context.principalId())));
                assertEquals(revisions,repository.history(saved.object().id()).size());
            }
            assertThrows(AccessDenied.class,()->access.definition(request,credential.objectId(),null,null));
            assertThrows(AccessDenied.class,()->access.mutateDefinition(context,credential.objectId(),null,null,()->{credentials.revoke(credential.versionId(),context.principalId());return null;}));
            assertNull(credentials.metadata(credential.objectId()).revokedAt());
            assertThrows(AccessDenied.class,()->access.mutateDefinition(context,credential.objectId(),null,null,()->credentials.replace(credential.objectId(),credential.generation(),"PASSWORD","hostile",new byte[]{2},context.principalId(),"test")));
            assertEquals(credential.versionId(),credentials.metadata(credential.objectId()).versionId());
            assertThrows(AccessDenied.class,()->access.mutateDefinition(context,source.object().id(),null,null,()->store.write(s->s.getMapper(ManagementMapper.class).enabled(source.object().id(),source.object().generation(),false))));
            assertTrue(repository.get(source.object().id(),null).object().enabled());
            var protectedDraft=repository.draft(new Draft(imported.object().id(),imported.object().logicalKey(),"Security draft",null,"test",imported.detail()),"fixture");
            var protectedValidation=repository.validate(protectedDraft.object().id(),protectedDraft.version().id());
            assertThrows(AccessDenied.class,()->access.mutateDefinition(context,imported.object().id(),protectedDraft.version().id(),null,()->repository.apply(protectedValidation,context.principalId(),"test")));
            assertThrows(AccessDenied.class,()->access.mutateDefinition(context,imported.object().id(),imported.version().id(),null,()->repository.rollback(imported.object().id(),imported.version().id(),imported.object().generation(),context.principalId(),"test")));
            assertEquals(imported.version().id(),repository.get(imported.object().id(),null).object().currentVersionId());
            var changed=new Workflow(null,((Workflow)workflow.detail()).stages(),List.of(),List.of());
            assertThrows(AccessDenied.class,()->access.definition(request,workflow.object().id(),null,changed));
            assertThrows(AccessDenied.class,()->access.mutateDefinition(context,workflow.object().id(),null,changed,()->repository.draft(new Draft(workflow.object().id(),workflow.object().logicalKey(),"Removed security",null,"test",changed),context.principalId())));
            var businessContext=access.definition(request,ordinary.object().id(),null,ordinary.detail());
            var draft=access.mutateDefinition(businessContext,ordinary.object().id(),null,ordinary.detail(),()->repository.draft(new Draft(ordinary.object().id(),ordinary.object().logicalKey(),"Business edit",null,"test",ordinary.detail()),businessContext.principalId()));
            var validation=repository.validate(draft.object().id(),draft.version().id());
            var applied=access.mutateDefinition(businessContext,draft.object().id(),draft.version().id(),null,()->repository.apply(validation,businessContext.principalId(),"test"));
            assertEquals(draft.version().id(),applied.object().currentVersionId());
            // An ordinary candidate can become an authority dependency after its HTTP gate.
            var replacement=new JdbcOperation(source.object().id(),contract.object().id(),contract.object().id(),Effect.READ_ONLY,1000,10,4096L,ordinary.object().id(),"business.read","SELECT_ONE","READ_ONLY",List.of(),List.of());
            var rebound=repository.draft(new Draft(operation.object().id(),operation.object().logicalKey(),"Rebound authority",null,"test",replacement),"fixture");
            repository.apply(repository.validate(rebound.object().id(),rebound.version().id()),"fixture","test");
            assertThrows(AccessDenied.class,()->access.mutateDefinition(businessContext,ordinary.object().id(),null,ordinary.detail(),()->repository.draft(new Draft(ordinary.object().id(),ordinary.object().logicalKey(),"Stale permission",null,"test",ordinary.detail()),businessContext.principalId())));
            assertThrows(AccessDenied.class,()->access.definition(request,ordinary.object().id(),null,ordinary.detail()));
            assertEquals(2,repository.history(ordinary.object().id()).size());
            restrictRole(f,Set.of("config.manage","client.manage","security.manage"));
            var securityContext=access.definition(request,ordinary.object().id(),null,ordinary.detail());
            var authorizedDraft=access.mutateDefinition(securityContext,ordinary.object().id(),null,ordinary.detail(),()->repository.draft(new Draft(ordinary.object().id(),ordinary.object().logicalKey(),"Authorized security edit",null,"test",ordinary.detail()),securityContext.principalId()));
            var authorizedValidation=repository.validate(authorizedDraft.object().id(),authorizedDraft.version().id());
            var authorizedApply=access.mutateDefinition(securityContext,ordinary.object().id(),authorizedDraft.version().id(),null,()->repository.apply(authorizedValidation,securityContext.principalId(),"test"));
            assertEquals(authorizedDraft.version().id(),authorizedApply.object().currentVersionId());
        }
    }

    @Test void sessionAndRoleRevocationBetweenGateAndSecretWritePreventCommit() throws Exception {
        try(var f=new SecurityFixture(directory)) { assertRevokedManagementWrite(f,f); }
    }

    public static void assertRevokedManagementWrite(SecurityFixture first,SecurityFixture revoker) throws Exception {
        var access=new ManagementAccess(first.authorization,first.sessions,first.store);
        for(boolean revokeSession:List.of(true,false)) {
            var browser=first.login("MANAGEMENT");var context=access.authorize(request(browser),"client.manage",true);
            long secrets=first.count("SELECT COUNT(*) FROM oauth_client_secret");
            long generation=first.count("SELECT generation FROM config_object WHERE id='confidential'");
            CountDownLatch gated=new CountDownLatch(1),release=new CountDownLatch(1);
            try(var executor=Executors.newVirtualThreadPerTaskExecutor()) {
                var mutation=executor.submit(()->assertThrows(AccessDenied.class,()->access.mutate(context,()->{
                    gated.countDown();await(release);
                    first.oauth.rotateClientSecret("confidential","replacement-synthetic-secret-256bits".toCharArray(),context.principalId());return null;
                })));
                assertTrue(gated.await(10,TimeUnit.SECONDS));
                try {
                    if(revokeSession)revoker.sessions.logout(browser.cookie(),SecurityFixture.ISSUER,browser.view().csrfToken());
                    else restrictRole(revoker,Set.of("config.manage","security.manage","audit.read"));
                } finally { release.countDown(); }
                mutation.get(15,TimeUnit.SECONDS);
            }
            assertEquals(secrets,first.count("SELECT COUNT(*) FROM oauth_client_secret"));
            assertEquals(generation,first.count("SELECT generation FROM config_object WHERE id='confidential'"));
            assertEquals(1,first.count("SELECT COUNT(*) FROM oauth_client_secret WHERE revoked_at IS NULL"));
        }
        // A rejected request must not leave its guard on the worker thread or the trusted offline path.
        first.oauth.rotateClientSecret("confidential",SecurityFixture.SECRET.toCharArray(),"fixture");
        assertEquals(1,first.count("SELECT COUNT(*) FROM oauth_client_secret WHERE revoked_at IS NULL"));
    }

    @Test void guardRechecksAtCommitAndDoesNotLeakAfterFailure() throws Exception {
        try(var f=new SecurityFixture(directory)) {
            var access=new ManagementAccess(f.authorization,f.sessions,f.store);var browser=f.login("MANAGEMENT");
            var context=access.authorize(request(browser),"client.manage",true);
            assertThrows(AccessDenied.class,()->access.mutate(context,()->f.store.write(s->{
                s.getMapper(OAuthMapper.class).revokeSession(browser.row().id(),System.currentTimeMillis());
                return null;
            })));
            assertNull(f.sessions.require(browser.cookie()).revokedAt());
            f.sessions.logout(browser.cookie(),SecurityFixture.ISSUER,browser.view().csrfToken());
            assertThrows(AccessDenied.class,()->f.sessions.require(browser.cookie()));
        }
    }

    private static Saved publish(DefinitionRepository repository,String key,Detail detail) {
        var saved=repository.draft(new Draft(null,key,key,null,"test",detail),"fixture");
        return repository.apply(repository.validate(saved.object().id(),saved.version().id()),"fixture","test");
    }
    private static Mapper mapper(String namespace,List<String> imports) {
        String xml="<?xml version=\"1.0\"?><!DOCTYPE mapper PUBLIC \"-//mybatis.org//DTD Mapper 3.0//EN\" \"https://mybatis.org/dtd/mybatis-3-mapper.dtd\"><mapper namespace=\""+namespace+"\"><select id=\"read\" resultType=\"map\">SELECT 1</select></mapper>";
        return new Mapper("SQLITE",List.of(new MapperDocument(namespace+".xml",xml)),imports);
    }
    public static void restrictRole(SecurityFixture fixture,Set<String> actions) {
        var definitions=new SecurityDefinitions(fixture.store,()->{throw new AssertionError("Role validation must not resolve runtime definitions");});
        var children=actions.stream().sorted().map(action->Map.<String,Object>of("action_id",action,"action_semantic_version",1)).toList();
        var draft=definitions.draft(new SecurityDefinitions.Draft("administrator-role","administrator-role","Restricted administrator",null,"test","ROLE",Map.of("actions",children)),"fixture");
        var validation=definitions.validate(draft.object().id(),draft.version().id());
        definitions.apply(draft.object().id(),draft.version().id(),validation.generation(),validation.dependencyVersions(),"fixture","test");
    }
    private static HttpRequest<?> request(BrowserSessionService.BrowserSession browser) {
        return new io.micronaut.http.simple.SimpleHttpRequest<>(io.micronaut.http.HttpMethod.POST,"/management",Map.of()).cookie(Cookie.of(BrowserSessionService.COOKIE_NAME,browser.cookie())).header("Origin",SecurityFixture.ISSUER).header("X-CSRF-Token",browser.view().csrfToken());
    }
    private static void await(CountDownLatch latch) {
        try { if(!latch.await(10,TimeUnit.SECONDS))throw new AssertionError("management barrier timeout"); }
        catch(InterruptedException failure) { Thread.currentThread().interrupt();throw new AssertionError(failure); }
    }
}
