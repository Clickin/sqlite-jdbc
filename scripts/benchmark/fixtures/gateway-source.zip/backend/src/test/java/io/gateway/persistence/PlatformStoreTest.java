package io.gateway.persistence;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

class PlatformStoreTest {
    @TempDir Path directory;

    @Test void readerIsEnforcedAndNestedAuditParticipatesInRollback() {
        try (PlatformStore store = new PlatformStore(directory.resolve("platform.db"))) {
            assertThrows(PlatformStore.StoreException.class,
                () -> store.read(s -> { s.getMapper(Fixture.class).scope("read", "not allowed"); return null; }));
            assertThrows(IllegalStateException.class, () -> store.write(s -> {
                s.getMapper(Fixture.class).scope("rolled-back", "정확한 업무 값");
                store.write(inner -> { assertSame(s, inner); inner.getMapper(Fixture.class).scope("inner", "value"); return null; });
                new io.gateway.audit.AuditService(store).record("TEST_MUTATION", "synthetic", "SUCCEEDED", null);
                throw new IllegalStateException("deliberate safe failure");
            }));
            assertEquals(0, store.read(s -> s.getMapper(Fixture.class).scopeCount()).intValue());
            assertEquals(0, store.read(s -> s.getMapper(Fixture.class).auditCount()).intValue());
            assertThrows(PlatformStore.StoreException.class, () -> store.write(s -> {
                s.getMapper(Fixture.class).scope("caught-inner", "value");
                try { store.write(inner -> { throw new IllegalArgumentException("safe"); }); }
                catch (IllegalArgumentException ignored) { }
                return null;
            }));
            assertEquals(0, store.read(s -> s.getMapper(Fixture.class).scopeCount()).intValue());
        }
    }

    @Test void eachReadHasSnapshotAndNextReadSeesCommit() throws Exception {
        try (PlatformStore store = new PlatformStore(directory.resolve("platform.db"));
             var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            store.write(s -> { s.getMapper(Fixture.class).resource("visible", "before"); return null; });
            CountDownLatch snapshot = new CountDownLatch(1);
            CountDownLatch changed = new CountDownLatch(1);
            Future<List<String>> reader = executor.submit(() -> store.read(s -> {
                String first = s.getMapper(Fixture.class).description("visible");
                snapshot.countDown();
                await(changed);
                return List.of(first, s.getMapper(Fixture.class).description("visible"));
            }));
            assertTrue(snapshot.await(5, TimeUnit.SECONDS));
            try { store.write(s -> { s.getMapper(Fixture.class).updateDescription("visible", "after"); return null; }); }
            finally { changed.countDown(); }
            assertEquals(List.of("before", "before"), reader.get(5, TimeUnit.SECONDS));
            assertEquals("after", store.read(s -> s.getMapper(Fixture.class).description("visible")));
        }
    }

    @Test void virtualThreadsShareOneWriterAndDurableMigrationDoesNotReset() throws Exception {
        Path file = directory.resolve("platform.db");
        try (PlatformStore store = new PlatformStore(file); var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            CountDownLatch start = new CountDownLatch(1);
            AtomicInteger active = new AtomicInteger();
            AtomicInteger maximum = new AtomicInteger();
            List<Future<?>> writes = new ArrayList<>();
            for (int i = 0; i < 12; i++) {
                String id = "scope-" + i;
                writes.add(executor.submit(() -> {
                    await(start);
                    store.write(s -> {
                        int simultaneous = active.incrementAndGet();
                        maximum.accumulateAndGet(simultaneous, Math::max);
                        try { s.getMapper(Fixture.class).scope(id, "보존"); }
                        finally { active.decrementAndGet(); }
                        return null;
                    });
                }));
            }
            start.countDown();
            for (Future<?> future : writes) future.get(10, TimeUnit.SECONDS);
            assertEquals(1, maximum.get());
        }
        try (PlatformStore reopened = new PlatformStore(file)) {
            assertEquals(12, reopened.read(s -> s.getMapper(Fixture.class).scopeCount()).intValue());
        }
    }

    @Test void schemaRejectsForeignHeadsAndCrossContractFieldOwnership() {
        try (PlatformStore store = new PlatformStore(directory.resolve("platform.db"))) {
            store.write(s -> {
                Fixture mapper = s.getMapper(Fixture.class);
                mapper.object("one"); mapper.object("two");
                mapper.version("v-one", "one"); mapper.version("v-two", "two");
                mapper.contract("v-one"); mapper.contract("v-two");
                mapper.field("field-one", "one");
                return null;
            });
            assertThrows(PlatformStore.StoreException.class,
                () -> store.write(s -> s.getMapper(Fixture.class).head("one", "v-two")));
            assertThrows(PlatformStore.StoreException.class, () -> store.write(s -> {
                s.getMapper(Fixture.class).fieldVersion("v-two", "field-one"); return null;
            }));
            store.write(s -> { s.getMapper(Fixture.class).fieldVersion("v-one", "field-one"); return null; });
            assertThrows(PlatformStore.StoreException.class,
                () -> store.write(s -> s.getMapper(Fixture.class).mutateField()));
            store.write(s -> {
                Fixture mapper = s.getMapper(Fixture.class);
                mapper.field("field-two", "one");
                mapper.head("one", "v-one");
                mapper.publishHistory();
                return null;
            });
            assertThrows(PlatformStore.StoreException.class,
                () -> store.write(s -> { s.getMapper(Fixture.class).appendPublishedField(); return null; }));
            assertThrows(PlatformStore.StoreException.class,
                () -> store.write(s -> s.getMapper(Fixture.class).deletePublishedField()));
            store.write(s -> s.getMapper(Fixture.class).head("one", null));
            assertThrows(PlatformStore.StoreException.class,
                () -> store.write(s -> { s.getMapper(Fixture.class).appendPublishedField(); return null; }));
            assertThrows(PlatformStore.StoreException.class,
                () -> store.write(s -> s.getMapper(Fixture.class).deletePublishedField()));
        }
    }

    private static void await(CountDownLatch latch) {
        try { if (!latch.await(5, TimeUnit.SECONDS)) throw new AssertionError("barrier timeout"); }
        catch (InterruptedException failure) { Thread.currentThread().interrupt(); throw new AssertionError("interrupted"); }
    }

    public interface Fixture extends PlatformMapper {
        @Insert("INSERT INTO oauth_scope(id,scope_name,description) VALUES(#{id},#{id},#{description})")
        void scope(@Param("id") String id, @Param("description") String description);
        @Select("SELECT count(*) FROM oauth_scope") int scopeCount();
        @Select("SELECT count(*) FROM audit_event") int auditCount();
        @Insert("INSERT INTO config_object(id,kind,logical_key,created_at,created_by) VALUES(#{id},'CONTRACT',#{id},1,'synthetic')")
        void object(String id);
        @Insert("INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name) VALUES(#{id},#{objectId},'CONTRACT',1,1,'synthetic','test',#{id})")
        void version(@Param("id") String id, @Param("objectId") String objectId);
        @Insert("INSERT INTO contract_version(version_id,model_kind) VALUES(#{id},'VALUE')") void contract(String id);
        @Insert("INSERT INTO oauth_resource(id,resource_uri,resource_kind,public_name,active) VALUES(#{id},#{id},'REST',#{description},TRUE)")
        void resource(@Param("id") String id, @Param("description") String description);
        @Select("SELECT public_name FROM oauth_resource WHERE id=#{id}") String description(String id);
        @Update("UPDATE oauth_resource SET public_name=#{description} WHERE id=#{id}")
        int updateDescription(@Param("id") String id, @Param("description") String description);
        @Insert("INSERT INTO contract_field(id,contract_object_id,logical_name) VALUES(#{id},#{objectId},#{id})")
        void field(@Param("id") String id, @Param("objectId") String objectId);
        @Insert("INSERT INTO contract_field_version(contract_version_id,field_id,node_kind,value_type,ordinal,required,nullable,audit_disposition) VALUES(#{version},#{field},'SCALAR','STRING',0,TRUE,FALSE,'PERSIST')")
        void fieldVersion(@Param("version") String version, @Param("field") String field);
        @Update("UPDATE config_object SET current_version_id=#{version} WHERE id=#{id}")
        int head(@Param("id") String id, @Param("version") String version);
        @Update("UPDATE contract_field_version SET ordinal=1") int mutateField();
        @Insert("INSERT INTO configuration_change(id,object_id,after_version_id,before_generation,after_generation,actor_subject_id,reason,changed_at) VALUES('publish','one','v-one',0,1,'fixture','publish',1)")
        void publishHistory();
        @Insert("INSERT INTO contract_field_version(contract_version_id,field_id,node_kind,value_type,ordinal,required,nullable,audit_disposition) VALUES('v-one','field-two','SCALAR','STRING',1,TRUE,FALSE,'PERSIST')")
        void appendPublishedField();
        @Delete("DELETE FROM contract_field_version WHERE contract_version_id='v-one' AND field_id='field-one'")
        int deletePublishedField();
    }
}
