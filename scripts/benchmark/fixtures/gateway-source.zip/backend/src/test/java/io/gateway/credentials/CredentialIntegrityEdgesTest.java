package io.gateway.credentials;

import io.gateway.audit.AuditService;
import io.gateway.persistence.PlatformMapper;
import io.gateway.persistence.PlatformStore;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermissions;
import java.security.SecureRandom;
import org.apache.ibatis.annotations.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class CredentialIntegrityEdgesTest {
    @TempDir Path directory;

    @Test void nonceTagAndAuthenticatedMetadataTamperIndependentlyFailWithoutKeyRepair() throws Exception {
        byte[] key=new byte[32];new SecureRandom().nextBytes(key);
        Path keyFile=directory.resolve("integrity.key");Files.write(keyFile,key);
        Files.setPosixFilePermissions(keyFile,PosixFilePermissions.fromString("r--------"));
        byte[] plaintext="INTEGRITY_SECRET_SENTINEL".getBytes(StandardCharsets.UTF_8);
        try(var store=new PlatformStore(directory.resolve("platform.db"))) {
            var service=new CredentialService(store,new AuditService(store),directory.toString(),"integrity");
            var donor=service.create("aad-donor","PASSWORD",null,plaintext,"fixture","integrity check");
            var donorCipher=store.read(s->s.getMapper(CredentialMapper.class).versionRow(donor.versionId()));
            // Free the donor's old nonce through legitimate rotation, preserving UNIQUE(key_id,nonce).
            service.reencrypt(donor.versionId(),donor.keyId(),"fixture");
            try(var resolved=service.resolve(donor.objectId())) {assertArrayEquals(plaintext,resolved.bytes());}
            for(String component:new String[]{"nonce","tag","aad"}) {
                var saved=service.create(component,"PASSWORD",null,plaintext,"fixture","integrity check");
                var original=store.read(s->s.getMapper(CredentialMapper.class).versionRow(saved.versionId()));
                var encrypted=component.equals("aad")?donorCipher:original;
                assertEquals(original.keyId(),encrypted.keyId(),"AAD transplant must use the same encryption key");
                byte[] nonce=encrypted.nonce().clone(),tag=encrypted.authenticationTag().clone();
                if(component.equals("nonce"))nonce[0]^=1;
                if(component.equals("tag"))tag[0]^=1;
                store.write(s->{
                    var mapper=s.getMapper(IntegrityMapper.class);
                    assertEquals(1,mapper.cipher(saved.versionId(),nonce,encrypted.ciphertext(),tag));
                    return null;
                });
                var failure=assertThrows(CredentialService.CredentialException.class,()->service.resolve(saved.objectId()),component);
                assertEquals("CREDENTIAL_DECRYPTION_FAILED",failure.getMessage());
                assertNull(failure.getCause());
                assertFalse(failure.toString().contains("INTEGRITY_SECRET_SENTINEL"));
                assertArrayEquals(key,Files.readAllBytes(keyFile),"A failed decrypt must never replace the operator key");
                var after=store.read(s->s.getMapper(CredentialMapper.class).versionRow(saved.versionId()));
                assertEquals(saved,service.metadata(saved.objectId()),"Failed decrypt must not repair authenticated metadata");
                assertArrayEquals(encrypted.ciphertext(),after.ciphertext());
                assertArrayEquals(nonce,after.nonce());assertArrayEquals(tag,after.authenticationTag());
                store.write(s->{assertEquals(1,s.getMapper(IntegrityMapper.class).cipher(saved.versionId(),original.nonce(),original.ciphertext(),original.authenticationTag()));return null;});
                try(var restored=service.resolve(saved.objectId())) {assertArrayEquals(plaintext,restored.bytes());}
            }
        }
    }

    public interface IntegrityMapper extends PlatformMapper {
        @Update("UPDATE credential_cipher SET nonce=#{nonce},ciphertext=#{ciphertext},authentication_tag=#{tag} WHERE credential_version_id=#{id}")
        int cipher(@Param("id")String id,@Param("nonce")byte[] nonce,@Param("ciphertext")byte[] ciphertext,@Param("tag")byte[] tag);
    }
}
