package io.gateway.oauth;

import com.nimbusds.oauth2.sdk.http.HTTPRequest;
import com.sun.net.httpserver.HttpServer;
import io.gateway.authorization.*;
import io.gateway.identity.Authority;
import io.gateway.management.SecurityDefinitions;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static io.gateway.oauth.SecurityFixture.*;
import static org.junit.jupiter.api.Assertions.*;

class OAuthLifecycleEdgesTest {
    @TempDir Path directory;

    @Test void invalidRedirectRegistrationsCannotPublishOrBecomeErrorDestinations() throws Exception {
        try(var f=new SecurityFixture(directory)) {
            var definitions=new SecurityDefinitions(f.store,()->null);
            record InvalidRedirect(String uri,boolean loopback) {}
            for(var invalid:List.of(
                    new InvalidRedirect("https://*.client.example/callback",false),
                    new InvalidRedirect("https://client.example/callback/*",false),
                    new InvalidRedirect("https://client.example/callback#fragment",false),
                    new InvalidRedirect("https://user@client.example/callback",false),
                    new InvalidRedirect("http://127.0.0.1.evil/callback",true),
                    new InvalidRedirect("http://localhost/callback",true),
                    new InvalidRedirect("http://192.168.1.1/callback",true),
                    new InvalidRedirect(REDIRECT,true))) {
                var detail=new LinkedHashMap<>(definitions.get("public",null).detail());
                detail.put("redirects",List.of(Map.of("redirect_uri",invalid.uri(),"native_loopback_port_policy",invalid.loopback())));
                var draft=definitions.draft(new SecurityDefinitions.Draft(null,"invalid-"+UUID.randomUUID(),"Invalid redirect",null,"test","OAUTH_CLIENT",detail),"fixture");
                assertThrows(IllegalArgumentException.class,()->definitions.validate(draft.object().id(),draft.version().id()),invalid.uri());
                assertThrows(IllegalArgumentException.class,()->definitions.apply(draft.object().id(),draft.version().id(),draft.object().generation(),Map.of(),"fixture","test"),invalid.uri());
                assertNull(definitions.list().stream().filter(h->h.id().equals(draft.object().id())).findFirst().orElseThrow().currentVersionId());
            }
            // A stale/imported wildcard row must not bypass the registration boundary by matching literally.
            String wildcard="https://client.example/callback/*";
            f.sql("INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name) VALUES('public-imported','public','OAUTH_CLIENT',2,2,'fixture','imported unsafe redirect','Synthetic')");
            f.sql("INSERT INTO oauth_client_version SELECT 'public-imported',kind,client_type,token_endpoint_auth_method,display_name,require_pkce_s256,refresh_enabled FROM oauth_client_version WHERE version_id='public-v1'");
            f.sql("INSERT INTO oauth_client_redirect VALUES('public-imported','"+wildcard+"',false,0)");
            f.sql("INSERT INTO oauth_client_scope SELECT 'public-imported',scope_id FROM oauth_client_scope WHERE client_version_id='public-v1'");
            f.sql("INSERT INTO oauth_client_action SELECT 'public-imported',action_id,action_semantic_version FROM oauth_client_action WHERE client_version_id='public-v1'");
            f.sql("INSERT INTO oauth_client_resource SELECT 'public-imported',resource_id FROM oauth_client_resource WHERE client_version_id='public-v1'");
            f.sql("UPDATE config_object SET current_version_id='public-imported',revision_counter=2,generation=2 WHERE id='public'");
            var browser=f.login("USER");
            var failure=assertThrows(OAuthProtocol.Failure.class,()->f.oauth.begin(authorizeParameters("public",wildcard,"clinical.read"),browser.cookie()));
            assertNull(failure.redirect());
            assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_authorization_request"));
            var client=f.store.read(s->s.getMapper(OAuthMapper.class).client("public"));
            String encoded="https://client.example/callback/%2A";
            var exact=List.of(new OAuthMapper.Redirect(encoded,false));
            assertTrue(OAuthProtocol.redirectAllowed(encoded,client,exact));
            assertFalse(OAuthProtocol.redirectAllowed("https://client.example/callback/%2a",client,exact));
        }
    }

    @Test void missingArbitraryAndMultipleResourcesCannotIssueOrRotateCredentials() throws Exception {
        try(var f=new SecurityFixture(directory)) {
            List<List<String>> invalid=List.of(List.of(),List.of(ISSUER+"/unregistered"),List.of(RESOURCE,ISSUER+"/unregistered"));
            var browser=f.login("USER");
            for(var resources:invalid) {
                var request=authorizeParameters("public",REDIRECT,"clinical.read");
                if(resources.isEmpty())request.remove("resource");else request.put("resource",resources);
                assertThrows(OAuthProtocol.Failure.class,()->f.oauth.begin(request,browser.cookie()));
            }
            assertEquals(0,f.count("SELECT count(*) FROM oauth_authorization_request"));
            var code=f.code("A");
            String exchange=form(Map.of("grant_type","authorization_code","client_id","public","code",code.value(),"redirect_uri",REDIRECT,"code_verifier",VERIFIER));
            for(var resources:invalid) {
                String suffix=resources.stream().map(r->"&resource="+URLEncoder.encode(r,StandardCharsets.UTF_8)).collect(java.util.stream.Collectors.joining());
                assertThrows(OAuthProtocol.Failure.class,()->f.oauth.token(exchange+suffix,null));
            }
            assertEquals(0,f.count("SELECT count(*) FROM oauth_authorization_code WHERE consumed_at IS NOT NULL"));
            assertEquals(0,f.count("SELECT count(*) FROM oauth_access_token"));
            var issued=f.exchange(code);String refresh=(String)issued.get("refresh_token");
            String rotation=form(Map.of("grant_type","refresh_token","client_id","public","refresh_token",refresh));
            for(var resources:invalid) {
                String suffix=resources.stream().map(r->"&resource="+URLEncoder.encode(r,StandardCharsets.UTF_8)).collect(java.util.stream.Collectors.joining());
                assertThrows(OAuthProtocol.Failure.class,()->f.oauth.token(rotation+suffix,null));
            }
            assertEquals(0,f.count("SELECT count(*) FROM oauth_refresh_token WHERE consumed_at IS NOT NULL OR revoked_at IS NOT NULL"));
            assertEquals(1,f.count("SELECT count(*) FROM oauth_access_token"));
            var old=f.authenticate(issued);var next=f.authenticate(f.refresh(refresh));
            assertEquals(old.grantId(),next.grantId());
            assertThrows(AccessDenied.class,()->f.authorization.authenticateBearer(List.of("Bearer "+issued.get("access_token")),ISSUER+"/unregistered"));
        }
    }

    @Test void refreshClientAndPatientSubstitutionCannotConsumeOrExpandTheGrant() throws Exception {
        try(var f=new SecurityFixture(directory)) {
            var initial=f.token("A");var principal=f.authenticate(initial);
            String refresh=(String)initial.get("refresh_token");
            var form=new LinkedHashMap<>(Map.of("grant_type","refresh_token","client_id","public","refresh_token",refresh,"resource",RESOURCE));
            var foreign=new LinkedHashMap<>(form);foreign.put("client_id","confidential");
            assertThrows(OAuthProtocol.Failure.class,()->f.oauth.token(form(foreign),basic()));
            for(var override:Map.of("patient","B","patientId","B","authorization_details","[{\"patientId\":\"B\"}]").entrySet()) {
                var changed=new LinkedHashMap<>(form);changed.put(override.getKey(),override.getValue());
                assertThrows(OAuthProtocol.Failure.class,()->f.oauth.token(form(changed),null));
            }
            assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_refresh_token WHERE consumed_at IS NOT NULL OR revoked_at IS NOT NULL"));
            assertEquals(1,f.count("SELECT COUNT(*) FROM oauth_access_token"));
            var current=f.authenticate(f.refresh(refresh));
            assertEquals(principal.grantId(),current.grantId());assertEquals("public",current.clientId());
            assertEquals("A",f.authorization.authorize(current,"clinical.lab.read",patient("A")).target().patientIdentifier());
            assertThrows(AccessDenied.class,()->f.authorization.authorize(current,"clinical.lab.read",patient("B")));
            assertEquals(1,f.count("SELECT COUNT(*) FROM oauth_grant_rule WHERE grant_id='"+current.grantId()+"' AND patient_identifier='A'"));
            assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_grant_rule WHERE patient_identifier='B'"));
        }
    }

    @Test void elapsedIdleAndAbsoluteSessionDeadlinesBlockConsentWithoutRevocation() throws Exception {
        try(var f=new SecurityFixture(directory)) {
            for(boolean absolute:List.of(false,true)) {
                var browser=f.login("USER");
                String request=f.oauth.begin(authorizeParameters("public",REDIRECT,"clinical.read"),browser.cookie());
                long future=System.currentTimeMillis()+60_000;
                if(absolute) {
                    f.sql("UPDATE auth_session SET idle_expires_at="+future+",absolute_expires_at="+future+" WHERE id='"+browser.row().id()+"'");
                    f.sessions.session(browser.cookie());
                    assertEquals(future,f.sessions.require(browser.cookie()).idleExpiresAt(),"Sliding idle renewal cannot extend the absolute deadline");
                }
                // Age the persisted timestamps, not a revoke flag; no wall-clock sleeps or clock replacement.
                f.sql("UPDATE auth_session SET authenticated_at=1,idle_expires_at=2,absolute_expires_at="+(absolute?3:future)+" WHERE id='"+browser.row().id()+"'");
                assertEquals(1,f.count("SELECT COUNT(*) FROM auth_session WHERE id='"+browser.row().id()+"' AND revoked_at IS NULL"));
                assertThrows(AccessDenied.class,()->f.sessions.require(browser.cookie()));
                assertThrows(AccessDenied.class,()->f.oauth.consent(request,browser.cookie(),ISSUER,browser.view().csrfToken(),consent("A")));
                var replacement=f.sessions.session(browser.cookie());
                assertNotEquals(browser.cookie(),replacement.cookie());assertFalse(replacement.view().authenticated());
                assertThrows(AccessDenied.class,()->f.oauth.request(request,replacement.cookie()));
            }
            assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_grant"));
            assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_authorization_code"));
        }
    }

    @Test void overlappingTabConsentsKeepTheirOwnStateAndPatientGrant() throws Exception {
        try(var f=new SecurityFixture(directory);var executor=Executors.newVirtualThreadPerTaskExecutor()) {
            var browser=f.login("USER");var requests=new LinkedHashMap<String,String>();
            for(String patient:List.of("A","B")) {
                var parameters=authorizeParameters("public",REDIRECT,"clinical.read");parameters.put("state",List.of("tab-"+patient));
                requests.put(patient,f.oauth.begin(parameters,browser.cookie()));
            }
            var entered=new CyclicBarrier(2);
            f.authority.beforeDecision=()->{try{entered.await(10,TimeUnit.SECONDS);}catch(Exception failure){throw new AssertionError(failure);}};
            var responses=new LinkedHashMap<String,Future<String>>();
            requests.forEach((patient,request)->responses.put(patient,executor.submit(()->f.oauth.consent(request,browser.cookie(),ISSUER,browser.view().csrfToken(),consent(patient)))));
            var callbacks=new LinkedHashMap<String,String>();
            try {for(var response:responses.entrySet())callbacks.put(response.getKey(),response.getValue().get(15,TimeUnit.SECONDS));}
            finally {f.authority.beforeDecision=()->{};}
            var grants=new HashSet<String>();
            for(var callback:callbacks.entrySet()) {
                var query=query(callback.getValue());String patient=callback.getKey();
                assertEquals(List.of("tab-"+patient),query.get("state"));assertEquals(List.of(ISSUER),query.get("iss"));
                var code=new Code(query.get("code").getFirst(),"public",VERIFIER,REDIRECT,requests.get(patient));
                var principal=f.authenticate(f.exchange(code));grants.add(principal.grantId());
                assertEquals(patient,f.authorization.authorize(principal,"clinical.lab.read",patient(patient)).target().patientIdentifier());
                assertThrows(AccessDenied.class,()->f.authorization.authorize(principal,"clinical.lab.read",patient(patient.equals("A")?"B":"A")));
            }
            assertEquals(2,grants.size());assertEquals(2,f.count("SELECT COUNT(*) FROM oauth_authorization_request WHERE status='COMPLETED'"));
        }
    }

    @Test void externalApprovalOutcomesCloseConsentAfterOneNetworkDecisionWithoutPolling() throws Exception {
        try(var f=new SecurityFixture(directory);var http=HttpClient.newHttpClient()) {
            var calls=new AtomicInteger();var outcome=new AtomicReference<>("PENDING");
            var remote=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
            remote.createContext("/approval",exchange->{
                calls.incrementAndGet();byte[] body=outcome.get().getBytes(StandardCharsets.US_ASCII);
                exchange.sendResponseHeaders(200,body.length);try(var stream=exchange.getResponseBody()){stream.write(body);}
            });remote.start();
            try {
                URI endpoint=URI.create("http://127.0.0.1:"+remote.getAddress().getPort()+"/approval");
                Authority authority=new Authority() {
                    public String securityBindingId(){return f.authority.securityBindingId();}
                    public Identity authenticate(String credential){return f.authority.authenticate(credential);}
                    public Set<String> roles(String provider,String subject){return f.authority.roles(provider,subject);}
                    public CanonicalTarget resolve(String provider,String subject,String action,CanonicalTarget target,String policy){return f.authority.resolve(provider,subject,action,target,policy);}
                    public Decision decide(String provider,String subject,String action,CanonicalTarget target) {
                        try {return new Decision(http.send(HttpRequest.newBuilder(endpoint).GET().build(),HttpResponse.BodyHandlers.ofString()).body(),"external-approval",Set.of("clinician"));}
                        catch(Exception failure){throw new AssertionError(failure);}
                    }
                };
                var oauth=new OAuthService(f.store,f.settings,f.sessions,authority);var browser=f.login("USER");
                for(String denied:List.of("PENDING","DENY","UNAVAILABLE")) {
                    outcome.set(denied);int before=calls.get();
                    String request=oauth.begin(authorizeParameters("public",REDIRECT,"clinical.read"),browser.cookie());
                    var response=query(oauth.consent(request,browser.cookie(),ISSUER,browser.view().csrfToken(),consent("A")));
                    assertEquals(List.of("access_denied"),response.get("error"));assertFalse(response.containsKey("code"));
                    outcome.set("ALLOW");
                    assertThrows(AccessDenied.class,()->oauth.request(request,browser.cookie()));
                    assertThrows(AccessDenied.class,()->oauth.consent(request,browser.cookie(),ISSUER,browser.view().csrfToken(),consent("A")));
                    assertEquals(before+1,calls.get(),"A terminal consent must not poll or retry the external approval");
                }
                assertEquals(3,f.count("SELECT COUNT(*) FROM oauth_authorization_request WHERE status='REJECTED'"));
                assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_grant"));assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_authorization_code"));
            } finally {remote.stop(0);}
        }
    }

    private static OAuthService.Consent consent(String patient){return new OAuthService.Consent("synthetic-care",List.of(new OAuthService.ActionTarget("clinical.lab.read",patient(patient))),true);}
    private static Map<String,List<String>> query(String uri){return new HTTPRequest(HTTPRequest.Method.GET,URI.create(uri)).getQueryStringParameters();}
}
