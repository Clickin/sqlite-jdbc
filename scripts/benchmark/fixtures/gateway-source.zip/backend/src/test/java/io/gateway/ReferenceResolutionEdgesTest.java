package io.gateway;

import com.sun.net.httpserver.HttpsConfigurator;
import com.sun.net.httpserver.HttpsServer;
import io.gateway.definitions.DefinitionRepository;
import io.gateway.definitions.Definitions.*;
import io.gateway.mcp.Mcp2026Adapter;
import io.gateway.oauth.SecurityFixture;
import io.gateway.results.ResultMapper;
import io.gateway.results.ResultModels.*;
import io.gateway.runtime.Payload;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import javax.net.ssl.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.KeyStore;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import static org.junit.jupiter.api.Assertions.*;

@SuppressWarnings("unchecked")
class ReferenceResolutionEdgesTest {
    @TempDir Path directory;
    private static final List<String> MCP_ACTIONS=List.of("clinical.lab.read","reference.read","reference.resolve");
    private static final List<String> REST_ACTIONS=List.of("result.create","result.read","reference.read","reference.resolve");

    @Test void registeredDefaultAndRelativePeriodMappingPreserveActualEffectiveArgumentsAfterMappingChanges() throws Exception {
        try(var fixture=new GatewayFixture(directory,-1,true);var http=new GatewayHttpClient(fixture.server.getURI())) {
            var repository=fixture.server.getApplicationContext().getBean(DefinitionRepository.class);
            var original=publish(repository,"period-public",new Contract("VALUE",List.of(
                    field("period-patient","patientId",0,true),field("period-document","documentId",1,true),
                    field("period-choice","period",2,true),field("period-end","endDate",3,false))));
            var effective=publish(repository,"period-effective",new Contract("VALUE",List.of(
                    field("effective-patient","patientId",0,true),field("effective-document","documentId",1,true),
                    field("effective-start","startDate",2,true),field("effective-end","endDate",3,true))));
            var mapper=publish(repository,"period-mapping",mapping(original.object().id(),effective.object().id(),"2026-09-18","2026-09-25"));
            fixture.store.write(session->{var m=session.getMapper(SecurityFixture.FixtureMapper.class);
                object(m,"period-policy","TARGET_POLICY");
                m.execute("INSERT INTO target_policy_version(version_id,target_kind,canonical_organization,identifier_system,require_parent_patient) VALUES('period-policy-v1','DOCUMENT','synthetic-hospital','synthetic-mrn',true)");
                m.execute("INSERT INTO target_argument_binding VALUES('period-policy-v1','REQUEST','period-patient','PATIENT',0),('period-policy-v1','REQUEST','period-document','DOCUMENT',1),('period-policy-v1','CONTEXT','effective-patient','PATIENT',2),('period-policy-v1','CONTEXT','effective-document','DOCUMENT',3)");
                activate(m,"period-policy");object(m,"period-screen","SCREEN_PROFILE");
                m.execute("INSERT INTO screen_profile_version(version_id,adapter_id,screen_code,allowed_launch_profile) VALUES('period-screen-v1','synthetic-hospital','LAB_PERIOD','view-period')");
                m.execute("INSERT INTO screen_parameter_binding VALUES('period-screen-v1','original.period','requested_period','STRING',0),('period-screen-v1','effective.startDate','start_date','STRING',1),('period-screen-v1','effective.endDate','end_date','STRING',2)");
                activate(m,"period-screen");return null;});
            var query=new AtomicReference<String>();
            fixture.source.createContext("/dates",exchange->{fixture.sourceCalls.incrementAndGet();query.set(exchange.getRequestURI().getRawQuery());
                byte[] bytes=("{\"answer\":\"period result\",\"recordText\":\""+GatewayFixture.RECORD_TEXT+"\",\"webLink\":\""+GatewayFixture.WEB_LINK+"\"}").getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type","application/json");exchange.sendResponseHeaders(200,bytes.length);try(var body=exchange.getResponseBody()){body.write(bytes);}});
            var representation=publish(repository,"period-json",new Representation(fixture.output.object().id(),"json","DEFAULT","application/json","UTF-8",List.of(),List.of()));
            var operation=publish(repository,"period-operation",new HttpOperation(fixture.datasource.object().id(),effective.object().id(),fixture.output.object().id(),Effect.READ_ONLY,3000,100,1048576L,"GET","dates",null,representation.object().id(),
                    List.of(new Parameter("QUERY","patientId","effective-patient",null,true),new Parameter("QUERY","documentId","effective-document",null,true),new Parameter("QUERY","startDate","effective-start",null,true),new Parameter("QUERY","endDate","effective-end",null,true)),
                    List.of(new ExpectedStatus(200,"SUCCEEDED")),List.of(new ReferenceBinding("TOOL_REFERENCE",null,null,"period-screen","Synthetic dated screen"))));
            var workflow=publish(repository,"period-workflow",new Workflow(null,List.of(new Stage("INPUT",0,operation.object().id(),null)),List.of(),List.of(new SecurityBinding("INPUT","security","clinical.lab.read","period-policy"))));
            fixture.store.write(session->{var m=session.getMapper(SecurityFixture.FixtureMapper.class);object(m,"period-tool","MCP_TOOL");
                m.execute("INSERT INTO mcp_tool_version(version_id,public_name,description,workflow_object_id,public_input_contract_version_id,public_output_contract_version_id,security_binding_object_id,target_policy_object_id,input_mapping_object_id,effect_kind) VALUES('period-tool-v1','period-tool','Synthetic date defaults','"+workflow.object().id()+"','"+original.version().id()+"','"+fixture.output.version().id()+"','security','period-policy','"+mapper.object().id()+"','READ_ONLY')");
                m.execute("INSERT INTO mcp_tool_action VALUES('period-tool-v1','clinical.lab.read')");m.execute("INSERT INTO mcp_tool_scope VALUES('period-tool-v1','read')");activate(m,"period-tool");return null;});
            String token=http.authorize(SecurityFixture.RESOURCE,"A",MCP_ACTIONS);
            var execution=call(http,token,"period-tool",Map.of("patientId","A","documentId","DA","period","previous-week"));
            assertEquals("SUCCEEDED",execution.get("status"));
            var actual=Arrays.stream(query.get().split("&")).map(pair->pair.split("=",2)).collect(java.util.stream.Collectors.toMap(pair->pair[0],pair->URLDecoder.decode(pair[1],StandardCharsets.UTF_8)));
            assertEquals(Map.of("patientId","A","documentId","DA","startDate","2026-09-18","endDate","2026-09-25"),actual);
            String reference=((List<String>)execution.get("references")).getFirst();
            String rest=http.authorize(GatewayFixture.REST_RESOURCE,"A",REST_ACTIONS);
            var resolved=resolve(http,rest,reference);
            assertEquals(Map.of("requested_period","previous-week","start_date","2026-09-18","end_date","2026-09-25"),resolved.parameters());
            var parameters=fixture.store.read(s->s.getMapper(ResultMapper.class).parameters(reference));
            assertEquals("MISSING",parameter(parameters,"ORIGINAL","endDate").get("value_type"));
            assertEquals("previous-week",parameter(parameters,"ORIGINAL","period").get("string_value"));
            assertEquals("2026-09-18",parameter(parameters,"EFFECTIVE","startDate").get("string_value"));
            assertEquals("2026-09-25",parameter(parameters,"EFFECTIVE","endDate").get("string_value"));
            var changed=repository.draft(new Draft(mapper.object().id(),mapper.object().logicalKey(),"Later period anchor",null,"change configured defaults",mapping(original.object().id(),effective.object().id(),"2026-10-02","2026-10-09")),"fixture");
            repository.apply(repository.validate(changed.object().id(),changed.version().id()),"fixture","later period anchor");
            assertEquals(resolved,resolve(http,rest,reference));assertEquals(1,fixture.sourceCalls.get(),"Reference opening cannot rerun or reinterpret the original request");
            var later=call(http,token,"period-tool",Map.of("patientId","A","documentId","DA","period","previous-week"));
            var laterReference=resolve(http,rest,((List<String>)later.get("references")).getFirst());
            assertEquals(Map.of("requested_period","previous-week","start_date","2026-10-02","end_date","2026-10-09"),laterReference.parameters());
            assertEquals(resolved,resolve(http,rest,reference));assertEquals(2,fixture.sourceCalls.get());
        }
    }

    @Test void correctedHttpsOriginalIsReadFromExistingDirectReferenceWithoutAnyBodySnapshot() throws Exception {
        Files.createDirectories(directory);
        try(var page=new OriginalPage(directory);var fixture=new GatewayFixture(directory.resolve("gateway"),-1,true,Map.of("gateway.references.web-origins",page.origin),"test");var http=new GatewayHttpClient(fixture.server.getURI())) {
            fixture.sourceWebLink=page.origin+"/record";
            String token=http.authorize(SecurityFixture.RESOURCE,"A",MCP_ACTIONS);
            var execution=call(http,token,"lab-tool",Map.of("patientId","A","documentId","DA","sourceSecret",GatewayFixture.SOURCE_SECRET));
            assertEquals("SUCCEEDED",execution.get("status"));assertEquals(0,page.calls.get(),"Reference creation must not fetch or snapshot the original page");
            String rest=http.authorize(GatewayFixture.REST_RESOURCE,"A",REST_ACTIONS);
            var references=new ArrayList<ResolvedReference>();for(String id:(List<String>)execution.get("references"))references.add(resolve(http,rest,id));
            var web=references.stream().filter(r->r.kind().equals("WEB_LINK")).findFirst().orElseThrow();
            assertEquals(fixture.sourceWebLink,web.directUrl());assertEquals("DIRECT_LINK",web.supportStatus());
            assertEquals(0,page.calls.get());
            var request=HttpRequest.newBuilder(URI.create(web.directUrl())).GET().build();
            var before=page.client.send(request,HttpResponse.BodyHandlers.ofString());assertEquals(200,before.statusCode());assertEquals(OriginalPage.BEFORE,before.body());
            page.body.set(OriginalPage.AFTER);
            assertEquals(web,resolve(http,rest,web.id()));
            var corrected=page.client.send(request,HttpResponse.BodyHandlers.ofString());assertEquals(200,corrected.statusCode());assertEquals(OriginalPage.AFTER,corrected.body());
            assertEquals(2,page.calls.get());assertEquals(1,fixture.sourceCalls.get());
            assertEquals(0,count(fixture,"SELECT count(*) FROM generated_result"));
            assertEquals(2,count(fixture,"SELECT count(*) FROM source_reference"));
            assertDatabaseFilesExclude(directory.resolve("gateway"),List.of(OriginalPage.BEFORE,OriginalPage.AFTER,GatewayFixture.RECORD_TEXT));
        }
        assertDatabaseFilesExclude(directory.resolve("gateway"),List.of(OriginalPage.BEFORE,OriginalPage.AFTER,GatewayFixture.RECORD_TEXT));
    }

    @Test void unsetAndExplicitlyDisabledRetentionPreserveExpiredResultsReferencesAndAudit() throws Exception {
        try(var fixture=new GatewayFixture(directory,-1,true);var http=new GatewayHttpClient(fixture.server.getURI())) {
            String mcp=http.authorize(SecurityFixture.RESOURCE,"A",MCP_ACTIONS);
            var execution=call(http,mcp,"lab-tool",Map.of("patientId","A","documentId","DA","sourceSecret",GatewayFixture.SOURCE_SECRET));
            assertEquals("SUCCEEDED",execution.get("status"));
            var references=(List<String>)execution.get("references");
            String rest=http.authorize(GatewayFixture.REST_RESOURCE,"A",REST_ACTIONS);
            var inputs=new ArrayList<ReferenceInput>();for(int i=0;i<references.size();i++)inputs.add(new ReferenceInput(references.get(i),"summary",i));
            var create=new CreateResult((String)execution.get("executionId"),fixture.generatedOutput.version().id(),"retention-fixture","synthetic-model",
                    List.of(new ValueInput("summary",null,"summary-field",0,"STRING","retained synthetic summary",null,null,null)),inputs);
            var savedResponse=http.api("/api/results","POST",create,rest);assertEquals(200,savedResponse.statusCode());
            var saved=http.json.readValue(savedResponse.body(),ResultDocument.class);
            fixture.store.write(session->{var m=session.getMapper(SecurityFixture.FixtureMapper.class);
                m.execute("UPDATE generated_result_revision SET created_at=1");m.execute("UPDATE source_reference SET created_at=1");
                m.execute("INSERT INTO audit_event(id,event_type,occurred_at,actor_subject_id,caller_service_id,outcome) VALUES('retention-expired-audit','RETENTION_FIXTURE',1,'fixture','fixture','SUCCEEDED')");return null;});
            assertEquals(1,count(fixture,"SELECT count(*) FROM generated_result_revision WHERE created_at=1"));
            assertEquals(references.size(),count(fixture,"SELECT count(*) FROM source_reference WHERE created_at=1"));
            var admin=http.login("MANAGEMENT");
            var headers=Map.of("Cookie",admin.cookie(),"Origin",SecurityFixture.ISSUER,"X-CSRF-Token",admin.csrf(),"Content-Type","application/json");
            var policies=http.send("/management/retention","GET",null,headers);assertEquals(200,policies.statusCode());
            for(var policy:(List<Map<String,Object>>)http.json.readValue(policies.body(),List.class)) {assertNull(policy.get("retentionDays"));assertEquals(false,policy.get("cleanupEnabled"));}
            long audit=count(fixture,"SELECT count(*) FROM audit_event WHERE occurred_at=1");
            assertEquals(1,audit,"The immutable audit fixture must already be old when inserted");
            var unsetCleanup=http.send("/management/retention/cleanup","POST",null,headers);assertEquals(200,unsetCleanup.statusCode());
            assertEquals(Map.of("AUDIT",0,"GENERATED_RESULT",0),http.object(unsetCleanup));
            assertEquals(audit,count(fixture,"SELECT count(*) FROM audit_event WHERE occurred_at=1"));assertReadable(http,rest,saved,references);
            for(String dataset:List.of("AUDIT","GENERATED_RESULT")) {
                var changed=http.send("/management/retention/"+dataset,"PUT",http.json.writeValueAsString(Map.of("retentionDays",1,"cleanupEnabled",false,"cleanupInterval",1,"batchLimit",100,"expectedGeneration",0)),headers);
                assertEquals(200,changed.statusCode());assertEquals(false,http.object(changed).get("cleanupEnabled"));
            }
            var cleanup=http.send("/management/retention/cleanup","POST",null,headers);assertEquals(200,cleanup.statusCode());
            assertEquals(Map.of("AUDIT",0,"GENERATED_RESULT",0),http.object(cleanup));
            fixture.server.getApplicationContext().getBean(io.gateway.operations.RetentionService.class).scheduledCleanup();
            assertEquals(audit,count(fixture,"SELECT count(*) FROM audit_event WHERE occurred_at=1"));assertReadable(http,rest,saved,references);
            assertEquals(1,fixture.sourceCalls.get());
        }
    }

    private static Converter mapping(String input,String output,String start,String end){return new Converter("basic",input,output,List.of(
            new Rule("INPUT","period-patient","effective-patient","COPY",List.of()),new Rule("INPUT","period-document","effective-document","COPY",List.of()),
            new Rule("INPUT","period-choice","effective-start","CODE_MAP",List.of(new Argument("previous-week","STRING",start,null,null,null))),
            new Rule("INPUT","period-end","effective-end","DEFAULT_MISSING",List.of(new Argument("value","STRING",end,null,null,null)))));}
    private static Field field(String id,String name,int order,boolean required){return new Field(id,name,null,name,"SCALAR","STRING",order,required,false,null,null,128,Payload.Disposition.PERSIST);}
    private static Saved publish(DefinitionRepository repository,String key,Detail detail){var draft=repository.draft(new Draft(null,key,key,null,"reference fixture",detail),"fixture");return repository.apply(repository.validate(draft.object().id(),draft.version().id()),"fixture","reference fixture");}
    private static void object(SecurityFixture.FixtureMapper m,String id,String kind){m.execute("INSERT INTO config_object(id,kind,logical_key,created_at,created_by) VALUES('"+id+"','"+kind+"','"+id+"',1,'fixture')");m.execute("INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name) VALUES('"+id+"-v1','"+id+"','"+kind+"',1,1,'fixture','fixture','Synthetic')");}
    private static void activate(SecurityFixture.FixtureMapper m,String id){m.execute("UPDATE config_object SET current_version_id='"+id+"-v1',revision_counter=1,generation=1 WHERE id='"+id+"'");}
    private static Map<String,Object> call(GatewayHttpClient http,String token,String name,Map<String,Object> arguments)throws Exception {
        var response=http.send("/mcp","POST",http.json.writeValueAsString(Map.of("jsonrpc","2.0","id",1,"method","tools/call","params",Map.of("_meta",Map.of(Mcp2026Adapter.PROTOCOL,Mcp2026Adapter.VERSION,Mcp2026Adapter.CAPABILITIES,Map.of()),"name",name,"arguments",arguments))),
                Map.of("Authorization","Bearer "+token,"Content-Type","application/json","Accept","application/json, text/event-stream","MCP-Protocol-Version",Mcp2026Adapter.VERSION,"Mcp-Method","tools/call","Mcp-Name",name));
        assertEquals(200,response.statusCode(),response.body());return (Map<String,Object>)((Map<String,Object>)http.object(response).get("result")).get("structuredContent");
    }
    private static ResolvedReference resolve(GatewayHttpClient http,String token,String reference)throws Exception {var response=http.api("/api/references/"+reference,"GET",null,token);assertEquals(200,response.statusCode());return http.json.readValue(response.body(),ResolvedReference.class);}
    private static Map<String,Object> parameter(List<Map<String,Object>> rows,String port,String name){return rows.stream().filter(row->port.equals(row.get("port"))&&name.equals(row.get("parameter_name"))).findFirst().orElseThrow();}
    private static long count(GatewayFixture fixture,String sql){return fixture.store.read(s->s.getMapper(SecurityFixture.FixtureMapper.class).count(sql));}
    private static void assertReadable(GatewayHttpClient http,String token,ResultDocument saved,List<String> references)throws Exception {
        var response=http.api("/api/results/"+saved.id(),"GET",null,token);assertEquals(200,response.statusCode());assertEquals(saved,http.json.readValue(response.body(),ResultDocument.class));
        for(String reference:references)assertEquals(reference,resolve(http,token,reference).id());
    }
    private static void assertDatabaseFilesExclude(Path directory,List<String> secrets)throws Exception {try(var files=Files.list(directory)){for(Path file:files.filter(p->p.getFileName().toString().startsWith("platform.db")).toList()){String bytes=new String(Files.readAllBytes(file),StandardCharsets.ISO_8859_1);for(String secret:secrets)assertFalse(bytes.contains(secret),"Original body reached database/WAL");}}}

    private static final class OriginalPage implements AutoCloseable {
        static final String BEFORE="ORIGINAL_PRIVATE_BODY_BEFORE_CORRECTION",AFTER="ORIGINAL_PRIVATE_BODY_AFTER_CORRECTION";
        final AtomicReference<String> body=new AtomicReference<>(BEFORE);final AtomicInteger calls=new AtomicInteger();
        final ExecutorService executor=Executors.newVirtualThreadPerTaskExecutor();final HttpsServer server;final HttpClient client;final String origin;
        OriginalPage(Path directory)throws Exception {
            Path store=directory.resolve("original-page.p12");String password="synthetic-fixture";
            var process=new ProcessBuilder(Path.of(System.getProperty("java.home"),"bin","keytool").toString(),"-genkeypair","-alias","original-page","-keyalg","EC","-groupname","secp256r1","-validity","2","-dname","CN=127.0.0.1","-ext","SAN=ip:127.0.0.1","-storetype","PKCS12","-keystore",store.toString(),"-storepass",password,"-keypass",password,"-noprompt").redirectErrorStream(true).start();
            assertTrue(process.waitFor(30,TimeUnit.SECONDS));assertEquals(0,process.exitValue(),new String(process.getInputStream().readAllBytes(),StandardCharsets.UTF_8));
            var keyStore=KeyStore.getInstance("PKCS12");try(var input=Files.newInputStream(store)){keyStore.load(input,password.toCharArray());}
            var keys=KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());keys.init(keyStore,password.toCharArray());
            var serverTls=SSLContext.getInstance("TLS");serverTls.init(keys.getKeyManagers(),null,null);
            var trustStore=KeyStore.getInstance("PKCS12");trustStore.load(null,null);trustStore.setCertificateEntry("only-fixture",keyStore.getCertificate("original-page"));
            var trust=TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());trust.init(trustStore);
            var clientTls=SSLContext.getInstance("TLS");clientTls.init(null,trust.getTrustManagers(),null);
            server=HttpsServer.create(new InetSocketAddress("127.0.0.1",0),0);server.setHttpsConfigurator(new HttpsConfigurator(serverTls));server.setExecutor(executor);
            server.createContext("/record",exchange->{calls.incrementAndGet();byte[] bytes=body.get().getBytes(StandardCharsets.UTF_8);exchange.getResponseHeaders().set("Content-Type","text/plain");exchange.sendResponseHeaders(200,bytes.length);try(var output=exchange.getResponseBody()){output.write(bytes);}});
            server.start();origin="https://127.0.0.1:"+server.getAddress().getPort();
            client=HttpClient.newBuilder().sslContext(clientTls).followRedirects(HttpClient.Redirect.NEVER).build();
        }
        @Override public void close(){client.close();server.stop(0);executor.close();}
    }
}
