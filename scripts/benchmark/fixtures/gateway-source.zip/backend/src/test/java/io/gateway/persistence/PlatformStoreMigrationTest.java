package io.gateway.persistence;

import io.gateway.oauth.SecurityFixture;
import io.gateway.audit.AuditService;
import io.gateway.credentials.CredentialService;
import io.gateway.credentials.CredentialMapper;
import io.gateway.definitions.DefinitionMapper;
import io.gateway.results.ResultMapper;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import io.micronaut.context.ApplicationContext;
import io.micronaut.runtime.server.EmbeddedServer;
import org.flywaydb.core.Flyway;
import org.flywaydb.core.api.FlywayException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;
import java.nio.file.attribute.PosixFilePermissions;

import static org.junit.jupiter.api.Assertions.*;

/** Future-release fixtures only: production still has one unreleased V001, not a legacy-data migration. */
class PlatformStoreMigrationTest {
    private static final String SESSION_COLUMNS = "id,session_digest,principal_id,authenticated_at,"
        + "idle_expires_at,absolute_expires_at,revoked_at,session_generation,csrf_digest,session_kind";
    private static final List<String> PRESERVED_TABLES = List.of("config_object", "config_version",
        "configuration_change", "contract_version", "contract_field", "contract_field_version",
        "execution", "generated_result", "generated_result_revision", "result_value",
        "source_reference", "web_reference", "result_reference", "credential_version", "credential_state");
    @TempDir Path directory;

    @Test void sqliteRebuildPreservesSessionsReferencesAndIndexAndOldApplicationRefusesNewSchema() throws Exception {
        Snapshot before = seedInitialSchema();
        Flyway upgrade = rebuildFixture(false);
        upgrade.migrate();
        assertStartupBlocked();
        try (Connection connection = connection()) {
            assertPreserved(connection, before);
            assertEquals(List.of(List.of("rebuilt")), rows(connection,
                "SELECT DISTINCT migration_fixture FROM auth_session"));
            assertEquals(List.of(List.of("1")), rows(connection,
                "SELECT success FROM flyway_schema_history WHERE script='V002__session_rebuild.sql'"));
        }
    }

    @Test void failedRebuildRollsBackRowsSchemaAndIndexAndBlocksStartupWithoutRepair() throws Exception {
        Snapshot before = seedInitialSchema();
        Flyway upgrade = rebuildFixture(true);
        var failure = assertThrows(FlywayException.class, upgrade::migrate);
        assertTrue(failure.getMessage().contains("deliberately_missing_migration_table"),
            "The fixture must reach the deliberate error after DROP/rename/index, not fail before rebuilding");
        // A failed migration remains failed: neither an automatic retry nor app startup repairs history.
        assertThrows(FlywayException.class, upgrade::migrate);
        assertStartupBlocked();
        try (Connection connection = connection()) {
            assertPreserved(connection, before);
            assertEquals(before.schema(), rows(connection,
                "SELECT sql FROM sqlite_schema WHERE name='auth_session'"));
            assertEquals(List.of(), rows(connection,
                "SELECT name FROM sqlite_schema WHERE name='auth_session_rebuild'"));
            assertEquals(List.of(List.of("0")), rows(connection,
                "SELECT success FROM flyway_schema_history WHERE script='V002__session_rebuild.sql'"));
        }
    }

    private Snapshot seedInitialSchema() throws Exception {
        SqlSessionFactory repositories;
        String credentialVersion;
        try (SecurityFixture fixture = new SecurityFixture(directory)) {
            var browser = fixture.login("USER");
            fixture.oauth.begin(SecurityFixture.authorizeParameters("public", SecurityFixture.REDIRECT,
                "clinical.read"), browser.cookie());
            fixture.sql("INSERT INTO config_object(id,kind,logical_key,created_at,created_by) VALUES('migration-contract','CONTRACT','migration-contract',1,'fixture')");
            fixture.sql("INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name) VALUES('migration-contract-v1','migration-contract','CONTRACT',1,1,'fixture','fixture','Migration result')");
            fixture.sql("INSERT INTO contract_version(version_id,model_kind) VALUES('migration-contract-v1','VALUE')");
            fixture.sql("INSERT INTO contract_field(id,contract_object_id,logical_name) VALUES('migration-summary','migration-contract','summary')");
            fixture.sql("INSERT INTO contract_field_version(contract_version_id,field_id,member_name,node_kind,value_type,ordinal,required,nullable,audit_disposition) VALUES('migration-contract-v1','migration-summary','summary','SCALAR','STRING',0,true,false,'PERSIST')");
            fixture.sql("UPDATE config_object SET current_version_id='migration-contract-v1',revision_counter=1,generation=1 WHERE id='migration-contract'");
            fixture.sql("INSERT INTO execution(id,trace_id,actor_subject_id,caller_service_id,started_at,finished_at,business_outcome,response_outcome,principal_id,client_object_id) SELECT 'migration-execution','trace','fixture','public',1,2,'SUCCEEDED','SUCCEEDED',id,'public' FROM principal_ref");
            fixture.sql("INSERT INTO generated_result(id,owner_scope,caller_service_id,owner_principal_id,owner_client_object_id) SELECT 'migration-result','fixture','public',id,'public' FROM principal_ref");
            fixture.sql("INSERT INTO generated_result_revision(id,result_id,revision,output_contract_version_id,source_execution_id,created_at) VALUES('migration-revision','migration-result',1,'migration-contract-v1','migration-execution',2)");
            fixture.sql("INSERT INTO result_value(id,result_revision_id,contract_field_id,node_kind,ordinal,value_type,text_value) VALUES('migration-value','migration-revision','migration-summary','SCALAR',0,'STRING','보존된 합성 결과')");
            fixture.sql("UPDATE generated_result SET current_revision_id='migration-revision',revision_counter=1 WHERE id='migration-result'");
            fixture.sql("INSERT INTO source_reference(id,reference_kind,owner_scope,owner_principal_id,owner_client_object_id,source_execution_id,created_at) SELECT 'migration-reference','WEB_LINK','fixture',id,'public','migration-execution',2 FROM principal_ref");
            fixture.sql("INSERT INTO web_reference(reference_id,original_url,display_name) VALUES('migration-reference','https://records.example/migration','Synthetic source')");
            fixture.sql("INSERT INTO result_reference VALUES('migration-revision','migration-value','migration-reference',0)");
            byte[] key = new byte[32]; new java.security.SecureRandom().nextBytes(key);
            Path keyFile = directory.resolve("migration.key"); Files.write(keyFile,key);
            Files.setPosixFilePermissions(keyFile,PosixFilePermissions.fromString("r--------"));
            var credential = new CredentialService(fixture.store,new AuditService(fixture.store),directory.toString(),"migration")
                .create("migration-credential","PASSWORD","reader","synthetic-password".getBytes(java.nio.charset.StandardCharsets.UTF_8),"fixture","migration preservation");
            credentialVersion = credential.versionId();
            repositories = fixture.store.read(s -> new SqlSessionFactoryBuilder().build(s.getConfiguration()));
        }
        try (Connection connection = connection()) {
            assertEquals(List.of(List.of("OPEN", "USER")), rows(connection,
                "SELECT r.status,s.session_kind FROM oauth_authorization_request r"
                    + " JOIN auth_session s ON s.id=r.auth_session_id"));
            return new Snapshot(rows(connection, "SELECT " + SESSION_COLUMNS + " FROM auth_session ORDER BY id"),
                rows(connection, "SELECT id,auth_session_id,status FROM oauth_authorization_request ORDER BY id"),
                rows(connection, "SELECT sql FROM sqlite_schema WHERE name='auth_session'"),
                preservedRows(connection), repositories, credentialVersion);
        }
    }

    private Flyway rebuildFixture(boolean fail) throws Exception {
        Path migrations = Files.createDirectory(directory.resolve("future-migrations"));
        // foreign_keys must change outside a transaction. Flyway 12's SQLite parser treats BEGIN as a
        // compound SQL block, not a transaction opener; an outermost SAVEPOINT gives the same atomicity.
        Files.writeString(migrations.resolve("V002__session_rebuild.sql.conf"), "executeInTransaction=false\n");
        Files.writeString(migrations.resolve("V002__session_rebuild.sql"), """
            PRAGMA foreign_keys=OFF;
            SAVEPOINT session_rebuild;
            CREATE TABLE auth_session_rebuild (
              id TEXT PRIMARY KEY NOT NULL,
              session_digest TEXT NOT NULL UNIQUE,
              principal_id TEXT REFERENCES principal_ref(id),
              authenticated_at INTEGER NOT NULL,
              idle_expires_at INTEGER NOT NULL CHECK(idle_expires_at > authenticated_at),
              absolute_expires_at INTEGER NOT NULL CHECK(absolute_expires_at >= idle_expires_at),
              revoked_at INTEGER,
              session_generation INTEGER NOT NULL CHECK(session_generation > 0),
              csrf_digest TEXT NOT NULL,
              session_kind TEXT NOT NULL CHECK(session_kind IN ('USER','MANAGEMENT','PREAUTH')),
              migration_fixture TEXT NOT NULL DEFAULT 'rebuilt',
              CHECK(session_kind='PREAUTH' OR principal_id IS NOT NULL)
            ) STRICT;
            INSERT INTO auth_session_rebuild (%s) SELECT %s FROM auth_session;
            DROP TABLE auth_session;
            ALTER TABLE auth_session_rebuild RENAME TO auth_session;
            CREATE INDEX auth_session_absolute_expires_at_idx ON auth_session (absolute_expires_at);
            %s
            RELEASE SAVEPOINT session_rebuild;
            PRAGMA foreign_keys=ON;
            """.formatted(SESSION_COLUMNS, SESSION_COLUMNS,
                fail ? "INSERT INTO deliberately_missing_migration_table VALUES (1);" : ""));
        // Nontransactional Flyway scripts need an explicit error path too. The deliberate error occurs
        // after the destructive DROP/rename/index steps; rollback restores those steps and the copied rows.
        Files.writeString(migrations.resolve("afterEachMigrateError__rollback.sql.conf"), "executeInTransaction=false\n");
        Files.writeString(migrations.resolve("afterEachMigrateError__rollback.sql"),
            "ROLLBACK TO SAVEPOINT session_rebuild;\nRELEASE SAVEPOINT session_rebuild;\nPRAGMA foreign_keys=ON;\n");
        return Flyway.configure().dataSource(url(), "", "").initSql("PRAGMA foreign_keys=ON")
            .locations("classpath:db/migration/sqlite", "filesystem:" + migrations.toAbsolutePath())
            .ignoreMigrationPatterns(new String[0]).cleanDisabled(true).validateMigrationNaming(true).load();
    }

    private void assertPreserved(Connection connection, Snapshot before) throws SQLException {
        // INDEXED BY also fails if the real expiration index was lost during the rebuild.
        assertEquals(before.sessions(), rows(connection, "SELECT " + SESSION_COLUMNS
            + " FROM auth_session INDEXED BY auth_session_absolute_expires_at_idx ORDER BY id"));
        assertEquals(List.of(List.of("absolute_expires_at")), rows(connection,
            "SELECT name FROM pragma_index_info('auth_session_absolute_expires_at_idx') ORDER BY seqno"));
        assertEquals(before.requests(), rows(connection,
            "SELECT id,auth_session_id,status FROM oauth_authorization_request ORDER BY id"));
        assertEquals(List.of(List.of("ok")), rows(connection, "PRAGMA integrity_check"));
        assertEquals(List.of(), rows(connection, "PRAGMA foreign_key_check"));
        assertEquals(before.preserved(), preservedRows(connection));
        try (var statement = connection.createStatement()) {
            assertThrows(SQLException.class,
                () -> statement.executeUpdate("UPDATE auth_session SET principal_id='missing-principal'"));
            assertThrows(SQLException.class, () -> statement.executeUpdate("DELETE FROM auth_session"));
            assertThrows(SQLException.class,
                () -> statement.executeUpdate("UPDATE auth_session SET idle_expires_at=authenticated_at"));
        }
        // Reuse the real registered MyBatis repositories with this explicit migrated connection;
        // the old application must still refuse to start against this future schema.
        try (var migrated = connection(); var session = before.repositories().openSession(migrated)) {
            assertEquals("migration-contract-v1", session.getMapper(DefinitionMapper.class).head("migration-contract").currentVersionId());
            var results = session.getMapper(ResultMapper.class);
            assertEquals("migration-revision", results.result("migration-result").get("current_revision_id"));
            assertEquals("보존된 합성 결과", results.values("migration-revision").getFirst().textValue());
            assertEquals("migration-reference", results.references("migration-revision").getFirst().referenceId());
            assertEquals("https://records.example/migration", results.web("migration-reference").get("original_url"));
            assertEquals("migration", session.getMapper(CredentialMapper.class).versionRow(before.credentialVersion()).keyId());
        }
    }

    private void assertStartupBlocked() {
        var properties = new HashMap<>(SecurityFixture.properties(directory));
        properties.put("micronaut.server.port", -1);
        properties.put("micronaut.server.host", "127.0.0.1");
        var failure = assertThrows(RuntimeException.class, () -> {
            try (var server = ApplicationContext.run(EmbeddedServer.class, properties, "test")) {
                fail("An incompatible or failed schema must stop startup before serving requests");
            }
        });
        Throwable cause = failure;
        while (cause.getCause() != null) cause = cause.getCause();
        assertEquals("DATABASE_INITIALIZATION_FAILED",
            assertInstanceOf(PlatformStore.StoreException.class, cause).getMessage());
    }

    private String url() { return "jdbc:sqlite:" + directory.resolve("platform.db").toAbsolutePath(); }

    private Connection connection() throws SQLException {
        Connection connection = DriverManager.getConnection(url());
        try (var statement = connection.createStatement()) { statement.execute("PRAGMA foreign_keys=ON"); }
        return connection;
    }

    private static List<List<String>> rows(Connection connection, String sql) throws SQLException {
        var rows = new ArrayList<List<String>>();
        try (var statement = connection.createStatement(); var result = statement.executeQuery(sql)) {
            while (result.next()) {
                var row = new ArrayList<String>();
                for (int i = 1; i <= result.getMetaData().getColumnCount(); i++) row.add(result.getString(i));
                rows.add(row);
            }
        }
        return rows;
    }

    private static Map<String,List<List<String>>> preservedRows(Connection connection) throws SQLException {
        Map<String,List<List<String>>> snapshot = new LinkedHashMap<>();
        for (String table : PRESERVED_TABLES) snapshot.put(table, rows(connection, "SELECT * FROM " + table + " ORDER BY 1"));
        snapshot.put("credential_cipher", rows(connection,
            "SELECT credential_version_id,key_id,hex(nonce),hex(ciphertext),hex(authentication_tag),cipher_generation FROM credential_cipher ORDER BY credential_version_id"));
        return snapshot;
    }

    private record Snapshot(List<List<String>> sessions, List<List<String>> requests, List<List<String>> schema,
                            Map<String,List<List<String>>> preserved, SqlSessionFactory repositories, String credentialVersion) {}
}
