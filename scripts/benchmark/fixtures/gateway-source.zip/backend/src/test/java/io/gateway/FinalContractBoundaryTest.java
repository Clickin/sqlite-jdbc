package io.gateway;

import com.sun.net.httpserver.HttpServer;
import io.gateway.contracts.ContractService;
import io.gateway.definitions.DefinitionRepository;
import io.gateway.definitions.Definitions.*;
import io.gateway.mcp.Mcp2026Adapter;
import io.gateway.oauth.SecurityFixture;
import io.gateway.runtime.Payload;
import io.modelcontextprotocol.json.schema.JsonSchemaValidator;
import io.modelcontextprotocol.json.schema.JsonSchemaValidatorSupplier;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import static org.junit.jupiter.api.Assertions.*;

@SuppressWarnings("unchecked")
class FinalContractBoundaryTest {
    @TempDir Path directory;

    @Test void advertisedInputSchemaAndRuntimeValidatorAgreeOnNestedArrayNullAndScalarShapes() throws Exception {
        try(var fixture=new GatewayFixture(directory,-1);var http=new GatewayHttpClient(fixture.server.getURI())) {
            var repository=fixture.server.getApplicationContext().getBean(DefinitionRepository.class);
            var fields=new ArrayList<Field>();
            var valid=new LinkedHashMap<String,Object>();
            var scalarTypes=List.of("STRING","TEXT","INTEGER","LONG","DECIMAL","NUMBER","BOOLEAN","DATE","DATETIME","INSTANT","TIME","BINARY");
            var scalarValues=List.<Object>of("한글 & <특수>","본문",7,9007199254740993L,new BigDecimal("123.45"),new BigDecimal("0.125"),true,"2026-09-26","2026-09-26T10:15:30","2026-09-26T01:15:30Z","10:15:30+09:00","aGVsbG8=");
            for(int i=0;i<scalarTypes.size();i++) {
                String name=scalarTypes.get(i).toLowerCase(Locale.ROOT);
                fields.add(field(name,null,name,"SCALAR",scalarTypes.get(i),i,true,false));
                valid.put(name,scalarValues.get(i));
            }
            fields.add(field("nested",null,"nested","OBJECT",null,12,true,true));
            fields.add(field("nested-label","nested","label","SCALAR","STRING",0,true,false));
            fields.add(field("items",null,"items","ARRAY",null,13,true,true));
            fields.add(field("item","items",null,"OBJECT",null,0,true,false));
            fields.add(field("item-id","item","id","SCALAR","STRING",0,true,false));
            fields.add(field("item-active","item","active","SCALAR","BOOLEAN",1,false,true));
            fields.add(field("tags",null,"tags","ARRAY",null,14,true,false));
            fields.add(field("tag","tags",null,"SCALAR","STRING",0,true,true));
            fields.add(field("optional",null,"optional","SCALAR","STRING",15,false,true));
            valid.put("nested",Map.of("label","중첩"));
            valid.put("items",List.of(Map.of("id","A","active",true),Map.of("id","B")));
            valid.put("tags",Arrays.asList("첫째",null,"둘째"));
            var draft=repository.draft(new Draft(null,"schema-boundary","Schema boundary",null,"fixture",new Contract("VALUE",fields)),"fixture");
            var saved=repository.apply(repository.validate(draft.object().id(),draft.version().id()),"fixture","fixture");
            fixture.store.write(s->{var m=s.getMapper(SecurityFixture.FixtureMapper.class);
                m.execute("INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name) VALUES('lab-tool-v2','lab-tool','MCP_TOOL',2,2,'fixture','schema boundary','Synthetic lab tool')");
                m.execute("INSERT INTO mcp_tool_version(version_id,public_name,description,workflow_object_id,public_input_contract_version_id,public_output_contract_version_id,security_binding_object_id,target_policy_object_id,input_mapping_object_id,output_mapping_object_id,effect_kind) SELECT 'lab-tool-v2',public_name,description,workflow_object_id,'"+saved.version().id()+"',public_output_contract_version_id,security_binding_object_id,target_policy_object_id,input_mapping_object_id,output_mapping_object_id,effect_kind FROM mcp_tool_version WHERE version_id='lab-tool-v1'");
                m.execute("INSERT INTO mcp_tool_action SELECT 'lab-tool-v2',action_id FROM mcp_tool_action WHERE tool_version_id='lab-tool-v1'");
                m.execute("INSERT INTO mcp_tool_scope SELECT 'lab-tool-v2',scope_id FROM mcp_tool_scope WHERE tool_version_id='lab-tool-v1'");
                m.execute("UPDATE config_object SET current_version_id='lab-tool-v2',revision_counter=2,generation=2 WHERE id='lab-tool'");
                return null;});
            String token=http.authorize(SecurityFixture.RESOURCE,"A",List.of("clinical.lab.read"));
            var schema=(Map<String,Object>)descriptor(http,token).get("inputSchema");
            var validator=ServiceLoader.load(JsonSchemaValidatorSupplier.class).findFirst().orElseThrow().get();
            assertTrue(validator.validateSchema(schema).valid());
            var contracts=fixture.server.getApplicationContext().getBean(ContractService.class);
            var contract=contracts.load(saved.version().id());
            var expectedFields=new HashSet<>(valid.keySet());expectedFields.add("optional");
            assertEquals(expectedFields,((Map<String,Object>)schema.get("properties")).keySet());
            assertEquals(valid.keySet(),new HashSet<>((List<String>)schema.get("required")));
            assertEquals(false,schema.get("additionalProperties"));
            assertParity(validator,schema,contracts,contract,valid,true,"complete supported shape");
            for(String name:valid.keySet()) {
                var missing=new LinkedHashMap<>(valid);missing.remove(name);
                assertParity(validator,schema,contracts,contract,missing,false,"missing "+name);
                var wrong=new LinkedHashMap<>(valid);wrong.put(name,name.equals("boolean")?"true":false);
                assertParity(validator,schema,contracts,contract,wrong,false,"wrong type "+name);
                var nulled=new LinkedHashMap<>(valid);nulled.put(name,null);
                assertParity(validator,schema,contracts,contract,nulled,Set.of("nested","items").contains(name),"null "+name);
            }
            var optional=new LinkedHashMap<>(valid);optional.put("optional",null);
            assertParity(validator,schema,contracts,contract,optional,true,"optional nullable value");
            optional.put("optional",5);
            assertParity(validator,schema,contracts,contract,optional,false,"optional wrong type");
            var extra=new LinkedHashMap<>(valid);extra.put("unregistered","no");
            assertParity(validator,schema,contracts,contract,extra,false,"extra root field");
            for(Object nested:List.of(Map.of(),Map.of("label","ok","extra",1),Map.of("label",9))) {
                var candidate=new LinkedHashMap<>(valid);candidate.put("nested",nested);
                assertParity(validator,schema,contracts,contract,candidate,false,"nested object "+nested);
            }
            for(Object items:List.of(List.of(Map.of()),List.of(Map.of("id","A","extra",1)),List.of(Map.of("id",9)),Arrays.asList((Object)null),List.of("not an object"))) {
                var candidate=new LinkedHashMap<>(valid);candidate.put("items",items);
                assertParity(validator,schema,contracts,contract,candidate,false,"array item "+items);
            }
            var emptyArrays=new LinkedHashMap<>(valid);emptyArrays.put("items",List.of());emptyArrays.put("tags",List.of());
            assertParity(validator,schema,contracts,contract,emptyArrays,true,"empty arrays");
            var nullableItem=new LinkedHashMap<>(valid);var item=new LinkedHashMap<String,Object>();item.put("id","A");item.put("active",null);nullableItem.put("items",List.of(item));
            assertParity(validator,schema,contracts,contract,nullableItem,true,"nullable member inside array");
            var wrongTag=new LinkedHashMap<>(valid);wrongTag.put("tags",List.of(9));
            assertParity(validator,schema,contracts,contract,wrongTag,false,"scalar array item type");
            assertEquals(0,fixture.sourceCalls.get());
        }
    }

    @Test void changingOnlySourceBaseUrlKeepsPublishedToolAndWorkflowButUsesNewDependency() throws Exception {
        var calls=new AtomicInteger();
        var second=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
        try(var executor=Executors.newVirtualThreadPerTaskExecutor();var fixture=new GatewayFixture(directory,-1);var http=new GatewayHttpClient(fixture.server.getURI())) {
            second.setExecutor(executor);
            second.createContext("/labs",exchange->{
                calls.incrementAndGet();byte[] bytes="{\"answer\":\"두 번째 원본\",\"recordText\":\"replacement body\"}".getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type","application/json");exchange.sendResponseHeaders(200,bytes.length);
                try(var body=exchange.getResponseBody()){body.write(bytes);}
            });
            second.start();
            String token=http.authorize(SecurityFixture.RESOURCE,"A",List.of("clinical.lab.read"));
            var beforeDescriptor=descriptor(http,token);
            var before=call(http,token);
            assertEquals("합성 정상 결과",((Map<String,Object>)before.get("data")).get("answer"));
            assertEquals(1,fixture.sourceCalls.get());assertEquals(0,calls.get());
            var repository=fixture.server.getApplicationContext().getBean(DefinitionRepository.class);
            var original=fixture.datasource;var old=(HttpSource)original.detail();
            var replacement=new HttpSource("http://127.0.0.1:"+second.getAddress().getPort(),old.authenticationKind(),old.credentialObjectId(),old.tlsProfileObjectId(),old.proxyProfileId(),old.networkPolicyObjectId(),old.poolMaxTotal(),old.poolMaxPerRoute(),old.connectTimeoutMs(),old.redirectPolicy(),old.maxConcurrent(),old.queueTimeoutMs(),old.headers());
            var draft=repository.draft(new Draft(original.object().id(),original.object().logicalKey(),original.version().displayName(),original.version().description(),"source URL only",replacement),"fixture");
            var applied=repository.apply(repository.validate(draft.object().id(),draft.version().id()),"fixture","source URL only");
            assertEquals(beforeDescriptor,descriptor(http,token));
            var after=call(http,token);
            assertEquals("두 번째 원본",((Map<String,Object>)after.get("data")).get("answer"));
            assertEquals(1,fixture.sourceCalls.get());assertEquals(1,calls.get());
            assertEquals(fixture.workflow.version().id(),repository.get(fixture.workflow.object().id(),null).version().id());
            assertEquals(1L,count(fixture,"SELECT count(*) FROM config_version WHERE object_id='"+fixture.workflow.object().id()+"'"));
            assertEquals(1L,count(fixture,"SELECT count(*) FROM config_version WHERE object_id='lab-tool'"));
            assertEquals(2L,count(fixture,"SELECT count(*) FROM execution WHERE workflow_version_id='"+fixture.workflow.version().id()+"'"));
            assertDependency(fixture,(String)before.get("executionId"),original.version().id(),applied.version().id());
            assertDependency(fixture,(String)after.get("executionId"),applied.version().id(),original.version().id());
        } finally {second.stop(0);}
    }

    private static Field field(String id,String parent,String name,String kind,String type,int ordinal,boolean required,boolean nullable) {
        return new Field(id,id,parent,name,kind,type,ordinal,required,nullable,null,null,null,Payload.Disposition.PERSIST);
    }
    private static void assertParity(JsonSchemaValidator validator,Map<String,Object> schema,ContractService contracts,ContractService.Contract contract,Map<String,Object> value,boolean expected,String description) {
        var validation=validator.validate(schema,value);
        assertEquals(expected,validation.valid(),description+": "+validation.errorMessage());
        if(expected)assertDoesNotThrow(()->contracts.validate(contract,value),description);
        else assertThrows(ContractService.InvalidContract.class,()->contracts.validate(contract,value),description);
    }
    private static Map<String,Object> descriptor(GatewayHttpClient http,String token) throws Exception {
        var params=Map.of("_meta",Map.of(Mcp2026Adapter.PROTOCOL,Mcp2026Adapter.VERSION,Mcp2026Adapter.CAPABILITIES,Map.of()));
        var response=http.send("/mcp","POST",http.json.writeValueAsString(Map.of("jsonrpc","2.0","id",1,"method","tools/list","params",params)),Map.of("Authorization","Bearer "+token,"Content-Type","application/json","Accept","application/json, text/event-stream","MCP-Protocol-Version",Mcp2026Adapter.VERSION,"Mcp-Method","tools/list"));
        assertEquals(200,response.statusCode(),response.body());
        return ((List<Map<String,Object>>)((Map<String,Object>)http.object(response).get("result")).get("tools")).stream().filter(t->"lab-tool".equals(t.get("name"))).findFirst().orElseThrow();
    }
    private static Map<String,Object> call(GatewayHttpClient http,String token) throws Exception {
        var response=http.call(token,Map.of("patientId","A","documentId","DA"));assertEquals(200,response.statusCode(),response.body());
        var result=(Map<String,Object>)http.object(response).get("result");assertEquals(false,result.get("isError"));
        var content=(Map<String,Object>)result.get("structuredContent");assertEquals("SUCCEEDED",content.get("status"));return content;
    }
    private static long count(GatewayFixture fixture,String sql) {return fixture.store.read(s->s.getMapper(SecurityFixture.FixtureMapper.class).count(sql));}
    private static void assertDependency(GatewayFixture fixture,String execution,String expected,String absent) {
        assertNotNull(execution);
        assertEquals(1L,count(fixture,"SELECT count(*) FROM execution_dependency WHERE execution_id='"+execution+"' AND config_version_id='"+expected+"'"));
        assertEquals(0L,count(fixture,"SELECT count(*) FROM execution_dependency WHERE execution_id='"+execution+"' AND config_version_id='"+absent+"'"));
    }
}
