package io.gateway;

import com.sun.net.httpserver.HttpServer;
import io.gateway.oauth.SecurityFixture;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import java.io.*;
import java.net.*;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.function.BooleanSupplier;
import static org.junit.jupiter.api.Assertions.*;

class WorkflowBoundaryHttpTest {
    @TempDir Path directory;
    enum Transport { MCP,REST,CONSOLE }
    private record Request(String path,String body,Map<String,String> headers) {}

    @Test void registeredMyBatisConverterAndHttpWriteShareIndependentReadAndWriteAuthority()throws Exception {
        try(var target=new Target();var fixture=new WorkflowBoundaryFixture(directory,target.uri(),30000,true);
            var client=new GatewayHttpClient(fixture.server.getURI())) {
            String readOnly=client.authorize(SecurityFixture.RESOURCE,"A",List.of("clinical.lab.read"));
            var denied=client.call(readOnly,WorkflowBoundaryFixture.ARGUMENTS);
            assertEquals(403,denied.statusCode(),denied.body());assertEquals(0,target.calls.get());
            String write=client.authorize(SecurityFixture.RESOURCE,"A",WorkflowBoundaryFixture.ACTIONS);
            var deniedAfterConversion=new AtomicBoolean();
            fixture.authority.beforeActionDecision=action->{
                if(action.equals("clinical.order.write")&&fixture.count("SELECT count(*) FROM execution_stage WHERE stage_key='CONVERT' AND business_outcome='SUCCEEDED'")==1) {
                    deniedAfterConversion.set(true);fixture.authority.deniedActions=Set.of(action);
                }
            };
            var deniedOutput=client.call(write,WorkflowBoundaryFixture.ARGUMENTS);
            assertEquals(403,deniedOutput.statusCode(),deniedOutput.body());assertEquals(0,target.calls.get());
            assertTrue(deniedAfterConversion.get());
            assertEquals(1,fixture.count("SELECT count(*) FROM execution_stage WHERE stage_key='INPUT' AND business_outcome='SUCCEEDED'"));
            assertEquals(1,fixture.count("SELECT count(*) FROM execution_stage WHERE stage_key='CONVERT' AND business_outcome='SUCCEEDED'"));
            assertEquals(0,fixture.count("SELECT count(*) FROM execution_stage WHERE stage_key='OUTPUT'"));
            fixture.authority.beforeActionDecision=action->{};fixture.authority.deniedActions=Set.of();
            var allowed=client.call(write,WorkflowBoundaryFixture.ARGUMENTS);
            var outcome=outcome(client,allowed,Transport.MCP);
            assertEquals("SUCCEEDED",outcome.get("businessOutcome"));assertEquals("PREPARED",outcome.get("responseOutcome"));
            assertEquals(Map.of("receipt","synthetic-confirmed"),outcome.get("data"));
            assertEquals(Map.of("patientId","A","documentId","DA","orderText",WorkflowBoundaryFixture.RAW_TEXT),client.json.readValue(target.body.get(),Map.class));
            assertEquals(1,target.calls.get());
            assertEquals(3,fixture.count("SELECT count(*) FROM execution_stage WHERE execution_id='"+outcome.get("executionId")+"' AND business_outcome='SUCCEEDED'"));
            assertEquals(0,fixture.count("SELECT count(*) FROM audit_parameter WHERE string_value='"+WorkflowBoundaryFixture.RAW_TEXT+"'"));
        }
    }

    @Test void writerAndAuditFailuresBeforeIoStopWorkAndPostSuccessAuditFailureNeverRetries()throws Exception {
        try(var target=new Target();var fixture=new WorkflowBoundaryFixture(directory,target.uri(),30000,true);
            var client=new GatewayHttpClient(fixture.server.getURI())) {
            String token=client.authorize(SecurityFixture.RESOURCE,"A",WorkflowBoundaryFixture.ACTIONS);
            for(String trigger:List.of(
                    "CREATE TRIGGER boundary_fail BEFORE INSERT ON execution BEGIN SELECT RAISE(ABORT,'synthetic writer failure'); END",
                    "CREATE TRIGGER boundary_fail BEFORE INSERT ON audit_parameter WHEN NEW.port='REQUEST' BEGIN SELECT RAISE(ABORT,'synthetic audit failure'); END")) {
                fixture.sql(trigger);
                var rejected=outcome(client,client.call(token,WorkflowBoundaryFixture.ARGUMENTS),Transport.MCP);
                assertEquals("FAILED",rejected.get("businessOutcome"));assertEquals("NOT_SENT",rejected.get("responseOutcome"));
                assertEquals(Map.of("code","AUDIT_UNAVAILABLE"),rejected.get("error"));
                assertEquals(0,target.calls.get());assertEquals(0,fixture.count("SELECT count(*) FROM execution"));
                fixture.sql("DROP TRIGGER boundary_fail");
            }
            var failures=Map.of(
                    "POST_OPERATION_VALIDATION_OR_AUDIT_FAILED","CREATE TRIGGER boundary_fail BEFORE INSERT ON audit_parameter WHEN NEW.port='TARGET_OUTPUT' BEGIN SELECT RAISE(ABORT,'synthetic audit failure'); END",
                    "RESPONSE_FAILED","CREATE TRIGGER boundary_fail BEFORE UPDATE ON execution WHEN NEW.response_outcome='PREPARED' BEGIN SELECT RAISE(ABORT,'synthetic writer failure'); END");
            int sent=0;
            for(var failure:failures.entrySet()) {
                fixture.sql(failure.getValue());
                var result=outcome(client,client.call(token,WorkflowBoundaryFixture.ARGUMENTS),Transport.MCP);
                assertEquals("RESPONSE_FAILED",result.get("status"));assertEquals("SUCCEEDED",result.get("businessOutcome"));assertEquals("FAILED",result.get("responseOutcome"));
                assertEquals(Map.of("code",failure.getKey()),result.get("error"));
                assertEquals(++sent,target.calls.get());
                assertEquals(sent,fixture.count("SELECT count(*) FROM execution WHERE business_outcome='SUCCEEDED' AND response_outcome='FAILED'"));
                assertEquals(sent,fixture.count("SELECT count(*) FROM execution_stage WHERE stage_key='OUTPUT' AND business_outcome='SUCCEEDED' AND finished_at IS NOT NULL"));
                fixture.sql("DROP TRIGGER boundary_fail");
            }
        }
    }

    @Test void disconnectedWriteWithNoConfirmedResponseStaysUnknownWithoutReplay()throws Exception {
        try(var target=new Target();var fixture=new WorkflowBoundaryFixture(directory,target.uri(),30000,true);
            var client=new GatewayHttpClient(fixture.server.getURI())) {
            target.drop=true;
            String token=client.authorize(SecurityFixture.RESOURCE,"A",WorkflowBoundaryFixture.ACTIONS);
            var result=outcome(client,client.call(token,WorkflowBoundaryFixture.ARGUMENTS),Transport.MCP);
            assertEquals("OUTCOME_UNKNOWN",result.get("businessOutcome"));assertEquals("OUTCOME_UNKNOWN",result.get("status"));assertEquals(1,target.calls.get());
            assertEquals(1,fixture.count("SELECT count(*) FROM execution WHERE business_outcome='OUTCOME_UNKNOWN'"));
            assertEquals(1,fixture.count("SELECT count(*) FROM execution_stage WHERE stage_key='OUTPUT' AND business_outcome='OUTCOME_UNKNOWN'"));
        }
    }

    @ParameterizedTest @EnumSource(Transport.class)
    void inboundHttp1DisconnectStopsLaterStagesAndLeavesPoolUsable(Transport transport)throws Exception {
        try(var target=new Target();var fixture=new WorkflowBoundaryFixture(directory,target.uri(),30000,true);
            var client=new GatewayHttpClient(fixture.server.getURI())) {
            Request request=request(client,transport);
            var entered=new CountDownLatch(1);var release=new CountDownLatch(1);var paused=new AtomicBoolean();
            fixture.authority.beforeActionDecision=action->{
                if(action.equals("clinical.lab.read")&&fixture.count("SELECT count(*) FROM execution")==1&&paused.compareAndSet(false,true)){entered.countDown();await(release);}
            };
            try(Socket socket=open(fixture.server.getURI(),request)) {
                assertTrue(entered.await(5,TimeUnit.SECONDS));
                socket.setSoLinger(true,0);
            }
            try {
                // The close crosses a real HTTP/1 socket; allow its independent Netty event loop to observe RST.
                Thread.sleep(200);
            } finally {release.countDown();}
            eventually(()->fixture.count("SELECT count(*) FROM execution WHERE finished_at IS NOT NULL") == 1);
            assertEquals(1,fixture.count("SELECT count(*) FROM execution WHERE business_outcome='FAILED' AND error_code='CANCELLED'"));
            assertEquals(0,fixture.count("SELECT count(*) FROM execution_stage"));assertEquals(0,target.calls.get());
            fixture.authority.beforeActionDecision=action->{};
            var recovered=outcome(client,client.send(request.path(),"POST",request.body(),request.headers()),transport);
            assertEquals("SUCCEEDED",recovered.get("businessOutcome"));assertEquals(1,target.calls.get());
        }
    }

    @ParameterizedTest @EnumSource(Transport.class)
    void executionDeadlineStopsLaterStagesAcrossAllIngresses(Transport transport)throws Exception {
        try(var target=new Target();var fixture=new WorkflowBoundaryFixture(directory,target.uri(),2000,true);
            var client=new GatewayHttpClient(fixture.server.getURI())) {
            Request request=request(client,transport);
            var paused=new AtomicBoolean();
            fixture.authority.beforeActionDecision=action->{if(action.equals("clinical.lab.read")&&fixture.count("SELECT count(*) FROM execution")==1&&paused.compareAndSet(false,true)) {
                try {Thread.sleep(2200);}catch(InterruptedException e){Thread.currentThread().interrupt();throw new AssertionError(e);}
            }};
            var result=outcome(client,client.send(request.path(),"POST",request.body(),request.headers()),transport);
            assertEquals("FAILED",result.get("businessOutcome"));assertEquals(Map.of("code","CANCELLED"),result.get("error"));
            assertEquals(0,target.calls.get());assertEquals(0,fixture.count("SELECT count(*) FROM execution_stage"));
            fixture.authority.beforeActionDecision=action->{};
            assertEquals("SUCCEEDED",outcome(client,client.send(request.path(),"POST",request.body(),request.headers()),transport).get("businessOutcome"));
            assertEquals(1,target.calls.get());
        }
    }

    @Test void inboundDisconnectDuringWriteDoesNotClaimRollbackOrReplay()throws Exception {
        try(var target=new Target();var fixture=new WorkflowBoundaryFixture(directory,target.uri(),30000,true);
            var client=new GatewayHttpClient(fixture.server.getURI())) {
            Request request=request(client,Transport.MCP);target.block=true;
            try(Socket socket=open(fixture.server.getURI(),request)) {
                assertTrue(target.entered.await(5,TimeUnit.SECONDS));socket.setSoLinger(true,0);
            }
            eventually(()->fixture.count("SELECT count(*) FROM execution WHERE finished_at IS NOT NULL") == 1);
            assertEquals(1,target.calls.get());
            assertEquals(1,fixture.count("SELECT count(*) FROM execution WHERE business_outcome='OUTCOME_UNKNOWN'"));
            assertEquals(1,fixture.count("SELECT count(*) FROM execution_stage WHERE stage_key='OUTPUT' AND business_outcome='OUTCOME_UNKNOWN'"));
            target.release.countDown();
        }
    }

    @Test void normalProcessRestartKeepsTokenAndInterruptedWriteRemainsIncompleteWithoutResume()throws Exception {
        try(var target=new Target()) {
            String token;
            try(var first=new Child(directory,target.uri(),true);var client=new GatewayHttpClient(first.uri)) {
                token=client.authorize(SecurityFixture.RESOURCE,"A",WorkflowBoundaryFixture.ACTIONS);
                assertEquals("SUCCEEDED",outcome(client,client.call(token,WorkflowBoundaryFixture.ARGUMENTS),Transport.MCP).get("businessOutcome"));
                assertEquals(1,target.calls.get());
            }
            try(var second=new Child(directory,target.uri(),false);var client=new GatewayHttpClient(second.uri)) {
                var catalogue=client.send("/mcp","POST",rpcBody(client,"tools/list",Map.of()),rpcHeaders(token,"tools/list"));
                assertEquals(200,catalogue.statusCode(),catalogue.body());assertTrue(catalogue.body().contains("lab-tool"));
                assertEquals(1,target.calls.get());
                target.block=true;
                try(Socket socket=open(second.uri,new Request("/mcp",rpcBody(client,"tools/call",WorkflowBoundaryFixture.ARGUMENTS),rpcHeaders(token,"tools/call")))) {
                    assertTrue(target.blocked.await(5,TimeUnit.SECONDS));
                    second.process.destroyForcibly();assertTrue(second.process.waitFor(10,TimeUnit.SECONDS));
                }
            }
            assertEquals(2,target.calls.get());target.release.countDown();target.block=false;
            try(var restarted=new WorkflowBoundaryFixture(directory,target.uri(),30000,false);var client=new GatewayHttpClient(restarted.server.getURI())) {
                var admin=managementHeaders(client);
                var executions=client.send("/management/executions","GET",null,admin);assertEquals(200,executions.statusCode(),executions.body());
                @SuppressWarnings("unchecked") var rows=(List<Map<String,Object>>)client.json.readValue(executions.body(),List.class);
                assertEquals(2,rows.size());
                var incomplete=rows.stream().filter(row->"INCOMPLETE".equals(row.get("completion_state"))).findFirst().orElseThrow();
                assertEquals("RUNNING",incomplete.get("business_outcome"));assertEquals("PENDING",incomplete.get("response_outcome"));
                assertNull(incomplete.get("finished_at"));
                var detail=client.object(client.send("/management/executions/"+incomplete.get("id"),"GET",null,admin));
                @SuppressWarnings("unchecked") var stages=(List<Map<String,Object>>)detail.get("stages");
                var output=stages.stream().filter(stage->"OUTPUT".equals(stage.get("stage_key"))).findFirst().orElseThrow();
                assertEquals("INCOMPLETE",output.get("completion_state"));assertEquals("RUNNING",output.get("business_outcome"));
                assertEquals(2,target.calls.get());
                // Only this explicit new request may send again. Startup/status reads never resume business work.
                assertEquals("SUCCEEDED",outcome(client,client.call(token,WorkflowBoundaryFixture.ARGUMENTS),Transport.MCP).get("businessOutcome"));
                assertEquals(3,target.calls.get());
                assertEquals(1,restarted.count("SELECT count(*) FROM execution WHERE finished_at IS NULL"));
            }
        }
    }

    private static Request request(GatewayHttpClient client,Transport transport)throws Exception {
        if(transport==Transport.CONSOLE)return new Request("/management/workflows/write-workflow/preview",client.json.writeValueAsString(Map.of("arguments",WorkflowBoundaryFixture.ARGUMENTS)),managementHeaders(client));
        String token=client.authorize(transport==Transport.MCP?SecurityFixture.RESOURCE:WorkflowBoundaryFixture.REST_RESOURCE,"A",WorkflowBoundaryFixture.ACTIONS);
        return transport==Transport.MCP?new Request("/mcp",rpcBody(client,"tools/call",WorkflowBoundaryFixture.ARGUMENTS),rpcHeaders(token,"tools/call")):
                new Request("/api/workflows/write-workflow/execute",client.json.writeValueAsString(WorkflowBoundaryFixture.ARGUMENTS),Map.of("Content-Type","application/json","Authorization","Bearer "+token));
    }
    private static String rpcBody(GatewayHttpClient client,String method,Map<String,Object> arguments) {
        var params=new LinkedHashMap<String,Object>();params.put("_meta",Map.of("io.modelcontextprotocol/protocolVersion","2026-07-28","io.modelcontextprotocol/clientCapabilities",Map.of()));
        if(method.equals("tools/call")){params.put("name","lab-tool");params.put("arguments",arguments);}
        return client.json.writeValueAsString(Map.of("jsonrpc","2.0","id",1,"method",method,"params",params));
    }
    private static Map<String,String> rpcHeaders(String token,String method) {
        var headers=new LinkedHashMap<>(Map.of("Content-Type","application/json","Accept","application/json, text/event-stream","MCP-Protocol-Version","2026-07-28","Mcp-Method",method,"Authorization","Bearer "+token));
        if(method.equals("tools/call"))headers.put("Mcp-Name","lab-tool");return headers;
    }
    private static Map<String,String> managementHeaders(GatewayHttpClient client)throws Exception {
        var session=client.send("/auth/session","GET",null,Map.of());assertEquals(200,session.statusCode(),session.body());
        String cookie=session.headers().firstValue("set-cookie").orElseThrow().split(";",2)[0];
        var logged=client.send("/auth/session/login","POST",client.json.writeValueAsString(Map.of("credential","synthetic-admin","sessionKind","MANAGEMENT")),
                Map.of("Cookie",cookie,"Origin",SecurityFixture.ISSUER,"X-CSRF-Token",(String)client.object(session).get("csrfToken"),"Content-Type","application/json"));
        assertEquals(200,logged.statusCode(),logged.body());
        return Map.of("Cookie",logged.headers().firstValue("set-cookie").orElseThrow().split(";",2)[0],"Origin",SecurityFixture.ISSUER,"X-CSRF-Token",(String)client.object(logged).get("csrfToken"),"Content-Type","application/json");
    }
    @SuppressWarnings("unchecked") private static Map<String,Object> outcome(GatewayHttpClient client,HttpResponse<String> response,Transport transport) {
        assertEquals(200,response.statusCode(),response.body());var body=client.object(response);
        return transport==Transport.MCP?(Map<String,Object>)((Map<String,Object>)body.get("result")).get("structuredContent"):body;
    }
    private static Socket open(URI uri,Request request)throws IOException {
        var socket=new Socket();socket.connect(new InetSocketAddress("127.0.0.1",uri.getPort()),3000);
        byte[] body=request.body().getBytes(StandardCharsets.UTF_8);
        var headers=new StringBuilder("POST ").append(request.path()).append(" HTTP/1.1\r\nHost: 127.0.0.1:").append(uri.getPort()).append("\r\nContent-Length: ").append(body.length).append("\r\n");
        request.headers().forEach((key,value)->headers.append(key).append(": ").append(value).append("\r\n"));headers.append("\r\n");
        socket.getOutputStream().write(headers.toString().getBytes(StandardCharsets.US_ASCII));socket.getOutputStream().write(body);socket.getOutputStream().flush();return socket;
    }
    private static void eventually(BooleanSupplier condition)throws InterruptedException {
        long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(8);
        while(!condition.getAsBoolean()&&System.nanoTime()<deadline)Thread.sleep(20);
        assertTrue(condition.getAsBoolean(),"Execution did not reach its terminal state");
    }
    private static void await(CountDownLatch latch) {
        try {if(!latch.await(10,TimeUnit.SECONDS))throw new AssertionError("Synthetic boundary was not released");}
        catch(InterruptedException e){Thread.currentThread().interrupt();throw new AssertionError(e);}
    }
    private static final class Target implements AutoCloseable {
        final HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
        final ExecutorService executor=Executors.newVirtualThreadPerTaskExecutor();
        final AtomicInteger calls=new AtomicInteger();final AtomicReference<String> body=new AtomicReference<>();
        final CountDownLatch entered=new CountDownLatch(1),blocked=new CountDownLatch(1),release=new CountDownLatch(1);
        volatile boolean drop,block;
        Target()throws IOException {
            server.createContext("/write",exchange->{
                calls.incrementAndGet();body.set(new String(exchange.getRequestBody().readAllBytes(),StandardCharsets.UTF_8));entered.countDown();
                try {
                    if(block){blocked.countDown();await(release);}
                    if(drop)return;
                    byte[] bytes="{\"receipt\":\"synthetic-confirmed\"}".getBytes(StandardCharsets.UTF_8);
                    exchange.getResponseHeaders().set("Content-Type","application/json");exchange.sendResponseHeaders(200,bytes.length);exchange.getResponseBody().write(bytes);
                } finally {exchange.close();}
            });server.setExecutor(executor);server.start();
        }
        String uri(){return "http://127.0.0.1:"+server.getAddress().getPort();}
        @Override public void close(){release.countDown();server.stop(0);executor.close();}
    }
    private static final class Child implements AutoCloseable {
        final Process process;final URI uri;
        final ExecutorService reader=Executors.newSingleThreadExecutor();
        Child(Path directory,String target,boolean seed)throws Exception {
            process=new ProcessBuilder(Path.of(System.getProperty("java.home"),"bin","java").toString(),"--enable-native-access=ALL-UNNAMED","-cp",
                    Objects.requireNonNull(System.getProperty("gateway.test.classpath"),"gateway.test.classpath"),WorkflowBoundaryFixture.class.getName(),directory.toString(),target,Boolean.toString(seed)).redirectErrorStream(true).start();
            var ready=new CompletableFuture<URI>();
            reader.submit(()->{try(var lines=process.inputReader()) {
                String line;while((line=lines.readLine())!=null) {
                    if(line.startsWith("WORKFLOW_BOUNDARY_READY "))ready.complete(URI.create(line.substring("WORKFLOW_BOUNDARY_READY ".length())));
                    else if(line.matches("WORKFLOW_BOUNDARY_FAILED [A-Za-z0-9_$]+(?: [A-Z_]+)?"))
                        ready.completeExceptionally(new IllegalStateException("Child startup failed: "+line.substring("WORKFLOW_BOUNDARY_FAILED ".length())));
                }
                if(!ready.isDone())ready.completeExceptionally(new IllegalStateException(process.isAlive()?"Child readiness stream closed":"Child exited before readiness (exit "+process.exitValue()+")"));
            }catch(Exception e){ready.completeExceptionally(e);}});
            try {uri=ready.get(30,TimeUnit.SECONDS);}catch(Exception e){process.destroyForcibly();reader.shutdownNow();throw e;}
        }
        @Override public void close()throws Exception {
            if(process.isAlive()){process.getOutputStream().close();if(!process.waitFor(10,TimeUnit.SECONDS)){process.destroyForcibly();assertTrue(process.waitFor(5,TimeUnit.SECONDS));}}
            reader.shutdown();assertTrue(reader.awaitTermination(5,TimeUnit.SECONDS));
        }
    }
}
