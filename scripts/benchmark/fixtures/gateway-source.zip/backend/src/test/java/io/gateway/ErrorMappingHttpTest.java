package io.gateway;

import io.gateway.definitions.*;
import io.gateway.definitions.Definitions.*;
import io.gateway.management.SecurityDefinitions;
import io.gateway.oauth.SecurityFixture;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class ErrorMappingHttpTest {
    @TempDir Path directory;
    @Test void errorRuleRevisionsChangePublicErrorsWithoutWorkflowCascadeOrRetry()throws Exception {
        try(var fixture=new GatewayFixture(directory,-1);var client=new GatewayHttpClient(fixture.server.getURI())){
            fixture.source.removeContext("/labs");
            fixture.source.createContext("/labs",exchange->{fixture.sourceCalls.incrementAndGet();exchange.sendResponseHeaders(503,-1);exchange.close();});
            var security=fixture.server.getApplicationContext().getBean(SecurityDefinitions.class);
            var rules=rule(security,null,"REMOTE_UNAVAILABLE",502);
            var repository=fixture.server.getApplicationContext().getBean(DefinitionRepository.class);
            var original=(Workflow)fixture.workflow.detail();
            var draft=repository.draft(new Draft(fixture.workflow.object().id(),"lab-workflow","lab-workflow",null,"register errors",
                new Workflow(rules.object().id(),original.stages(),original.ports(),original.securityBindings())),"fixture");
            var workflow=repository.apply(repository.validate(draft.object().id(),draft.version().id()),"fixture","register errors");
            String token=client.authorize(SecurityFixture.RESOURCE,"A",List.of("clinical.lab.read"));
            assertMapped(client,token,"REMOTE_UNAVAILABLE",502);
            var next=rule(security,rules.object().id(),"REMOTE_TEMPORARY",503);
            assertMapped(client,token,"REMOTE_TEMPORARY",503);
            assertEquals(2,fixture.sourceCalls.get());
            assertEquals(workflow.version().id(),repository.get(workflow.object().id(),null).version().id());
            long observed=fixture.store.read(s->s.getMapper(SecurityFixture.FixtureMapper.class).count("SELECT count(*) FROM execution_dependency WHERE config_version_id='"+next.version().id()+"'"));
            assertEquals(1L,observed);
        }
    }
    private SecurityDefinitions.Saved rule(SecurityDefinitions service,String id,String code,int status){
        var draft=service.draft(new SecurityDefinitions.Draft(id,"remote-errors","Remote errors",null,"synthetic","ERROR_MAPPING",
            Map.of("rules",List.of(Map.of("remote_code","HTTP_STATUS_503","public_code",code,"status_code",status)))),"fixture");
        var checked=service.validate(draft.object().id(),draft.version().id());
        return service.apply(draft.object().id(),draft.version().id(),checked.generation(),checked.dependencyVersions(),"fixture","synthetic");
    }
    @SuppressWarnings("unchecked") private void assertMapped(GatewayHttpClient client,String token,String code,int status)throws Exception {
        var response=client.call(token,Map.of("patientId","A","documentId","DA"));assertEquals(200,response.statusCode(),response.body());
        var result=(Map<String,Object>)client.object(response).get("result");assertEquals(true,result.get("isError"));
        var content=(Map<String,Object>)result.get("structuredContent");assertEquals("FAILED",content.get("businessOutcome"));
        var error=(Map<String,Object>)content.get("error");assertEquals(code,error.get("code"));assertEquals(status,((Number)error.get("httpStatus")).intValue());
    }
}
