package io.gateway.oauth;

import io.gateway.authorization.*;
import io.gateway.persistence.PlatformStore;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;
import static io.gateway.oauth.SecurityFixture.*;

class OAuthSecurityTest {
    @TempDir Path directory;
    @Test void publicAndConfidentialPkceAndBearerAudience() throws Exception {
        try(var f=new SecurityFixture(directory)){
            var token=f.token("A");var principal=f.authenticate(token);
            var context=f.authorization.authorize(principal,"clinical.lab.read",patient("A"));
            assertEquals("A",context.target().patientIdentifier());assertEquals("synthetic-doctor",context.principal().subject());
            var confidential=f.code("confidential",f.login("USER"),List.of(new OAuthService.ActionTarget("clinical.lab.read",patient("A"))),"clinical.read");
            assertThrows(OAuthProtocol.Failure.class,()->f.oauth.token(exchangeForm(confidential),null));
            assertEquals("confidential",f.authenticate(f.exchange(confidential)).clientId());
            assertThrows(AccessDenied.class,()->f.authorization.authenticateBearer(List.of("Bearer "+token.get("access_token")),ISSUER+"/management"));
            assertThrows(AccessDenied.class,()->f.authorization.authenticateBearer(List.of("Bearer "+token.get("access_token"),"Bearer other"),RESOURCE));
            assertThrows(AccessDenied.class,()->f.authorization.authenticateBearer(List.of(),RESOURCE));
        }
    }
    @Test void pkceClientRedirectAndResourceFailuresDoNotConsumeCode() throws Exception {
        try(var f=new SecurityFixture(directory)){
            var code=f.code("A");
            for(var invalid:List.of(new SecurityFixture.Code(code.value(),"public","wrong",REDIRECT,code.requestId()),new SecurityFixture.Code(code.value(),"public",VERIFIER,"https://other.example/callback",code.requestId()),new SecurityFixture.Code(code.value(),"confidential",VERIFIER,REDIRECT,code.requestId())))assertThrows(OAuthProtocol.Failure.class,()->f.exchange(invalid));
            assertThrows(OAuthProtocol.Failure.class,()->f.oauth.token(exchangeForm(code)+"&resource="+RESOURCE,null));
            assertThrows(OAuthProtocol.Failure.class,()->f.oauth.token(exchangeForm(code).replace("code_verifier=","omitted_verifier="),null));
            assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_authorization_code WHERE consumed_at IS NOT NULL"));
            assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_access_token"));
            assertEquals("public",f.authenticate(f.exchange(code)).clientId());
            assertThrows(OAuthProtocol.Failure.class,()->f.exchange(code));
        }
    }
    @Test void exactRedirectAndRestrictedLoopbackPortException() throws Exception {
        try(var f=new SecurityFixture(directory)){
            var client=f.store.read(s->s.getMapper(OAuthMapper.class).client("public"));var redirects=f.store.read(s->s.getMapper(OAuthMapper.class).redirects(client.versionId()));
            assertTrue(OAuthProtocol.redirectAllowed(REDIRECT,client,redirects));
            assertTrue(OAuthProtocol.redirectAllowed("http://127.0.0.1:59321/callback",client,redirects));
            for(String invalid:List.of("https://client.example/callback/extra","https://client.example.evil/callback","https://client.example/callback#fragment","http://127.0.0.1.evil:321/callback","http://localhost:321/callback","http://127.0.0.2:321/callback","http://127.0.0.1:321/other","http://127.0.0.1:321/callback?evil=1"))assertFalse(OAuthProtocol.redirectAllowed(invalid,client,redirects),invalid);
            var browser=f.login("USER");var parameters=authorizeParameters("public","https://evil.example/callback","clinical.read");
            var failure=assertThrows(OAuthProtocol.Failure.class,()->f.oauth.begin(parameters,browser.cookie()));assertNull(failure.redirect());
            var invalid=authorizeParameters("public",REDIRECT,"clinical.read");invalid.put("code_challenge_method",List.of("plain"));
            failure=assertThrows(OAuthProtocol.Failure.class,()->f.oauth.begin(invalid,browser.cookie()));assertTrue(failure.redirect().startsWith(REDIRECT+"?error="));assertTrue(failure.redirect().contains("state=synthetic-state-sentinel"));assertTrue(failure.redirect().contains("iss=https%3A%2F%2Fgateway.example"));
        }
    }
    @Test void originCsrfFixationLogoutAndIndependentTabs() throws Exception {
        try(var f=new SecurityFixture(directory)){
            var pre=f.sessions.session(null);
            assertThrows(AccessDenied.class,()->f.sessions.login(pre.cookie(),"https://evil.example",pre.view().csrfToken(),"synthetic-doctor","USER"));
            assertThrows(AccessDenied.class,()->f.sessions.login(pre.cookie(),ISSUER,"forged","synthetic-doctor","USER"));
            String first=f.oauth.begin(authorizeParameters("public",REDIRECT,"clinical.read"),pre.cookie()),second=f.oauth.begin(authorizeParameters("public",REDIRECT,"clinical.read"),pre.cookie());
            var browser=f.sessions.login(pre.cookie(),ISSUER,pre.view().csrfToken(),"synthetic-doctor","USER");
            assertNotEquals(pre.cookie(),browser.cookie());assertThrows(AccessDenied.class,()->f.sessions.require(pre.cookie()));
            assertThrows(AccessDenied.class,()->f.oauth.request(first,f.login("USER").cookie()));
            for(var pair:Map.of(first,"A",second,"B").entrySet())f.oauth.consent(pair.getKey(),browser.cookie(),ISSUER,browser.view().csrfToken(),new OAuthService.Consent("care",List.of(new OAuthService.ActionTarget("clinical.lab.read",patient(pair.getValue()))),true));
            assertEquals(1,f.count("SELECT COUNT(*) FROM oauth_grant_rule WHERE patient_identifier='A'"));assertEquals(1,f.count("SELECT COUNT(*) FROM oauth_grant_rule WHERE patient_identifier='B'"));
            assertThrows(AccessDenied.class,()->f.oauth.consent(first,browser.cookie(),ISSUER,browser.view().csrfToken(),new OAuthService.Consent("care",List.of(),true)));
            f.sessions.logout(browser.cookie(),ISSUER,browser.view().csrfToken());assertThrows(AccessDenied.class,()->f.sessions.require(browser.cookie()));
        }
    }
    @Test void pendingDeniedUnavailableEndConsentWithoutGrant() throws Exception {
        try(var f=new SecurityFixture(directory)){
            var browser=f.login("USER");for(String outcome:List.of("DENY","PENDING","UNAVAILABLE")){String id=f.oauth.begin(authorizeParameters("public",REDIRECT,"clinical.read"),browser.cookie());f.authority.outcome=outcome;String response=f.oauth.consent(id,browser.cookie(),ISSUER,browser.view().csrfToken(),new OAuthService.Consent("care",List.of(new OAuthService.ActionTarget("clinical.lab.read",patient("A"))),true));assertTrue(response.contains("error=access_denied"));assertThrows(AccessDenied.class,()->f.oauth.request(id,browser.cookie()));}
            assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_grant"));assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_authorization_code"));
        }
    }
    @Test void intersectionAndCanonicalResolverDenyBeforeBody() throws Exception {
        try(var f=new SecurityFixture(directory)){
            var browser=f.login("USER");var code=f.code("public",browser,List.of(new OAuthService.ActionTarget("clinical.lab.read",patient("A")),new OAuthService.ActionTarget("clinical.order.write",patient("A")),new OAuthService.ActionTarget("clinical.lab.read",patient("B"))),"clinical.read clinical.write");var principal=f.authenticate(f.exchange(code));AtomicInteger bodies=new AtomicInteger();
            assertThrows(AccessDenied.class,()->{f.authorization.authorize(principal,"clinical.order.write",patient("B"));bodies.incrementAndGet();});
            assertThrows(AccessDenied.class,()->{f.authorization.authorize(principal,"clinical.lab.read",new CanonicalTarget("DOCUMENT","synthetic-hospital","synthetic-mrn","A",null,"DB"));bodies.incrementAndGet();});
            f.authority.outcome="DENY";assertThrows(AccessDenied.class,()->{f.authorization.authorize(principal,"clinical.lab.read",patient("A"));bodies.incrementAndGet();});
            f.authority.outcome="ALLOW";f.authority.clinicalRoles=Set.of();assertThrows(AccessDenied.class,()->{f.authorization.authorize(principal,"clinical.lab.read",patient("A"));bodies.incrementAndGet();});assertFalse(f.authorization.canList(principal,"clinical.lab.read"));
            assertEquals(0,bodies.get());f.authority.clinicalRoles=Set.of("clinician");var context=f.authorization.authorize(principal,"clinical.lab.read",new CanonicalTarget("DOCUMENT","synthetic-hospital","synthetic-mrn","A",null,"DA"));assertEquals("DA",((Map<?,?>)context.parameters().get("authorized")).get("documentIdentifier"));
            assertThrows(UnsupportedOperationException.class,()->context.parameters().put("authorized",Map.of()));
        }
    }
    @Test void configurationAdminIsNotClinicalAdminAndUserSessionIsNotManagement() throws Exception {
        try(var f=new SecurityFixture(directory)){
            var admin=f.login("MANAGEMENT");var context=f.authorization.authorizeManagement(admin.cookie(),"config.manage");
            assertThrows(AccessDenied.class,()->f.authorization.authorize(context.principal(),"clinical.lab.read",patient("A")));
            var doctor=f.login("USER");assertThrows(AccessDenied.class,()->f.authorization.authorizeManagement(doctor.cookie(),"config.manage"));
            assertThrows(IllegalArgumentException.class,()->patient("*"));assertThrows(IllegalArgumentException.class,()->new CanonicalTarget("PATIENT","org","system",null,null,null));
        }
    }
    @Test void clientPrincipalTokenAndGrantRevocationAreLive() throws Exception {
        try(var f=new SecurityFixture(directory)){
            var token=f.token("A");var principal=f.authenticate(token);f.sql("UPDATE config_object SET enabled=false WHERE id='public'");assertThrows(AccessDenied.class,()->f.authenticate(token));f.sql("UPDATE config_object SET enabled=true WHERE id='public'");
            f.sql("UPDATE principal_ref SET blocked=true WHERE id='"+principal.principalId()+"'");assertThrows(AccessDenied.class,()->f.authenticate(token));f.sql("UPDATE principal_ref SET blocked=false WHERE id='"+principal.principalId()+"'");
            f.oauth.revokeGrant(principal.grantId(),"fixture");assertThrows(AccessDenied.class,()->f.authorization.recheckLocal(principal));
            var current=f.token("A");f.oauth.revoke(form(Map.of("client_id","public","token",(String)current.get("access_token"))),null);assertThrows(AccessDenied.class,()->f.authenticate(current));
            f.oauth.revoke(form(Map.of("client_id","public","token","not-a-real-token")),null);
        }
    }
    @Test void refreshRotatesNarrowsAndReplayRevokesWholeFamily() throws Exception {
        try(var f=new SecurityFixture(directory)){
            var token=f.exchange(f.code("public",f.login("USER"),List.of(new OAuthService.ActionTarget("clinical.lab.read",patient("A")),new OAuthService.ActionTarget("clinical.order.write",patient("A"))),"clinical.read clinical.write"));String original=(String)token.get("refresh_token");
            var next=f.oauth.token(form(Map.of("grant_type","refresh_token","client_id","public","refresh_token",original,"resource",RESOURCE,"scope","clinical.read")),null);
            assertNotEquals(original,next.get("refresh_token"));assertEquals("clinical.read",next.get("scope"));
            assertThrows(OAuthProtocol.Failure.class,()->f.oauth.token(form(Map.of("grant_type","refresh_token","client_id","public","refresh_token",(String)next.get("refresh_token"),"resource",RESOURCE,"scope","clinical.read clinical.write")),null));
            assertThrows(OAuthProtocol.Failure.class,()->f.refresh(original));assertThrows(AccessDenied.class,()->f.authenticate(token));assertThrows(AccessDenied.class,()->f.authenticate(next));assertThrows(OAuthProtocol.Failure.class,()->f.refresh((String)next.get("refresh_token")));
        }
    }
    @Test void currentLocalGenerationIsRecheckedAfterAuthorityOutsideWriter() throws Exception {
        try(var f=new SecurityFixture(directory)){
            var code=f.code("A");f.authority.beforeDecision=()->f.sql("UPDATE config_object SET enabled=false,generation=generation+1 WHERE id='public'");
            assertThrows(OAuthProtocol.Failure.class,()->f.exchange(code));assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_access_token"));assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_authorization_code WHERE consumed_at IS NOT NULL"));
        }
    }
    @Test void codeConcurrentExchangeAndAuditRollback() throws Exception {
        try(var f=new SecurityFixture(directory)){
            var code=f.code("A");f.sql("CREATE TRIGGER reject_token_audit BEFORE INSERT ON audit_event WHEN NEW.event_type='TOKEN_ISSUED' BEGIN SELECT RAISE(ABORT,'synthetic failure'); END");
            assertThrows(PlatformStore.StoreException.class,()->f.exchange(code));assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_access_token"));assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_authorization_code WHERE consumed_at IS NOT NULL"));
            f.sql("DROP TRIGGER reject_token_audit");assertRace(f,()->f.exchange(code),false);
        }
    }
    @Test void refreshConcurrentReplayAndAuditRollback() throws Exception {
        try(var f=new SecurityFixture(directory)){
            var token=f.token("A");String refresh=(String)token.get("refresh_token");f.sql("CREATE TRIGGER reject_refresh_audit BEFORE INSERT ON audit_event WHEN NEW.event_type='REFRESH_ROTATED' BEGIN SELECT RAISE(ABORT,'synthetic failure'); END");
            assertThrows(PlatformStore.StoreException.class,()->f.refresh(refresh));assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_refresh_token WHERE consumed_at IS NOT NULL"));assertEquals(1,f.count("SELECT COUNT(*) FROM oauth_access_token"));f.sql("DROP TRIGGER reject_refresh_audit");
            assertRace(f,()->f.refresh(refresh),true);assertThrows(AccessDenied.class,()->f.authenticate(token));
        }
    }
    @Test void consumedAncestorReplayAndExplicitRevokeSerializeWithLiveDescendantRotation() throws Exception {
        try(var first=new SecurityFixture(directory);var second=new SecurityFixture(new PlatformStore(directory.resolve("platform.db")),directory,false)) {
            assertAncestorReplayAndRevoke(first,second);
        }
    }
    static void assertAncestorReplayAndRevoke(SecurityFixture first,SecurityFixture second) throws Exception {
        for(boolean replay:List.of(true,false))for(boolean rotationFirst:List.of(true,false)) {
            var ancestor=first.token("A");String old=(String)ancestor.get("refresh_token");
            var descendant=first.refresh(old);String live=(String)descendant.get("refresh_token");
            String family=first.store.read(s->s.getMapper(OAuthMapper.class).refresh(Secrets.digest(old)).familyId());
            CountDownLatch held=new CountDownLatch(1),release=new CountDownLatch(1),started=new CountDownLatch(1);
            if(!rotationFirst)first.authority.beforeDecision=()->{held.countDown();await(release);};
            try(var executor=Executors.newVirtualThreadPerTaskExecutor()) {
                var rotation=executor.submit(()->{
                    try {
                        return first.store.withWriteGuard((s,before)->{if(rotationFirst&&!before){held.countDown();await(release);}},()->first.refresh(live));
                    } catch(OAuthProtocol.Failure failure) { return failure; }
                });
                assertTrue(held.await(10,TimeUnit.SECONDS));
                var revocation=executor.submit(()->{
                    started.countDown();
                    if(replay)assertThrows(OAuthProtocol.Failure.class,()->second.refresh(old));
                    else second.oauth.revoke(form(Map.of("client_id","public","token",live)),null);
                });
                try {
                    assertTrue(started.await(10,TimeUnit.SECONDS));
                    if(!rotationFirst)revocation.get(15,TimeUnit.SECONDS);
                } finally { release.countDown(); }
                var result=rotation.get(15,TimeUnit.SECONDS);revocation.get(15,TimeUnit.SECONDS);
                if(rotationFirst) {
                    assertInstanceOf(Map.class,result);
                    @SuppressWarnings("unchecked") var successor=(Map<String,Object>)result;
                    assertThrows(AccessDenied.class,()->second.authenticate(successor));
                    assertThrows(OAuthProtocol.Failure.class,()->second.refresh((String)successor.get("refresh_token")));
                } else assertInstanceOf(OAuthProtocol.Failure.class,result);
            } finally {release.countDown();first.authority.beforeDecision=()->{};}
            assertEquals(1,first.count("SELECT COUNT(*) FROM oauth_refresh_family WHERE id='"+family+"' AND revoked_at IS NOT NULL"));
            assertEquals(0,first.count("SELECT COUNT(*) FROM oauth_refresh_token WHERE family_id='"+family+"' AND revoked_at IS NULL"));
            assertEquals(0,first.count("SELECT COUNT(*) FROM oauth_access_token WHERE family_id='"+family+"' AND revoked_at IS NULL"));
            assertThrows(AccessDenied.class,()->second.authenticate(descendant));
        }
    }
    private static void await(CountDownLatch latch) {
        try {if(!latch.await(10,TimeUnit.SECONDS))throw new AssertionError("refresh barrier timeout");}
        catch(InterruptedException failure){Thread.currentThread().interrupt();throw new AssertionError(failure);}
    }
    static void assertRace(SecurityFixture f,Callable<Map<String,Object>> operation,boolean refresh) throws Exception {
        CyclicBarrier barrier=new CyclicBarrier(2);f.authority.beforeDecision=()->{try{barrier.await(10,TimeUnit.SECONDS);}catch(Exception e){throw new AssertionError(e);}};
        try(var executor=Executors.newVirtualThreadPerTaskExecutor()){
            List<Future<Object>> futures=new ArrayList<>();for(int i=0;i<2;i++)futures.add(executor.submit(()->{try{return operation.call();}catch(OAuthProtocol.Failure failure){return failure;}}));
            Object first=futures.get(0).get(15,TimeUnit.SECONDS),second=futures.get(1).get(15,TimeUnit.SECONDS);assertEquals(1,(first instanceof Map?1:0)+(second instanceof Map?1:0));assertEquals(1,(first instanceof OAuthProtocol.Failure?1:0)+(second instanceof OAuthProtocol.Failure?1:0));
            if(refresh){assertEquals(1,f.count("SELECT COUNT(*) FROM oauth_refresh_token WHERE predecessor_id IS NOT NULL"));assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_access_token WHERE revoked_at IS NULL"));}else{assertEquals(1,f.count("SELECT COUNT(*) FROM oauth_access_token"));assertEquals(1,f.count("SELECT COUNT(*) FROM audit_event WHERE event_type='TOKEN_ISSUED'"));}
        }finally{f.authority.beforeDecision=()->{};}
    }
    @Test void persistedCredentialsAreDigestsAndStateCiphertextAndRestoreInvalidates() throws Exception {
        try(var f=new SecurityFixture(directory)){
            var browser=f.login("USER");String request=f.oauth.begin(authorizeParameters("public",REDIRECT,"clinical.read"),browser.cookie());
            var stored=f.store.read(s->s.getMapper(OAuthMapper.class).request(request));assertFalse(new String(stored.stateCipher(),java.nio.charset.StandardCharsets.UTF_8).contains("synthetic-state-sentinel"));
            var token=f.token("A");String raw=(String)token.get("access_token");assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_access_token WHERE token_digest='"+raw+"'"));assertEquals(1,f.count("SELECT COUNT(*) FROM oauth_access_token WHERE token_digest='"+Secrets.digest(raw)+"'"));
            f.oauth.invalidateForRestore();assertThrows(AccessDenied.class,()->f.authenticate(token));assertThrows(AccessDenied.class,()->f.sessions.require(browser.cookie()));assertThrows(OAuthProtocol.Failure.class,()->f.refresh((String)token.get("refresh_token")));assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_authorization_request WHERE opaque_state_cipher IS NOT NULL"));
        }
    }
    @Test void optionalRefreshAndScopeMappingChangesNeverExpandAnIssuedGrant() throws Exception {
        try(var f=new SecurityFixture(directory)){
            var code=f.code("no-refresh",f.login("USER"),List.of(new OAuthService.ActionTarget("clinical.lab.read",patient("A"))),"clinical.read");
            var token=f.exchange(code);
            assertFalse(token.containsKey("refresh_token"));
            assertEquals(0,f.count("SELECT COUNT(*) FROM oauth_refresh_family"));
            var principal=f.authenticate(token);
            f.sql("INSERT INTO oauth_scope_action VALUES('read','clinical.order.write',1)");
            assertThrows(AccessDenied.class,()->f.authorization.authorize(principal,"clinical.order.write",patient("A")));
            f.sql("UPDATE config_object SET enabled=false WHERE id='clinician-role'");
            assertThrows(AccessDenied.class,()->f.authorization.authorize(principal,"clinical.lab.read",patient("A")));
        }
    }
    @Test void finiteMandatoryTtlAndExpiryAreEnforced() throws Exception {
        try(var f=new SecurityFixture(directory)){
            assertThrows(IllegalArgumentException.class,()->new OAuthSettings(ISSUER,RESOURCE,ISSUER,"security",0,300,3600,7200,600,1800,3600,directory.resolve("state.key").toString()));
            var token=f.token("A");f.sql("UPDATE oauth_access_token SET issued_at=1,expires_at=2");assertThrows(AccessDenied.class,()->f.authenticate(token));
            var browser=f.login("USER");f.sql("UPDATE auth_session SET revoked_at=1");assertThrows(AccessDenied.class,()->f.sessions.require(browser.cookie()));
        }
    }
}
