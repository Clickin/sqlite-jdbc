package io.gateway.connectors.jdbc;

import io.gateway.definitions.Definitions.*;
import io.gateway.runtime.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import java.sql.DriverManager;
import java.time.Instant;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class MapperSafetyTest {
    @TempDir Path directory;
    @Test void normalMyBatisBindWorksButJavaAndContextMutationExpressionsCannotPublish()throws Exception {
        String url="jdbc:sqlite:"+directory.resolve("source.db");
        try(var connection=DriverManager.getConnection(url)){connection.createStatement().execute("CREATE TABLE fixture(id INTEGER)");}
        try(var store=new io.gateway.persistence.PlatformStore(directory.resolve("platform.db"));
            var resources=new JdbcResources(new io.gateway.credentials.CredentialService(store,new io.gateway.audit.AuditService(store),"",""))){
            var safe=graph(url,"<select id=\"read\" resultType=\"map\"><bind name=\"bound\" value=\"'allow' + 'ed'\"/>SELECT #{bound,typeHandler=org.apache.ibatis.type.StringTypeHandler} AS answer</select>");
            try(var adapter=resources.prepare(safe,operation())){assertEquals("allowed",adapter.execute(Payload.of(Map.of()),new Cancellation(Instant.now().plusSeconds(5))).object().get("answer"));}
            for(String expression:List.of("@java.lang.System@getProperty('user.home')","new java.io.File('unsafe')","#context","_parameter.class","_parameter.authorized = null")){
                var xml="<select id=\"read\" resultType=\"map\"><bind name=\"bound\" value=\""+expression+"\"/>SELECT #{bound} AS answer</select>";
                assertThrows(ExecutionFailure.class,()->{try(var unused=resources.prepare(graph(url,xml),operation())){}});
            }
            var overwrite="<select id=\"read\" resultType=\"map\"><bind name=\"authorized\" value=\"null\"/>SELECT 'unsafe' AS answer</select>";
            assertThrows(ExecutionFailure.class,()->{try(var unused=resources.prepare(graph(url,overwrite),operation())){}});
            for(String option:List.of("typeHandler=java.util.Timer","javaType=java.util.Timer")){
                var inline="<select id=\"read\" resultType=\"map\"><bind name=\"bound\" value=\"'allowed'\"/>SELECT #{bound,"+option+"} AS answer</select>";
                assertThrows(ExecutionFailure.class,()->{try(var unused=resources.prepare(graph(url,inline),operation())){}});
            }
        }
    }
    @Test void resultTypesCannotConstructIoObjectsOrLoadCompiledMapperNamespaces()throws Exception {
        String url="jdbc:sqlite:"+directory.resolve("source.db");
        try(var connection=DriverManager.getConnection(url)){connection.createStatement().execute("CREATE TABLE fixture(id INTEGER)");}
        Path marker=directory.resolve("must-not-be-created");
        String body="<resultMap id=\"unsafe\" type=\"java.io.FileOutputStream\"><constructor><arg column=\"filename\" javaType=\"string\"/></constructor></resultMap><select id=\"read\" resultMap=\"unsafe\">SELECT '"+marker+"' AS filename</select>";
        try(var store=new io.gateway.persistence.PlatformStore(directory.resolve("platform.db"));
            var resources=new JdbcResources(new io.gateway.credentials.CredentialService(store,new io.gateway.audit.AuditService(store),"",""))){
            assertThrows(ExecutionFailure.class,()->{try(var unused=resources.prepare(graph(url,body),operation())){}});
            assertFalse(Files.exists(marker));
            var existing=graph(url,"<select id=\"read\" resultType=\"map\">SELECT 'allowed' AS answer</select>");
            var definitions=new HashMap<>(existing.definitions());
            definitions.put("mapper",saved("mapper",new Mapper("SQLITE",List.of(new MapperDocument("fixture.xml","<mapper namespace=\"java.lang.System\"><select id=\"read\" resultType=\"map\">SELECT 1</select></mapper>")),List.of())));
            assertThrows(ExecutionFailure.class,()->JdbcResources.validateMappers(new ResolvedGraph("operation",definitions)));
        }
    }
    private static JdbcOperation operation(){return new JdbcOperation("source","input","output",Effect.READ_ONLY,2000,10,4096L,"mapper","fixture.read","SELECT_ONE","READ_ONLY",List.of(),List.of());}
    private static ResolvedGraph graph(String url,String body){
        var source=new JdbcSource(url,"SQLITE",null,0,1,1000,true,1,1000);
        var input=new Contract("VALUE",List.of());
        var output=new Contract("VALUE",List.of(new Field("answer","answer",null,"answer","SCALAR","STRING",0,true,false,null,null,100,Payload.Disposition.PERSIST)));
        String xml="<?xml version=\"1.0\"?><!DOCTYPE mapper PUBLIC \"-//mybatis.org//DTD Mapper 3.0//EN\" \"https://mybatis.org/dtd/mybatis-3-mapper.dtd\"><mapper namespace=\"fixture\">"+body+"</mapper>";
        return new ResolvedGraph("operation",Map.of("source",saved("source",source),"input",saved("input",input),"output",saved("output",output),"mapper",saved("mapper",new Mapper("SQLITE",List.of(new MapperDocument("fixture.xml",xml)),List.of()))));
    }
    private static Saved saved(String id,Detail detail){return new Saved(new Head(id,detail.kind().name(),id,id+"-v",1,1,true),new Version(id+"-v",id,detail.kind().name(),1,0,"fixture","fixture",id,null),detail);}
}
