package io.gateway.operations;

import io.gateway.audit.AuditService;
import io.gateway.authorization.AccessDenied;
import io.gateway.oauth.*;
import io.gateway.persistence.*;
import io.gateway.results.ResultModels.*;
import java.nio.file.*;
import java.util.*;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static io.gateway.operations.ResultsOperationsTest.*;
import static org.junit.jupiter.api.Assertions.*;

class StorageAtomicityTest {
    @TempDir Path directory;

    @Test void failedReferenceAndResultAuditsRollbackValuesLinksHeadsAndTargets() throws Exception {
        try (var fixture = new SecurityFixture(directory)) {
            seed(fixture);
            var results = service(fixture);
            var principal = principal(fixture, "public", "A");
            execution(fixture, principal, "execution", "A");
            var observed = new WebObservation("https://records.example/note/synthetic", "note", null);
            fixture.sql("CREATE TRIGGER fail_reference_audit BEFORE INSERT ON audit_event WHEN NEW.event_type='REFERENCE_RECORDED' BEGIN SELECT RAISE(ABORT,'fixture'); END");
            assertThrows(PlatformStore.StoreException.class, () -> results.recordWebReference(principal, "execution", observed));
            for (String table : List.of("source_reference", "web_reference", "reference_target"))
                assertEquals(0, fixture.count("SELECT count(*) FROM " + table), table);
            assertEquals(0, fixture.count("SELECT count(*) FROM audit_event WHERE event_type='REFERENCE_RECORDED'"));
            fixture.sql("DROP TRIGGER fail_reference_audit");
            String reference = results.recordWebReference(principal, "execution", observed);
            var content = request("execution", List.of(new ReferenceInput(reference, "summary", 0)));
            var saved = results.create(principal, content);
            var before = resultRows(fixture.store);
            long auditBefore = fixture.count("SELECT count(*) FROM audit_event WHERE event_type='RESULT_SAVED'");
            fixture.sql("CREATE TRIGGER fail_result_audit BEFORE INSERT ON audit_event WHEN NEW.event_type='RESULT_SAVED' BEGIN SELECT RAISE(ABORT,'fixture'); END");
            assertThrows(PlatformStore.StoreException.class, () -> results.create(principal, content));
            assertEquals(before, resultRows(fixture.store));
            assertThrows(PlatformStore.StoreException.class, () -> results.revise(principal, saved.id(), new ReviseResult(saved.revisionId(), content)));
            assertEquals(before, resultRows(fixture.store));
            assertEquals(auditBefore, fixture.count("SELECT count(*) FROM audit_event WHERE event_type='RESULT_SAVED'"));
            assertEquals(saved.revisionId(), results.read(principal, saved.id()).revisionId());
            assertEquals(reference, results.read(principal, saved.id()).references().getFirst().referenceId());
            assertEquals(observed.url(), results.resolve(principal, reference).directUrl());
            fixture.sql("DROP TRIGGER fail_result_audit");
            assertEquals(2, results.revise(principal, saved.id(), new ReviseResult(saved.revisionId(), content)).revision());
        }
    }

    @Test void naturalExpiryPreservesLiveReplayFamilyAndHistoricalResultAuditLinks() throws Exception {
        try (var fixture = new SecurityFixture(directory)) {
            seed(fixture);
            var results = service(fixture);
            var expired = principal(fixture, "public", "A");
            execution(fixture, expired, "historical", "A");
            String reference = results.recordWebReference(expired, "historical", new WebObservation("https://records.example/note/expiry", "note", null));
            var saved = results.create(expired, request("historical", List.of(new ReferenceInput(reference, "summary", 0))));
            var historicalAudits = rows(fixture.store, "SELECT id,execution_id,principal_id,client_object_id,public_grant_id,public_token_record_id FROM audit_event WHERE execution_id='historical' ORDER BY id");
            assertEquals(2, historicalAudits.size());
            var liveOriginal = fixture.token("A");
            var liveFirst = fixture.authenticate(liveOriginal);
            var liveRotated = fixture.refresh((String) liveOriginal.get("refresh_token"));
            var liveCurrent = fixture.authenticate(liveRotated);
            // Age timestamps, not revoke flags: natural expiry must not depend on an administrative revoke.
            fixture.sql("UPDATE oauth_access_token SET issued_at=1,expires_at=2 WHERE id IN ('" + expired.tokenId() + "','" + liveFirst.tokenId() + "')");
            fixture.sql("UPDATE oauth_authorization_code SET issued_at=1,expires_at=2 WHERE grant_id='" + expired.grantId() + "'");
            fixture.sql("UPDATE oauth_authorization_request SET created_at=1,expires_at=2 WHERE id IN (SELECT request_id FROM oauth_authorization_code WHERE grant_id='" + expired.grantId() + "')");
            fixture.sql("UPDATE oauth_refresh_token SET issued_at=1,expires_at=2 WHERE family_id IN (SELECT id FROM oauth_refresh_family WHERE grant_id='" + expired.grantId() + "') OR (family_id IN (SELECT id FROM oauth_refresh_family WHERE grant_id='" + liveFirst.grantId() + "') AND predecessor_id IS NULL)");
            fixture.sql("UPDATE oauth_refresh_family SET created_at=1,absolute_expires_at=2 WHERE grant_id='" + expired.grantId() + "'");
            fixture.sql("UPDATE oauth_grant SET issued_at=1,expires_at=2 WHERE id='" + expired.grantId() + "'");
            var retention = new RetentionService(fixture.store, fixture.authorization, new AuditService(fixture.store));
            retention.cleanupAuthentication();
            assertThrows(AccessDenied.class, () -> results.read(expired, saved.id()));
            assertEquals(0, fixture.count("SELECT count(*) FROM oauth_grant WHERE id='" + expired.grantId() + "'"));
            assertEquals(0, fixture.count("SELECT count(*) FROM oauth_access_token WHERE id IN ('" + expired.tokenId() + "','" + liveFirst.tokenId() + "')"));
            assertEquals(2, fixture.count("SELECT count(*) FROM oauth_refresh_token WHERE family_id IN (SELECT id FROM oauth_refresh_family WHERE grant_id='" + liveFirst.grantId() + "')"));
            assertEquals(liveCurrent.tokenId(), fixture.authenticate(liveRotated).tokenId());
            assertEquals(historicalAudits, rows(fixture.store, "SELECT id,execution_id,principal_id,client_object_id,public_grant_id,public_token_record_id FROM audit_event WHERE execution_id='historical' ORDER BY id"));
            assertEquals(1, fixture.count("SELECT count(*) FROM execution WHERE id='historical' AND public_grant_id='" + expired.grantId() + "'"));
            assertEquals(1, fixture.count("SELECT count(*) FROM generated_result WHERE id='" + saved.id() + "' AND public_grant_id='" + expired.grantId() + "'"));
            assertEquals(1, fixture.count("SELECT count(*) FROM source_reference WHERE id='" + reference + "' AND public_grant_id='" + expired.grantId() + "'"));
            var renewed = principal(fixture, "public", "A");
            assertEquals(saved.revisionId(), results.read(renewed, saved.id()).revisionId());
            assertEquals(reference, results.resolve(renewed, reference).id());
            // The expired ancestor remains a replay tombstone while its descendant is usable.
            assertThrows(OAuthProtocol.Failure.class, () -> fixture.refresh((String) liveOriginal.get("refresh_token")));
            assertThrows(AccessDenied.class, () -> fixture.authenticate(liveRotated));
        }
    }

    private static Map<String,List<Map<String,Object>>> resultRows(PlatformStore store) {
        var snapshot = new LinkedHashMap<String,List<Map<String,Object>>>();
        for (String table : List.of("generated_result", "generated_result_revision", "result_value", "result_reference", "result_target", "source_reference", "reference_target", "web_reference"))
            snapshot.put(table, rows(store, "SELECT * FROM " + table));
        return snapshot;
    }
    private static List<Map<String,Object>> rows(PlatformStore store, String sql) {
        return store.read(s -> s.getMapper(Fixture.class).rows(sql));
    }
    public interface Fixture extends PlatformMapper {
        @Select("${sql}") List<Map<String,Object>> rows(@Param("sql") String sql);
    }
}
