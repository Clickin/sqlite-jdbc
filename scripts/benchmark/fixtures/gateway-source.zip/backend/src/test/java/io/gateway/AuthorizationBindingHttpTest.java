package io.gateway;

import com.sun.net.httpserver.HttpExchange;
import io.gateway.authorization.AuthorizationService;
import io.gateway.definitions.DefinitionRepository;
import io.gateway.definitions.Definitions.*;
import io.gateway.identity.Authority;
import io.gateway.identity.ConfiguredAuthority;
import io.gateway.management.SecurityDefinitions;
import io.gateway.mcp.Mcp2026Adapter;
import io.gateway.oauth.*;
import io.gateway.runtime.Payload.Disposition;
import java.net.URI;
import java.net.http.*;
import java.nio.file.Path;
import java.sql.DriverManager;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import tools.jackson.databind.json.JsonMapper;
import static org.junit.jupiter.api.Assertions.*;

/** Registered JDBC identity and HTTP permission/resolver operations, with the production PEP. */
class AuthorizationBindingHttpTest {
    @TempDir Path directory;
    private static final JsonMapper JSON=JsonMapper.builder().build();
    private static final String SUBJECT="database-confirmed-doctor";
    private static final Map<String,Object> A=Map.of("patientId","A","documentId","DA");

    @Test void mixedJdbcIdentityAndHttpPermissionSeparateOutcomesWithoutPollingOrClinicalBody() throws Exception {
        try(var f=new Fixture(directory)) {
            String token=f.token(List.of(rule("clinical.lab.read","A")),"clinical.read");
            var principal=f.gateway.server.getApplicationContext().getBean(AuthorizationService.class)
                .authenticateBearer(List.of("Bearer "+token),SecurityFixture.RESOURCE);
            assertEquals(SUBJECT,principal.subject());
            assertEquals(f.identity.object().id(),principal.identityProvider());
            assertInstanceOf(ConfiguredAuthority.class,f.gateway.server.getApplicationContext().getBean(Authority.class));
            f.calls.clear();
            var allowed=f.rpc("lab-tool",A,token);
            assertEquals(200,allowed.statusCode(),allowed.body());assertTrue(allowed.body().contains("SUCCEEDED"),allowed.body());
            assertEquals(Map.of("patientId",List.of("A"),"documentId",List.of("DA")),f.bodyArguments.poll(2,TimeUnit.SECONDS));
            assertEquals(List.of("resolver","permission","resolver","permission"),f.drainCalls());
            assertNull(f.calls.poll(300,TimeUnit.MILLISECONDS),"ALLOW must not schedule a background authority retry");
            for(String outcome:List.of("DENY","PENDING","UNAVAILABLE")) {
                f.outcome.set(outcome);
                var denied=f.rpc("lab-tool",A,token);
                assertEquals(outcome.equals("UNAVAILABLE")?503:403,denied.statusCode(),denied.body());
                assertEquals("authority_rejected",JSON.readTree(denied.body()).path("error").asText(),denied.body());
                assertTrue(denied.headers().firstValue("WWW-Authenticate").isEmpty(),"Authority rejection must not request wider OAuth scopes");
                // MCP deliberately shares the public error for DENY/PENDING; the audit preserves the authority outcome.
                assertEquals(1,f.count("SELECT count(*) FROM audit_event WHERE event_type='AUTHORIZATION' AND outcome='"+outcome
                    +"' AND reason_code='authority_rejected' AND public_token_record_id='"+principal.tokenId()
                    +"' AND authority_decision_id='synthetic-http-decision'"));
                assertEquals(List.of("resolver","permission"),f.drainCalls());
                assertNull(f.calls.poll(300,TimeUnit.MILLISECONDS),"Terminal authority outcomes must not poll/retry");
                assertEquals(1,f.gateway.sourceCalls.get());assertTrue(f.bodyArguments.isEmpty());
            }
            assertNull(f.failure.get());
        }
    }

    @Test void spoofedIdentityAndBypassMissingPatientAndWrongIdentifierSystemNeverReadBody() throws Exception {
        try(var f=new Fixture(directory)) {
            String token=f.token(List.of(rule("clinical.lab.read","A")),"clinical.read");
            f.calls.clear();
            for(var forged:Map.<String,Object>of("userId","other-doctor","roles",List.of("administrator"),"grantId","other-grant",
                "authorized",Map.of("patientIdentifier","B"),"_meta",Map.of("subject","other-doctor"),"bypassAuthorization",true).entrySet()) {
                var input=new LinkedHashMap<>(A);input.put(forged.getKey(),forged.getValue());
                var response=f.rpc("lab-tool",input,token);
                assertInvalidArguments(response);
                assertTrue(f.calls.isEmpty(),forged.getKey()+" must not reach authority operations");
            }
            assertInvalidArguments(f.rpc("lab-tool",Map.of("documentId","DA"),token));
            assertEquals(400,f.rpc("lab-tool",Map.of("patientId","*","documentId","DA"),token).statusCode());
            assertTrue(f.calls.isEmpty(),"Invalid patient identifiers must not reach authority operations");
            assertEquals(403,f.rpc("lab-tool",Map.of("patientId","A","documentId","DB"),token).statusCode());
            var policy=new LinkedHashMap<>(f.security.get("document-policy",null).detail());
            policy.put("identifier_system","different-mrn");f.security("document-policy","document-policy","TARGET_POLICY",policy);
            assertEquals(403,f.rpc("lab-tool",A,token).statusCode());
            assertEquals(0,f.gateway.sourceCalls.get());assertTrue(f.bodyArguments.isEmpty());assertNull(f.failure.get());
        }
    }

    @Test void maliciousInputConverterCannotReplaceAuthorizedPatientAndDocumentBindings() throws Exception {
        try(var f=new Fixture(directory)) {
            String token=f.token(List.of(rule("clinical.lab.read","A")),"clinical.read");
            var converter=f.publish("mapped-input",new Converter("basic",f.gateway.input.object().id(),f.gateway.input.object().id(),List.of(
                new Rule("INPUT",null,"patient-field","CONSTANT",List.of(new Argument("value","STRING","B",null,null,null))),
                new Rule("INPUT",null,"document-field","CONSTANT",List.of(new Argument("value","STRING","DB",null,null,null))))));
            var tool=new LinkedHashMap<>(f.security.get("lab-tool",null).detail());tool.put("input_mapping_object_id",converter.object().id());
            f.security("lab-tool","lab-tool","MCP_TOOL",tool);
            var rejected=f.rpc("lab-tool",A,token);assertEquals(403,rejected.statusCode(),rejected.body());
            assertEquals(0,f.gateway.sourceCalls.get());assertTrue(f.bodyArguments.isEmpty());
            var safe=f.repository.draft(new Draft(converter.object().id(),"mapped-input","Identity mapping",null,"restore",new Converter("basic",
                f.gateway.input.object().id(),f.gateway.input.object().id(),List.of(new Rule("INPUT","patient-field","patient-field","COPY",List.of()),
                new Rule("INPUT","document-field","document-field","COPY",List.of())))),"fixture");
            f.repository.apply(f.repository.validate(safe.object().id(),safe.version().id()),"fixture","restore");
            var allowed=f.rpc("lab-tool",A,token);assertEquals(200,allowed.statusCode(),allowed.body());
            assertEquals(Map.of("patientId",List.of("A"),"documentId",List.of("DA")),f.bodyArguments.poll(2,TimeUnit.SECONDS));
            assertEquals(1,f.gateway.sourceCalls.get());assertNull(f.failure.get());
        }
    }

    @Test void actionTargetPairsAndCurrentRolesIntersectAndRoleAdditionsNeverWidenIssuedGrant() throws Exception {
        try(var f=new Fixture(directory)) {
            String paired=f.token(List.of(rule("clinical.lab.read","A"),rule("clinical.order.write","A"),rule("clinical.lab.read","B")),"clinical.read clinical.write");
            assertEquals(403,f.rpc("write-tool",Map.of("patientId","B","documentId","DB"),paired).statusCode());
            var allowed=f.rpc("write-tool",A,paired);assertEquals(200,allowed.statusCode(),allowed.body());assertEquals(1,f.writes.get());
            f.roles.set(List.of("unmapped-role"));
            assertEquals(403,f.rpc("write-tool",A,paired).statusCode());assertEquals(1,f.writes.get());
            f.roles.set(List.of("clinician"));
            var oldRole=f.security.get("clinician-role",null);
            @SuppressWarnings("unchecked") var actions=(List<Map<String,Object>>)oldRole.detail().get("actions");
            var readOnly=new LinkedHashMap<>(oldRole.detail());
            readOnly.put("actions",actions.stream().filter(a->!a.get("action_id").equals("clinical.order.write")).toList());
            f.security("clinician-role","clinician-role","ROLE",readOnly);
            assertEquals(403,f.rpc("write-tool",A,paired).statusCode());assertEquals(1,f.writes.get());
            String bounded=f.token(List.of(rule("clinical.lab.read","A")),"clinical.read clinical.write");
            f.security("clinician-role","clinician-role","ROLE",oldRole.detail());
            assertEquals(403,f.rpc("write-tool",A,bounded).statusCode());assertEquals(1,f.writes.get());
            var read=f.rpc("lab-tool",A,bounded);assertEquals(200,read.statusCode(),read.body());assertEquals(1,f.gateway.sourceCalls.get());
            assertNull(f.failure.get());
        }
    }

    @Test void authoritySelfReferencesAndTransitiveMapperCyclesCannotPublishOrEnablePublicBypass() throws Exception {
        try(var f=new Fixture(directory)) {
            var binding=f.security.get("security",null);
            var self=new LinkedHashMap<>(binding.detail());self.put("authorization_operation_object_id","security");
            var candidate=f.security.draft(new SecurityDefinitions.Draft("security","security","Invalid self reference",null,"test","SECURITY_BINDING",self),"fixture");
            assertThrows(IllegalArgumentException.class,()->f.security.validate(candidate.object().id(),candidate.version().id()));
            assertThrows(IllegalArgumentException.class,()->f.security.apply(candidate.object().id(),candidate.version().id(),binding.object().generation(),Map.of(),"fixture","test"));
            assertEquals(binding.version().id(),f.security.get("security",null).version().id());
            var source=(JdbcSource)f.repository.get(f.identitySource.object().id(),null).detail();
            var invalidSource=f.repository.draft(new Draft(f.identitySource.object().id(),"authority-jdbc","Invalid source",null,"test",
                new JdbcSource(source.jdbcUrl(),source.driverProfileId(),"security",0,2,1000,true,4,1000)),"fixture");
            assertThrows(IllegalArgumentException.class,()->f.repository.validate(invalidSource.object().id(),invalidSource.version().id()));
            assertEquals(f.identitySource.version().id(),f.repository.get(f.identitySource.object().id(),null).version().id());
            var imported=f.publish("authority-import",new Mapper("SQLITE",List.of(new MapperDocument("import.xml",xml("authorityImport",""))),List.of(f.identityMapper.object().id())));
            var original=(Mapper)f.identityMapper.detail();
            var cycle=f.repository.draft(new Draft(f.identityMapper.object().id(),"identity-mapper","Cycle",null,"test",
                new Mapper("SQLITE",original.documents(),List.of(imported.object().id()))),"fixture");
            assertEquals("DEPENDENCY_CYCLE",assertThrows(IllegalArgumentException.class,()->f.repository.validate(cycle.object().id(),cycle.version().id())).getMessage());
            assertEquals(f.identityMapper.version().id(),f.repository.get(f.identityMapper.object().id(),null).version().id());
            String token=f.token(List.of(rule("clinical.lab.read","A")),"clinical.read");
            f.calls.clear();
            f.outcome.set("DENY");var input=new LinkedHashMap<>(A);input.put("internalPurpose","PERMISSION");
            assertInvalidArguments(f.rpc("lab-tool",input,token));
            assertTrue(f.calls.isEmpty(),"Public internalPurpose must not enter authority execution");
            assertEquals(403,f.rpc("lab-tool",A,token).statusCode());
            assertEquals(List.of("resolver","permission"),f.drainCalls());
            assertNull(f.calls.poll(300,TimeUnit.MILLISECONDS),"Rejected bypass must not schedule authority work");
            assertEquals(0,f.gateway.sourceCalls.get());assertTrue(f.bodyArguments.isEmpty());assertNull(f.failure.get());
        }
    }

    private static void assertInvalidArguments(HttpResponse<String> response) {
        assertEquals(200,response.statusCode(),response.body());
        var envelope=JSON.readTree(response.body());
        assertFalse(envelope.has("error"),response.body());
        var result=envelope.path("result");
        assertTrue(result.path("isError").asBoolean(),response.body());
        assertEquals("INVALID_ARGUMENTS",result.path("structuredContent").path("error").path("code").asText(),response.body());
        assertEquals("NOT_EXECUTED",result.path("structuredContent").path("businessOutcome").asText(),response.body());
    }

    private static OAuthService.ActionTarget rule(String action,String patient) {return new OAuthService.ActionTarget(action,SecurityFixture.patient(patient));}
    private static String xml(String namespace,String body) {return "<?xml version=\"1.0\"?><!DOCTYPE mapper PUBLIC \"-//mybatis.org//DTD Mapper 3.0//EN\" \"https://mybatis.org/dtd/mybatis-3-mapper.dtd\"><mapper namespace=\""+namespace+"\">"+body+"</mapper>";}

    private static final class Fixture implements AutoCloseable {
        final GatewayFixture gateway;
        final DefinitionRepository repository;
        final SecurityDefinitions security;
        final Saved identity,identitySource,identityMapper;
        final AtomicReference<String> outcome=new AtomicReference<>("ALLOW");
        final AtomicReference<List<String>> roles=new AtomicReference<>(List.of("clinician"));
        final AtomicReference<Throwable> failure=new AtomicReference<>();
        final AtomicInteger writes=new AtomicInteger();
        final BlockingQueue<String> calls=new LinkedBlockingQueue<>();
        final BlockingQueue<Map<String,List<String>>> bodyArguments=new LinkedBlockingQueue<>();
        final HttpClient client=HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1).build();
        Fixture(Path directory) throws Exception {
            gateway=new GatewayFixture(directory,-1,false,Map.of());
            repository=gateway.server.getApplicationContext().getBean(DefinitionRepository.class);
            security=gateway.server.getApplicationContext().getBean(SecurityDefinitions.class);
            String jdbc="jdbc:sqlite:"+directory.resolve("identity.db");
            try(var connection=DriverManager.getConnection(jdbc);var statement=connection.createStatement()) {
                statement.execute("CREATE TABLE identities(credential TEXT PRIMARY KEY,subject TEXT NOT NULL,active INTEGER NOT NULL)");
                statement.execute("INSERT INTO identities VALUES('synthetic-submitted-login','"+SUBJECT+"',1)");
            }
            identitySource=publish("authority-jdbc",new JdbcSource(jdbc,"SQLITE",null,0,2,1000,true,4,1000));
            var identityInput=contract("identity-input",Map.of("credential","STRING"),Set.of());
            var identityOutput=contract("identity-output",Map.of("subject","STRING","active","BOOLEAN"),Set.of());
            identityMapper=publish("identity-mapper",new Mapper("SQLITE",List.of(new MapperDocument("identity.xml",xml("authorityIdentity",
                "<resultMap id=\"identity\" type=\"map\"><result column=\"subject\" property=\"subject\" javaType=\"string\"/><result column=\"active\" property=\"active\" javaType=\"boolean\"/></resultMap><select id=\"authenticate\" resultMap=\"identity\">SELECT subject,active FROM identities WHERE credential=#{credential}</select>"))),List.of()));
            identity=publish("configured-identity",new JdbcOperation(identitySource.object().id(),identityInput.object().id(),identityOutput.object().id(),Effect.READ_ONLY,2000,1,4096L,identityMapper.object().id(),"authorityIdentity.authenticate","SELECT_ONE","READ_ONLY",List.of(),List.of()));
            var httpSource=publish("authority-http",new HttpSource("http://127.0.0.1:"+gateway.source.getAddress().getPort(),"NONE",null,null,null,null,4,4,1000,"NEVER",4,1000,List.of()));
            var rolesInput=contract("roles-input",Map.of("subject","STRING","identityProvider","STRING"),Set.of());
            var rolesOutput=contract("roles-output",Map.of("active","BOOLEAN","roles","ARRAY"),Set.of());
            var targetMembers=new LinkedHashMap<>(Map.of("subject","STRING","identityProvider","STRING","action","STRING","targetKind","STRING",
                "organization","STRING","identifierSystem","STRING","patientIdentifier","STRING","encounterIdentifier","STRING","documentIdentifier","STRING"));
            var authorityInput=contract("authority-input",targetMembers,Set.of("organization","identifierSystem","patientIdentifier","encounterIdentifier","documentIdentifier"));
            var permissionOutput=contract("permission-output",Map.of("outcome","STRING","decisionId","STRING","roles","ARRAY"),Set.of());
            var resolverOutput=contract("resolver-output",Map.of("organization","STRING","identifierSystem","STRING","patientIdentifier","STRING","documentIdentifier","STRING"),Set.of("documentIdentifier"));
            var rolesOperation=http("configured-roles",httpSource,rolesInput,rolesOutput,"roles",Effect.READ_ONLY);
            var permission=http("configured-permission",httpSource,authorityInput,permissionOutput,"permission",Effect.READ_ONLY);
            var resolver=http("configured-resolver",httpSource,authorityInput,resolverOutput,"resolver",Effect.READ_ONLY);
            gateway.source.createContext("/roles",exchange->authority(exchange,"roles"));
            gateway.source.createContext("/permission",exchange->authority(exchange,"permission"));
            gateway.source.createContext("/resolver",exchange->authority(exchange,"resolver"));
            gateway.source.removeContext("/labs");
            gateway.source.createContext("/labs",exchange->{gateway.sourceCalls.incrementAndGet();bodyArguments.add(new com.nimbusds.oauth2.sdk.http.HTTPRequest(com.nimbusds.oauth2.sdk.http.HTTPRequest.Method.GET,URI.create("http://fixture"+exchange.getRequestURI())).getQueryStringParameters());respond(exchange,200,Map.of("answer","synthetic A lab","recordText","synthetic clinical body"));});
            gateway.source.createContext("/write",exchange->{writes.incrementAndGet();respond(exchange,200,Map.of("answer","synthetic write","recordText","synthetic write body"));});
            var detail=new LinkedHashMap<>(security.get("security",null).detail());
            detail.put("identity_operation_object_id",identity.object().id());detail.put("identity_converter_object_id",copy("identity-copy",identityOutput).object().id());
            detail.put("authorization_operation_object_id",permission.object().id());detail.put("authorization_converter_object_id",copy("permission-copy",permissionOutput).object().id());
            detail.put("roles_operation_object_id",rolesOperation.object().id());detail.put("roles_converter_object_id",copy("roles-copy",rolesOutput).object().id());
            security("security","security","SECURITY_BINDING",detail);
            String resolverCopy=copy("resolver-copy",resolverOutput).object().id();
            var policy=new LinkedHashMap<>(security.get("document-policy",null).detail());
            policy.put("resolver_operation_object_id",resolver.object().id());policy.put("resolver_converter_object_id",resolverCopy);
            security("document-policy","document-policy","TARGET_POLICY",policy);
            security(null,"patient-policy","TARGET_POLICY",Map.of("target_kind","PATIENT","canonical_organization","synthetic-hospital","identifier_system","synthetic-mrn",
                "resolver_operation_object_id",resolver.object().id(),"resolver_converter_object_id",resolverCopy,"require_parent_patient",false,
                "arguments",List.of(Map.of("source_port","REQUEST","contract_field_id","patient-field","target_part","PATIENT"))));
            var writeOperation=http("write-operation",gateway.datasource,gateway.input,gateway.output,"write",Effect.WRITE);
            var workflow=publish("write-workflow",new Workflow(null,List.of(new Stage("INPUT",0,writeOperation.object().id(),null)),List.of(),List.of(new SecurityBinding("INPUT","security","clinical.order.write","document-policy"))));
            var writeTool=new LinkedHashMap<>(security.get("lab-tool",null).detail());writeTool.put("public_name","write-tool");writeTool.put("workflow_object_id",workflow.object().id());writeTool.put("effect_kind","WRITE");
            writeTool.put("actions",List.of(Map.of("action_id","clinical.order.write")));writeTool.put("scopes",List.of(Map.of("scope_id","write")));
            security(null,"write-tool","MCP_TOOL",writeTool);
        }
        Saved publish(String name,Detail detail) {var draft=repository.draft(new Draft(null,name,name,null,"fixture",detail),"fixture");return repository.apply(repository.validate(draft.object().id(),draft.version().id()),"fixture","fixture");}
        void security(String id,String name,String kind,Map<String,Object> detail) {var draft=security.draft(new SecurityDefinitions.Draft(id,name,name,null,"fixture",kind,detail),"fixture");var checked=security.validate(draft.object().id(),draft.version().id());security.apply(draft.object().id(),draft.version().id(),checked.generation(),checked.dependencyVersions(),"fixture","fixture");}
        Saved contract(String name,Map<String,String> members,Set<String> optional) {
            var fields=new ArrayList<Field>();int ordinal=0;
            for(var member:new TreeMap<>(members).entrySet()) {
                String id=name+"-"+member.getKey();boolean array=member.getValue().equals("ARRAY");
                fields.add(new Field(id,member.getKey(),null,member.getKey(),array?"ARRAY":"SCALAR",array?null:member.getValue(),ordinal++,!optional.contains(member.getKey()),false,null,null,member.getValue().equals("STRING")?1024:null,member.getKey().equals("credential")?Disposition.OMIT_SECRET:Disposition.PERSIST));
                if(array)fields.add(new Field(id+"-item","item",id,null,"SCALAR","STRING",0,true,false,null,null,256,Disposition.PERSIST));
            }
            return publish(name,new Contract("VALUE",fields));
        }
        Saved copy(String name,Saved contract) {return publish(name,new Converter("basic",contract.object().id(),contract.object().id(),((Contract)contract.detail()).fields().stream().map(f->new Rule("INPUT",f.id(),f.id(),"COPY",List.of())).toList()));}
        Saved http(String name,Saved source,Saved input,Saved output,String path,Effect effect) {
            var request=publish(name+"-request",new Representation(input.object().id(),"json","DEFAULT","application/json","UTF-8",List.of(),List.of()));
            var response=publish(name+"-response",new Representation(output.object().id(),"json","DEFAULT","application/json","UTF-8",List.of(),List.of()));
            return publish(name,new HttpOperation(source.object().id(),input.object().id(),output.object().id(),effect,2000,100,16384L,"POST",path,request.object().id(),response.object().id(),List.of(),List.of(new ExpectedStatus(200,"SUCCEEDED")),List.of()));
        }
        String token(List<OAuthService.ActionTarget> rules,String scopes) {
            var app=gateway.server.getApplicationContext();var sessions=app.getBean(BrowserSessionService.class);var oauth=app.getBean(OAuthService.class);
            var before=sessions.session(null);var browser=sessions.login(before.cookie(),SecurityFixture.ISSUER,before.view().csrfToken(),"synthetic-submitted-login","USER");
            String id=oauth.begin(SecurityFixture.authorizeParameters("public",SecurityFixture.REDIRECT,scopes),browser.cookie());
            String redirect=oauth.consent(id,browser.cookie(),SecurityFixture.ISSUER,browser.view().csrfToken(),new OAuthService.Consent("synthetic-care",rules,true));
            var query=new com.nimbusds.oauth2.sdk.http.HTTPRequest(com.nimbusds.oauth2.sdk.http.HTTPRequest.Method.GET,URI.create(redirect)).getQueryStringParameters();
            assertTrue(query.containsKey("code"),redirect);
            return (String)oauth.token(SecurityFixture.exchangeForm(new SecurityFixture.Code(query.get("code").getFirst(),"public",SecurityFixture.VERIFIER,SecurityFixture.REDIRECT,id)),null).get("access_token");
        }
        HttpResponse<String> rpc(String tool,Map<String,Object> arguments,String token) throws Exception {
            var params=Map.of("name",tool,"arguments",arguments,"_meta",Map.of(Mcp2026Adapter.PROTOCOL,"2026-07-28",Mcp2026Adapter.CAPABILITIES,Map.of()));
            var request=HttpRequest.newBuilder(gateway.server.getURI().resolve("/mcp")).header("Authorization","Bearer "+token).header("Content-Type","application/json")
                .header("Accept","application/json, text/event-stream")
                .header("MCP-Protocol-Version","2026-07-28").header("Mcp-Method","tools/call").header("Mcp-Name",tool)
                .POST(HttpRequest.BodyPublishers.ofString(JSON.writeValueAsString(Map.of("jsonrpc","2.0","id",1,"method","tools/call","params",params)))).build();
            return client.send(request,HttpResponse.BodyHandlers.ofString());
        }
        List<String> drainCalls() {var result=new ArrayList<String>();calls.drainTo(result);return result;}
        long count(String sql) {return gateway.store.read(s->s.getMapper(SecurityFixture.FixtureMapper.class).count(sql));}
        void authority(HttpExchange exchange,String kind) {
            calls.add(kind);
            try {
                var input=JSON.readValue(exchange.getRequestBody().readAllBytes(),Map.class);
                assertEquals(SUBJECT,input.get("subject"));assertEquals(identity.object().id(),input.get("identityProvider"));
                if(kind.equals("roles"))respond(exchange,200,Map.of("active",true,"roles",roles.get()));
                else if(kind.equals("permission"))respond(exchange,200,Map.of("outcome",outcome.get(),"decisionId","synthetic-http-decision","roles",roles.get()));
                else {
                    String document=(String)input.get("documentIdentifier");
                    String patient=document==null?(String)input.get("patientIdentifier"):Map.of("DA","A","DB","B").get(document);
                    if(patient==null||!Set.of("A","B").contains(patient)){respond(exchange,404,Map.of("missing",true));return;}
                    var resolved=new LinkedHashMap<String,Object>(Map.of("organization","synthetic-hospital","identifierSystem","synthetic-mrn","patientIdentifier",patient));
                    if(document!=null)resolved.put("documentIdentifier",document);
                    respond(exchange,200,resolved);
                }
            } catch(Throwable problem) {failure.compareAndSet(null,problem);respond(exchange,500,Map.of("failed",true));}
        }
        static void respond(HttpExchange exchange,int status,Map<String,Object> value) {
            try {byte[] bytes=JSON.writeValueAsBytes(value);exchange.getResponseHeaders().set("Content-Type","application/json");exchange.sendResponseHeaders(status,bytes.length);try(var body=exchange.getResponseBody()){body.write(bytes);}}
            catch(Exception error) {exchange.close();throw new RuntimeException(error);}
        }
        @Override public void close() {client.close();gateway.close();}
    }
}
