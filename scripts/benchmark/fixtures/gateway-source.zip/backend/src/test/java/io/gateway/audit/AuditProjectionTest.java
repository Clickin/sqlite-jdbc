package io.gateway.audit;

import io.gateway.persistence.PlatformMapper;
import io.gateway.persistence.PlatformStore;
import org.apache.ibatis.annotations.Select;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.util.List;

import static io.gateway.audit.AuditProjection.Disposition.*;
import static io.gateway.audit.AuditProjection.Kind.*;
import static org.junit.jupiter.api.Assertions.*;

class AuditProjectionTest {
    @TempDir Path directory;

    @Test void nestedListsNullMissingEmptyAndDecimalsPersistWithoutSecretAliases() {
        var source = new AuditProjection.Value(null, "recordText", STRING, "SOURCE_SENTINEL", List.of(), OMIT_RECOVERABLE);
        var renamed = AuditProjection.Value.derived(null, "harmlessAlias", STRING, "SOURCE_SENTINEL",
            List.of(), PERSIST, List.of(source));
        var token = new AuditProjection.Value(null, "token", STRING, "SECRET_SENTINEL", List.of(), OMIT_SECRET);
        var values = List.of(new AuditProjection.Value(null, "request", OBJECT, null, List.of(
            scalar("empty", STRING, ""), scalar("absent", MISSING, null), scalar("null", NULL, null),
            new AuditProjection.Value(null, "list", ARRAY, null, List.of(
                scalar(null, DECIMAL, new BigDecimal("12345678901234567890.00100")),
                scalar(null, STRING, "한글<>&")), PERSIST), renamed, token), PERSIST));
        List<AuditProjection.Parameter> rows = AuditProjection.project("SOURCE_OUTPUT", values);
        try (PlatformStore store = new PlatformStore(directory.resolve("platform.db"))) {
            new AuditService(store).append(new AuditService.Event(null, null, "SOURCE_FINISHED", "synthetic", "test",
                null, "SUCCEEDED", null, null), rows);
            List<Stored> stored = store.read(s -> s.getMapper(Fixture.class).values());
            assertTrue(stored.stream().anyMatch(v -> "empty".equals(v.parameterName()) && "".equals(v.stringValue())));
            assertTrue(stored.stream().anyMatch(v -> "MISSING".equals(v.valueType())));
            assertTrue(stored.stream().anyMatch(v -> "NULL".equals(v.valueType())));
            assertTrue(stored.stream().anyMatch(v -> "12345678901234567890.00100".equals(v.decimalText())));
            assertTrue(stored.stream().anyMatch(v -> "한글<>&".equals(v.stringValue())));
            assertTrue(stored.stream().anyMatch(v -> "harmlessAlias".equals(v.parameterName())
                && "EXCLUDED".equals(v.valueType()) && "OMIT_RECOVERABLE".equals(v.exclusionReason())));
            assertTrue(stored.stream().anyMatch(v -> "token".equals(v.parameterName())
                && "OMIT_SECRET".equals(v.exclusionReason())));
            assertTrue(stored.stream().noneMatch(v -> v.stringValue() != null && v.stringValue().contains("SENTINEL")));
            String arrayId = rows.stream().filter(p -> "list".equals(p.parameterName())).findFirst().orElseThrow().id();
            assertEquals(List.of(0, 1), rows.stream().filter(p -> arrayId.equals(p.parentParameterId()))
                .map(AuditProjection.Parameter::ordinal).toList());
        }
    }

    @Test void inheritedSecretExcludesContainerAndDerivedValueCannotLowerSensitivity() {
        var sensitiveContainer = new AuditProjection.Value(null, "private", OBJECT, null,
            List.of(scalar("nested", STRING, "NEVER_PERSIST")), OMIT_SECRET);
        var derived = AuditProjection.Value.derived(null, "renamed", STRING, "NEVER_PERSIST", List.of(),
            PERSIST, List.of(sensitiveContainer));
        List<AuditProjection.Parameter> projected = AuditProjection.project("REQUEST", List.of(sensitiveContainer, derived));
        assertEquals(List.of("OMIT_SECRET", "OMIT_SECRET"), projected.stream().map(AuditProjection.Parameter::exclusionReason).toList());
        assertTrue(projected.stream().allMatch(row -> row.stringValue() == null && row.integerValue() == null
            && row.decimalText() == null && row.booleanValue() == null));
    }

    @Test void unsupportedValuesFailWithoutStringifyingOrTruncating() {
        Object hostile = new Object() { @Override public String toString() { throw new AssertionError("must not stringify"); } };
        var invalid = new AuditProjection.Value(null, "declared", STRING, hostile, List.of(), PERSIST);
        assertEquals("AUDIT_VALUE_INVALID", assertThrows(IllegalArgumentException.class,
            () -> AuditProjection.project("REQUEST", List.of(invalid))).getMessage());
    }

    private static AuditProjection.Value scalar(String name, AuditProjection.Kind kind, Object value) {
        return new AuditProjection.Value(null, name, kind, value, List.of(), PERSIST);
    }
    public record Stored(String parameterName, String valueType, String stringValue, String decimalText, String exclusionReason) {}
    public interface Fixture extends PlatformMapper {
        @Select("SELECT parameter_name,value_type,string_value,decimal_text,exclusion_reason FROM audit_parameter ORDER BY ordinal")
        List<Stored> values();
    }
}
