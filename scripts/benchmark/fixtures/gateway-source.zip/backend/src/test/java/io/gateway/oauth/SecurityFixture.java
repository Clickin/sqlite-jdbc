package io.gateway.oauth;

import com.nimbusds.oauth2.sdk.http.HTTPRequest;
import com.nimbusds.oauth2.sdk.pkce.*;
import io.gateway.authorization.*;
import io.gateway.persistence.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import org.apache.ibatis.annotations.*;

/** Synthetic identities and clients exist exclusively in the test source set. */
public final class SecurityFixture implements AutoCloseable {
    public static final String ISSUER="https://gateway.example",RESOURCE=ISSUER+"/mcp",REDIRECT="https://client.example/callback";
    public static final String VERIFIER="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~";
    public static final String SECRET="synthetic-confidential-client-secret-256bits";
    public final PlatformStore store;
    public final OAuthSettings settings;
    public final SyntheticAuthority authority;
    public final BrowserSessionService sessions;
    public final AuthorizationService authorization;
    public final OAuthService oauth;
    public record Code(String value,String clientId,String verifier,String redirect,String requestId) {}
    public SecurityFixture(Path directory) throws Exception {this(new PlatformStore(directory.resolve("platform.db")),directory,true);}
    public SecurityFixture(PlatformStore store,Path directory,boolean seed) throws Exception {
        this.store=store;Path key=directory.resolve("state.key");if(!Files.exists(key))Files.writeString(key,Base64.getEncoder().encodeToString(new byte[32]));
        settings=new OAuthSettings(ISSUER,RESOURCE,ISSUER,"security",120,300,3600,7200,600,1800,3600,key.toString());
        if(seed)seed(store);
        authority=new SyntheticAuthority(store);sessions=new BrowserSessionService(store,settings,authority);authorization=new AuthorizationService(store,authority,sessions);oauth=new OAuthService(store,settings,sessions,authority);
        if(seed)oauth.rotateClientSecret("confidential",SECRET.toCharArray(),"fixture");
    }
    public static Map<String,Object> properties(Path directory){return Map.ofEntries(Map.entry("gateway.database.url","jdbc:sqlite:"+directory.resolve("platform.db").toAbsolutePath()),Map.entry("gateway.oauth.issuer",ISSUER),Map.entry("gateway.oauth.resource",RESOURCE),Map.entry("gateway.oauth.public-origin",ISSUER),Map.entry("gateway.oauth.security-binding-id","security"),Map.entry("gateway.oauth.code-ttl-seconds",120),Map.entry("gateway.oauth.access-ttl-seconds",300),Map.entry("gateway.oauth.refresh-ttl-seconds",3600),Map.entry("gateway.oauth.grant-ttl-seconds",7200),Map.entry("gateway.oauth.request-ttl-seconds",600),Map.entry("gateway.oauth.session-idle-ttl-seconds",1800),Map.entry("gateway.oauth.session-absolute-ttl-seconds",3600),Map.entry("gateway.oauth.state-key-file",directory.resolve("state.key").toAbsolutePath().toString()));}
    public BrowserSessionService.BrowserSession login(String kind){return login(kind,kind.equals("MANAGEMENT")?"synthetic-admin":"synthetic-doctor");}
    public BrowserSessionService.BrowserSession login(String kind,String credential){var pre=sessions.session(null);return sessions.login(pre.cookie(),ISSUER,pre.view().csrfToken(),credential,kind);}
    public static CanonicalTarget patient(String id){return new CanonicalTarget("PATIENT","synthetic-hospital","synthetic-mrn",id,null,null);}
    public Code code(String patient){return code("public",login("USER"),List.of(new OAuthService.ActionTarget("clinical.lab.read",patient(patient))),"clinical.read");}
    public Code code(String client,BrowserSessionService.BrowserSession browser,List<OAuthService.ActionTarget> rules,String scopes){
        String id=oauth.begin(authorizeParameters(client,REDIRECT,scopes),browser.cookie());
        String response=oauth.consent(id,browser.cookie(),ISSUER,browser.view().csrfToken(),new OAuthService.Consent("synthetic-care",rules,true));
        var query=new HTTPRequest(HTTPRequest.Method.GET,URI.create(response)).getQueryStringParameters();
        if(!query.containsKey("code"))throw new AssertionError("Consent denied: "+query.get("error"));
        return new Code(query.get("code").getFirst(),client,VERIFIER,REDIRECT,id);
    }
    public static Map<String,List<String>> authorizeParameters(String client,String redirect,String scopes){Map<String,List<String>> p=new LinkedHashMap<>();p.put("response_type",List.of("code"));p.put("client_id",List.of(client));p.put("redirect_uri",List.of(redirect));p.put("scope",List.of(scopes));p.put("resource",List.of(RESOURCE));p.put("code_challenge_method",List.of("S256"));p.put("code_challenge",List.of(CodeChallenge.compute(CodeChallengeMethod.S256,new CodeVerifier(VERIFIER)).getValue()));p.put("state",List.of("synthetic-state-sentinel"));return p;}
    public Map<String,Object> exchange(Code code){return oauth.token(exchangeForm(code),code.clientId().equals("confidential")?basic():null);}
    public static String exchangeForm(Code code){return form(Map.of("grant_type","authorization_code","client_id",code.clientId(),"code",code.value(),"redirect_uri",code.redirect(),"code_verifier",code.verifier(),"resource",RESOURCE));}
    public Map<String,Object> token(String patient){return exchange(code(patient));}
    public AuthenticatedPrincipal authenticate(Map<String,Object> token){return authorization.authenticateBearer(List.of("Bearer "+token.get("access_token")),RESOURCE);}
    public Map<String,Object> refresh(String token){return oauth.token(form(Map.of("grant_type","refresh_token","client_id","public","refresh_token",token,"resource",RESOURCE)),null);}
    public static String basic(){return "Basic "+Base64.getEncoder().encodeToString(("confidential:"+SECRET).getBytes(StandardCharsets.UTF_8));}
    public static String form(Map<String,String> values){return String.join("&",values.entrySet().stream().map(e->URLEncoder.encode(e.getKey(),StandardCharsets.UTF_8)+"="+URLEncoder.encode(e.getValue(),StandardCharsets.UTF_8)).toList());}
    public void sql(String sql){store.write(s->{s.getMapper(FixtureMapper.class).execute(sql);return null;});}
    public long count(String query){return store.read(s->s.getMapper(FixtureMapper.class).count(query));}
    public static void seed(PlatformStore store){store.write(session->{var m=session.getMapper(FixtureMapper.class);
        object(m,"identity-operation","OPERATION");object(m,"permission-operation","OPERATION");object(m,"roles-operation","OPERATION");object(m,"identity-converter","CONVERTER");object(m,"permission-converter","CONVERTER");
        object(m,"security","SECURITY_BINDING");m.execute("INSERT INTO security_binding_version(version_id,identity_operation_object_id,identity_converter_object_id,authorization_operation_object_id,authorization_converter_object_id,roles_operation_object_id,roles_converter_object_id) VALUES('security-v1','identity-operation','identity-converter','permission-operation','permission-converter','roles-operation','permission-converter')");
        object(m,"clinician-role","ROLE");object(m,"administrator-role","ROLE");m.execute("INSERT INTO role_version(version_id) VALUES('clinician-role-v1'),('administrator-role-v1')");m.execute("INSERT INTO external_role_mapping VALUES('security-v1','clinician','clinician-role'),('security-v1','administrator','administrator-role')");
        m.execute("INSERT INTO oauth_resource VALUES('mcp-resource','"+RESOURCE+"','MCP','Synthetic MCP',true)");m.execute("INSERT INTO oauth_scope VALUES('read','clinical.read','Synthetic read'),('write','clinical.write','Synthetic write')");
        List<String> clinical=List.of("clinical.lab.read","clinical.order.write","result.create","result.read","reference.read","reference.resolve");
        for(String action:clinical){boolean write=action.equals("clinical.order.write")||action.equals("result.create");m.execute("INSERT INTO protected_action VALUES('"+action+"','"+action+"','PATIENT','"+(write?"WRITE":"READ_ONLY")+"',1)");m.execute("INSERT INTO role_action VALUES('clinician-role-v1','"+action+"',1)");m.execute("INSERT INTO oauth_scope_action VALUES('"+(write?"write":"read")+"','"+action+"',1)");}
        for(String action:List.of("config.manage","security.manage","client.manage","audit.read")){m.execute("INSERT INTO protected_action VALUES('"+action+"','"+action+"','SERVICE','READ_ONLY',1)");m.execute("INSERT INTO role_action VALUES('administrator-role-v1','"+action+"',1)");}
        for(String client:List.of("public","confidential","no-refresh")){
            object(m,client,"OAUTH_CLIENT");
            boolean nativeClient=!client.equals("confidential");
            m.execute("INSERT INTO oauth_client_version(version_id,client_type,token_endpoint_auth_method,display_name,require_pkce_s256,refresh_enabled) VALUES('"+client+"-v1','"+(nativeClient?"PUBLIC_NATIVE":"CONFIDENTIAL_WEB")+"','"+(nativeClient?"none":"client_secret_basic")+"','Synthetic client',true,"+!client.equals("no-refresh")+")");
            m.execute("INSERT INTO oauth_client_redirect VALUES('"+client+"-v1','"+REDIRECT+"',false,0)");
            if(client.equals("public"))m.execute("INSERT INTO oauth_client_redirect VALUES('public-v1','http://127.0.0.1/callback',true,1)");
            m.execute("INSERT INTO oauth_client_resource VALUES('"+client+"-v1','mcp-resource')");
            m.execute("INSERT INTO oauth_client_scope VALUES('"+client+"-v1','read'),('"+client+"-v1','write')");
            for(String action:clinical)m.execute("INSERT INTO oauth_client_action VALUES('"+client+"-v1','"+action+"',1)");
        }
        // SyntheticAuthority owns these test-only handles; incomplete operation drafts are never published.
        m.execute("UPDATE config_object SET current_version_id=id || '-v1',revision_counter=1,generation=1 WHERE created_by='fixture' AND current_version_id IS NULL AND kind NOT IN ('OPERATION','CONVERTER')");
        return null;});}
    private static void object(FixtureMapper m,String id,String kind){m.execute("INSERT INTO config_object(id,kind,logical_key,created_at,created_by) VALUES('"+id+"','"+kind+"','"+id+"',1,'fixture')");m.execute("INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name) VALUES('"+id+"-v1','"+id+"','"+kind+"',1,1,'fixture','synthetic','Synthetic')");}
    @Override public void close(){store.close();}
    public interface FixtureMapper extends PlatformMapper {
        @Update("${sql}") void execute(@Param("sql")String sql);
        @Select("${sql}") long count(@Param("sql")String sql);
    }
}
