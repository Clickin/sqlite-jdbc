package io.gateway;

import io.gateway.authorization.AccessDenied;
import io.gateway.authorization.AuthorizationService;
import io.gateway.credentials.CredentialMapper;
import io.gateway.credentials.CredentialService;
import io.gateway.definitions.DefinitionRepository;
import io.gateway.definitions.Definitions.*;
import io.gateway.oauth.*;
import io.gateway.persistence.PlatformStore;
import io.gateway.results.ResultModels.*;
import io.micronaut.context.ApplicationContext;
import io.micronaut.runtime.server.EmbeddedServer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermissions;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

@SuppressWarnings("unchecked")
class StorageRecoveryHttpTest {
    private static final String SOURCE_CREDENTIAL = "SYNTHETIC_RECOVERY_CREDENTIAL_NEVER_PERSIST";
    private static final String SUMMARY = "복구 후 보존되는 합성 요약";
    private static final List<String> RESULT_ACTIONS = List.of("result.create", "result.read", "reference.read", "reference.resolve");
    private static final List<String> AUTH_TABLES = List.of("auth_session", "oauth_authorization_code", "oauth_access_token",
            "oauth_refresh_token", "oauth_refresh_family", "oauth_grant");
    @TempDir Path directory;

    @Test void walBackupAndOfflineRestorePreserveEncryptedConfigurationAndOwnedResultsButInvalidateSavedAuthority() throws Exception {
        Path current = directory.resolve("current"), bundle = directory.resolve("backup"), restored = directory.resolve("restored");
        List<String> secrets = new ArrayList<>(List.of(SOURCE_CREDENTIAL, GatewayFixture.SOURCE_SECRET,
                GatewayFixture.RECORD_TEXT, SecurityFixture.VERIFIER, "synthetic-state-sentinel"));
        try (var fixture = new GatewayFixture(current, -1, true)) {
            // Keep the real schema and definitions; restart only to supply externally provisioned keys.
            fixture.server.close();
            Path keys = current.resolve("keys");
            Files.createDirectory(keys, PosixFilePermissions.asFileAttribute(PosixFilePermissions.fromString("rwx------")));
            byte[] key = new byte[32];
            new SecureRandom().nextBytes(key);
            Files.write(keys.resolve("recovery.key"), key);
            Arrays.fill(key, (byte) 0);
            Files.copy(current.resolve("state.key"), keys.resolve("state.key"));
            for (String name : List.of("recovery.key", "state.key"))
                Files.setPosixFilePermissions(keys.resolve(name), PosixFilePermissions.fromString("r--------"));

            AtomicInteger credentialConnections = new AtomicInteger();
            fixture.source.createContext("/credential/", exchange -> {
                try (exchange) {
                    if (!("Bearer " + SOURCE_CREDENTIAL).equals(exchange.getRequestHeaders().getFirst("Authorization"))) {
                        exchange.sendResponseHeaders(401, -1);
                        return;
                    }
                    if (exchange.getRequestURI().getPath().equals("/credential/connection")) {
                        credentialConnections.incrementAndGet();
                        exchange.sendResponseHeaders(204, -1);
                        return;
                    }
                    if (!exchange.getRequestURI().getPath().equals("/credential/labs")) {
                        exchange.sendResponseHeaders(404, -1);
                        return;
                    }
                    fixture.sourceCalls.incrementAndGet();
                    byte[] response = ("{\"answer\":\"합성 정상 결과\",\"recordText\":\"" + GatewayFixture.RECORD_TEXT
                            + "\",\"webLink\":\"" + GatewayFixture.WEB_LINK + "\"}").getBytes(StandardCharsets.UTF_8);
                    exchange.getResponseHeaders().set("Content-Type", "application/json");
                    exchange.sendResponseHeaders(200, response.length);
                    exchange.getResponseBody().write(response);
                }
            });

            try (var server = start(current); var http = new GatewayHttpClient(server.getURI())) {
                var context = server.getApplicationContext();
                var store = context.getBean(PlatformStore.class);
                var credentials = context.getBean(CredentialService.class);
                byte[] plaintext = SOURCE_CREDENTIAL.getBytes(StandardCharsets.UTF_8);
                CredentialService.Metadata credential;
                try { credential = credentials.create("recovery-source", "TOKEN", null, plaintext, "fixture", "recovery proof"); }
                finally { Arrays.fill(plaintext, (byte) 0); }
                var repository = context.getBean(DefinitionRepository.class);
                var oldSource = (HttpSource) fixture.datasource.detail();
                var sourceDraft = repository.draft(new Draft(fixture.datasource.object().id(), fixture.datasource.object().logicalKey(),
                        "Recovery source", null, "use external credential", new HttpSource(oldSource.baseUri() + "/credential", "BEARER",
                        credential.objectId(), null, null, null, 4, 4, 2000, "NEVER", 4, 1000, List.of())), "fixture");
                var source = repository.apply(repository.validate(sourceDraft.object().id(), sourceDraft.version().id()), "fixture", "recovery proof");
                assertEquals(2, source.version().revision());
                assertEquals(List.of(2L, 1L), repository.history(source.object().id()).stream().map(Version::revision).toList());
                var encrypted = store.read(s -> s.getMapper(CredentialMapper.class).versionRow(credential.versionId()));
                var heads = repository.list();
                var histories = new LinkedHashMap<String, List<Version>>();
                for (var head : heads) histories.put(head.id(), repository.history(head.id()));
                var graph = repository.resolve(fixture.workflow.object().id());

                ResultDocument saved;
                Map<String, ResolvedReference> references = new LinkedHashMap<>();
                String oldMcp, oldRest;
                GatewayHttpClient.Browser oldBrowser;
                SecurityFixture.Code oldCode;
                String oldRefresh, pendingRequest;
                var activeAuthentication = new LinkedHashMap<String, List<String>>();
                io.gateway.authorization.AuthenticatedPrincipal oldOwner;
                try (var pinned = database(current.resolve("platform.db"))) {
                    try (var statement = pinned.createStatement(); var checkpoint = statement.executeQuery("PRAGMA wal_checkpoint(TRUNCATE)")) {
                        assertTrue(checkpoint.next());
                        assertEquals(0, checkpoint.getInt(1));
                    }
                    pinned.setAutoCommit(false);
                    assertEquals(List.of("0"), query(pinned, "SELECT count(*) FROM generated_result"));

                    oldMcp = http.authorize(SecurityFixture.RESOURCE, "A", List.of("clinical.lab.read", "reference.read", "reference.resolve"));
                    var called = http.call(oldMcp, Map.of("patientId", "A", "documentId", "DA", "sourceSecret", GatewayFixture.SOURCE_SECRET));
                    assertEquals(200, called.statusCode());
                    var execution = (Map<String, Object>) ((Map<String, Object>) http.object(called).get("result")).get("structuredContent");
                    assertEquals("SUCCEEDED", execution.get("status"));
                    assertEquals(1, fixture.sourceCalls.get());
                    String executionId = (String) execution.get("executionId");
                    var referenceIds = (List<String>) execution.get("references");
                    oldRest = http.authorize(GatewayFixture.REST_RESOURCE, "A", RESULT_ACTIONS);
                    oldOwner = context.getBean(AuthorizationService.class).authenticateBearer(List.of("Bearer " + oldRest), GatewayFixture.REST_RESOURCE);
                    var inputs = new ArrayList<ReferenceInput>();
                    for (int i = 0; i < referenceIds.size(); i++) inputs.add(new ReferenceInput(referenceIds.get(i), "summary", i));
                    var request = new CreateResult(executionId, fixture.generatedOutput.version().id(), "recovery-generation", "synthetic-submitted-model",
                            List.of(new ValueInput("summary", null, "summary-field", 0, "STRING", SUMMARY, null, null, null)), inputs);
                    var created = http.api("/api/results", "POST", request, oldRest);
                    assertEquals(200, created.statusCode());
                    saved = http.json.readValue(created.body(), ResultDocument.class);
                    assertEquals(Map.of("summary", SUMMARY), saved.data());
                    assertEquals(executionId, saved.sourceExecutionId());
                    assertEquals(fixture.generatedOutput.version().id(), saved.outputContractVersionId());
                    assertEquals(referenceIds, saved.references().stream().map(StoredReference::referenceId).toList());
                    assertEquals(saved, result(http, saved.id(), oldRest));
                    for (String id : referenceIds) references.put(id, reference(http, id, oldRest));
                    assertEquals(Set.of("WEB_LINK", "TOOL_REFERENCE"), new HashSet<>(references.values().stream().map(ResolvedReference::kind).toList()));
                    var web = references.values().stream().filter(r -> r.kind().equals("WEB_LINK")).findFirst().orElseThrow();
                    assertEquals(GatewayFixture.WEB_LINK, web.directUrl());
                    var tool = references.values().stream().filter(r -> r.kind().equals("TOOL_REFERENCE")).findFirst().orElseThrow();
                    assertEquals(Map.of("original_patient", "A", "patient_id", "A", "document_id", "DA"), tool.parameters());
                    assertEquals("LAB", tool.screenCode());

                    oldBrowser = http.login("MANAGEMENT");
                    assertEquals(200, http.send("/management/security/grants", "GET", null, Map.of("Cookie", oldBrowser.cookie())).statusCode());
                    // The fixture shares this store but does not own its lifecycle here.
                    var security = new SecurityFixture(store, current, false);
                    oldCode = security.code("A");
                    var refreshTokens = security.token("A");
                    oldRefresh = (String) refreshTokens.get("refresh_token");
                    var pendingBrowser = security.login("USER");
                    pendingRequest = security.oauth.begin(SecurityFixture.authorizeParameters("public", SecurityFixture.REDIRECT, "clinical.read"), pendingBrowser.cookie());
                    secrets.addAll(List.of(oldCode.value(), oldRefresh, (String) refreshTokens.get("access_token"), pendingBrowser.cookie(), pendingBrowser.view().csrfToken()));
                    secrets.addAll(http.rawSecrets);
                    try (var committed = database(current.resolve("platform.db"))) {
                        for (String table : AUTH_TABLES) {
                            var ids = query(committed, "SELECT id FROM " + table + " WHERE revoked_at IS NULL ORDER BY id");
                            assertFalse(ids.isEmpty(), "Recovery must include live " + table);
                            activeAuthentication.put(table, ids);
                        }
                        assertEquals(List.of("1"), query(committed, "SELECT count(*) FROM oauth_authorization_request WHERE status='OPEN' AND opaque_state_cipher IS NOT NULL"));
                    }
                    assertEquals(List.of("0"), query(pinned, "SELECT count(*) FROM generated_result"));
                    assertTrue(Files.size(current.resolve("platform.db-wal")) > 32);
                    // Prove the result is committed only in WAL, not merely a pre-checkpointed database.
                    Path mainOnly = directory.resolve("main-only.db");
                    Files.copy(current.resolve("platform.db"), mainOnly);
                    try (var base = database(mainOnly)) { assertEquals(List.of("0"), query(base, "SELECT count(*) FROM generated_result")); }
                    assertCli(0, "Backup complete.", "backup", "--database", current.resolve("platform.db").toString(),
                            "--keys", keys.toString(), "--destination", bundle.toString());
                }
                assertEquals(saved, result(http, saved.id(), oldRest), "Backup itself must not revoke authority");
                server.close();

                assertCli(1, "Operation refused or failed; source unchanged. Check paths, permissions, bundle and schema compatibility.",
                        "restore", "--bundle", bundle.toString(), "--destination", restored.toString());
                assertFalse(Files.exists(restored));
                assertCli(0, "Restore complete; all saved authentication invalidated. Start only from the new directory.",
                        "restore", "--bundle", bundle.toString(), "--destination", restored.toString(), "--offline");
                for (String name : List.of("recovery.key", "state.key")) {
                    assertEquals(-1, Files.mismatch(keys.resolve(name), bundle.resolve("keys").resolve(name)));
                    assertEquals(-1, Files.mismatch(keys.resolve(name), restored.resolve("keys").resolve(name)));
                    assertEquals(PosixFilePermissions.fromString("r--------"), Files.getPosixFilePermissions(restored.resolve("keys").resolve(name)));
                }
                // Inspect the restored schema before any application can serve or repair authentication.
                try (var offline = database(restored.resolve("platform.db"))) {
                    for (String table : AUTH_TABLES) {
                        assertEquals(List.of(), query(offline, "SELECT id FROM " + table + " WHERE revoked_at IS NULL"));
                        assertTrue(query(offline, "SELECT id FROM " + table + " WHERE revoked_at IS NOT NULL").containsAll(activeAuthentication.get(table)), "Saved authority must be revoked, not silently lost");
                    }
                    assertEquals(List.of(), query(offline, "SELECT id FROM oauth_authorization_request WHERE status<>'REJECTED' OR opaque_state_cipher IS NOT NULL OR state_key_id IS NOT NULL OR state_nonce IS NOT NULL OR state_tag IS NOT NULL"));
                    assertTrue(query(offline, "SELECT id FROM oauth_authorization_request WHERE status='REJECTED'").contains(pendingRequest));
                    assertEquals(List.of("ok"), query(offline, "PRAGMA integrity_check"));
                    assertEquals(List.of(), query(offline, "PRAGMA foreign_key_check"));
                }

                try (var recovered = start(restored); var recoveredHttp = new GatewayHttpClient(recovered.getURI())) {
                    var recoveredContext = recovered.getApplicationContext();
                    var recoveredStore = recoveredContext.getBean(PlatformStore.class);
                    var recoveredRepository = recoveredContext.getBean(DefinitionRepository.class);
                    assertEquals(heads, recoveredRepository.list());
                    for (var entry : histories.entrySet()) assertEquals(entry.getValue(), recoveredRepository.history(entry.getKey()));
                    assertEquals(graph, recoveredRepository.resolve(fixture.workflow.object().id()));
                    var recoveredCredentials = recoveredContext.getBean(CredentialService.class);
                    assertEquals(credential, recoveredCredentials.metadata(credential.objectId()));
                    var cipher = recoveredStore.read(s -> s.getMapper(CredentialMapper.class).versionRow(credential.versionId()));
                    assertEquals(encrypted.keyId(), cipher.keyId());
                    assertEquals(encrypted.cipherGeneration(), cipher.cipherGeneration());
                    assertTrue(Arrays.equals(encrypted.ciphertext(), cipher.ciphertext()), "Recovery changed credential ciphertext");
                    assertTrue(Arrays.equals(encrypted.nonce(), cipher.nonce()), "Recovery changed credential nonce");
                    assertTrue(Arrays.equals(encrypted.authenticationTag(), cipher.authenticationTag()), "Recovery changed credential authentication tag");
                    var recoveredSource = (HttpSource) recoveredRepository.get(source.object().id(), source.version().id()).detail();
                    try (var secret = recoveredCredentials.resolve(recoveredSource.credentialObjectId());
                         var connection = new GatewayHttpClient(URI.create(recoveredSource.baseUri() + "/"))) {
                        assertTrue(SOURCE_CREDENTIAL.equals(secret.utf8()), "Restored external key cannot decrypt the credential");
                        var response = connection.send("connection", "GET", null, Map.of("Authorization", "Bearer " + secret.utf8()));
                        assertEquals(204, response.statusCode(), "Restored credential cannot authenticate a source connection");
                    }
                    assertEquals(1, credentialConnections.get());
                    assertEquals(401, recoveredHttp.call(oldMcp, Map.of("patientId", "A", "documentId", "DA", "sourceSecret", GatewayFixture.SOURCE_SECRET)).statusCode());
                    assertEquals(401, recoveredHttp.api("/api/results/" + saved.id(), "GET", null, oldRest).statusCode());
                    for (String id : references.keySet()) assertEquals(401, recoveredHttp.api("/api/references/" + id, "GET", null, oldRest).statusCode());
                    var authorization = recoveredContext.getBean(AuthorizationService.class);
                    assertThrows(AccessDenied.class, () -> authorization.recheckLocal(oldOwner));
                    rejectedToken(recoveredHttp, SecurityFixture.exchangeForm(oldCode));
                    rejectedToken(recoveredHttp, SecurityFixture.form(Map.of("grant_type", "refresh_token", "client_id", "public",
                            "refresh_token", oldRefresh, "resource", SecurityFixture.RESOURCE)));
                    assertEquals(401, recoveredHttp.send("/management/security/grants", "GET", null, Map.of("Cookie", oldBrowser.cookie())).statusCode());
                    var oldSession = recoveredHttp.send("/auth/session", "GET", null, Map.of("Cookie", oldBrowser.cookie()));
                    assertEquals(200, oldSession.statusCode());
                    assertEquals(Boolean.FALSE, recoveredHttp.object(oldSession).get("authenticated"));

                    String fresh = recoveredHttp.authorize(GatewayFixture.REST_RESOURCE, "A", RESULT_ACTIONS);
                    var freshOwner = authorization.authenticateBearer(List.of("Bearer " + fresh), GatewayFixture.REST_RESOURCE);
                    assertEquals(oldOwner.principalId(), freshOwner.principalId());
                    assertNotEquals(oldOwner.grantId(), freshOwner.grantId());
                    assertEquals(saved, result(recoveredHttp, saved.id(), fresh));
                    for (var entry : references.entrySet()) assertEquals(entry.getValue(), reference(recoveredHttp, entry.getKey(), fresh));
                    recoveredContext.getBean(SyntheticAuthority.class).outcome = "DENY";
                    assertEquals(403, recoveredHttp.api("/api/results/" + saved.id(), "GET", null, fresh).statusCode());
                    for (String id : references.keySet()) assertEquals(403, recoveredHttp.api("/api/references/" + id, "GET", null, fresh).statusCode());
                    assertEquals(1, fixture.sourceCalls.get(), "Recovery, credential checks and stored reads must not repeat business source I/O");
                    secrets.addAll(recoveredHttp.rawSecrets);
                }
            }
        }
        try (var files = Files.walk(directory)) {
            for (var file : files.filter(Files::isRegularFile).filter(p -> p.getFileName().toString().contains(".db")).toList()) {
                String bytes = new String(Files.readAllBytes(file), StandardCharsets.ISO_8859_1);
                for (String secret : secrets) assertFalse(bytes.contains(secret), "Recovery retained raw authentication or recoverable source content");
            }
        }
    }

    private static EmbeddedServer start(Path store) {
        var properties = new HashMap<>(SecurityFixture.properties(store));
        properties.put("micronaut.server.port", -1);
        properties.put("micronaut.server.host", "127.0.0.1");
        properties.put("gateway.oauth.rest-resource", GatewayFixture.REST_RESOURCE);
        properties.put("gateway.references.web-origins", "https://clinical.example");
        properties.put("gateway.oauth.state-key-file", store.resolve("keys/state.key").toAbsolutePath().toString());
        properties.put("gateway.credentials.key-directory", store.resolve("keys").toAbsolutePath().toString());
        properties.put("gateway.credentials.active-key-id", "recovery");
        return ApplicationContext.run(EmbeddedServer.class, properties, "test");
    }

    private static Connection database(Path file) throws Exception {
        assertTrue(Files.isRegularFile(file), "Recovery checks must never create an accidental database");
        return DriverManager.getConnection("jdbc:sqlite:" + file.toAbsolutePath());
    }

    private static List<String> query(Connection connection, String sql) throws Exception {
        try (var statement = connection.createStatement(); var rows = statement.executeQuery(sql)) {
            var values = new ArrayList<String>();
            while (rows.next()) values.add(rows.getString(1));
            return values;
        }
    }

    private static ResultDocument result(GatewayHttpClient http, String id, String token) throws Exception {
        var response = http.api("/api/results/" + id, "GET", null, token);
        assertEquals(200, response.statusCode());
        return http.json.readValue(response.body(), ResultDocument.class);
    }

    private static ResolvedReference reference(GatewayHttpClient http, String id, String token) throws Exception {
        var response = http.api("/api/references/" + id, "GET", null, token);
        assertEquals(200, response.statusCode());
        return http.json.readValue(response.body(), ResolvedReference.class);
    }

    private static void rejectedToken(GatewayHttpClient http, String form) throws Exception {
        var response = http.send("/oauth/token", "POST", form, Map.of("Content-Type", "application/x-www-form-urlencoded"));
        assertEquals(400, response.statusCode());
        assertEquals("invalid_grant", http.object(response).get("error"));
    }

    private static void assertCli(int exit, String status, String... arguments) throws Exception {
        Path script = Path.of("ops/gateway_store.py").toAbsolutePath();
        if (!Files.isRegularFile(script)) script = Path.of("../ops/gateway_store.py").toAbsolutePath();
        assertTrue(Files.isRegularFile(script), "Actual backup/restore CLI is required");
        var command = new ArrayList<>(List.of("python3", script.toString()));
        command.addAll(List.of(arguments));
        var process = new ProcessBuilder(command).redirectErrorStream(true).start();
        try {
            assertTrue(process.waitFor(30, TimeUnit.SECONDS), "Backup/restore CLI timed out");
            assertEquals(exit, process.exitValue());
            assertEquals(status, new String(process.getInputStream().readAllBytes(), StandardCharsets.UTF_8).strip());
        } finally { if (process.isAlive()) process.destroyForcibly(); }
    }
}
