package io.gateway.runtime;

import io.gateway.definitions.*;
import io.gateway.definitions.Definitions.*;
import io.micronaut.context.ApplicationContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import java.sql.DriverManager;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import static org.junit.jupiter.api.Assertions.*;

final class DefinitionRuntimeTest {
    @TempDir Path directory;
    private Saved publish(DefinitionRepository repository,String key,Detail detail){Saved saved=repository.draft(new Draft(null,key,key,null,"synthetic",detail),"fixture");return repository.apply(repository.validate(saved.object().id(),saved.version().id()),"fixture","synthetic");}
    private Contract contract(String field,String name){return new Contract("VALUE",List.of(new Field(field,name,null,name,"SCALAR","STRING",0,true,false,null,null,128,Payload.Disposition.PERSIST)));}
    private String source(String file,String text)throws Exception {String url="jdbc:sqlite:"+directory.resolve(file);try(var connection=DriverManager.getConnection(url);var statement=connection.createStatement()){statement.execute("CREATE TABLE fixture(value TEXT NOT NULL)");try(var insert=connection.prepareStatement("INSERT INTO fixture(value) VALUES(?)")){insert.setString(1,text);insert.executeUpdate();}}return url;}
    @Test void revisionCasRollbackAndLeasedDependencyCutover()throws Exception{
        String sourceA=source("source-a.db","A"),sourceB=source("source-b.db","B");
        try(ApplicationContext context=ApplicationContext.run(Map.of("micronaut.server.enabled",false,"gateway.database.url","jdbc:sqlite:"+directory.resolve("platform.db")))){
            DefinitionRepository repository=context.getBean(DefinitionRepository.class);RuntimeRegistry registry=context.getBean(RuntimeRegistry.class);
            Saved in=publish(repository,"request",new Contract("VALUE",List.of()));Saved out=publish(repository,"response",contract("answer-field","answer"));
            Saved datasource=publish(repository,"source",new JdbcSource(sourceA,"SQLITE",null,0,2,1000,true,4,1000));
            String xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?><!DOCTYPE mapper PUBLIC \"-//mybatis.org//DTD Mapper 3.0//EN\" \"https://mybatis.org/dtd/mybatis-3-mapper.dtd\"><mapper namespace=\"fixture\"><select id=\"read\" resultType=\"map\">SELECT value AS answer FROM fixture</select></mapper>";
            Saved mapper=publish(repository,"mapper",new Mapper("SQLITE",List.of(new MapperDocument("fixture.xml",xml)),List.of()));
            Saved operation=publish(repository,"operation",new JdbcOperation(datasource.object().id(),in.object().id(),out.object().id(),Effect.READ_ONLY,1000,10,4096L,mapper.object().id(),"fixture.read","SELECT_ONE","READ_ONLY",List.of(),List.of()));
            Saved workflow=publish(repository,"workflow",new Workflow(null,List.of(new Stage("INPUT",0,operation.object().id(),null)),List.of(),List.of()));
            ResolvedGraph old=repository.resolve(workflow.object().id());RuntimeRegistry.Lease retained=registry.acquire(old);
            int count=12;CyclicBarrier start=new CyclicBarrier(count);List<Future<RuntimeGraph>> requests=new ArrayList<>();
            try(var executor=Executors.newVirtualThreadPerTaskExecutor()){for(int i=0;i<count;i++)requests.add(executor.submit(()->{start.await();try(var lease=registry.acquire(old)){return lease.get();}}));for(Future<RuntimeGraph> f:requests)assertSame(retained.get(),f.get(5,TimeUnit.SECONDS));}
            Saved draft=repository.draft(new Draft(datasource.object().id(),"source","source",null,"switch",new JdbcSource(sourceB,"SQLITE",null,0,2,1000,true,4,1000)),"fixture");
            Validation first=repository.validate(datasource.object().id(),draft.version().id());repository.apply(first,"fixture","switch");assertThrows(IllegalStateException.class,()->repository.apply(first,"fixture","stale"));
            ResolvedGraph current=repository.resolve(workflow.object().id());assertEquals(workflow.version().id(),current.version(workflow.object().id()));assertEquals(1,repository.history(workflow.object().id()).size());
            try(var fresh=registry.acquire(current)){assertEquals("B",fresh.get().execute(operation.object().id(),Payload.of(Map.of()),new Cancellation(Instant.now().plusSeconds(5))).object().get("answer"));}
            registry.evict(old.key());assertEquals("A",retained.get().execute(operation.object().id(),Payload.of(Map.of()),new Cancellation(Instant.now().plusSeconds(5))).object().get("answer"));
            RuntimeGraph closed=retained.get();retained.close();assertThrows(IllegalStateException.class,()->closed.execute(operation.object().id(),Payload.of(Map.of()),new Cancellation(Instant.now().plusSeconds(5))));
            Saved rolled=repository.rollback(datasource.object().id(),datasource.version().id(),first.generation()+1,"fixture","rollback");assertEquals(first.generation()+2,rolled.object().generation());assertEquals(datasource.version().id(),rolled.version().id());
            assertThrows(IllegalArgumentException.class,()->repository.validate(datasource.object().id(),workflow.version().id()));
        }
    }
    @Test void importsCycleAndPartialDraftAreRejectedAtomically(){
        try(ApplicationContext context=ApplicationContext.run(Map.of("micronaut.server.enabled",false,"gateway.database.url","jdbc:sqlite:"+directory.resolve("definitions.db")))){
            DefinitionRepository repository=context.getBean(DefinitionRepository.class);
            String xml="<?xml version=\"1.0\"?><!DOCTYPE mapper PUBLIC \"-//mybatis.org//DTD Mapper 3.0//EN\" \"https://mybatis.org/dtd/mybatis-3-mapper.dtd\"><mapper namespace=\"empty\"/>";
            Saved mapper=publish(repository,"mapper",new Mapper("SQLITE",List.of(new MapperDocument("empty.xml",xml)),List.of()));
            Saved cycle=repository.draft(new Draft(mapper.object().id(),"mapper","mapper",null,"cycle",new Mapper("SQLITE",List.of(new MapperDocument("empty.xml",xml)),List.of(mapper.object().id()))),"fixture");
            assertThrows(IllegalArgumentException.class,()->repository.validate(mapper.object().id(),cycle.version().id()));assertEquals(mapper.version().id(),repository.get(mapper.object().id(),null).version().id());
            Contract broken=new Contract("VALUE",List.of(new Field("child","child","missing","child","SCALAR","STRING",0,true,false,null,null,null,Payload.Disposition.PERSIST)));
            int before=repository.list().size();assertThrows(IllegalArgumentException.class,()->repository.draft(new Draft(null,"bad","bad",null,"fixture",broken),"fixture"));assertEquals(before,repository.list().size());
        }
    }
    @Test void auditInsertFailureRollsBackHeadAndGeneration()throws Exception {
        String url="jdbc:sqlite:"+directory.resolve("atomic.db");
        try(ApplicationContext context=ApplicationContext.run(Map.of("micronaut.server.enabled",false,"gateway.database.url",url))){
            DefinitionRepository repository=context.getBean(DefinitionRepository.class);
            Saved original=publish(repository,"contract",contract("field","value"));
            Saved draft=repository.draft(new Draft(original.object().id(),"contract","new display",null,"change",contract("field","value")),"fixture");
            Validation validation=repository.validate(original.object().id(),draft.version().id());
            try(var connection=DriverManager.getConnection(url);var statement=connection.createStatement()){
                statement.execute("CREATE TRIGGER reject_change BEFORE INSERT ON configuration_change BEGIN SELECT RAISE(ABORT,'fixture'); END");
            }
            assertThrows(RuntimeException.class,()->repository.apply(validation,"fixture","must rollback"));
            Saved unchanged=repository.get(original.object().id(),null);
            assertEquals(original.version().id(),unchanged.version().id());assertEquals(original.object().generation(),unchanged.object().generation());
            try(var connection=DriverManager.getConnection(url);var statement=connection.createStatement();var rows=statement.executeQuery("SELECT COUNT(*) FROM configuration_change")){
                assertTrue(rows.next());assertEquals(1,rows.getInt(1));
            }
        }
    }
}
