package io.gateway.connectors.jdbc;

import static org.junit.jupiter.api.Assertions.*;

import io.gateway.connectors.OperationAdapter;
import io.gateway.credentials.CredentialService;
import io.gateway.audit.AuditService;
import io.gateway.persistence.PlatformStore;
import io.gateway.definitions.Definitions.*;
import io.gateway.runtime.Cancellation;
import io.gateway.runtime.ExecutionFailure;
import io.gateway.runtime.ExecutionFailure.Outcome;
import io.gateway.runtime.Payload;
import io.gateway.runtime.Payload.Disposition;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermissions;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialClob;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class JdbcResourcesTest {
    private static final String DTD = "<!DOCTYPE mapper PUBLIC \"-//mybatis.org//DTD Mapper 3.0//EN\" \"https://mybatis.org/dtd/mybatis-3-mapper.dtd\">";
    private static final String IMPORT = DTD + """
        <mapper namespace="shared">
          <sql id="columns">id, name, note</sql>
          <resultMap id="row" type="map">
            <id column="id" property="id" javaType="int"/>
            <result column="name" property="name" javaType="string"/>
            <result column="note" property="note" javaType="string"/>
          </resultMap>
        </mapper>
        """;
    private static final String XML = DTD + """
        <mapper namespace="fixture">
          <update id="create">CREATE TABLE item(id INTEGER PRIMARY KEY, name TEXT, note TEXT)</update>
          <insert id="add">INSERT INTO item(id,name,note) VALUES(#{id},#{name},#{note,jdbcType=VARCHAR})</insert>
          <select id="find" resultMap="shared.row">
            <bind name="match" value="prefix == null ? null : prefix + '%'"/>
            SELECT <include refid="shared.columns"/> FROM item
            <where>
              <if test="ids != null">
                id IN <foreach collection="ids" item="item" open="(" separator="," close=")">#{item}</foreach>
              </if>
              <if test="prefix != null">AND name LIKE #{match}</if>
            </where>
            ORDER BY id
          </select>
          <select id="multiInsert" resultType="map" affectData="true" flushCache="true">
            INSERT INTO item(id,name) VALUES(90,'a'),(91,'b') RETURNING id
          </select>
          <select id="slow" resultType="long">
            WITH RECURSIVE counter(x) AS (SELECT 1 UNION ALL SELECT x+1 FROM counter WHERE x &lt; 1000000000)
            SELECT sum(x) FROM counter
          </select>
          <select id="large" resultType="string">SELECT '한글-SECRET-SENTINEL'</select>
        </mapper>
        """;

    @Test void dynamicImportedMapperUsesCurrentParametersNullsAndSelectionModes() {
        try (JdbcResources resources = resources(); OperationAdapter keeper = create(resources)) {
            ResolvedGraph graph = graph(XML, "mapper-1");
            try (OperationAdapter add = resources.prepare(graph, operation("add", "EXECUTE", "LOCAL_WRITE", Effect.WRITE, null, null));
                 OperationAdapter many = resources.prepare(graph, operation("find", "MANY", "READ_ONLY", Effect.READ_ONLY, null, null));
                 OperationAdapter one = resources.prepare(graph, operation("find", "SELECT_ONE", "READ_ONLY", Effect.READ_ONLY, null, null));
                 OperationAdapter optional = resources.prepare(graph, operation("find", "OPTIONAL", "READ_ONLY", Effect.READ_ONLY, null, null))) {
                add.execute(Payload.of(row(1, "한글%_", null)), cancellation());
                add.execute(Payload.of(row(2, "second", "")), cancellation());
                assertEquals(Map.of("records", List.of(row(1, "한글%_", null))), many.execute(Payload.of(filter(List.of(1, 2), "한글")), cancellation()).value());
                assertEquals(row(2, "second", ""), one.execute(Payload.of(filter(List.of(2), null)), cancellation()).value());
                assertEquals(Collections.singletonMap("record", null), optional.execute(Payload.of(filter(List.of(99), null)), cancellation()).value());
                assertEquals(Map.of("record", row(2, "second", "")), optional.execute(Payload.of(filter(List.of(2), null)), cancellation()).value());
                assertEquals("JDBC_RESULT_CARDINALITY", assertThrows(ExecutionFailure.class,
                        () -> one.execute(Payload.of(filter(List.of(99), null)), cancellation())).code());
                assertEquals("JDBC_RESULT_CARDINALITY", assertThrows(ExecutionFailure.class,
                        () -> optional.execute(Payload.of(filter(null, null)), cancellation())).code());
                assertEquals(Disposition.OMIT_RECOVERABLE, many.execute(Payload.of(filter(List.of(2), null)), cancellation()).dispositions().get("many-name"));
            }
        }
    }

    @Test void concurrentRequestsDoNotShareParameterObjectsOrBoundSql() throws Exception {
        try (JdbcResources resources = resources(); OperationAdapter keeper = create(resources)) {
            ResolvedGraph graph = graph(XML, "mapper-1");
            try (OperationAdapter add = resources.prepare(graph, operation("add", "EXECUTE", "LOCAL_WRITE", Effect.WRITE, null, null));
                 OperationAdapter find = resources.prepare(graph, operation("find", "SELECT_ONE", "READ_ONLY", Effect.READ_ONLY, null, null));
                 ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor()) {
                for (int id = 1; id <= 12; id++) add.execute(Payload.of(row(id, "row-" + id, null)), cancellation());
                List<Future<Payload>> results = new ArrayList<>();
                for (int id = 1; id <= 12; id++) {
                    int selected = id;
                    results.add(executor.submit(() -> find.execute(Payload.of(filter(List.of(selected), null)), cancellation())));
                }
                for (int i = 0; i < results.size(); i++) assertEquals(row(i + 1, "row-" + (i + 1), null), results.get(i).get(5, TimeUnit.SECONDS).value());
            }
        }
    }

    @Test void localWriteRollsBackButCompletedAutocommitRetainsSuccessfulBusinessOutcome() {
        try (JdbcResources resources = resources(); OperationAdapter keeper = create(resources)) {
            ResolvedGraph graph = graph(XML, "mapper-1");
            try (OperationAdapter local = resources.prepare(graph, operation("multiInsert", "SELECT_ONE", "LOCAL_WRITE", Effect.WRITE, null, null));
                 OperationAdapter none = resources.prepare(graph, operation("multiInsert", "SELECT_ONE", "NONE", Effect.WRITE, null, null));
                 OperationAdapter read = resources.prepare(graph, operation("find", "MANY", "READ_ONLY", Effect.READ_ONLY, null, null))) {
                ExecutionFailure rolledBack = assertThrows(ExecutionFailure.class, () -> local.execute(Payload.of(Map.of()), cancellation()));
                assertEquals(Outcome.FAILED, rolledBack.outcome());
                assertEquals(Map.of("records", List.of()), read.execute(Payload.of(filter(null, null)), cancellation()).value());
                ExecutionFailure responseFailure = assertThrows(ExecutionFailure.class, () -> none.execute(Payload.of(Map.of()), cancellation()));
                assertEquals(Outcome.SUCCEEDED, responseFailure.outcome());
                assertTrue(responseFailure.responseFailed());
                assertEquals(Map.of("records", List.of(row(90, "a", null), row(91, "b", null))), read.execute(Payload.of(filter(null, null)), cancellation()).value());
            }
        }
    }

    @Test void mapperOnlyReplacementSharesPoolAndLastAdapterEvictionClosesIt() {
        try (JdbcResources resources = resources()) {
            OperationAdapter keeper = create(resources);
            String replacement = XML.replace("ORDER BY id", "ORDER BY id DESC");
            OperationAdapter current = resources.prepare(graph(replacement, "mapper-2"), operation("find", "MANY", "READ_ONLY", Effect.READ_ONLY, null, null));
            try (OperationAdapter add = resources.prepare(graph(XML, "mapper-1"), operation("add", "EXECUTE", "LOCAL_WRITE", Effect.WRITE, null, null))) {
                add.execute(Payload.of(row(1, "one", null)), cancellation());
                add.execute(Payload.of(row(2, "two", null)), cancellation());
            }
            // A connection probe ignores mapper contents and releases its temporary pool reference.
            resources.probe(graph("not mapper XML", "unused-mapper"), "source");
            keeper.close();
            keeper.close();
            assertEquals(Map.of("records", List.of(row(2, "two", null), row(1, "one", null))), current.execute(Payload.of(filter(null, null)), cancellation()).value());
            current.close();
            assertEquals("JDBC_ADAPTER_CLOSED", assertThrows(ExecutionFailure.class,
                    () -> current.execute(Payload.of(Map.of()), cancellation())).code());
            try (OperationAdapter newPool = resources.prepare(graph(XML, "mapper-3"), operation("find", "MANY", "READ_ONLY", Effect.READ_ONLY, null, null))) {
                // A newly opened private in-memory SQLite pool cannot see the previous pool's table.
                ExecutionFailure absent = assertThrows(ExecutionFailure.class,
                        () -> newPool.execute(Payload.of(filter(null, null)), cancellation()));
                assertEquals("JDBC_EXECUTION_FAILED", absent.code());
                assertNull(absent.getCause());
            }
        }
    }

    @Test void sqliteReadOnlyPolicyIsAppliedAtPhysicalOpenAndRejectsWrites(@TempDir Path directory) {
        String url = "jdbc:sqlite:" + directory.resolve("source.db");
        Map<String, Saved> definitions = new HashMap<>(graph(XML, "mapper-1").definitions());
        definitions.put("source", saved("source", "write-source", new JdbcSource(url, "SQLITE", null, 0, 1, 1000, false, 4, 1000)));
        ResolvedGraph writable = new ResolvedGraph("mapper", definitions);
        try (JdbcResources resources = resources()) {
            try (OperationAdapter create = resources.prepare(writable, operation("create", "EXECUTE", "LOCAL_WRITE", Effect.WRITE, null, null));
                 OperationAdapter add = resources.prepare(writable, operation("add", "EXECUTE", "LOCAL_WRITE", Effect.WRITE, null, null))) {
                create.execute(Payload.of(Map.of()), cancellation());
                add.execute(Payload.of(row(1, "readable", null)), cancellation());
            }
            definitions.put("source", saved("source", "read-source", new JdbcSource(url, "SQLITE", null, 0, 1, 1000, true, 4, 1000)));
            ResolvedGraph readOnly = new ResolvedGraph("mapper", definitions);
            try (OperationAdapter read = resources.prepare(readOnly, operation("find", "MANY", "READ_ONLY", Effect.READ_ONLY, null, null));
                 OperationAdapter misdeclaredWrite = resources.prepare(readOnly, operation("multiInsert", "MANY", "READ_ONLY", Effect.READ_ONLY, null, null))) {
                resources.probe(readOnly, "source");
                assertEquals(Map.of("records", List.of(row(1, "readable", null))),
                        read.execute(Payload.of(filter(null, null)), cancellation()).value());
                assertThrows(ExecutionFailure.class, () -> misdeclaredWrite.execute(Payload.of(Map.of()), cancellation()));
                assertEquals(Map.of("records", List.of(row(1, "readable", null))),
                        read.execute(Payload.of(filter(null, null)), cancellation()).value());
            }
        }
    }

    @Test void deadlineCancelsAnExecutingStatementAndPoolRemainsUsable() throws Exception {
        try (JdbcResources resources = resources(); OperationAdapter keeper = create(resources);
             OperationAdapter slow = resources.prepare(graph(XML, "mapper-1"),
                     new JdbcOperation("source", null, "output", Effect.READ_ONLY, 200, null, null, "mapper", "fixture.slow", "SELECT_ONE", "READ_ONLY", List.of(), List.of()));
             OperationAdapter read = resources.prepare(graph(XML, "mapper-1"), operation("find", "MANY", "READ_ONLY", Effect.READ_ONLY, null, null));
             ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor()) {
            Future<ExecutionFailure> result = executor.submit(() -> assertThrows(ExecutionFailure.class,
                    () -> slow.execute(Payload.of(Map.of()), cancellation())));
            ExecutionFailure cancelled = result.get(5, TimeUnit.SECONDS);
            assertEquals(Outcome.FAILED, cancelled.outcome());
            assertNull(cancelled.getCause());
            assertEquals(Map.of("records", List.of()), read.execute(Payload.of(filter(null, null)), cancellation()).value());
        }
    }

    @Test void boundedRowsAndBytesFailWithoutLeakingRawDataOrConnections() {
        try (JdbcResources resources = resources(); OperationAdapter keeper = create(resources);
             OperationAdapter add = resources.prepare(graph(XML, "mapper-1"), operation("add", "EXECUTE", "LOCAL_WRITE", Effect.WRITE, null, null));
             OperationAdapter limitedRows = resources.prepare(graph(XML, "mapper-1"), operation("find", "MANY", "READ_ONLY", Effect.READ_ONLY, 1, null));
             OperationAdapter limitedBytes = resources.prepare(graph(XML, "mapper-1"), operation("large", "SELECT_ONE", "READ_ONLY", Effect.READ_ONLY, null, 3L));
             OperationAdapter read = resources.prepare(graph(XML, "mapper-1"), operation("find", "MANY", "READ_ONLY", Effect.READ_ONLY, null, null))) {
            add.execute(Payload.of(row(1, "one", null)), cancellation());
            add.execute(Payload.of(row(2, "two", null)), cancellation());
            ExecutionFailure rows = assertThrows(ExecutionFailure.class,
                    () -> limitedRows.execute(Payload.of(filter(null, null)), cancellation()));
            ExecutionFailure bytes = assertThrows(ExecutionFailure.class,
                    () -> limitedBytes.execute(Payload.of(Map.of()), cancellation()));
            assertEquals(Outcome.FAILED, rows.outcome());
            assertEquals(Outcome.FAILED, bytes.outcome());
            assertFalse(bytes.toString().contains("SECRET-SENTINEL"));
            assertNull(bytes.getCause());
            assertEquals(Map.of("records", List.of(row(1, "one", null), row(2, "two", null))), read.execute(Payload.of(filter(null, null)), cancellation()).value());
        }
    }

    @Test void allMapperStatementsResolveAndSubstitutionsEntitiesAndArbitraryDriversAreRejected() {
        try (JdbcResources resources = resources()) {
            String unresolved = XML.replace("</mapper>", "<select id=\"unused\" resultMap=\"missing.result\">SELECT 1</select></mapper>");
            assertThrows(ExecutionFailure.class, () -> JdbcResources.validateMappers(graph(unresolved, "mapper-1")));
            assertThrows(ExecutionFailure.class, () -> resources.prepare(graph(unresolved, "mapper-1"), operation("find", "MANY", "READ_ONLY", Effect.READ_ONLY, null, null)));
            for (String substitution : List.of("${external}", "&#36;{external}")) {
                String injected = XML.replace("ORDER BY id", "ORDER BY " + substitution);
                assertEquals("JDBC_LITERAL_SUBSTITUTION_FORBIDDEN", assertThrows(ExecutionFailure.class,
                        () -> resources.prepare(graph(injected, "mapper-1"), operation("find", "MANY", "READ_ONLY", Effect.READ_ONLY, null, null))).code());
            }
            String entity = "<!DOCTYPE mapper [<!ENTITY leak SYSTEM 'file:///private/forbidden'>]><mapper namespace='bad'><select id='q' resultType='string'>SELECT '&leak;'</select></mapper>";
            assertThrows(ExecutionFailure.class, () -> resources.prepare(graph(entity, "mapper-1"), operation("find", "MANY", "READ_ONLY", Effect.READ_ONLY, null, null)));
            Map<String, Saved> definitions = new HashMap<>(graph(XML, "mapper-1").definitions());
            definitions.put("source", saved("source", "source-2", new JdbcSource("jdbc:sqlite::memory:", "untrusted.Driver", null, 1, 1, 1000, false, 16, 2000)));
            assertEquals("JDBC_DRIVER_PROFILE_INVALID", assertThrows(ExecutionFailure.class,
                    () -> resources.prepare(new ResolvedGraph("mapper", definitions), operation("find", "MANY", "READ_ONLY", Effect.READ_ONLY, null, null))).code());
            for (String url : List.of("jdbc:postgresql://user:secret@localhost/test", "jdbc:postgresql://localhost/test?%70assword=secret",
                    "jdbc:oracle:thin:user/secret@localhost:1521/test")) {
                definitions.put("source", saved("source", "source-2", new JdbcSource(url,
                        url.startsWith("jdbc:oracle:") ? "ORACLE19C" : "POSTGRES", null, 1, 1, 1000, false, 16, 2000)));
                ExecutionFailure credentialUrl = assertThrows(ExecutionFailure.class,
                        () -> resources.prepare(new ResolvedGraph("mapper", definitions), operation("find", "MANY", "READ_ONLY", Effect.READ_ONLY, null, null)));
                assertEquals(Outcome.FAILED_BEFORE_EFFECT, credentialUrl.outcome());
                assertEquals(url.startsWith("jdbc:oracle:") ? "JDBC_URL_PROFILE_MISMATCH" : "JDBC_URL_CREDENTIAL_FORBIDDEN", credentialUrl.code());
                assertFalse(credentialUrl.toString().contains("secret"));
            }
        }
    }

    @Test void preparedPoolChecksLiveCredentialVersionWithoutDecryptingOnEachExecution(@TempDir Path directory) throws Exception {
        byte[] key = new byte[32];
        new SecureRandom().nextBytes(key);
        Path keyFile = directory.resolve("active.key");
        Files.write(keyFile, key);
        Files.setPosixFilePermissions(keyFile, PosixFilePermissions.fromString("r--------"));
        Arrays.fill(key, (byte) 0);
        try (PlatformStore store = new PlatformStore(directory.resolve("platform.db"))) {
            CredentialService credentials = new CredentialService(store, new AuditService(store), directory.toString(), "active");
            var credential = credentials.create("source", "PASSWORD", "synthetic", new byte[]{1, 2, 3}, "test", "synthetic fixture");
            Map<String, Saved> definitions = new HashMap<>(graph(XML, "mapper-1").definitions());
            definitions.put("source", saved("source", "source-credential", new JdbcSource("jdbc:sqlite::memory:", "SQLITE", credential.objectId(), 1, 1, 1000, false, 16, 2000)));
            definitions.put(credential.objectId(), saved(credential.objectId(), credential.versionId(), new Credential("PASSWORD", "synthetic")));
            ResolvedGraph graph = new ResolvedGraph("mapper", definitions);
            try (JdbcResources resources = new JdbcResources(credentials);
                 OperationAdapter create = resources.prepare(graph, operation("create", "EXECUTE", "LOCAL_WRITE", Effect.WRITE, null, null));
                 OperationAdapter read = resources.prepare(graph, operation("find", "MANY", "READ_ONLY", Effect.READ_ONLY, null, null))) {
                create.execute(Payload.of(Map.of()), cancellation());
                Files.delete(keyFile);
                assertEquals(Map.of("records", List.of()), read.execute(Payload.of(filter(null, null)), cancellation()).value());
                resources.probe(graph, "source");
                credentials.revoke(credential.versionId(), "test");
                ExecutionFailure revoked = assertThrows(ExecutionFailure.class,
                        () -> read.execute(Payload.of(filter(null, null)), cancellation()));
                assertEquals(Outcome.FAILED_BEFORE_EFFECT, revoked.outcome());
                assertNull(revoked.getCause());
                assertEquals(Outcome.FAILED_BEFORE_EFFECT,
                        assertThrows(ExecutionFailure.class, () -> resources.probe(graph, "source")).outcome());
            }
        }
    }

    @Test void lobValuesAreDetachedAndFreedEvenWhenTheLimitFails() throws Exception {
        SerialBlob binary = new SerialBlob(new byte[]{1, 2, 3});
        JdbcExecution bounded = new JdbcExecution(cancellation(), 1000, 10, 3, false, false, List.of());
        assertArrayEquals(new byte[]{1, 2, 3}, (byte[]) bounded.materialize(binary));
        assertThrows(java.sql.SQLException.class, binary::length);
        SerialClob text = new SerialClob("한글".toCharArray());
        assertEquals("한글", new JdbcExecution(cancellation(), 1000, 10, 6, false, false, List.of()).materialize(text));
        assertThrows(java.sql.SQLException.class, text::length);
        SerialBlob oversized = new SerialBlob(new byte[]{1, 2, 3, 4});
        assertEquals("JDBC_RESULT_BYTE_LIMIT", assertThrows(ExecutionFailure.class,
                () -> new JdbcExecution(cancellation(), 1000, 10, 3, false, false, List.of()).materialize(oversized)).code());
        assertThrows(java.sql.SQLException.class, oversized::length);
    }

    private static JdbcResources resources() {
        // These sources have no credential reference; no store/key service is consulted.
        return new JdbcResources(new CredentialService(null, null, "", ""));
    }
    private static OperationAdapter create(JdbcResources resources) {
        OperationAdapter adapter = resources.prepare(graph(XML, "mapper-1"), operation("create", "EXECUTE", "LOCAL_WRITE", Effect.WRITE, null, null));
        adapter.execute(Payload.of(Map.of()), cancellation());
        return adapter;
    }
    private static Cancellation cancellation() { return new Cancellation(Instant.now().plusSeconds(10)); }
    private static JdbcOperation operation(String statement, String mode, String transaction, Effect effect, Integer rows, Long bytes) {
        String contract = switch (mode) { case "MANY" -> "many"; case "EXECUTE" -> "count"; case "OPTIONAL" -> "optional"; default -> "output"; };
        return new JdbcOperation("source", null, contract, effect, 5000, rows, bytes, "mapper", "fixture." + statement, mode, transaction, List.of(), List.of());
    }
    private static Map<String, Object> row(int id, String name, String note) {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("id", id); row.put("name", name); row.put("note", note);
        return row;
    }
    private static Map<String, Object> filter(List<Integer> ids, String prefix) {
        Map<String, Object> filter = new HashMap<>();
        filter.put("ids", ids); filter.put("prefix", prefix);
        return filter;
    }
    private static ResolvedGraph graph(String xml, String version) {
        return new ResolvedGraph("mapper", Map.of(
                "source", saved("source", "source-1", new JdbcSource("jdbc:sqlite::memory:", "SQLITE", null, 1, 1, 1000, false, 16, 2000)),
                "mapper", saved("mapper", version, new Mapper("SQLITE", List.of(new MapperDocument("mapper.xml", xml)), List.of("import"))),
                "import", saved("import", "import-1", new Mapper("SQLITE", List.of(new MapperDocument("mapper.xml", IMPORT)), List.of())),
                "output", saved("output", "output-1", new Contract("VALUE", rowFields("one", null))),
                "count", saved("count", "count-1", new Contract("VALUE", List.of(field("count-field", null, "changed", "SCALAR", "INTEGER")))),
                "optional", saved("optional", "optional-1", new Contract("VALUE", optionalFields())),
                "many", saved("many", "many-1", new Contract("VALUE", manyFields()))));
    }
    private static List<Field> rowFields(String prefix, String parent) {
        return List.of(field(prefix + "-id", parent, "id", "SCALAR", "INTEGER"),
                new Field(prefix + "-name", "name", parent, "name", "SCALAR", "STRING", 1, false, true, null, null, null, Disposition.OMIT_RECOVERABLE),
                field(prefix + "-note", parent, "note", "SCALAR", "STRING"));
    }
    private static List<Field> manyFields() {
        List<Field> fields = new ArrayList<>(List.of(field("records", null, "records", "ARRAY", "STRING"),
                field("entry", "records", "entry", "OBJECT", "STRING")));
        fields.addAll(rowFields("many", "entry"));
        return fields;
    }
    private static List<Field> optionalFields() {
        List<Field> fields = new ArrayList<>(List.of(field("record", null, "record", "OBJECT", "STRING")));
        fields.addAll(rowFields("optional", "record"));
        return fields;
    }
    private static Field field(String id, String parent, String member, String nodeKind, String valueType) {
        return new Field(id, member, parent, member, nodeKind, valueType, 0, false, true, null, null, null, Disposition.PERSIST);
    }
    private static Saved saved(String id, String version, Detail detail) {
        return new Saved(new Head(id, detail.kind().name(), id, version, 1, 1, true),
                new Version(version, id, detail.kind().name(), 1, 0, "synthetic", "test", id, null), detail);
    }
}
