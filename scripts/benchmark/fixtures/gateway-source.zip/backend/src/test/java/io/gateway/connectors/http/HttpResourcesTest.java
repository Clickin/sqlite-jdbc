package io.gateway.connectors.http;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import io.gateway.connectors.OperationAdapter;
import io.gateway.contracts.ContractService;
import io.gateway.definitions.Definitions.*;
import io.gateway.runtime.*;
import java.io.IOException;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import org.junit.jupiter.api.Test;
import tools.jackson.databind.json.JsonMapper;

import static io.gateway.runtime.ExecutionFailure.Outcome.*;
import static org.junit.jupiter.api.Assertions.*;

class HttpResourcesTest {
    private static final Field MESSAGE = field("message-id", null, "message", "SCALAR", "STRING", 0, true, false, Payload.Disposition.PERSIST);
    private static final Contract INPUT = new Contract("VALUE", List.of(MESSAGE));
    private static final Representation JSON_INPUT = new Representation("input", "JSON", null, "application/json", "UTF-8",
            List.of(new JsonBinding("message-id", "content", "MEMBER")), List.of());
    private static final Contract XML_OUTPUT = new Contract("VALUE", List.of(
            field("root", null, "reply", "OBJECT", null, 0, true, false, Payload.Disposition.PERSIST),
            field("status", "root", "status", "SCALAR", "STRING", 0, true, false, Payload.Disposition.PERSIST),
            field("text", "root", "recordText", "SCALAR", "STRING", 1, true, false, Payload.Disposition.OMIT_RECOVERABLE),
            field("number", "root", "count", "SCALAR", "INTEGER", 2, true, false, Payload.Disposition.PERSIST),
            field("nullable", "root", "optional", "SCALAR", "STRING", 3, false, true, Payload.Disposition.PERSIST)));
    private static final Representation XML_RESPONSE = new Representation("output", "XML", null, "application/xml", "UTF-8", List.of(), List.of(
            xml("root", "urn:reply", "response", "ELEMENT", 0, "ERROR"),
            xml("status", "urn:attributes", "status", "ATTRIBUTE", 0, "ERROR"),
            xml("text", "urn:reply", "text", "ELEMENT", 1, "ERROR"),
            xml("number", "urn:reply", "count", "ELEMENT", 2, "ERROR"),
            xml("nullable", "urn:reply", "optional", "ELEMENT", 3, "XSI_NIL")));
    private static final String XML_REPLY = "<response xmlns=\"urn:reply\" xmlns:a=\"urn:attributes\" a:status=\"ok\">"
            + "<text>합성 &amp; fixture</text><count>9007199254740993</count>"
            + "<optional xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/></response>";

    @Test void independentJsonRequestAndXmlResponsePreserveBindingsNamespacesAndDisposition() throws Exception {
        try (var server = new Server(); var resources = resources(4096, 4096, 20)) {
            var received = new AtomicReference<String>();
            server.http.createContext("/api/run", exchange -> {
                received.set(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
                send(exchange, 200, "application/xml", XML_REPLY);
            });
            try (var adapter = resources.prepare(graph(server, INPUT, XML_OUTPUT, JSON_INPUT, XML_RESPONSE), operation("run", List.of(), null, null, 3000))) {
                Payload result = adapter.execute(Payload.of(Map.of("message", "한글 <>&",
                        "authorized", Map.of("principal", "synthetic-principal", "token", "never-on-wire"))), cancellation());
                assertEquals(Map.of("content", "한글 <>&"), JsonMapper.builder().build().readValue(received.get(), Map.class));
                var reply = (Map<?,?>) result.object().get("reply");
                assertEquals("ok", reply.get("status"));
                assertEquals("합성 & fixture", reply.get("recordText"));
                assertEquals(new BigInteger("9007199254740993"), reply.get("count"));
                assertTrue(reply.containsKey("optional"));
                assertNull(reply.get("optional"));
                assertEquals(Payload.Disposition.OMIT_RECOVERABLE, result.dispositions().get("text"));
            }
        }
    }

    @Test void queryAndPathAreBoundToRegisteredHostAndHeader() throws Exception {
        try (var server = new Server(); var resources = resources(4096, 4096, 20)) {
            var uri = new AtomicReference<String>();
            var header = new AtomicReference<String>();
            server.http.createContext("/api/record/", exchange -> {
                uri.set(exchange.getRequestURI().toASCIIString());
                header.set(exchange.getRequestHeaders().getFirst("X-Synthetic"));
                send(exchange, 200, "application/xml", XML_REPLY);
            });
            List<Parameter> params = List.of(new Parameter("PATH", "id", null, "entry 1", true),
                    new Parameter("QUERY", "query", "message-id", null, true),
                    new Parameter("QUERY", "query", null, "second", true),
                    new Parameter("HEADER", "X-Synthetic", null, "fixture", true));
            try (var adapter = resources.prepare(graph(server, INPUT, XML_OUTPUT, JSON_INPUT, XML_RESPONSE), operation("record/{id}", params, null, null, 3000))) {
                adapter.execute(Payload.of(Map.of("message", "a&b=1")), cancellation());
                assertEquals("/api/record/entry%201?query=a%26b%3D1&query=second", uri.get());
                assertEquals("fixture", header.get());
            }
        }
    }

    @Test void serverErrorConnectionDropRedirectAndAuthChallengeNeverReplay() throws Exception {
        try (var server = new Server(); var resources = resources(4096, 4096, 20)) {
            var counts = new ConcurrentHashMap<String,AtomicInteger>();
            for (String path : List.of("error", "drop", "redirect", "auth", "second")) {
                counts.put(path, new AtomicInteger());
                server.http.createContext("/api/" + path, exchange -> {
                    counts.get(path).incrementAndGet();
                    exchange.getRequestBody().readAllBytes();
                    switch (path) {
                        case "drop" -> exchange.close();
                        case "redirect" -> { exchange.getResponseHeaders().add("Location", "/api/second"); send(exchange, 307, "text/plain", ""); }
                        case "auth" -> { exchange.getResponseHeaders().add("WWW-Authenticate", "Basic realm=\"fixture\""); send(exchange, 401, "text/plain", ""); }
                        default -> send(exchange, 500, "text/plain", "synthetic remote error");
                    }
                });
            }
            var graph = graph(server, INPUT, XML_OUTPUT, JSON_INPUT, XML_RESPONSE);
            for (String path : List.of("error", "drop", "redirect", "auth")) {
                try (var adapter = resources.prepare(graph, operation(path, List.of(), null, null, 3000))) {
                    ExecutionFailure failure = assertThrows(ExecutionFailure.class, () -> adapter.execute(Payload.of(Map.of("message", "once")), cancellation()));
                    assertEquals(OUTCOME_UNKNOWN, failure.outcome());
                    assertNull(failure.getCause());
                }
                assertEquals(1, counts.get(path).get(), path);
            }
            assertEquals(0, counts.get("second").get());
        }
    }

    @Test void readOnlyResetIsFailureWithoutMutationUncertaintyOrRetry() throws Exception {
        try(var server=new Server();var resources=resources(4096,4096,20)){
            var calls=new AtomicInteger();
            server.http.createContext("/api/read",exchange->{calls.incrementAndGet();exchange.getRequestBody().readAllBytes();exchange.close();});
            var read=new HttpOperation("source","input","output",Effect.READ_ONLY,3000,null,null,"POST","read","request","response",List.of(),List.of(),List.of());
            try(var adapter=resources.prepare(graph(server,INPUT,XML_OUTPUT,JSON_INPUT,XML_RESPONSE),read)){
                var failure=assertThrows(ExecutionFailure.class,()->adapter.execute(Payload.of(Map.of("message","read-only")),cancellation()));
                assertEquals(FAILED,failure.outcome());assertEquals(1,calls.get());
            }
        }
    }

    @Test void requestBoundsPreventTransmissionAndResponseBoundsPreserveConfirmedSuccess() throws Exception {
        try (var server = new Server(); var resources = resources(512, 512, 20)) {
            var count = new AtomicInteger();
            server.http.createContext("/api/run", exchange -> {
                count.incrementAndGet();
                send(exchange, 200, "application/xml", "x".repeat(600));
            });
            try (var adapter = resources.prepare(graph(server, INPUT, XML_OUTPUT, JSON_INPUT, XML_RESPONSE), operation("run", List.of(), null, null, 3000))) {
                ExecutionFailure request = assertThrows(ExecutionFailure.class, () -> adapter.execute(Payload.of(Map.of("message", "x".repeat(600))), cancellation()));
                assertEquals(FAILED_BEFORE_EFFECT, request.outcome());
                assertEquals(0, count.get());
                ExecutionFailure response = assertThrows(ExecutionFailure.class, () -> adapter.execute(Payload.of(Map.of("message", "bounded")), cancellation()));
                assertEquals(SUCCEEDED, response.outcome());
                assertTrue(response.responseFailed());
                assertEquals(1, count.get());
            }
        }
    }

    @Test void chunkedResponseAndAggregateArrayRowsAreBounded() throws Exception {
        var array = new Contract("VALUE", List.of(
                field("rows", null, "rows", "ARRAY", null, 0, true, false, Payload.Disposition.PERSIST),
                field("row", "rows", "item", "SCALAR", "INTEGER", 0, true, false, Payload.Disposition.PERSIST)));
        var jsonResponse = new Representation("output", "JSON", null, "application/json", "UTF-8", List.of(), List.of());
        try (var server = new Server(); var resources = resources(4096, 512, 2)) {
            server.http.createContext("/api/rows", exchange -> send(exchange, 200, "application/json", "{\"rows\":[1,2,3]}"));
            server.http.createContext("/api/chunked", exchange -> {
                exchange.sendResponseHeaders(200, 0);
                try (var body = exchange.getResponseBody()) { body.write("x".repeat(600).getBytes(StandardCharsets.UTF_8)); }
            });
            var graph = graph(server, INPUT, array, JSON_INPUT, jsonResponse);
            for (String path : List.of("rows", "chunked")) try (var adapter = resources.prepare(graph, operation(path, List.of(), null, null, 3000))) {
                ExecutionFailure failure = assertThrows(ExecutionFailure.class, () -> adapter.execute(Payload.of(Map.of("message", "fixture")), cancellation()));
                assertEquals(SUCCEEDED, failure.outcome());
                assertTrue(failure.responseFailed());
            }
        }
    }

    @Test void xxeWrongNamespaceAndMalformedXmlAreSanitizedWithoutExternalFetch() throws Exception {
        try (var server = new Server(); var resources = resources(4096, 4096, 20)) {
            var fetches = new AtomicInteger();
            var response = new AtomicReference<String>();
            server.http.createContext("/entity", exchange -> { fetches.incrementAndGet(); send(exchange, 200, "text/plain", "must not fetch"); });
            server.http.createContext("/api/run", exchange -> send(exchange, 200, "application/xml", response.get()));
            List<String> bodies = List.of("<!DOCTYPE response [<!ENTITY xxe SYSTEM \"" + server.base().replace("/api/", "/entity") + "\">]>"
                            + "<response xmlns=\"urn:reply\">&xxe;</response>",
                    XML_REPLY.replace("urn:reply", "urn:wrong"), "<response>RAW_SENTINEL");
            try (var adapter = resources.prepare(graph(server, INPUT, XML_OUTPUT, JSON_INPUT, XML_RESPONSE), operation("run", List.of(), null, null, 3000))) {
                for (String body : bodies) {
                    response.set(body);
                    ExecutionFailure failure = assertThrows(ExecutionFailure.class, () -> adapter.execute(Payload.of(Map.of("message", "fixture")), cancellation()));
                    assertEquals(SUCCEEDED, failure.outcome());
                    assertTrue(failure.responseFailed());
                    assertEquals("HTTP_RESPONSE_FAILED", failure.getMessage());
                    assertNull(failure.getCause());
                }
            }
            assertEquals(0, fetches.get());
        }
    }

    @Test void argumentAndDefinitionUrlHeaderInjectionAreRejectedBeforeTransmission() throws Exception {
        try (var server = new Server(); var resources = resources(4096, 4096, 20)) {
            var calls = new AtomicInteger();
            server.http.createContext("/api/", exchange -> { calls.incrementAndGet(); send(exchange, 200, "application/xml", XML_REPLY); });
            var graph = graph(server, INPUT, XML_OUTPUT, JSON_INPUT, XML_RESPONSE);
            for (String path : List.of("//evil.invalid/x", "http://evil.invalid/x", "../escape", "run?evil=1", "run#fragment", "%2f%2fevil")) {
                assertThrows(ExecutionFailure.class, () -> resources.prepare(graph, operation(path, List.of(), null, null, 3000)));
            }
            var pathBinding = List.of(new Parameter("PATH", "id", "message-id", null, true));
            try (var adapter = resources.prepare(graph, operation("record/{id}", pathBinding, null, null, 3000))) {
                for (String value : List.of("../escape", "//evil.invalid", "http://evil.invalid", "%2e%2e", "x\r\nInjected: true")) {
                    ExecutionFailure failure = assertThrows(ExecutionFailure.class, () -> adapter.execute(Payload.of(Map.of("message", value)), cancellation()));
                    assertEquals(FAILED_BEFORE_EFFECT, failure.outcome());
                }
            }
            var headerBinding = List.of(new Parameter("HEADER", "X-Input", "message-id", null, true));
            try (var adapter = resources.prepare(graph, operation("run", headerBinding, null, null, 3000))) {
                assertThrows(ExecutionFailure.class, () -> adapter.execute(Payload.of(Map.of("message", "good\r\nHost: evil.invalid")), cancellation()));
            }
            for (String name : List.of("Host", "Authorization", "Content-Length", "X-Evil\r\nInjected")) {
                var params = List.of(new Parameter("HEADER", name, "message-id", null, true));
                assertThrows(ExecutionFailure.class, () -> resources.prepare(graph, operation("run", params, null, null, 3000)));
            }
            assertEquals(0, calls.get());
        }
    }

    @Test void cancellationAndOperationDeadlineCancelActiveRequestWithoutClaimingRollback() throws Exception {
        for (boolean explicitCancel : List.of(true, false)) {
            try (var server = new Server(); var resources = resources(4096, 4096, 20); var executor = Executors.newVirtualThreadPerTaskExecutor()) {
                var received = new CountDownLatch(1);
                var release = new CountDownLatch(1);
                var count = new AtomicInteger();
                server.http.createContext("/api/run", exchange -> {
                    count.incrementAndGet();
                    exchange.getRequestBody().readAllBytes();
                    received.countDown();
                    try { release.await(5, TimeUnit.SECONDS); }
                    catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                    finally { exchange.close(); }
                });
                try (var adapter = resources.prepare(graph(server, INPUT, XML_OUTPUT, JSON_INPUT, XML_RESPONSE), operation("run", List.of(), null, null, explicitCancel ? 4000 : 1000))) {
                    Cancellation cancellation = cancellation();
                    Future<Payload> result = executor.submit(() -> adapter.execute(Payload.of(Map.of("message", "once")), cancellation));
                    try {
                        assertTrue(received.await(3, TimeUnit.SECONDS));
                        if (explicitCancel) cancellation.cancel();
                        var failure = assertThrows(ExecutionException.class, () -> result.get(4, TimeUnit.SECONDS));
                        assertInstanceOf(ExecutionFailure.class, failure.getCause());
                        assertEquals(OUTCOME_UNKNOWN, ((ExecutionFailure) failure.getCause()).outcome());
                        assertEquals(1, count.get());
                    } finally { release.countDown(); }
                }
            }
        }
    }

    @Test void headerOnlySourceRevisionSharesConnectionUntilLastAdapterLeaseCloses() throws Exception {
        try (var server = new Server(); var resources = resources(4096, 4096, 20)) {
            var peers = new CopyOnWriteArrayList<Integer>();
            var header = new AtomicReference<String>();
            server.http.createContext("/api/run", exchange -> {
                peers.add(exchange.getRemoteAddress().getPort());
                header.set(exchange.getRequestHeaders().getFirst("X-Revision"));
                send(exchange, 200, "application/xml", XML_REPLY);
            });
            var graph = graph(server, INPUT, XML_OUTPUT, JSON_INPUT, XML_RESPONSE);
            var definitions = new LinkedHashMap<>(graph.definitions());
            var nextSource = new HttpSource(server.base(), "NONE", null, null, null, null,
                    4, 4, 1000, "NEVER", 4, 1000, List.of(new Header("X-Revision", "v2", null)));
            definitions.put("source", new Saved(new Head("source", "DATASOURCE", "source", "source-v2", 2, 2, true),
                    new Version("source-v2", "source", "DATASOURCE", 2, 0, "test", "header change", "source", null), nextSource));
            var nextGraph = new ResolvedGraph("operation", definitions);
            try (var first = resources.prepare(graph, operation("run", List.of(), null, null, 3000))) {
                first.execute(Payload.of(Map.of("message", "first")), cancellation());
                assertNull(header.get());
                try (var second = resources.prepare(nextGraph, operation("run", List.of(), null, null, 3000))) {
                    first.close(); first.close();
                    assertThrows(ExecutionFailure.class, () -> first.execute(Payload.of(Map.of("message", "closed")), cancellation()));
                    assertEquals("ok", ((Map<?,?>) second.execute(Payload.of(Map.of("message", "active")), cancellation()).object().get("reply")).get("status"));
                    assertEquals("v2", header.get());
                    assertEquals(List.of(peers.getFirst(), peers.getFirst()), peers);
                }
            }
        }
    }

    @Test void xmlRequestUsesDeclaredElementsAttributesOrderingAndNullPolicy() throws Exception {
        var requestRepresentation = new Representation("input", "XML", null, "application/xml", "UTF-8", List.of(), XML_RESPONSE.xmlBindings());
        var responseRepresentation = new Representation("output", "JSON", null, "application/json", "UTF-8", List.of(), List.of());
        try (var server = new Server(); var resources = resources(4096, 4096, 20)) {
            var captured = new AtomicReference<byte[]>();
            server.http.createContext("/api/run", exchange -> {
                captured.set(exchange.getRequestBody().readAllBytes());
                send(exchange, 200, "application/json", "{\"message\":\"accepted\"}");
            });
            var graph = graph(server, XML_OUTPUT, INPUT, requestRepresentation, responseRepresentation);
            var reply = new LinkedHashMap<String,Object>();
            reply.put("status", "ok"); reply.put("recordText", "합성 & fixture");
            reply.put("count", new BigInteger("9007199254740993")); reply.put("optional", null);
            try (var adapter = resources.prepare(graph, operation("run", List.of(), null, null, 3000))) {
                assertEquals("accepted", adapter.execute(Payload.of(Map.of("reply", reply)), cancellation()).object().get("message"));
                var invalid = new LinkedHashMap<>(reply);
                invalid.put("recordText", "invalid\u0000character");
                ExecutionFailure failure = assertThrows(ExecutionFailure.class,
                        () -> adapter.execute(Payload.of(Map.of("reply", invalid)), cancellation()));
                assertEquals(FAILED_BEFORE_EFFECT, failure.outcome());
            }
            WireCodec decoder = new WireCodec(graph, "request", "input", new ContractService(null));
            assertEquals(reply, decoder.decode(captured.get(), 20).object().get("reply"));
        }
    }

    @Test void optionalNestedParameterDoesNotRequireItsMissingParent() throws Exception {
        var input = new Contract("VALUE", List.of(
                field("filter", null, "filter", "OBJECT", null, 0, false, true, Payload.Disposition.PERSIST),
                field("term", "filter", "term", "SCALAR", "STRING", 0, false, false, Payload.Disposition.PERSIST)));
        var representation = new Representation("input", "JSON", null, "application/json", "UTF-8", List.of(), List.of());
        try (var server = new Server(); var resources = resources(4096, 4096, 20)) {
            var query = new AtomicReference<String>();
            server.http.createContext("/api/run", exchange -> {
                query.set(exchange.getRequestURI().getRawQuery());
                send(exchange, 200, "application/xml", XML_REPLY);
            });
            var parameters = List.of(new Parameter("QUERY", "term", "term", null, false));
            try (var adapter = resources.prepare(graph(server, input, XML_OUTPUT, representation, XML_RESPONSE),
                    operation("run", parameters, null, null, 3000))) {
                adapter.execute(Payload.of(Map.of()), cancellation());
                assertNull(query.get());
                adapter.execute(Payload.of(Map.of("filter", Map.of("term", "value"))), cancellation());
                assertEquals("term=value", query.get());
            }
        }
    }

    @Test void binaryFieldsUseBase64AcrossBothRepresentationsWithoutChangingBytes() throws Exception {
        byte[] binary = new byte[] {0, 1, 127, -1, -128, 13, 10};
        String encoded = Base64.getEncoder().encodeToString(binary);
        var contract = new Contract("VALUE", List.of(
                field("blob", null, "blob", "SCALAR", "BINARY", 0, true, false, Payload.Disposition.PERSIST)));
        for (boolean xmlRequest : List.of(false, true)) {
            var xmlBindings = List.of(xml("blob", "urn:binary", "blob", "ELEMENT", 0, "ERROR"));
            var request = new Representation("input", xmlRequest ? "XML" : "JSON", null,
                    xmlRequest ? "application/xml" : "application/json", "UTF-8", List.of(), xmlRequest ? xmlBindings : List.of());
            var response = new Representation("output", xmlRequest ? "JSON" : "XML", null,
                    xmlRequest ? "application/json" : "application/xml", "UTF-8", List.of(), xmlRequest ? List.of() : xmlBindings);
            try (var server = new Server(); var resources = resources(4096, 4096, 20)) {
                var captured = new AtomicReference<byte[]>();
                server.http.createContext("/api/run", exchange -> {
                    captured.set(exchange.getRequestBody().readAllBytes());
                    send(exchange, 200, response.mediaType(), xmlRequest ? "{\"blob\":\"" + encoded + "\"}"
                            : "<blob xmlns=\"urn:binary\">" + encoded + "</blob>");
                });
                try (var adapter = resources.prepare(graph(server, contract, contract, request, response),
                        operation("run", List.of(), null, null, 3000))) {
                    assertArrayEquals(binary, (byte[]) adapter.execute(Payload.of(Map.of("blob", binary)), cancellation()).object().get("blob"));
                }
                if (xmlRequest) {
                    var parsed = javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder()
                            .parse(new java.io.ByteArrayInputStream(captured.get()));
                    assertEquals(encoded, parsed.getDocumentElement().getTextContent());
                } else assertEquals(Map.of("blob", encoded), JsonMapper.builder().build().readValue(captured.get(), Map.class));
            }
        }
    }

    @Test void connectionProbeConnectsWithoutSendingHttpOrBusinessBytes() throws Exception {
        try (var listener = new java.net.ServerSocket(0, 1, java.net.InetAddress.getByName("127.0.0.1"));
             var server = Executors.newVirtualThreadPerTaskExecutor();
             var resources = resources(4096, 4096, 20)) {
            listener.setSoTimeout(3000);
            Future<Integer> firstByte = server.submit(() -> {
                try (var accepted = listener.accept()) {
                    accepted.setSoTimeout(3000);
                    return accepted.getInputStream().read();
                }
            });
            var source = new HttpSource("http://127.0.0.1:" + listener.getLocalPort(), "NONE", null,
                    null, null, null, 1, 1, 1000, "NEVER", 1, 1000, List.of());
            resources.probe(new ResolvedGraph("source", Map.of("source", saved("source", source))), "source");
            assertEquals(-1, firstByte.get(3, TimeUnit.SECONDS).intValue());
        }
    }

    @Test void tlsConnectionProbeTimesOutWithoutSendingAnHttpRequest() throws Exception {
        try (var listener = new java.net.ServerSocket(0, 1, java.net.InetAddress.getByName("127.0.0.1"));
             var server = Executors.newVirtualThreadPerTaskExecutor();
             var resources = resources(4096, 4096, 20)) {
            listener.setSoTimeout(3000);
            Future<Integer> firstByte = server.submit(() -> {
                try (var accepted = listener.accept()) {
                    accepted.setSoTimeout(3000);
                    int first = accepted.getInputStream().read();
                    try { accepted.getInputStream().readAllBytes(); }
                    catch (java.net.SocketException ignored) { /* cancellation may close via TCP reset */ }
                    return first;
                }
            });
            var source = new HttpSource("https://127.0.0.1:" + listener.getLocalPort(), "NONE", null,
                    null, null, null, 1, 1, 1000, "NEVER", 1, 1000, List.of());
            var graph = new ResolvedGraph("source", Map.of("source", saved("source", source)));
            var failure = assertThrows(ExecutionFailure.class, () -> resources.probe(graph, "source"));
            assertEquals(FAILED_BEFORE_EFFECT, failure.outcome());
            assertEquals("HTTP_CONNECTION_PROBE_FAILED", failure.code());
            assertNull(failure.getCause());
            assertEquals(22, firstByte.get(3, TimeUnit.SECONDS).intValue()); // TLS handshake record, not an HTTP method.
        }
    }

    private static HttpResources resources(int requestBytes, int responseBytes, int rows) {
        return new HttpResources(null, new ContractService(null), requestBytes, responseBytes, rows);
    }
    private static Cancellation cancellation() { return new Cancellation(Instant.now().plusSeconds(10)); }
    private static HttpOperation operation(String path, List<Parameter> parameters, Integer rows, Long bytes, int timeout) {
        return new HttpOperation("source", "input", "output", Effect.WRITE, timeout, rows, bytes, "POST", path, "request", "response", parameters, List.of(), List.of());
    }
    private static ResolvedGraph graph(Server server, Contract input, Contract output, Representation request, Representation response) {
        var source = new HttpSource(server.base(), "NONE", null, null, null, null, 4, 4, 1000, "NEVER", 4, 1000, List.of());
        var definitions = new LinkedHashMap<String,Saved>();
        definitions.put("source", saved("source", source)); definitions.put("input", saved("input", input));
        definitions.put("output", saved("output", output)); definitions.put("request", saved("request", request));
        definitions.put("response", saved("response", response));
        return new ResolvedGraph("operation", definitions);
    }
    private static Saved saved(String id, Detail detail) {
        return new Saved(new Head(id, detail.kind().name(), id, id + "-v1", 1, 1, true),
                new Version(id + "-v1", id, detail.kind().name(), 1, 0, "test", "fixture", id, null), detail);
    }
    private static Field field(String id, String parent, String name, String kind, String type, int order, boolean required, boolean nullable, Payload.Disposition disposition) {
        return new Field(id, name, parent, name, kind, type, order, required, nullable, null, null, null, disposition);
    }
    private static XmlBinding xml(String id, String namespace, String local, String kind, int order, String nullPolicy) {
        return new XmlBinding(id, namespace, local, kind, order, nullPolicy);
    }
    private static void send(HttpExchange exchange, int status, String contentType, String body) throws IOException {
        exchange.getRequestBody().readAllBytes();
        exchange.getResponseHeaders().set("Content-Type", contentType);
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(status, bytes.length == 0 ? -1 : bytes.length);
        try (var output = exchange.getResponseBody()) { output.write(bytes); }
    }
    private static final class Server implements AutoCloseable {
        final HttpServer http = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        final ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();
        Server() throws IOException { http.setExecutor(executor); http.start(); }
        String base() { return "http://127.0.0.1:" + http.getAddress().getPort() + "/api/"; }
        public void close() { http.stop(0); executor.close(); }
    }
}
