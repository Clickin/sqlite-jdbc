package io.gateway;

import com.sun.net.httpserver.HttpServer;
import io.gateway.definitions.*;
import io.gateway.definitions.Definitions.*;
import io.gateway.oauth.SecurityFixture;
import io.gateway.persistence.PlatformStore;
import io.gateway.runtime.Payload;
import io.micronaut.context.ApplicationContext;
import io.micronaut.runtime.server.EmbeddedServer;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/** Real HTTP/MyBatis/SQLite runtime; every authority and patient here is synthetic. */
public final class GatewayFixture implements AutoCloseable {
    public static final String REST_RESOURCE=SecurityFixture.ISSUER+"/api";
    public static final String RECORD_TEXT="RECOVERABLE_SENTINEL_NEVER_PERSIST";
    public static final String SOURCE_SECRET="SOURCE_SECRET_SENTINEL_NEVER_PERSIST";
    public static final String WEB_LINK="https://clinical.example/notes/synthetic";
    public final EmbeddedServer server;
    public final PlatformStore store;
    public final HttpServer source;
    public final AtomicInteger sourceCalls=new AtomicInteger();
    public volatile String sourceWebLink=WEB_LINK;
    public final Saved input,output,workflow,datasource,generatedOutput;
    private final java.util.concurrent.ExecutorService sourceExecutor=Executors.newVirtualThreadPerTaskExecutor();
    public GatewayFixture(Path directory,int port) throws Exception {this(directory,port,false);}
    public GatewayFixture(Path directory,int port,boolean references) throws Exception {
        this(directory,port,references,Map.of(),"test");
    }
    public GatewayFixture(Path directory,int port,boolean references,Map<String,Object> overrides,String... environments) throws Exception {
        Files.createDirectories(directory);
        Files.writeString(directory.resolve("state.key"),Base64.getEncoder().encodeToString(new byte[32]));
        source=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
        source.createContext("/labs",exchange->{
            sourceCalls.incrementAndGet();
            String response="{\"answer\":\"합성 정상 결과\",\"recordText\":\""+RECORD_TEXT+"\""+(references?",\"webLink\":\""+sourceWebLink+"\"":"")+"}";
            byte[] bytes=response.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type","application/json");exchange.sendResponseHeaders(200,bytes.length);
            try(var body=exchange.getResponseBody()){body.write(bytes);}
        });
        source.createContext("/_synthetic/calls",exchange->{
            byte[] count=Integer.toString(sourceCalls.get()).getBytes(StandardCharsets.US_ASCII);
            exchange.sendResponseHeaders(200,count.length);try(var body=exchange.getResponseBody()){body.write(count);}
        });
        source.setExecutor(sourceExecutor);source.start();
        var properties=new HashMap<>(SecurityFixture.properties(directory));
        properties.put("micronaut.server.port",port);properties.put("micronaut.server.host","127.0.0.1");
        properties.put("gateway.references.web-origins","https://clinical.example");
        if(references)properties.put("gateway.oauth.rest-resource",REST_RESOURCE);
        String publicOrigin=System.getenv("GATEWAY_SYNTHETIC_PUBLIC_ORIGIN");
        if(publicOrigin!=null){properties.put("gateway.oauth.public-origin",publicOrigin);properties.put("gateway.oauth.issuer",publicOrigin);}
        properties.putAll(overrides);
        server=ApplicationContext.builder().deduceEnvironment(false).environments(environments).properties(properties).run(EmbeddedServer.class);
        store=server.getApplicationContext().getBean(PlatformStore.class);
        SecurityFixture.seed(store);
        var repository=server.getApplicationContext().getBean(DefinitionRepository.class);
        var inputFields=new ArrayList<>(List.of(field("patient-field","patientId","PERSIST"),field("document-field","documentId","PERSIST")));
        var outputFields=new ArrayList<>(List.of(field("answer-field","answer","PERSIST"),field("body-field","recordText","OMIT_RECOVERABLE")));
        if(references) {
            inputFields.add(field("secret-field","sourceSecret",2,"OMIT_SECRET"));
            outputFields.add(field("link-field","webLink",2,"PERSIST"));
            store.write(s->{var m=s.getMapper(SecurityFixture.FixtureMapper.class);
                m.execute("INSERT INTO oauth_resource VALUES('rest-resource','"+REST_RESOURCE+"','REST','Synthetic results',true)");
                m.execute("INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name) VALUES('public-v2','public','OAUTH_CLIENT',2,2,'fixture','REST results','Synthetic client')");
                m.execute("INSERT INTO oauth_client_version SELECT 'public-v2',kind,client_type,token_endpoint_auth_method,display_name,require_pkce_s256,refresh_enabled FROM oauth_client_version WHERE version_id='public-v1'");
                m.execute("INSERT INTO oauth_client_redirect SELECT 'public-v2',redirect_uri,native_loopback_port_policy,ordinal FROM oauth_client_redirect WHERE client_version_id='public-v1'");
                m.execute("INSERT INTO oauth_client_scope SELECT 'public-v2',scope_id FROM oauth_client_scope WHERE client_version_id='public-v1'");
                m.execute("INSERT INTO oauth_client_action SELECT 'public-v2',action_id,action_semantic_version FROM oauth_client_action WHERE client_version_id='public-v1'");
                m.execute("INSERT INTO oauth_client_resource VALUES('public-v2','mcp-resource'),('public-v2','rest-resource')");
                m.execute("UPDATE config_object SET current_version_id='public-v2',revision_counter=2,generation=2 WHERE id='public'");
                object(m,"lab-screen","SCREEN_PROFILE");
                m.execute("INSERT INTO screen_profile_version(version_id,adapter_id,screen_code,allowed_launch_profile) VALUES('lab-screen-v1','synthetic-hospital','LAB','view-lab')");
                m.execute("INSERT INTO screen_parameter_binding VALUES('lab-screen-v1','original.patientId','original_patient','STRING',0),('lab-screen-v1','effective.patientId','patient_id','STRING',1),('lab-screen-v1','effective.documentId','document_id','STRING',2)");
                activate(m,"lab-screen");return null;});
        }
        input=publish(repository,"lab-input",new Contract("VALUE",inputFields));
        output=publish(repository,"lab-output",new Contract("VALUE",outputFields));
        generatedOutput=references?publish(repository,"generated-summary",new Contract("VALUE",List.of(field("summary-field","summary","PERSIST")))):null;
        var representation=publish(repository,"lab-json",new Representation(output.object().id(),"json","DEFAULT","application/json","UTF-8",List.of(),List.of()));
        datasource=publish(repository,"lab-source",new HttpSource("http://127.0.0.1:"+source.getAddress().getPort(),"NONE",null,null,null,null,4,4,2000,"NEVER",4,1000,List.of()));
        var parameters=new ArrayList<>(List.of(new Parameter("QUERY","patientId","patient-field",null,true),new Parameter("QUERY","documentId","document-field",null,true)));
        if(references)parameters.add(new Parameter("HEADER","X-Synthetic-Secret","secret-field",null,true));
        var referenceBindings=references?List.of(new ReferenceBinding("WEB_LINK","link-field",null,null,"Synthetic source note"),
                new ReferenceBinding("TOOL_REFERENCE",null,null,"lab-screen","Synthetic lab screen")):List.<ReferenceBinding>of();
        var operation=publish(repository,"lab-operation",new HttpOperation(datasource.object().id(),input.object().id(),output.object().id(),Effect.READ_ONLY,5000,100,1048576L,"GET","labs",null,representation.object().id(),
                parameters,List.of(new ExpectedStatus(200,"SUCCEEDED")),referenceBindings));
        store.write(s->{var m=s.getMapper(SecurityFixture.FixtureMapper.class);
            object(m,"document-policy","TARGET_POLICY");
            m.execute("INSERT INTO target_policy_version(version_id,target_kind,canonical_organization,identifier_system,require_parent_patient) VALUES('document-policy-v1','DOCUMENT','synthetic-hospital','synthetic-mrn',true)");
            m.execute("INSERT INTO target_argument_binding VALUES('document-policy-v1','REQUEST','patient-field','PATIENT',0),('document-policy-v1','REQUEST','document-field','DOCUMENT',1)");
            activate(m,"document-policy");
            return null;});
        workflow=publish(repository,"lab-workflow",new Workflow(null,List.of(new Stage("INPUT",0,operation.object().id(),null)),List.of(),
                List.of(new SecurityBinding("INPUT","security","clinical.lab.read","document-policy"))));
        store.write(s->{var m=s.getMapper(SecurityFixture.FixtureMapper.class);object(m,"lab-tool","MCP_TOOL");
            m.execute("INSERT INTO mcp_tool_version(version_id,public_name,description,workflow_object_id,public_input_contract_version_id,public_output_contract_version_id,security_binding_object_id,target_policy_object_id,effect_kind) VALUES('lab-tool-v1','lab-tool','Synthetic patient lab query','"+workflow.object().id()+"','"+input.version().id()+"','"+output.version().id()+"','security','document-policy','READ_ONLY')");
            m.execute("INSERT INTO mcp_tool_action VALUES('lab-tool-v1','clinical.lab.read')");m.execute("INSERT INTO mcp_tool_scope VALUES('lab-tool-v1','read')");activate(m,"lab-tool");return null;});
    }
    private static Field field(String id,String name,String disposition){return field(id,name,Set.of("document-field","body-field").contains(id)?1:0,disposition);}
    private static Field field(String id,String name,int ordinal,String disposition){return new Field(id,name,null,name,"SCALAR","STRING",ordinal,true,false,null,null,1024,Payload.Disposition.valueOf(disposition));}
    private static Saved publish(DefinitionRepository repository,String key,Detail detail){
        try {var saved=repository.draft(new Draft(null,key,key,null,"synthetic fixture",detail),"fixture");return repository.apply(repository.validate(saved.object().id(),saved.version().id()),"fixture","synthetic fixture");}
        catch(RuntimeException failure){throw new IllegalStateException("Synthetic definition failed: "+key,failure);}
    }
    private static void object(SecurityFixture.FixtureMapper mapper,String id,String kind){
        mapper.execute("INSERT INTO config_object(id,kind,logical_key,created_at,created_by) VALUES('"+id+"','"+kind+"','"+id+"',1,'fixture')");
        mapper.execute("INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name) VALUES('"+id+"-v1','"+id+"','"+kind+"',1,1,'fixture','synthetic','Synthetic')");
    }
    private static void activate(SecurityFixture.FixtureMapper mapper,String id){
        mapper.execute("UPDATE config_object SET current_version_id='"+id+"-v1',revision_counter=1,generation=1 WHERE id='"+id+"'");
    }
    @Override public void close(){server.close();source.stop(0);sourceExecutor.close();}
    public static void main(String[] args)throws Exception {
        Path directory=Files.createTempDirectory("gateway-synthetic-");
        var fixture=new GatewayFixture(directory,args.length==0?18080:Integer.parseInt(args[0]),Arrays.asList(args).contains("--references"));
        Runtime.getRuntime().addShutdownHook(new Thread(fixture::close));
        System.out.println("SYNTHETIC_GATEWAY_READY "+fixture.server.getURI()+" database="+directory);
        new java.util.concurrent.CountDownLatch(1).await();
    }
}
