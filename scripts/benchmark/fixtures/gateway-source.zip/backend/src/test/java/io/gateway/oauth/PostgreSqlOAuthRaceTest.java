package io.gateway.oauth;

import io.gateway.authorization.AccessDenied;
import io.gateway.persistence.PlatformStore;
import java.nio.file.Path;
import java.util.Map;
import java.util.concurrent.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

/** Requires an explicitly provisioned empty, disposable PostgreSQL database on its primary. */
@EnabledIfEnvironmentVariable(named="GATEWAY_TEST_POSTGRES_URL",matches=".+")
class PostgreSqlOAuthRaceTest {
    @TempDir Path directory;
    @Test void independentWritersCodeRefreshReplayRollbackAndRevokeVisibility() throws Exception {
        String url=System.getenv("GATEWAY_TEST_POSTGRES_URL"),user=System.getenv().getOrDefault("GATEWAY_TEST_POSTGRES_USER",""),password=System.getenv().getOrDefault("GATEWAY_TEST_POSTGRES_PASSWORD","");
        try(var first=new SecurityFixture(new PlatformStore(url,user,password,4,5000),directory,true);var second=new SecurityFixture(new PlatformStore(url,user,password,4,5000),directory,false)){
            var code=first.code("A");Object[] issued=race(first,second,()->first.exchange(code),()->second.exchange(code));
            assertEquals(1,first.count("SELECT COUNT(*) FROM oauth_access_token"));
            @SuppressWarnings("unchecked") Map<String,Object> token=(Map<String,Object>)(issued[0] instanceof Map?issued[0]:issued[1]);String refresh=(String)token.get("refresh_token");
            race(first,second,()->first.refresh(refresh),()->second.refresh(refresh));
            assertEquals(1,first.count("SELECT COUNT(*) FROM oauth_refresh_token WHERE predecessor_id IS NOT NULL"));assertEquals(0,first.count("SELECT COUNT(*) FROM oauth_access_token WHERE revoked_at IS NULL"));assertThrows(AccessDenied.class,()->first.authenticate(token));
            first.sql("CREATE FUNCTION reject_oauth_audit() RETURNS trigger LANGUAGE plpgsql AS 'BEGIN IF NEW.event_type = ''TOKEN_ISSUED'' THEN RAISE EXCEPTION ''synthetic failure''; END IF; RETURN NEW; END'");first.sql("CREATE TRIGGER reject_oauth_audit BEFORE INSERT ON audit_event FOR EACH ROW EXECUTE FUNCTION reject_oauth_audit()");
            var failedCode=first.code("A");long accessBefore=first.count("SELECT COUNT(*) FROM oauth_access_token");assertThrows(PlatformStore.StoreException.class,()->first.exchange(failedCode));assertEquals(accessBefore,first.count("SELECT COUNT(*) FROM oauth_access_token"));assertEquals(0,first.count("SELECT COUNT(*) FROM oauth_authorization_code WHERE code_digest='"+Secrets.digest(failedCode.value())+"' AND consumed_at IS NOT NULL"));first.sql("DROP TRIGGER reject_oauth_audit ON audit_event");first.sql("DROP FUNCTION reject_oauth_audit()");
            var current=first.exchange(failedCode);var principal=first.authenticate(current);CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);first.authority.beforeDecision=()->{entered.countDown();try{if(!release.await(10,TimeUnit.SECONDS))throw new AssertionError("revoke barrier timeout");}catch(InterruptedException e){Thread.currentThread().interrupt();throw new AssertionError(e);}};
            try(var executor=Executors.newVirtualThreadPerTaskExecutor()){
                var authorization=executor.submit(()->assertThrows(AccessDenied.class,()->first.authorization.authorize(principal,"clinical.lab.read",SecurityFixture.patient("A"))));assertTrue(entered.await(10,TimeUnit.SECONDS));second.oauth.revokeGrant(principal.grantId(),"fixture");release.countDown();authorization.get(10,TimeUnit.SECONDS);assertThrows(AccessDenied.class,()->second.authenticate(current));
                first.authority.beforeDecision=()->{};
            }
            OAuthSecurityTest.assertAncestorReplayAndRevoke(first,second);
            io.gateway.management.ManagementMutationTest.assertRevokedManagementWrite(first,second);
        }
    }
    private static Object[] race(SecurityFixture first,SecurityFixture second,Callable<?> a,Callable<?> b)throws Exception{
        CyclicBarrier barrier=new CyclicBarrier(2);Runnable wait=()->{try{barrier.await(10,TimeUnit.SECONDS);}catch(Exception e){throw new AssertionError(e);}};first.authority.beforeDecision=wait;second.authority.beforeDecision=wait;
        try(var executor=Executors.newVirtualThreadPerTaskExecutor()){
            Future<Object> left=executor.submit(()->invoke(a)),right=executor.submit(()->invoke(b));Object[] results={left.get(15,TimeUnit.SECONDS),right.get(15,TimeUnit.SECONDS)};assertEquals(1,(results[0] instanceof Map?1:0)+(results[1] instanceof Map?1:0));assertEquals(1,(results[0] instanceof OAuthProtocol.Failure?1:0)+(results[1] instanceof OAuthProtocol.Failure?1:0));return results;
        }finally{first.authority.beforeDecision=()->{};second.authority.beforeDecision=()->{};}
    }
    private static Object invoke(Callable<?> action)throws Exception{try{return action.call();}catch(OAuthProtocol.Failure failure){return failure;}}
}
