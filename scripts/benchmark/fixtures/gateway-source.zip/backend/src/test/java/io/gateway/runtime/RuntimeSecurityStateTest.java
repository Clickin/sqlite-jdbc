package io.gateway.runtime;

import io.gateway.authorization.AccessDenied;
import io.gateway.credentials.CredentialService;
import io.gateway.definitions.DefinitionRepository;
import io.gateway.definitions.Definitions.*;
import io.gateway.oauth.*;
import io.gateway.persistence.*;
import io.micronaut.context.ApplicationContext;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermissions;
import java.time.Instant;
import java.util.*;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class RuntimeSecurityStateTest {
    @TempDir Path directory;
    @Test void oauthIssuanceRefreshAndRevocationDoNotChangeConfigurationOrLiveDatasource() throws Exception {
        try (var context = context()) {
            var store = context.getBean(PlatformStore.class);
            var security = new SecurityFixture(store, directory, true);
            var repository = context.getBean(DefinitionRepository.class);
            var runtime = memoryWorkflow(repository, null);
            var registry = context.getBean(RuntimeRegistry.class);
            var graph = repository.resolve(runtime.workflow().object().id());
            try (var lease = registry.acquire(graph)) {
                initialize(registry, repository, runtime);
                assertEquals(Map.of("answer", "still-live"), execute(lease.get(), runtime.read()).value());
                var config = configurationRows(store);
                var code = security.code("A");
                assertEquals(config, configurationRows(store));
                var token = security.exchange(code);
                var rotated = security.refresh((String) token.get("refresh_token"));
                var principal = security.authenticate(rotated);
                security.oauth.revokeGrant(principal.grantId(), "fixture");
                assertThrows(AccessDenied.class, () -> security.authenticate(rotated));
                assertEquals(config, configurationRows(store));
                var current = repository.resolve(runtime.workflow().object().id());
                assertEquals(graph.key(), current.key());
                try (var again = registry.acquire(current)) {
                    assertSame(lease.get(), again.get());
                    assertEquals(Map.of("answer", "still-live"), execute(again.get(), runtime.read()).value());
                }
            }
        }
    }

    @Test void reencryptKeepsLivePoolButSecretReplacementAndRollbackRespectCurrentRevocation() throws Exception {
        key("first"); key("second");
        try (var context = context()) {
            var repository = context.getBean(DefinitionRepository.class);
            var registry = context.getBean(RuntimeRegistry.class);
            var credentials = context.getBean(CredentialService.class);
            var first = credentials.create("outbound", "PASSWORD", "fixture", "first-secret".getBytes(StandardCharsets.UTF_8), "fixture", "initial");
            var runtime = memoryWorkflow(repository, first.objectId());
            var before = repository.resolve(runtime.workflow().object().id());
            try (var old = registry.acquire(before)) {
                initialize(registry, repository, runtime);
                assertEquals(Map.of("answer", "still-live"), execute(old.get(), runtime.read()).value());
                var config = configurationRows(context.getBean(PlatformStore.class));
                credentials.reencrypt(first.versionId(), "second", "fixture");
                assertEquals(config, configurationRows(context.getBean(PlatformStore.class)));
                var rotated = repository.resolve(runtime.workflow().object().id());
                assertEquals(before.key(), rotated.key());
                assertEquals("second", credentials.metadata(first.objectId()).keyId());
                try (var same = registry.acquire(rotated)) {
                    assertSame(old.get(), same.get());
                    assertEquals(Map.of("answer", "still-live"), execute(same.get(), runtime.read()).value());
                }
                var second = credentials.replace(first.objectId(), first.generation(), "PASSWORD", "fixture", "second-secret".getBytes(StandardCharsets.UTF_8), "fixture", "replace");
                var replaced = repository.resolve(runtime.workflow().object().id());
                assertEquals(second.versionId(), replaced.version(first.objectId()));
                assertEquals(runtime.workflow().version().id(), replaced.version(runtime.workflow().object().id()));
                try (var fresh = registry.acquire(replaced)) {
                    assertNotSame(old.get(), fresh.get());
                    assertEquals("JDBC_EXECUTION_FAILED", assertThrows(ExecutionFailure.class, () -> execute(fresh.get(), runtime.read())).code());
                    initialize(registry, repository, runtime);
                    assertEquals(Map.of("answer", "still-live"), execute(fresh.get(), runtime.read()).value());
                    assertEquals(Map.of("answer", "still-live"), execute(old.get(), runtime.read()).value());
                    var draft = repository.draft(new Draft(runtime.workflow().object().id(), "memory-workflow", "changed workflow", null, "fixture", runtime.workflow().detail()), "fixture");
                    var changed = repository.apply(repository.validate(draft.object().id(), draft.version().id()), "fixture", "fixture");
                    credentials.revoke(first.versionId(), "fixture");
                    repository.rollback(changed.object().id(), runtime.workflow().version().id(), changed.object().generation(), "fixture", "rollback");
                    var rolledBack = repository.resolve(runtime.workflow().object().id());
                    assertEquals(runtime.workflow().version().id(), rolledBack.version(runtime.workflow().object().id()));
                    assertEquals(second.versionId(), rolledBack.version(first.objectId()));
                    try (var current = registry.acquire(rolledBack)) {
                        assertEquals(Map.of("answer", "still-live"), execute(current.get(), runtime.read()).value());
                    }
                    assertEquals(ExecutionFailure.Outcome.FAILED_BEFORE_EFFECT, assertThrows(ExecutionFailure.class, () -> execute(old.get(), runtime.read())).outcome());
                    credentials.revoke(second.versionId(), "fixture");
                    assertEquals("CREDENTIAL_REVOKED", assertThrows(IllegalStateException.class, () -> repository.resolve(runtime.workflow().object().id())).getMessage());
                    assertEquals(ExecutionFailure.Outcome.FAILED_BEFORE_EFFECT, assertThrows(ExecutionFailure.class, () -> execute(fresh.get(), runtime.read())).outcome());
                }
            }
        }
    }

    private ApplicationContext context() {
        return ApplicationContext.run(Map.of("micronaut.server.enabled", false,
                "gateway.database.url", "jdbc:sqlite:" + directory.resolve("platform.db"),
                "gateway.credentials.key-directory", directory.toString(), "gateway.credentials.active-key-id", "first"));
    }
    private record MemoryWorkflow(Saved workflow, Saved read, Saved create, Saved seed) {}
    private static MemoryWorkflow memoryWorkflow(DefinitionRepository repository, String credential) {
        var input = publish(repository, "memory-input", new Contract("VALUE", List.of()));
        var output = publish(repository, "memory-output", new Contract("VALUE", List.of(new Field("answer", "answer", null, "answer", "SCALAR", "STRING", 0, true, false, null, null, 128, Payload.Disposition.PERSIST))));
        var count = publish(repository, "memory-count", new Contract("VALUE", List.of(new Field("count", "count", null, "count", "SCALAR", "INTEGER", 0, true, false, null, null, null, Payload.Disposition.PERSIST))));
        var source = publish(repository, "memory-source", new JdbcSource("jdbc:sqlite::memory:", "SQLITE", credential, 0, 1, 5000, false, 4, 5000));
        String xml = "<!DOCTYPE mapper PUBLIC \"-//mybatis.org//DTD Mapper 3.0//EN\" \"https://mybatis.org/dtd/mybatis-3-mapper.dtd\"><mapper namespace=\"memory\"><select id=\"read\" resultType=\"map\">SELECT value AS answer FROM fixture</select><update id=\"create\">CREATE TABLE fixture(value TEXT NOT NULL)</update><insert id=\"seed\">INSERT INTO fixture VALUES('still-live')</insert></mapper>";
        var mapper = publish(repository, "memory-mapper", new Mapper("SQLITE", List.of(new MapperDocument("memory.xml", xml)), List.of()));
        var read = publish(repository, "memory-read", new JdbcOperation(source.object().id(), input.object().id(), output.object().id(), Effect.READ_ONLY, 5000, 10, 4096L, mapper.object().id(), "memory.read", "SELECT_ONE", "READ_ONLY", List.of(), List.of()));
        var create = publish(repository, "memory-create", new JdbcOperation(source.object().id(), input.object().id(), count.object().id(), Effect.WRITE, 5000, 10, 4096L, mapper.object().id(), "memory.create", "EXECUTE", "LOCAL_WRITE", List.of(), List.of()));
        var seed = publish(repository, "memory-seed", new JdbcOperation(source.object().id(), input.object().id(), count.object().id(), Effect.WRITE, 5000, 10, 4096L, mapper.object().id(), "memory.seed", "EXECUTE", "LOCAL_WRITE", List.of(), List.of()));
        var workflow = publish(repository, "memory-workflow", new Workflow(null, List.of(new Stage("INPUT", 0, read.object().id(), null)), List.of(), List.of()));
        return new MemoryWorkflow(workflow, read, create, seed);
    }
    private static Saved publish(DefinitionRepository repository, String key, Detail detail) {
        var saved = repository.draft(new Draft(null, key, key, null, "fixture", detail), "fixture");
        return repository.apply(repository.validate(saved.object().id(), saved.version().id()), "fixture", "fixture");
    }
    private static void initialize(RuntimeRegistry registry, DefinitionRepository repository, MemoryWorkflow fixture) {
        for (var operation : List.of(fixture.create(), fixture.seed()))
            try (var lease = registry.acquire(repository.resolve(operation.object().id()))) { execute(lease.get(), operation); }
    }
    private static Payload execute(RuntimeGraph runtime, Saved operation) {
        return runtime.execute(operation.object().id(), Payload.of(Map.of()), new Cancellation(Instant.now().plusSeconds(10)));
    }
    private void key(String id) throws Exception {
        byte[] value = new byte[32]; new java.security.SecureRandom().nextBytes(value);
        Path file = directory.resolve(id + ".key"); Files.write(file, value);
        Files.setPosixFilePermissions(file, PosixFilePermissions.fromString("r--------"));
    }
    private static Map<String,List<Map<String,Object>>> configurationRows(PlatformStore store) {
        var snapshot = new LinkedHashMap<String,List<Map<String,Object>>>();
        for (String table : List.of("config_object", "config_version", "configuration_change"))
            snapshot.put(table, rows(store, "SELECT * FROM " + table + " ORDER BY id"));
        return snapshot;
    }

    private static List<Map<String,Object>> rows(PlatformStore store, String sql) {
        return store.read(s -> s.getMapper(Fixture.class).rows(sql));
    }
    public interface Fixture extends PlatformMapper {
        @Select("${sql}") List<Map<String,Object>> rows(@Param("sql") String sql);
    }
}
