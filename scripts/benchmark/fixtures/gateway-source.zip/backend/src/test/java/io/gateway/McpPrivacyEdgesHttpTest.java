package io.gateway;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.ThrowableProxyUtil;
import ch.qos.logback.core.read.ListAppender;
import io.gateway.credentials.CredentialService;
import io.gateway.definitions.DefinitionRepository;
import io.gateway.definitions.Definitions.*;
import io.gateway.mcp.Mcp2026Adapter;
import io.gateway.oauth.*;
import io.gateway.runtime.Payload;
import io.modelcontextprotocol.json.schema.JsonSchemaValidatorSupplier;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.slf4j.LoggerFactory;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermission;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import static org.junit.jupiter.api.Assertions.*;

@SuppressWarnings("unchecked")
class McpPrivacyEdgesHttpTest {
    @TempDir Path directory;
    private static final Map<String,Object> ARGUMENTS=Map.of("patientId","A","documentId","DA");

    @Test void caseInsensitiveHeaderNamesAndSingleBase64DecodeCannotSelectAnotherTool() throws Exception {
        try(var fixture=new GatewayFixture(directory,-1);var http=new GatewayHttpClient(fixture.server.getURI())) {
            String token=http.authorize(SecurityFixture.RESOURCE,"A",List.of("clinical.lab.read"));
            String body=http.json.writeValueAsString(body("tools/call",Map.of("name","lab-tool","arguments",ARGUMENTS)));
            var mixed=new LinkedHashMap<String,String>();
            headers(token,"tools/call","lab-tool").forEach((key,value)->mixed.put(key.toLowerCase(Locale.ROOT),value));
            assertEquals("SUCCEEDED",structured(http,http.send("/mcp","POST",body,mixed)).get("status"));
            var encoded=headers(token,"tools/call",encoded("lab-tool"));
            assertEquals("SUCCEEDED",structured(http,http.send("/mcp","POST",body,encoded)).get("status"));
            for(String invalid:List.of("=?base64?%%%?=","=?base64?/w==?=",encoded(encoded("lab-tool")),"=?BASE64?bGFiLXRvb2w=?=",encoded("lab-tool\u0000"),encoded("different-tool"))) {
                var rejected=http.send("/mcp","POST",body,headers(token,"tools/call",invalid));
                assertEquals(400,rejected.statusCode());
                assertEquals(-32020,((Number)((Map<String,Object>)http.object(rejected).get("error")).get("code")).intValue());
            }
            var duplicate=headers(token,"tools/call","lab-tool");duplicate.put("mcp-name","lab-tool");
            assertEquals(400,http.send("/mcp","POST",body,duplicate).statusCode());
            assertEquals(2,fixture.sourceCalls.get(),"Rejected encodings and duplicate mixed-case headers must never dispatch");
        }
    }

    @Test void completeLargeCatalogueIsSortedFilteredAndRejectsCursorsAcrossGenerationChanges() throws Exception {
        try(var fixture=new GatewayFixture(directory,-1);var http=new GatewayHttpClient(fixture.server.getURI())) {
            var expected=new ArrayList<String>();expected.add("lab-tool");
            fixture.store.write(session->{
                var mapper=session.getMapper(SecurityFixture.FixtureMapper.class);
                for(int i=104;i>=0;i--) {
                    String name="catalogue-"+String.format(Locale.ROOT,"%03d",i);expected.add(name);
                    cloneTool(mapper,name,"clinical.lab.read","read",fixture.workflow.object().id(),fixture.output.version().id());
                }
                cloneTool(mapper,"hidden-write-tool","clinical.order.write","read",fixture.workflow.object().id(),fixture.output.version().id());return null;
            });
            expected.sort(String::compareTo);
            String token=http.authorize(SecurityFixture.RESOURCE,"A",List.of("clinical.lab.read"));
            String hidden=http.authorize(SecurityFixture.RESOURCE,"A",List.of("result.read"),"no-refresh");
            for(int i=0;i<2;i++)assertEquals(expected,names(http,rpc(http,token,"tools/list",Map.of())));
            assertEquals(List.of(),names(http,rpc(http,hidden,"tools/list",Map.of())));
            assertEquals(400,rpc(http,token,"tools/list",Map.of("cursor","old-generation:100")).statusCode());
            fixture.store.write(session->{var mapper=session.getMapper(SecurityFixture.FixtureMapper.class);
                mapper.execute("UPDATE config_object SET enabled=false,generation=generation+1 WHERE id='catalogue-000'");
                cloneTool(mapper,"catalogue-new","clinical.lab.read","read",fixture.workflow.object().id(),fixture.output.version().id());return null;});
            expected.remove("catalogue-000");expected.add("catalogue-new");expected.sort(String::compareTo);
            assertEquals(expected,names(http,rpc(http,token,"tools/list",Map.of())));
            assertEquals(400,rpc(http,token,"tools/list",Map.of("cursor","old-generation:100")).statusCode());
            assertEquals(List.of(),names(http,rpc(http,hidden,"tools/list",Map.of())));
            assertEquals(403,rpc(http,token,"tools/call",Map.of("name","hidden-write-tool","arguments",ARGUMENTS)).statusCode());
            assertEquals(0,fixture.sourceCalls.get());
        }
    }

    @Test void advertisedOutputSchemaValidatesSuccessSdkInputErrorAndRemoteBusinessError() throws Exception {
        try(var fixture=new GatewayFixture(directory,-1);var http=new GatewayHttpClient(fixture.server.getURI())) {
            String token=http.authorize(SecurityFixture.RESOURCE,"A",List.of("clinical.lab.read"));
            var list=result(http,rpc(http,token,"tools/list",Map.of()));
            var descriptor=((List<Map<String,Object>>)list.get("tools")).getFirst();
            var schema=(Map<String,Object>)descriptor.get("outputSchema");
            var validator=ServiceLoader.load(JsonSchemaValidatorSupplier.class).findFirst().orElseThrow().get();
            assertTrue(validator.validateSchema(schema).valid());
            var success=result(http,http.call(token,ARGUMENTS));
            assertEquals(false,success.get("isError"));assertEquals("complete",success.get("resultType"));
            var valid=validator.validate(schema,success.get("structuredContent"));assertTrue(valid.valid(),valid.errorMessage());
            assertEquals(GatewayFixture.RECORD_TEXT,((Map<String,Object>)((Map<String,Object>)success.get("structuredContent")).get("data")).get("recordText"));
            var invalid=result(http,http.call(token,Map.of("patientId","A","documentId","DA","unknown","PRIVATE_SDK_INPUT_SENTINEL")));
            assertEquals(true,invalid.get("isError"));assertEquals("complete",invalid.get("resultType"));
            var invalidSchema=validator.validate(schema,invalid.get("structuredContent"));assertTrue(invalidSchema.valid(),invalidSchema.errorMessage());
            assertEquals("NOT_EXECUTED",((Map<String,Object>)invalid.get("structuredContent")).get("businessOutcome"));
            fixture.source.removeContext("/labs");
            fixture.source.createContext("/labs",exchange->{fixture.sourceCalls.incrementAndGet();exchange.sendResponseHeaders(503,-1);exchange.close();});
            var failed=result(http,http.call(token,ARGUMENTS));
            assertEquals(true,failed.get("isError"));assertEquals("complete",failed.get("resultType"));
            var failedSchema=validator.validate(schema,failed.get("structuredContent"));assertTrue(failedSchema.valid(),failedSchema.errorMessage());
            assertEquals("FAILED",((Map<String,Object>)failed.get("structuredContent")).get("businessOutcome"));
            assertEquals(2,fixture.sourceCalls.get());
        }
    }

    @Test void authenticationScopePatientDenialAndAuthorityOutageHaveDistinctChallenges() throws Exception {
        try(var fixture=new GatewayFixture(directory,-1);var http=new GatewayHttpClient(fixture.server.getURI())) {
            String token=http.authorize(SecurityFixture.RESOURCE,"A",List.of("clinical.lab.read"));
            var unauthenticated=http.call("invalid-access-token",ARGUMENTS);
            assertEquals(401,unauthenticated.statusCode());
            assertEquals("Bearer resource_metadata=\""+SecurityFixture.ISSUER+"/.well-known/oauth-protected-resource/mcp\"",unauthenticated.headers().firstValue("www-authenticate").orElseThrow());
            fixture.store.write(session->{cloneTool(session.getMapper(SecurityFixture.FixtureMapper.class),"write-scope-tool","clinical.lab.read","write",fixture.workflow.object().id(),fixture.output.version().id());return null;});
            var authority=fixture.server.getApplicationContext().getBean(SyntheticAuthority.class);
            int beforeScope=authority.decisions.get();
            var scope=rpc(http,token,"tools/call",Map.of("name","write-scope-tool","arguments",ARGUMENTS));assertEquals(403,scope.statusCode());
            assertEquals("insufficient_scope",http.object(scope).get("error"));
            assertEquals("Bearer error=\"insufficient_scope\"",scope.headers().firstValue("www-authenticate").orElseThrow());
            assertEquals(beforeScope,authority.decisions.get(),"Missing OAuth scope must be rejected before authority I/O");
            var patient=http.call(token,Map.of("patientId","B","documentId","DB"));
            assertEquals(403,patient.statusCode());assertTrue(patient.headers().firstValue("www-authenticate").isEmpty());
            for(String outcome:List.of("DENY","PENDING","UNAVAILABLE")) {
                authority.outcome=outcome;int before=authority.decisions.get();
                var response=http.call(token,ARGUMENTS);
                assertEquals(outcome.equals("UNAVAILABLE")?503:403,response.statusCode());
                assertTrue(response.headers().firstValue("www-authenticate").isEmpty(),"Patient decisions must not request broader OAuth scope");
                assertNotEquals("insufficient_scope",http.object(response).get("error"));
                assertEquals(before+1,authority.decisions.get(),"No authority retry or polling");
            }
            assertEquals(0,fixture.sourceCalls.get());
        }
    }

    @Test void refreshAndLostRefreshResponseNeverReplayBusinessAndDuplicateRpcIdIsNotExactlyOnce() throws Exception {
        try(var fixture=new GatewayFixture(directory,-1);var http=new GatewayHttpClient(fixture.server.getURI())) {
            String token=http.authorize(SecurityFixture.RESOURCE,"A",List.of("clinical.lab.read"));
            String refresh=http.rawSecrets.getLast();assertNotNull(refresh);
            assertEquals("SUCCEEDED",structured(http,http.call(token,ARGUMENTS)).get("status"));
            var form=Map.of("grant_type","refresh_token","client_id","public","refresh_token",refresh,"resource",SecurityFixture.RESOURCE);
            var rotated=http.send("/oauth/token","POST",SecurityFixture.form(form),Map.of("Content-Type","application/x-www-form-urlencoded"));
            assertEquals(200,rotated.statusCode());
            String next=(String)http.object(rotated).get("access_token");
            assertEquals(1,fixture.sourceCalls.get(),"Refresh alone cannot replay a tool call");
            assertEquals("SUCCEEDED",structured(http,http.call(next,ARGUMENTS)).get("status"));
            assertEquals(2,fixture.sourceCalls.get(),"An explicit new request with the same RPC ID is not deduplicated");
            var lost=http.send("/oauth/token","POST",SecurityFixture.form(form),Map.of("Content-Type","application/x-www-form-urlencoded"));
            assertEquals(400,lost.statusCode());assertEquals("invalid_grant",http.object(lost).get("error"));
            assertEquals(401,http.call(next,ARGUMENTS).statusCode());
            assertEquals(2,fixture.sourceCalls.get(),"Consumed refresh retry revokes the family, without replaying business I/O");
        }
    }

    @Test void dedicatedOutboundCredentialAndSdkXmlErrorPathsNeverPersistOrLogPrivateValues() throws Exception {
        Path key=directory.resolve("active.key");
        Files.write(key,new byte[32]);Files.setPosixFilePermissions(key,Set.of(PosixFilePermission.OWNER_READ));
        var logger=(Logger)LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        var capture=new ListAppender<ILoggingEvent>();capture.start();logger.addAppender(capture);
        String dedicated="DEDICATED_OUTBOUND_BEARER_SENTINEL",xmlSecret="PRIVATE_XML_ERROR_SENTINEL";
        var secrets=new ArrayList<>(List.of(dedicated,xmlSecret,GatewayFixture.RECORD_TEXT,SecurityFixture.VERIFIER,"synthetic-state-sentinel","PRIVATE_SDK_INPUT_SENTINEL"));
        try(var fixture=new GatewayFixture(directory,-1,false,Map.of("gateway.credentials.key-directory",directory.toString(),"gateway.credentials.active-key-id","active"),"test");var http=new GatewayHttpClient(fixture.server.getURI())) {
            LoggerFactory.getLogger("gateway.acceptance").warn("SAFE_PRIVACY_CAPTURE_CANARY");
            var outbound=new AtomicReference<String>();var xmlBody=new AtomicReference<String>();
            fixture.source.createContext("/dedicated/labs",exchange->{
                fixture.sourceCalls.incrementAndGet();outbound.set(exchange.getRequestHeaders().getFirst("Authorization"));
                String xml=xmlBody.get();byte[] bytes=(xml==null?"{\"answer\":\"normal\",\"recordText\":\""+GatewayFixture.RECORD_TEXT+"\"}":xml).getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type",xml==null?"application/json":"application/xml");
                exchange.sendResponseHeaders(200,bytes.length);try(var body=exchange.getResponseBody()){body.write(bytes);}
            });
            var context=fixture.server.getApplicationContext();var repository=context.getBean(DefinitionRepository.class);
            byte[] raw=dedicated.getBytes(StandardCharsets.UTF_8);CredentialService.Metadata credential;
            try {credential=context.getBean(CredentialService.class).create("dedicated-outbound","TOKEN",null,raw,"fixture","privacy proof");} finally {Arrays.fill(raw,(byte)0);}
            var old=(HttpSource)fixture.datasource.detail();
            var source=repository.draft(new Draft(fixture.datasource.object().id(),fixture.datasource.object().logicalKey(),"Dedicated source",null,"dedicated credential",
                    new HttpSource(old.baseUri()+"/dedicated","BEARER",credential.objectId(),null,null,null,4,4,2000,"NEVER",4,1000,List.of())),"fixture");
            repository.apply(repository.validate(source.object().id(),source.version().id()),"fixture","privacy proof");
            String token=http.authorize(SecurityFixture.RESOURCE,"A",List.of("clinical.lab.read"));
            var ok=http.call(token,ARGUMENTS);assertEquals("SUCCEEDED",structured(http,ok).get("status"));
            assertEquals("Bearer "+dedicated,outbound.get());assertNotEquals("Bearer "+token,outbound.get());
            assertTrue(ok.body().contains(GatewayFixture.RECORD_TEXT));
            for(var content:(List<Map<String,Object>>)result(http,ok).get("content"))
                assertFalse(http.json.writeValueAsString(content).contains(GatewayFixture.RECORD_TEXT),"Text content must not duplicate the recoverable body");
            var spoof=new LinkedHashMap<>(ARGUMENTS);spoof.put("authorization","Bearer "+token);
            assertEquals(true,result(http,http.call(token,spoof)).get("isError"));assertEquals(1,fixture.sourceCalls.get());
            var invalid=new LinkedHashMap<>(ARGUMENTS);invalid.put("unknown","PRIVATE_SDK_INPUT_SENTINEL");
            assertEquals(true,result(http,http.call(token,invalid)).get("isError"));
            var authority=context.getBean(SyntheticAuthority.class);
            authority.beforeActionDecision=action->{throw new IllegalStateException("token="+token+" password="+dedicated+" state=synthetic-state-sentinel");};
            var exception=http.call(token,ARGUMENTS);
            authority.beforeActionDecision=action->{};
            assertTrue(exception.statusCode()>=400,exception.body());
            for(String privateValue:List.of(token,dedicated,"synthetic-state-sentinel"))assertFalse(exception.body().contains(privateValue));
            assertEquals(1,fixture.sourceCalls.get(),"SDK exception handling must not execute or replay the business source");

            var output=publish(repository,"xml-output",new Contract("VALUE",List.of(
                    new Field("xml-root","reply",null,"reply","OBJECT",null,0,true,false,null,null,null,Payload.Disposition.PERSIST),
                    new Field("xml-body","recordText","xml-root","recordText","SCALAR","STRING",0,true,false,null,null,1024,Payload.Disposition.OMIT_RECOVERABLE))));
            var representation=publish(repository,"xml-representation",new Representation(output.object().id(),"xml","DEFAULT","application/xml","UTF-8",List.of(),List.of(
                    new XmlBinding("xml-root","urn:synthetic","reply","ELEMENT",0,"ERROR"),new XmlBinding("xml-body","urn:synthetic","text","ELEMENT",0,"ERROR"))));
            var operation=publish(repository,"xml-operation",new HttpOperation(fixture.datasource.object().id(),fixture.input.object().id(),output.object().id(),Effect.READ_ONLY,3000,10,4096L,"GET","labs",null,representation.object().id(),List.of(),List.of(new ExpectedStatus(200,"SUCCEEDED")),List.of()));
            var workflow=publish(repository,"xml-workflow",new Workflow(null,List.of(new Stage("INPUT",0,operation.object().id(),null)),List.of(),List.of(new SecurityBinding("INPUT","security","clinical.lab.read","document-policy"))));
            fixture.store.write(session->{cloneTool(session.getMapper(SecurityFixture.FixtureMapper.class),"xml-tool","clinical.lab.read","read",workflow.object().id(),output.version().id());return null;});
            var externalFetches=new java.util.concurrent.atomic.AtomicInteger();
            fixture.source.createContext("/entity",exchange->{externalFetches.incrementAndGet();exchange.sendResponseHeaders(200,-1);exchange.close();});
            for(String xml:List.of("<reply xmlns=\"urn:wrong\"><text>"+xmlSecret+"</text></reply>",
                    "<reply xmlns=\"urn:synthetic\"><text>"+xmlSecret+"</reply>",
                    "<!DOCTYPE reply [<!ENTITY external SYSTEM \""+old.baseUri()+"/entity\">]><reply xmlns=\"urn:synthetic\"><text>&external;"+xmlSecret+"</text></reply>",
                    "<reply xmlns=\"urn:synthetic\"><text>"+xmlSecret.repeat(400)+"</text></reply>")) {
                xmlBody.set(xml);var failed=rpc(http,token,"tools/call",Map.of("name","xml-tool","arguments",ARGUMENTS));
                assertEquals(true,result(http,failed).get("isError"));assertFalse(failed.body().contains(xmlSecret));
                var outcome=structured(http,failed);
                assertEquals("SUCCEEDED",outcome.get("businessOutcome"),"Confirmed HTTP success must not be rewritten as an unexecuted or failed business request");
                assertEquals("RESPONSE_FAILED",outcome.get("status"));assertEquals("FAILED",outcome.get("responseOutcome"));
            }
            assertEquals(0,externalFetches.get());assertEquals(5,fixture.sourceCalls.get());
            secrets.addAll(http.rawSecrets.stream().filter(Objects::nonNull).toList());
            String logs=String.join("\n",capture.list.stream().map(event->event.getFormattedMessage()+"\n"+(event.getThrowableProxy()==null?"":ThrowableProxyUtil.asString(event.getThrowableProxy()))).toList());
            assertTrue(logs.contains("SAFE_PRIVACY_CAPTURE_CANARY"));
            for(String secret:secrets)assertFalse(logs.contains(secret),"Sensitive value reached application or SDK log/throwable");
            assertEquals(0,fixture.store.read(s->s.getMapper(SecurityFixture.FixtureMapper.class).count("SELECT count(*) FROM generated_result")).longValue());
            assertDatabaseFilesExclude(directory,secrets);
        } finally {logger.detachAppender(capture);capture.stop();}
        assertDatabaseFilesExclude(directory,secrets);
    }

    private static String encoded(String value){return "=?base64?"+Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8))+"?=";}
    private static Map<String,Object> body(String method,Map<String,Object> parameters){var params=new LinkedHashMap<>(parameters);params.put("_meta",Map.of(Mcp2026Adapter.PROTOCOL,Mcp2026Adapter.VERSION,Mcp2026Adapter.CAPABILITIES,Map.of()));return Map.of("jsonrpc","2.0","id",1,"method",method,"params",params);}
    private static Map<String,String> headers(String token,String method,String name){var headers=new LinkedHashMap<>(Map.of("Authorization","Bearer "+token,"Content-Type","application/json","Accept","application/json, text/event-stream","MCP-Protocol-Version",Mcp2026Adapter.VERSION,"Mcp-Method",method));if(name!=null)headers.put("Mcp-Name",name);return headers;}
    private static HttpResponse<String> rpc(GatewayHttpClient http,String token,String method,Map<String,Object> params)throws Exception{return http.send("/mcp","POST",http.json.writeValueAsString(body(method,params)),headers(token,method,(String)params.get("name")));}
    private static Map<String,Object> result(GatewayHttpClient http,HttpResponse<String> response){assertEquals(200,response.statusCode(),response.body());return (Map<String,Object>)http.object(response).get("result");}
    private static Map<String,Object> structured(GatewayHttpClient http,HttpResponse<String> response){return (Map<String,Object>)result(http,response).get("structuredContent");}
    private static List<String> names(GatewayHttpClient http,HttpResponse<String> response){var result=result(http,response);assertFalse(result.containsKey("nextCursor"));return ((List<Map<String,Object>>)result.get("tools")).stream().map(tool->(String)tool.get("name")).toList();}
    private static Saved publish(DefinitionRepository repository,String key,Detail detail){var draft=repository.draft(new Draft(null,key,key,null,"edge fixture",detail),"fixture");return repository.apply(repository.validate(draft.object().id(),draft.version().id()),"fixture","edge fixture");}
    private static void cloneTool(SecurityFixture.FixtureMapper m,String name,String action,String scope,String workflow,String output){
        m.execute("INSERT INTO config_object(id,kind,logical_key,created_at,created_by) VALUES('"+name+"','MCP_TOOL','"+name+"',1,'fixture')");
        m.execute("INSERT INTO config_version(id,object_id,kind,revision,created_at,created_by,change_reason,display_name) VALUES('"+name+"-v1','"+name+"','MCP_TOOL',1,1,'fixture','fixture','Synthetic')");
        m.execute("INSERT INTO mcp_tool_version(version_id,public_name,description,workflow_object_id,public_input_contract_version_id,public_output_contract_version_id,security_binding_object_id,target_policy_object_id,effect_kind) SELECT '"+name+"-v1','"+name+"',description,'"+workflow+"',public_input_contract_version_id,'"+output+"',security_binding_object_id,target_policy_object_id,effect_kind FROM mcp_tool_version WHERE version_id='lab-tool-v1'");
        m.execute("INSERT INTO mcp_tool_action VALUES('"+name+"-v1','"+action+"')");m.execute("INSERT INTO mcp_tool_scope VALUES('"+name+"-v1','"+scope+"')");
        m.execute("UPDATE config_object SET current_version_id='"+name+"-v1',revision_counter=1,generation=1 WHERE id='"+name+"'");
    }
    private static void assertDatabaseFilesExclude(Path directory,List<String> secrets)throws Exception {
        try(var paths=Files.list(directory)){for(Path path:paths.filter(p->p.getFileName().toString().startsWith("platform.db")).toList()){
            String bytes=new String(Files.readAllBytes(path),StandardCharsets.ISO_8859_1);for(String secret:secrets)assertFalse(bytes.contains(secret),"Private value reached database/WAL");
        }}
    }
}
