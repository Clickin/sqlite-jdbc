package io.gateway;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import io.gateway.mcp.Mcp2026Adapter;
import io.gateway.oauth.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.slf4j.LoggerFactory;
import java.net.Socket;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.*;
import static org.junit.jupiter.api.Assertions.*;

class McpIngressTest {
    @TempDir Path directory;
    private static Map<String,Object> body(String method,Map<String,Object> extra){
        var params=new LinkedHashMap<String,Object>(extra);
        params.put("_meta",Map.of(Mcp2026Adapter.PROTOCOL,"2026-07-28",Mcp2026Adapter.CAPABILITIES,Map.of(),"subject","forged-administrator"));
        return Map.of("jsonrpc","2.0","id",1,"method",method,"params",params);
    }
    private static Map<String,String> headers(String token,String method,String name){
        var headers=new LinkedHashMap<>(Map.of("Authorization","Bearer "+token,"Content-Type","application/json","Accept","application/json, text/event-stream","MCP-Protocol-Version","2026-07-28","Mcp-Method",method));
        if(name!=null)headers.put("Mcp-Name",name);return headers;
    }
    private static HttpResponse<String> rpc(GatewayHttpClient client,String token,String method,Map<String,Object> params)throws Exception {
        return client.send("/mcp","POST",client.json.writeValueAsString(body(method,params)),headers(token,method,(String)params.get("name")));
    }
    @SuppressWarnings("unchecked") private static void error(GatewayHttpClient client,HttpResponse<String> response,int status,int code){
        assertEquals(status,response.statusCode(),response.body());
        assertEquals(code,((Number)((Map<String,Object>)client.object(response).get("error")).get("code")).intValue());
    }
    @Test void malformedHeadersMetadataOriginsAndGenericToolsNeverReadClinicalSourceOrLogSecrets()throws Exception {
        var logger=(Logger)LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        var capture=new ListAppender<ILoggingEvent>();capture.start();logger.addAppender(capture);
        try(var fixture=new GatewayFixture(directory,-1);var client=new GatewayHttpClient(fixture.server.getURI())){
            LoggerFactory.getLogger("gateway.acceptance").warn("SAFE_DIAGNOSTIC_CANARY");
            String token=client.authorize(SecurityFixture.RESOURCE,"A",List.of("clinical.lab.read"));
            var call=body("tools/call",Map.of("name","lab-tool","arguments",Map.of("patientId","A","documentId","DA")));
            for(String missing:List.of("MCP-Protocol-Version","Mcp-Method","Mcp-Name")){
                var h=headers(token,"tools/call","lab-tool");h.remove(missing);
                error(client,client.send("/mcp","POST",client.json.writeValueAsString(call),h),400,-32020);
            }
            for(String mismatch:List.of("MCP-Protocol-Version","Mcp-Method","Mcp-Name")){
                var h=headers(token,"tools/call","lab-tool");h.put(mismatch,"mismatched");
                error(client,client.send("/mcp","POST",client.json.writeValueAsString(call),h),400,-32020);
            }
            var malformed=body("tools/list",Map.of());
            @SuppressWarnings("unchecked") var params=(Map<String,Object>)malformed.get("params");
            for(String field:List.of(Mcp2026Adapter.PROTOCOL,Mcp2026Adapter.CAPABILITIES)){
                var meta=new HashMap<String,Object>(Map.of(Mcp2026Adapter.PROTOCOL,"2026-07-28",Mcp2026Adapter.CAPABILITIES,Map.of()));meta.remove(field);params.put("_meta",meta);
                error(client,client.send("/mcp","POST",client.json.writeValueAsString(malformed),headers(token,"tools/list",null)),400,-32602);
            }
            var origin=headers(token,"tools/list",null);origin.put("Origin","https://attacker.invalid");
            assertEquals(403,client.send("/mcp","POST",client.json.writeValueAsString(body("tools/list",Map.of())),origin).statusCode());
            for(String name:List.of("execute_sql","http_request","run_any_workflow","set_current_user","set_current_patient"))
                error(client,rpc(client,token,"tools/call",Map.of("name",name,"arguments",Map.of())),400,-32602);
            error(client,rpc(client,token,"tools/list",Map.of("cursor","old-catalogue-cursor")),400,-32602);
            error(client,rpc(client,token,"initialize",Map.of()),404,-32601);
            assertEquals(405,client.send("/mcp","DELETE",null,Map.of()).statusCode());
            assertEquals(0,fixture.sourceCalls.get());
            var bad=rpc(client,token,"tools/call",Map.of("name","lab-tool","arguments",Map.of("patientId","A","documentId","DA","userId","PRIVATE_ARGUMENT_SENTINEL")));
            assertEquals(200,bad.statusCode(),bad.body());
            @SuppressWarnings("unchecked") var toolError=(Map<String,Object>)client.object(bad).get("result");
            assertEquals(true,toolError.get("isError"));assertNotNull(toolError.get("structuredContent"));
            assertFalse(bad.body().contains("PRIVATE_ARGUMENT_SENTINEL"));assertEquals(0,fixture.sourceCalls.get());
            var encoded=headers(token,"tools/call","=?base64?bGFiLXRvb2w=?=");encoded.put("Mcp-Session-Id","untrusted-legacy-session");
            assertEquals(200,client.send("/mcp","POST",client.json.writeValueAsString(call),encoded).statusCode());
            assertEquals(200,rpc(client,token,"tools/call",Map.of("name","lab-tool","arguments",Map.of("patientId","A","documentId","DA"))).statusCode());
            assertEquals(2,fixture.sourceCalls.get()); // Equal RPC IDs are not an idempotency/replay cache.
            String logs=String.join("\n",capture.list.stream().map(ILoggingEvent::getFormattedMessage).toList());
            assertTrue(logs.contains("SAFE_DIAGNOSTIC_CANARY"));
            for(String secret:client.rawSecrets)if(secret!=null)assertFalse(logs.contains(secret),"authentication value leaked to logs");
            assertFalse(logs.contains("PRIVATE_ARGUMENT_SENTINEL"));assertFalse(logs.contains("RECOVERABLE_SENTINEL_NEVER_PERSIST"));
        } finally {logger.detachAppender(capture);capture.stop();}
    }
    @Test void concurrentClientCataloguesStayIsolatedAndHostHeadersCannotRewriteIssuer()throws Exception {
        try(var fixture=new GatewayFixture(directory,-1);var client=new GatewayHttpClient(fixture.server.getURI())){
            String allowed=client.authorize(SecurityFixture.RESOURCE,"A",List.of("clinical.lab.read"));
            String hidden=client.authorize(SecurityFixture.RESOURCE,"A",List.of("result.read"),"no-refresh");
            try(var executor=Executors.newVirtualThreadPerTaskExecutor()){
                var start=new CyclicBarrier(2);var futures=new ArrayList<Future<?>>();
                for(boolean visible:List.of(true,false))futures.add(executor.submit(()->{
                    start.await(10,TimeUnit.SECONDS);
                    for(int i=0;i<8;i++){
                        var response=rpc(client,visible?allowed:hidden,"tools/list",Map.of());assertEquals(200,response.statusCode(),response.body());
                        assertEquals(visible,response.body().contains("lab-tool"));
                    }
                    return null;
                }));
                for(var future:futures)future.get(30,TimeUnit.SECONDS);
            }
            assertEquals(403,rpc(client,hidden,"tools/call",Map.of("name","lab-tool","arguments",Map.of("patientId","A","documentId","DA"))).statusCode());
            assertEquals(0,fixture.sourceCalls.get());
            try(var socket=new Socket("127.0.0.1",fixture.server.getPort())){
                socket.setSoTimeout(5000);
                socket.getOutputStream().write(("GET /.well-known/oauth-authorization-server HTTP/1.1\r\nHost: attacker.invalid\r\nX-Forwarded-Host: attacker.invalid\r\nX-Forwarded-Proto: http\r\nForwarded: host=attacker.invalid;proto=http\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
                String response=new String(socket.getInputStream().readAllBytes(),StandardCharsets.UTF_8);
                assertTrue(response.startsWith("HTTP/1.1 200"),response);assertTrue(response.contains(SecurityFixture.ISSUER));assertFalse(response.contains("attacker.invalid"));
            }
        }
    }
    @Test void auditAdministrationDoesNotGrantClinicalParameterAccess()throws Exception {
        try(var fixture=new GatewayFixture(directory,-1);var client=new GatewayHttpClient(fixture.server.getURI())){
            String token=client.authorize(SecurityFixture.RESOURCE,"A",List.of("clinical.lab.read"));
            var call=client.call(token,Map.of("patientId","A","documentId","DA"));assertEquals(200,call.statusCode(),call.body());
            @SuppressWarnings("unchecked") var result=(Map<String,Object>)client.object(call).get("result");
            @SuppressWarnings("unchecked") String execution=(String)((Map<String,Object>)result.get("structuredContent")).get("executionId");
            var admin=client.login("MANAGEMENT");var h=Map.of("Cookie",admin.cookie());
            var metadata=client.send("/management/executions/"+execution,"GET",null,h);assertEquals(200,metadata.statusCode(),metadata.body());
            @SuppressWarnings("unchecked") var events=(List<Map<String,Object>>)client.object(metadata).get("audit");
            String event=(String)events.stream().filter(e->"EXECUTION_PARAMETERS".equals(e.get("event_type"))).findFirst().orElseThrow().get("id");
            assertEquals(403,client.send("/management/audit/"+event+"/parameters","GET",null,h).statusCode());
            var authority=fixture.server.getApplicationContext().getBean(SyntheticAuthority.class);
            authority.administratorRoles=Set.of("administrator","clinician");
            var visible=client.send("/management/audit/"+event+"/parameters","GET",null,h);assertEquals(200,visible.statusCode(),visible.body());
            assertTrue(visible.body().contains("patientId"));assertFalse(visible.body().contains("RECOVERABLE_SENTINEL_NEVER_PERSIST"));
            authority.deniedActions=Set.of("clinical.lab.read");
            assertEquals(403,client.send("/management/audit/"+event+"/parameters","GET",null,h).statusCode());
            assertEquals(1,fixture.sourceCalls.get());
        }
    }
    @Test void alternateIngressesCannotReplaceClinicalBearerWithCookiesOrAnotherAudience()throws Exception {
        try(var fixture=new GatewayFixture(directory,-1,true);var client=new GatewayHttpClient(fixture.server.getURI())){
            var actions=List.of("clinical.lab.read","reference.read","reference.resolve");
            String mcp=client.authorize(SecurityFixture.RESOURCE,"B",actions);
            String rest=client.authorize(GatewayFixture.REST_RESOURCE,"B",actions);
            var manager=client.login("MANAGEMENT");
            Map<String,Object> args=Map.of("patientId","A","documentId","DA","sourceSecret",GatewayFixture.SOURCE_SECRET);
            var cookieHeaders=new HashMap<String,String>();
            cookieHeaders.put("Content-Type","application/json");cookieHeaders.put("Cookie",manager.cookie());
            cookieHeaders.put("Origin",SecurityFixture.ISSUER);cookieHeaders.put("X-CSRF-Token",manager.csrf());
            assertEquals(401,client.send("/api/workflows/lab-workflow/execute","POST",client.json.writeValueAsString(args),cookieHeaders).statusCode());
            cookieHeaders.put("Authorization","Bearer "+mcp);
            assertEquals(401,client.send("/api/workflows/lab-workflow/execute","POST",client.json.writeValueAsString(args),cookieHeaders).statusCode());
            assertEquals(403,client.send("/management/workflows/lab-workflow/preview","POST",client.json.writeValueAsString(Map.of("arguments",args)),cookieHeaders).statusCode());
            cookieHeaders.remove("Authorization");
            assertEquals(403,client.send("/management/workflows/lab-workflow/preview","POST",client.json.writeValueAsString(Map.of("arguments",args)),cookieHeaders).statusCode());
            assertEquals(401,client.call(rest,args).statusCode());
            assertEquals(403,client.api("/api/workflows/lab-workflow/execute","POST",args,rest).statusCode());
            assertEquals(403,client.api("/api/workflows/identity-operation/execute","POST",args,rest).statusCode());
            for(String unsupported:List.of("/api/execute","/api/xapi","/xapi","/internal/operations/identity-operation"))
                assertEquals(404,client.api(unsupported,"POST",args,rest).statusCode(),unsupported);
            assertEquals(0,fixture.sourceCalls.get());
            long executions=fixture.store.read(s->s.getMapper(SecurityFixture.FixtureMapper.class).count("SELECT count(*) FROM execution"));
            assertEquals(0,executions);
        }
    }
}
