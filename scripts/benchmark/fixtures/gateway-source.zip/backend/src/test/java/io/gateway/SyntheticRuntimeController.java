package io.gateway;

import io.micronaut.context.annotation.Requires;
import io.micronaut.http.annotation.*;
import java.util.Map;

@Controller("/test/runtime")
@Requires(env="test")
public final class SyntheticRuntimeController {
    @Get public Map<String,Object> runtime(){return Map.of("virtual",Thread.currentThread().isVirtual(),"java",Runtime.version().toString());}
}
