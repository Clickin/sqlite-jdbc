package io.gateway.oauth;

import io.gateway.authorization.*;
import io.gateway.identity.*;
import io.gateway.persistence.PlatformStore;
import io.micronaut.context.annotation.Replaces;
import io.micronaut.context.annotation.Requires;
import jakarta.inject.Singleton;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

@Singleton
@Requires(env="test")
@Replaces(ConfiguredAuthority.class)
public final class SyntheticAuthority implements Authority {
    public volatile String outcome="ALLOW";
    public volatile boolean active=true;
    public volatile Runnable beforeDecision=()->{};
    public volatile Set<String> clinicalRoles=Set.of("clinician");
    public volatile Set<String> administratorRoles=Set.of("administrator");
    public volatile Set<String> deniedActions=Set.of();
    public volatile java.util.function.Consumer<String> beforeActionDecision=action->{};
    public final AtomicInteger resolutions=new AtomicInteger();
    public final AtomicInteger decisions=new AtomicInteger();
    private final PlatformStore store;
    public SyntheticAuthority(PlatformStore store){this.store=store;}
    public String securityBindingId(){return "security";}
    public Identity authenticate(String credential){outsideTransaction();if(!Set.of("synthetic-doctor","synthetic-admin").contains(credential)||!active)throw AccessDenied.unauthenticated();return new Identity("identity-operation",credential,true);}
    public Set<String> roles(String provider,String subject){outsideTransaction();if(!active)throw AccessDenied.denied();return subject.equals("synthetic-admin")?administratorRoles:clinicalRoles;}
    public Decision decide(String provider,String subject,String action,CanonicalTarget target){outsideTransaction();beforeDecision.run();beforeActionDecision.accept(action);decisions.incrementAndGet();if(!active||deniedActions.contains(action))return new Decision("DENY","synthetic-decision",Set.of());return new Decision(outcome,"synthetic-decision",roles(provider,subject));}
    public CanonicalTarget resolve(String provider,String subject,String action,CanonicalTarget claimed,String policy){outsideTransaction();resolutions.incrementAndGet();if(claimed.documentIdentifier()!=null){String patient=switch(claimed.documentIdentifier()){case "DA"->"A";case "DB"->"B";default->throw AccessDenied.denied();};if(!patient.equals(claimed.patientIdentifier()))throw AccessDenied.denied();}return claimed;}
    private void outsideTransaction(){if(store.inTransaction())throw new AssertionError("Authority was called with platform transaction held");}
}
