package io.gateway.management;

import io.gateway.persistence.PlatformStore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

final class SecurityDefinitionsTest {
    @TempDir Path temporary;
    @Test void draftDoesNotPublishAndOldValidationCannotOverwriteNewHead() {
        try(var store=new PlatformStore(temporary.resolve("management.sqlite"))) {
            store.write(s->{s.getMapper(ManagementMapper.class).action(Map.of("id","action-read","action_key","audit.read","target_kind","SERVICE","effect_kind","READ_ONLY","semantic_version",1));return null;});
            var repository=new SecurityDefinitions(store,()->{throw new AssertionError("Role validation must not resolve runtime definitions");});
            var detail=Map.<String,Object>of("actions",List.of(Map.of("action_id","action-read","action_semantic_version",1)));
            var first=repository.draft(new SecurityDefinitions.Draft(null,"auditor","Auditor",null,"Initial audited role","ROLE",detail),"operator");
            assertNull(first.object().currentVersionId());
            var validation=repository.validate(first.object().id(),first.version().id());
            var applied=repository.apply(first.object().id(),first.version().id(),validation.generation(),validation.dependencyVersions(),"operator","Publish");
            assertEquals(first.version().id(),applied.object().currentVersionId());
            var next=repository.draft(new SecurityDefinitions.Draft(first.object().id(),"auditor","Auditor updated",null,"New description","ROLE",detail),"operator");
            assertEquals(first.version().id(),next.object().currentVersionId());
            assertThrows(IllegalStateException.class,()->repository.apply(first.object().id(),next.version().id(),validation.generation(),validation.dependencyVersions(),"operator","Stale apply"));
            assertEquals(first.version().id(),repository.get(first.object().id(),null).version().id());
            var current=repository.validate(next.object().id(),next.version().id());
            var second=repository.apply(next.object().id(),next.version().id(),current.generation(),current.dependencyVersions(),"operator","Apply newer revision");
            var rolledBack=repository.rollback(first.object().id(),first.version().id(),second.object().generation(),"operator","Restore audited role");
            assertEquals(first.version().id(),rolledBack.object().currentVersionId());
            assertEquals(3,rolledBack.object().generation());
            assertEquals(2,repository.history(first.object().id()).size());
        }
    }
    @Test void offlineBootstrapRefusesExistingDatabaseBeforeReadingAnyManifest() throws Exception {
        Path database=temporary.resolve("existing.sqlite");
        byte[] original={1,2,3,4}; java.nio.file.Files.write(database,original);
        assertThrows(IllegalArgumentException.class,()->OfflineBootstrap.run(new String[]{"--database",database.toString(),"--manifest",temporary.resolve("absent.json").toString()}));
        assertArrayEquals(original,java.nio.file.Files.readAllBytes(database));
    }
}
