package io.gateway;

import com.nimbusds.oauth2.sdk.http.HTTPRequest;
import io.gateway.mcp.Mcp2026Adapter;
import io.gateway.oauth.SecurityFixture;
import tools.jackson.databind.json.JsonMapper;
import java.net.URI;
import java.net.http.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

/** Actual browser login, S256 consent and resource-bound token exchange for synthetic HTTP tests. */
final class GatewayHttpClient implements AutoCloseable {
    private final URI base;
    private final HttpClient client=HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1).followRedirects(HttpClient.Redirect.NEVER).build();
    final JsonMapper json=JsonMapper.builder().build();
    final List<String> rawSecrets=new ArrayList<>();
    record Browser(String cookie,String csrf) { @Override public String toString(){return "Browser[redacted]";} }
    GatewayHttpClient(URI base){this.base=base;}
    HttpResponse<String> send(String path,String method,String body,Map<String,String> headers)throws Exception {
        var request=HttpRequest.newBuilder(base.resolve(path)).method(method,body==null?HttpRequest.BodyPublishers.noBody():HttpRequest.BodyPublishers.ofString(body));
        headers.forEach(request::header);return client.send(request.build(),HttpResponse.BodyHandlers.ofString());
    }
    @SuppressWarnings("unchecked") Map<String,Object> object(HttpResponse<String> response){return json.readValue(response.body(),Map.class);}
    HttpResponse<String> api(String path,String method,Object body,String token)throws Exception {
        return send(path,method,body==null?null:json.writeValueAsString(body),Map.of("Content-Type","application/json","Authorization","Bearer "+token));
    }
    Browser login(String kind)throws Exception {
        var session=send("/auth/session","GET",null,Map.of());assertEquals(200,session.statusCode(),session.body());
        String cookie=session.headers().firstValue("set-cookie").orElseThrow().split(";",2)[0];
        String csrf=(String)object(session).get("csrfToken");
        var response=send("/auth/session/login","POST",json.writeValueAsString(Map.of("credential",kind.equals("MANAGEMENT")?"synthetic-admin":"synthetic-doctor","sessionKind",kind)),
                Map.of("Cookie",cookie,"Origin",SecurityFixture.ISSUER,"X-CSRF-Token",csrf,"Content-Type","application/json"));
        assertEquals(200,response.statusCode(),response.body());
        String fresh=response.headers().firstValue("set-cookie").orElseThrow().split(";",2)[0];assertNotEquals(cookie,fresh);
        String freshCsrf=(String)object(response).get("csrfToken");
        rawSecrets.add(fresh.substring(fresh.indexOf('=')+1));rawSecrets.add(freshCsrf);
        return new Browser(fresh,freshCsrf);
    }
    String authorize(String resource,String patient,List<String> actions)throws Exception {
        return authorize(resource,patient,actions,"public");
    }
    String authorize(String resource,String patient,List<String> actions,String clientId)throws Exception {
        var browser=login("USER");
        var parameters=SecurityFixture.authorizeParameters(clientId,SecurityFixture.REDIRECT,actions.contains("result.create")||actions.contains("clinical.order.write")?"clinical.read clinical.write":"clinical.read");
        parameters.put("resource",List.of(resource));
        var flat=new LinkedHashMap<String,String>();parameters.forEach((key,value)->flat.put(key,value.getFirst()));
        var response=send("/oauth/authorize?"+SecurityFixture.form(flat),"GET",null,Map.of("Cookie",browser.cookie()));
        assertEquals(303,response.statusCode(),response.body());
        String requestId=query(response.headers().firstValue("location").orElseThrow()).get("request_id").getFirst();
        var consent=send("/auth/requests/"+requestId+"/consent","POST",json.writeValueAsString(Map.of("purpose","synthetic-care","approve",true,
                "actionTargets",actions.stream().map(action->Map.of("action",action,"target",SecurityFixture.patient(patient))).toList())),
                Map.of("Cookie",browser.cookie(),"Origin",SecurityFixture.ISSUER,"X-CSRF-Token",browser.csrf(),"Content-Type","application/json"));
        assertEquals(200,consent.statusCode(),consent.body());
        var redirect=query((String)object(consent).get("redirectUri"));
        assertEquals(SecurityFixture.ISSUER,redirect.get("iss").getFirst());
        assertEquals("synthetic-state-sentinel",redirect.get("state").getFirst());
        assertTrue(redirect.containsKey("code"),consent.body());
        String code=redirect.get("code").getFirst();rawSecrets.add(code);
        var token=send("/oauth/token","POST",SecurityFixture.form(Map.of("grant_type","authorization_code","client_id",clientId,"code",code,
                "redirect_uri",SecurityFixture.REDIRECT,"code_verifier",SecurityFixture.VERIFIER,"resource",resource)),Map.of("Content-Type","application/x-www-form-urlencoded"));
        assertEquals(200,token.statusCode(),token.body());assertEquals("no-store",token.headers().firstValue("cache-control").orElseThrow());
        var values=object(token);String access=(String)values.get("access_token");
        rawSecrets.add(access);rawSecrets.add((String)values.get("refresh_token"));return access;
    }
    HttpResponse<String> call(String token,Map<String,Object> arguments)throws Exception {
        var params=Map.of("_meta",Map.of(Mcp2026Adapter.PROTOCOL,"2026-07-28",Mcp2026Adapter.CAPABILITIES,Map.of()),"name","lab-tool","arguments",arguments);
        return send("/mcp","POST",json.writeValueAsString(Map.of("jsonrpc","2.0","id",1,"method","tools/call","params",params)),
                Map.of("Content-Type","application/json","Accept","application/json, text/event-stream","MCP-Protocol-Version","2026-07-28","Mcp-Method","tools/call","Mcp-Name","lab-tool","Authorization","Bearer "+token));
    }
    @SuppressWarnings("unchecked") void revokeGrants()throws Exception {
        var browser=login("MANAGEMENT");
        var headers=Map.of("Cookie",browser.cookie(),"Origin",SecurityFixture.ISSUER,"X-CSRF-Token",browser.csrf());
        var response=send("/management/security/grants","GET",null,headers);assertEquals(200,response.statusCode(),response.body());
        for(var grant:(List<Map<String,Object>>)json.readValue(response.body(),List.class)) {
            var revoked=send("/management/security/grants/"+grant.get("id")+"/revoke","POST",null,headers);
            assertEquals(200,revoked.statusCode(),revoked.body());
        }
    }
    private static Map<String,List<String>> query(String uri){return new HTTPRequest(HTTPRequest.Method.GET,URI.create(uri)).getQueryStringParameters();}
    @Override public void close(){client.close();}
}
