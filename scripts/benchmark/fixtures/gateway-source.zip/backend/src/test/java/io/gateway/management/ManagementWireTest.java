package io.gateway.management;

import io.gateway.definitions.Definitions;
import io.micronaut.context.ApplicationContext;
import io.micronaut.json.JsonMapper;
import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class ManagementWireTest {
    @Test void datasourceDraftAcceptsAbsentOptionalProfilesAndKeepsTypedValues()throws Exception {
        try(var context=ApplicationContext.run(Map.of("micronaut.server.enabled",false))){
            var json=context.getBean(JsonMapper.class);
            var detail=new LinkedHashMap<String,Object>();
            detail.put("baseUri","https://source.example");detail.put("authenticationKind","NONE");
            for(String field:List.of("credentialObjectId","tlsProfileObjectId","proxyProfileId","networkPolicyObjectId"))detail.put(field,null);
            detail.put("poolMaxTotal",4);detail.put("poolMaxPerRoute",4);detail.put("connectTimeoutMs",2000);
            detail.put("redirectPolicy","NEVER");detail.put("maxConcurrent",4);detail.put("queueTimeoutMs",1000);detail.put("headers",List.of());
            var wire=new DefinitionController.DraftRequest(null,"source","Source",null,"synthetic","HttpSource",detail);
            var draft=DefinitionController.toDraft(json,wire);
            var source=(Definitions.HttpSource)draft.detail();
            assertEquals("https://source.example",source.baseUri());
            assertNull(source.credentialObjectId());assertEquals("NONE",source.authenticationKind());assertEquals(2000,source.connectTimeoutMs());
            @SuppressWarnings("unchecked") Map<String,Object> loaded=json.readValue(json.writeValueAsBytes(source),Map.class);
            var edited=DefinitionController.toDraft(json,new DefinitionController.DraftRequest("existing","source","Updated",null,"edit","HttpSource",loaded));
            assertEquals(source,edited.detail());
        }
    }
}
