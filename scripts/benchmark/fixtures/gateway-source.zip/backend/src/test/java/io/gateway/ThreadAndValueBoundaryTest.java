package io.gateway;

import io.gateway.authorization.CanonicalTarget;
import io.gateway.definitions.DefinitionRepository;
import io.gateway.definitions.Definitions.*;
import io.gateway.identity.Authority;
import io.gateway.identity.ConfiguredAuthority;
import io.gateway.management.SecurityDefinitions;
import io.gateway.mcp.Mcp2026Adapter;
import io.gateway.oauth.SecurityFixture;
import io.gateway.oauth.SyntheticAuthority;
import io.gateway.persistence.PlatformStore;
import io.gateway.persistence.PlatformMapper;
import io.gateway.runtime.Payload;
import io.gateway.runtime.RuntimeGraph;
import io.micronaut.context.annotation.Replaces;
import io.micronaut.context.annotation.Requires;
import io.micronaut.context.event.BeanCreatedEvent;
import io.micronaut.context.event.BeanCreatedEventListener;
import jakarta.inject.Singleton;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.reflection.SystemMetaObject;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import tools.jackson.databind.DeserializationFeature;
import tools.jackson.databind.json.JsonMapper;
import static org.junit.jupiter.api.Assertions.*;

class ThreadAndValueBoundaryTest {
    @TempDir Path directory;
    private static final JsonMapper JSON=JsonMapper.builder().enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS).build();
    private static final BigDecimal AMOUNT=new BigDecimal("12345678901234567890.12345678901234567891");
    private static final Map<String,Object> VALUES=Map.of(
        "amount",AMOUNT,"date","2024-02-29","localTime","2024-02-29T23:59:58.123456789",
        "offsetTime","23:59:58.123456789+09:30","instant","2024-02-29T23:59:58.123456789+09:30",
        "text","한글 & <검사> \"정상\" \\ 경로\n다음 줄","patientId","A","documentId","DA");

    @Test void httpWorkflowKeepsIdentityAuthorityMyBatisAndOutboundIoOnVirtualThreadsAndPreservesSourceValues() throws Exception {
        var entered=new CountDownLatch(1);var release=new CountDownLatch(1);
        var received=new AtomicReference<Map<?,?>>();var sourceFailure=new AtomicReference<Throwable>();
        try(var gateway=new GatewayFixture(directory,-1,false,Map.of("thread-value-test",true),"thread-value");
            var client=new GatewayHttpClient(gateway.server.getURI());var caller=Executors.newSingleThreadExecutor()) {
            var app=gateway.server.getApplicationContext();
            var authority=app.getBean(ObservedAuthority.class);var queries=app.getBean(QueryThreads.class);
            gateway.source.createContext("/echo-values",exchange->{
                try {
                    received.set(JSON.readValue(exchange.getRequestBody().readAllBytes(),Map.class));
                    entered.countDown();
                    if(!release.await(10,TimeUnit.SECONDS))throw new AssertionError("Outbound observation was not released");
                    byte[] response=JSON.writeValueAsBytes(received.get());
                    exchange.getResponseHeaders().set("Content-Type","application/json");
                    exchange.sendResponseHeaders(200,response.length);exchange.getResponseBody().write(response);
                } catch(Throwable failure) {sourceFailure.set(failure);}
                finally {exchange.close();}
            });
            var repository=app.getBean(DefinitionRepository.class);
            var values=publish(repository,"source-values",new Contract("VALUE",List.of(
                field("amount","DECIMAL",0),field("date","DATE",1),field("localTime","DATETIME",2),
                field("offsetTime","TIME",3),field("instant","INSTANT",4),field("text","STRING",5),
                field("patientId","STRING",6),field("documentId","STRING",7))));
            String url="jdbc:sqlite:"+directory.resolve("values.db");
            // SQLite NUMERIC affinity is not an arbitrary-precision decimal store. TEXT plus the
            // registered BigDecimal result mapping preserves the exact source decimal deliberately.
            try(var connection=DriverManager.getConnection(url);var ddl=connection.createStatement()) {
                ddl.execute("CREATE TABLE source_values(patient TEXT,document TEXT,amount TEXT,date TEXT,localTime TEXT,offsetTime TEXT,instant TEXT,text TEXT)");
                try(var insert=connection.prepareStatement("INSERT INTO source_values VALUES(?,?,?,?,?,?,?,?)")) {
                    insert.setString(1,"A");insert.setString(2,"DA");int index=3;
                    for(String name:List.of("amount","date","localTime","offsetTime","instant","text"))insert.setString(index++,VALUES.get(name).toString());
                    assertEquals(1,insert.executeUpdate());
                }
            }
            var source=publish(repository,"value-source",new JdbcSource(url,"SQLITE",null,0,1,1000,true,2,1000));
            String xml="""
                <?xml version="1.0"?>
                <!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "https://mybatis.org/dtd/mybatis-3-mapper.dtd">
                <mapper namespace="valueBoundary">
                  <resultMap id="values" type="map" autoMapping="false">
                    <result column="amount" property="amount" javaType="bigdecimal"/>
                    <result column="date" property="date" javaType="string"/>
                    <result column="localTime" property="localTime" javaType="string"/>
                    <result column="offsetTime" property="offsetTime" javaType="string"/>
                    <result column="instant" property="instant" javaType="string"/>
                    <result column="text" property="text" javaType="string"/>
                    <result column="patient" property="patientId" javaType="string"/>
                    <result column="document" property="documentId" javaType="string"/>
                  </resultMap>
                  <select id="read" resultMap="values">
                    SELECT amount,date,localTime,offsetTime,instant,text,patient,document FROM source_values
                    WHERE patient=#{patientId} AND document=#{documentId}
                  </select>
                  <select id="resolve" resultType="map">
                    SELECT 'synthetic-hospital' AS organization,'synthetic-mrn' AS identifierSystem,
                           patient AS patientIdentifier,document AS documentIdentifier FROM source_values
                    WHERE patient=#{patientIdentifier} AND document=#{documentIdentifier}
                  </select>
                </mapper>
                """;
            var mapper=publish(repository,"value-mapper",new Mapper("SQLITE",List.of(new MapperDocument("values.xml",xml)),List.of()));
            var read=publish(repository,"value-read",new JdbcOperation(source.object().id(),gateway.input.object().id(),values.object().id(),
                Effect.READ_ONLY,5000,1,16384L,mapper.object().id(),"valueBoundary.read","SELECT_ONE","READ_ONLY",List.of(),List.of()));
            var representation=publish(repository,"value-json",new Representation(values.object().id(),"json","DEFAULT","application/json","UTF-8",List.of(),List.of()));
            var echo=publish(repository,"value-echo",new HttpOperation(gateway.datasource.object().id(),values.object().id(),values.object().id(),
                Effect.READ_ONLY,15000,1,16384L,"POST","echo-values",representation.object().id(),representation.object().id(),List.of(),List.of(new ExpectedStatus(200,"SUCCEEDED")),List.of()));
            var converter=publish(repository,"value-copy",new Converter("basic",values.object().id(),values.object().id(),
                ((Contract)values.detail()).fields().stream().map(field->new Rule("INPUT",field.id(),field.id(),"COPY",List.of())).toList()));
            var canonical=publish(repository,"value-canonical",new Contract("VALUE",List.of(
                field("organization","STRING",0),field("identifierSystem","STRING",1),
                field("patientIdentifier","STRING",2),field("documentIdentifier","STRING",3))));
            var resolverFields=new ArrayList<Field>();
            for(String name:List.of("subject","identityProvider","action","targetKind","organization","identifierSystem","patientIdentifier","documentIdentifier"))
                resolverFields.add(new Field("resolver-"+name,name,null,name,"SCALAR","STRING",resolverFields.size(),true,false,null,null,1024,Payload.Disposition.PERSIST));
            var resolverInput=publish(repository,"value-resolver-input",new Contract("VALUE",resolverFields));
            var resolver=publish(repository,"value-resolver",new JdbcOperation(source.object().id(),resolverInput.object().id(),canonical.object().id(),
                Effect.READ_ONLY,5000,1,16384L,mapper.object().id(),"valueBoundary.resolve","SELECT_ONE","READ_ONLY",List.of(),List.of()));
            var canonicalCopy=publish(repository,"value-canonical-copy",new Converter("basic",canonical.object().id(),canonical.object().id(),
                ((Contract)canonical.detail()).fields().stream().map(field->new Rule("INPUT",field.id(),field.id(),"COPY",List.of())).toList()));
            var security=app.getBean(SecurityDefinitions.class);var policy=new LinkedHashMap<>(security.get("document-policy",null).detail());
            policy.put("resolver_operation_object_id",resolver.object().id());
            policy.put("resolver_converter_object_id",canonicalCopy.object().id());
            policy.put("arguments",List.of(
                Map.of("source_port","REQUEST","contract_field_id","patient-field","target_part","PATIENT"),
                Map.of("source_port","REQUEST","contract_field_id","document-field","target_part","DOCUMENT"),
                Map.of("source_port","CONTEXT","contract_field_id","value-patientId","target_part","PATIENT"),
                Map.of("source_port","CONTEXT","contract_field_id","value-documentId","target_part","DOCUMENT")));
            var policyDraft=security.draft(new SecurityDefinitions.Draft(null,"value-policy","Value targets",null,"fixture","TARGET_POLICY",policy),"fixture");
            var policyChecked=security.validate(policyDraft.object().id(),policyDraft.version().id());
            security.apply(policyDraft.object().id(),policyDraft.version().id(),policyChecked.generation(),policyChecked.dependencyVersions(),"fixture","fixture");
            var workflow=publish(repository,"value-workflow",new Workflow(null,List.of(new Stage("INPUT",0,read.object().id(),null),
                new Stage("CONVERT",1,null,converter.object().id()),new Stage("OUTPUT",2,echo.object().id(),null)),List.of(),
                List.of(new SecurityBinding("INPUT","security","clinical.lab.read","document-policy"),new SecurityBinding("OUTPUT","security","clinical.lab.read",policyDraft.object().id()))));
            var tool=new LinkedHashMap<>(security.get("lab-tool",null).detail());
            tool.put("public_name","value-tool");tool.put("workflow_object_id",workflow.object().id());tool.put("public_output_contract_version_id",values.version().id());
            var draft=security.draft(new SecurityDefinitions.Draft(null,"value-tool","Value tool",null,"fixture","MCP_TOOL",tool),"fixture");
            var checked=security.validate(draft.object().id(),draft.version().id());
            security.apply(draft.object().id(),draft.version().id(),checked.generation(),checked.dependencyVersions(),"fixture","fixture");
            String token=client.authorize(SecurityFixture.RESOURCE,"A",List.of("clinical.lab.read"));
            assertTrue(authority.observations.stream().anyMatch(o->o.method().equals("authenticate")),"HTTP login must exercise identity verification");
            for(var observation:authority.observations)assertTrue(observation.thread().isVirtual(),observation.method());
            authority.observations.clear();
            var params=Map.of("name","value-tool","arguments",Map.of("patientId","A","documentId","DA"),
                "_meta",Map.of(Mcp2026Adapter.PROTOCOL,"2026-07-28",Mcp2026Adapter.CAPABILITIES,Map.of()));
            var response=caller.submit(()->client.send("/mcp","POST",JSON.writeValueAsString(Map.of("jsonrpc","2.0","id",1,"method","tools/call","params",params)),
                Map.of("Authorization","Bearer "+token,"Content-Type","application/json","Accept","application/json, text/event-stream",
                    "MCP-Protocol-Version","2026-07-28","Mcp-Method","tools/call","Mcp-Name","value-tool")));
            try {
                assertTrue(entered.await(10,TimeUnit.SECONDS),"Workflow did not reach the real HTTP source");
                assertEquals(VALUES,received.get(),"MyBatis values must reach the HTTP request without rounding or timezone conversion");
                assertEquals(1,queries.threads.size());Thread gatewayThread=queries.threads.getFirst();
                assertTrue(gatewayThread.isVirtual(),"Actual MyBatis StatementHandler.query must run on a virtual thread");
                for(String method:List.of("resolve","decide")) {
                    var observations=authority.observations.stream().filter(o->o.method().equals(method)).toList();
                    assertFalse(observations.isEmpty(),method+" must be checked for this workflow request");
                    for(var observation:observations)assertSame(gatewayThread,observation.thread(),method);
                }
                // Observe the captured gateway thread while the remote server withholds its response.
                // The remote server's own thread is intentionally never used as execution evidence.
                var stack=Arrays.asList(gatewayThread.getStackTrace());
                assertTrue(stack.stream().anyMatch(frame->frame.getClassName().equals("io.gateway.connectors.http.HttpResources$Adapter")&&frame.getMethodName().equals("execute")),stack.toString());
                assertTrue(stack.stream().anyMatch(frame->frame.getClassName().startsWith("org.apache.hc.client5.http.impl.classic.")),stack.toString());
            } finally {release.countDown();}
            var result=response.get(10,TimeUnit.SECONDS);assertEquals(200,result.statusCode(),result.body());
            Map<?,?> envelope=JSON.readValue(result.body(),Map.class);
            var structured=(Map<?,?>)((Map<?,?>)envelope.get("result")).get("structuredContent");
            assertEquals("SUCCEEDED",structured.get("businessOutcome"));
            assertEquals(VALUES,structured.get("data"),"The real HTTP response decoder and public response must preserve declared values");
            var audit=gateway.store.read(session->session.getMapper(AuditValues.class).values((String)structured.get("executionId")));
            var expectedAudit=new ArrayList<AuditRow>();
            for(String port:List.of("REQUEST","SOURCE_REQUEST")) {
                expectedAudit.add(auditRow(port,"patient-field","patientId",0,"A"));
                expectedAudit.add(auditRow(port,"document-field","documentId",1,"DA"));
            }
            for(String port:List.of("SOURCE_OUTPUT","CONVERT_REQUEST","CONVERT_OUTPUT","TARGET_REQUEST","TARGET_OUTPUT","RESPONSE")) {
                int ordinal=0;
                for(String name:List.of("amount","date","localTime","offsetTime","instant","text","patientId","documentId"))
                    expectedAudit.add(auditRow(port,"value-"+name,name,ordinal++,VALUES.get(name)));
            }
            expectedAudit.sort(Comparator.comparing(AuditRow::port).thenComparingInt(AuditRow::ordinal));
            assertEquals(expectedAudit,audit,"Every declared persisted parameter must match the actual JDBC/converter/HTTP/request/response values");
            assertNull(sourceFailure.get());
        } finally {release.countDown();}
    }

    private static Field field(String name,String type,int ordinal) {
        return new Field("value-"+name,name,null,name,"SCALAR",type,ordinal,true,false,
            type.equals("DECIMAL")?40:null,type.equals("DECIMAL")?20:null,type.equals("STRING")?1024:null,Payload.Disposition.PERSIST);
    }
    private static Saved publish(DefinitionRepository repository,String name,Detail detail) {
        var draft=repository.draft(new Draft(null,name,name,null,"synthetic value boundary",detail),"fixture");
        return repository.apply(repository.validate(draft.object().id(),draft.version().id()),"fixture","synthetic value boundary");
    }
    private static AuditRow auditRow(String port,String field,String name,int ordinal,Object value) {
        return new AuditRow(port,field,name,ordinal,value instanceof BigDecimal?"DECIMAL":"STRING",
            value instanceof String text?text:null,null,value instanceof BigDecimal decimal?decimal.toPlainString():null,null,null,null);
    }
    public record AuditRow(String port,String fieldId,String parameterName,int ordinal,String valueType,
                           String stringValue,Long integerValue,String decimalText,Boolean booleanValue,String parentParameterId,String exclusionReason) {}
    public interface AuditValues extends PlatformMapper {
        @Select("""
            SELECT p.port,p.field_id,p.parameter_name,p.ordinal,p.value_type,p.string_value,p.integer_value,
                   p.decimal_text,p.boolean_value,p.parent_parameter_id,p.exclusion_reason
            FROM audit_parameter p JOIN audit_event e ON e.id=p.audit_event_id
            WHERE e.execution_id=#{execution} ORDER BY p.port,p.ordinal
            """)
        List<AuditRow> values(@Param("execution") String execution);
    }

    private record Observation(String method,Thread thread) {}
    @Singleton
    @Requires(property="thread-value-test",value="true")
    @Replaces(ConfiguredAuthority.class)
    public static final class ObservedAuthority implements Authority {
        private final SyntheticAuthority delegate;
        final Queue<Observation> observations=new ConcurrentLinkedQueue<>();
        public ObservedAuthority(PlatformStore store){delegate=new SyntheticAuthority(store);}
        private void observe(String method){observations.add(new Observation(method,Thread.currentThread()));}
        public String securityBindingId(){return delegate.securityBindingId();}
        public Identity authenticate(String credential){observe("authenticate");return delegate.authenticate(credential);}
        public Set<String> roles(String provider,String subject){observe("roles");return delegate.roles(provider,subject);}
        public CanonicalTarget resolve(String provider,String subject,String action,CanonicalTarget target,String policy){observe("resolve");return delegate.resolve(provider,subject,action,target,policy);}
        public Decision decide(String provider,String subject,String action,CanonicalTarget target){observe("decide");return delegate.decide(provider,subject,action,target);}
    }

    @Singleton
    @Requires(property="thread-value-test",value="true")
    public static final class QueryThreads implements BeanCreatedEventListener<RuntimeGraph> {
        final List<Thread> threads=new CopyOnWriteArrayList<>();
        @Override public RuntimeGraph onCreated(BeanCreatedEvent<RuntimeGraph> event) {
            var runtime=event.getBean();
            var operations=(Map<?,?>)SystemMetaObject.forObject(runtime).getValue("operations");
            for(var entry:operations.entrySet())if(runtime.definitions().require((String)entry.getKey()).detail() instanceof JdbcOperation) {
                // Native test-only MyBatis registration, never an executable handler named by mapper XML.
                var factory=(SqlSessionFactory)SystemMetaObject.forObject(entry.getValue()).getValue("factory");
                factory.getConfiguration().addInterceptor(new QueryObservation(threads));
            }
            return runtime;
        }
    }
    @Intercepts(@Signature(type=StatementHandler.class,method="query",args={Statement.class,ResultHandler.class}))
    public static final class QueryObservation implements Interceptor {
        private final List<Thread> threads;
        QueryObservation(List<Thread> threads){this.threads=threads;}
        @Override public Object intercept(Invocation invocation) throws Throwable {
            Object result=invocation.proceed();threads.add(Thread.currentThread());return result;
        }
    }
}
