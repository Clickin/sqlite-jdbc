package io.gateway;

import io.gateway.authorization.CanonicalTarget;
import io.gateway.oauth.*;
import io.gateway.results.ResultMapper;
import io.gateway.results.ResultModels.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

@SuppressWarnings("unchecked")
class ReferenceResultsHttpTest {
    private static final List<String> MCP_ACTIONS=List.of("clinical.lab.read","reference.read","reference.resolve");
    private static final List<String> RESULT_ACTIONS=List.of("result.create","result.read","reference.read","reference.resolve");
    private static final String SUMMARY="외부 생성 합성 요약",MODEL="synthetic-submitted-model-not-server-observed";
    @TempDir Path directory;

    @Test void observedReferencesBecomeTypedResultsAndRemainAccessibleOnlyWithCurrentOwnerPermission()throws Exception {
        List<String> secrets=new ArrayList<>(List.of(GatewayFixture.RECORD_TEXT,GatewayFixture.SOURCE_SECRET,SecurityFixture.VERIFIER));
        try(var fixture=new GatewayFixture(directory,-1,true);var http=new GatewayHttpClient(fixture.server.getURI())) {
            String mcp=http.authorize(SecurityFixture.RESOURCE,"A",MCP_ACTIONS);
            assertEquals(403,http.call(mcp,arguments("B","DB")).statusCode());assertEquals(0,fixture.sourceCalls.get());
            var execution=successful(http,http.call(mcp,arguments("A","DA")));
            assertEquals(Map.of("answer","합성 정상 결과","recordText",GatewayFixture.RECORD_TEXT,"webLink",GatewayFixture.WEB_LINK),execution.get("data"));
            String executionId=(String)execution.get("executionId");
            var referenceIds=(List<String>)execution.get("references");
            assertEquals(1,fixture.sourceCalls.get());

            String rest=http.authorize(GatewayFixture.REST_RESOURCE,"A",RESULT_ACTIONS);
            var request=request(fixture,executionId,referenceIds);
            assertEquals(401,http.api("/api/results","POST",request,mcp).statusCode());
            assertEquals(401,http.call(rest,arguments("A","DA")).statusCode());
            var created=http.api("/api/results","POST",request,rest);assertEquals(200,created.statusCode(),created.body());
            assertEquals("no-store",created.headers().firstValue("cache-control").orElseThrow());
            var saved=http.json.readValue(created.body(),ResultDocument.class);
            assertEquals(Map.of("summary",SUMMARY),saved.data());assertEquals(MODEL,saved.submittedModel());
            assertEquals("synthetic-generation",saved.externalGenerationId());assertEquals(executionId,saved.sourceExecutionId());
            assertEquals(fixture.generatedOutput.version().id(),saved.outputContractVersionId());
            assertNotEquals(fixture.output.version().id(),saved.outputContractVersionId());
            assertEquals(List.of(new CanonicalTarget("DOCUMENT","synthetic-hospital","synthetic-mrn","A",null,"DA")),saved.targets());
            assertEquals(referenceIds,saved.references().stream().map(StoredReference::referenceId).toList());
            assertEquals(Set.of(saved.values().getFirst().id()),new HashSet<>(saved.references().stream().map(StoredReference::resultValueId).toList()));
            assertEquals(saved,read(http,saved.id(),rest));

            var resolved=new HashMap<String,ResolvedReference>();
            for(String id:referenceIds) {
                var response=http.api("/api/references/"+id,"GET",null,rest);assertEquals(200,response.statusCode(),response.body());
                assertEquals("no-referrer",response.headers().firstValue("referrer-policy").orElseThrow());
                var reference=http.json.readValue(response.body(),ResolvedReference.class);resolved.put(reference.kind(),reference);
            }
            assertEquals(Set.of("WEB_LINK","TOOL_REFERENCE"),resolved.keySet());
            var web=resolved.get("WEB_LINK");assertEquals(GatewayFixture.WEB_LINK,web.directUrl());assertEquals("DIRECT_LINK",web.supportStatus());
            var tool=resolved.get("TOOL_REFERENCE");assertNull(tool.directUrl());assertEquals("METADATA_ONLY",tool.supportStatus());
            assertEquals("synthetic-hospital",tool.adapterId());assertEquals("LAB",tool.screenCode());assertEquals("view-lab",tool.launchProfile());
            assertEquals(Map.of("original_patient","A","patient_id","A","document_id","DA"),tool.parameters());
            assertEquals(1,fixture.sourceCalls.get(),"Resolving a reference must not repeat the original HTTP operation");
            var captured=fixture.store.read(s->s.getMapper(ResultMapper.class).parameters(tool.id()));
            for(String port:List.of("ORIGINAL","EFFECTIVE")) {
                assertEquals("A",parameter(captured,port,"patientId").get("string_value"));
                assertEquals("DA",parameter(captured,port,"documentId").get("string_value"));
                assertEquals("EXCLUDED",parameter(captured,port,"sourceSecret").get("value_type"));
                assertEquals("OMIT_SECRET",parameter(captured,port,"sourceSecret").get("exclusion_reason"));
                assertNull(parameter(captured,port,"sourceSecret").get("string_value"));
            }
            assertEquals(2,count(fixture,"SELECT count(*) FROM audit_parameter p JOIN audit_event a ON a.id=p.audit_event_id WHERE a.execution_id='"+executionId+"' AND p.parameter_name='recordText' AND p.value_type='EXCLUDED' AND p.exclusion_reason='OMIT_RECOVERABLE' AND p.string_value IS NULL"));

            String mcpB=http.authorize(SecurityFixture.RESOURCE,"B",MCP_ACTIONS);
            var otherExecution=successful(http,http.call(mcpB,arguments("B","DB")));
            var otherReferences=(List<String>)otherExecution.get("references");
            String restB=http.authorize(GatewayFixture.REST_RESOURCE,"B",RESULT_ACTIONS);
            var hiddenList=http.api("/api/results","GET",null,restB);assertEquals(200,hiddenList.statusCode());
            assertEquals(List.of(),http.json.readValue(hiddenList.body(),List.class));
            var ownList=http.api("/api/results","GET",null,rest);assertEquals(200,ownList.statusCode());
            assertEquals(List.of(saved.id()),Arrays.stream(http.json.readValue(ownList.body(),ResultSummary[].class)).map(ResultSummary::id).toList());
            assertEquals(403,http.api("/api/results/"+saved.id(),"GET",null,restB).statusCode());
            assertEquals(403,http.api("/api/references/"+web.id(),"GET",null,restB).statusCode());
            assertEquals(403,http.api("/api/results","POST",request,restB).statusCode());
            assertEquals(403,http.api("/api/results","POST",request(fixture,executionId,otherReferences),rest).statusCode());
            assertEquals(403,http.api("/api/results","POST",request(fixture,executionId,List.of("https://clinical.example/notes/forged")),rest).statusCode());
            assertEquals(1,count(fixture,"SELECT count(*) FROM generated_result"));
            assertEquals(1,count(fixture,"SELECT count(*) FROM audit_event WHERE event_type='RESULT_SAVED'"));
            assertEquals(2,fixture.sourceCalls.get());

            http.revokeGrants();
            assertEquals(401,http.api("/api/results/"+saved.id(),"GET",null,rest).statusCode());
            assertEquals(401,http.call(mcp,arguments("A","DA")).statusCode());
            String current=http.authorize(GatewayFixture.REST_RESOURCE,"A",RESULT_ACTIONS);
            assertNotEquals(rest,current);assertEquals(saved,read(http,saved.id(),current));
            assertEquals(200,http.api("/api/references/"+web.id(),"GET",null,current).statusCode());
            var currentTool=http.api("/api/references/"+tool.id(),"GET",null,current);
            assertEquals(200,currentTool.statusCode(),currentTool.body());assertEquals(tool,http.json.readValue(currentTool.body(),ResolvedReference.class));
            var authority=fixture.server.getApplicationContext().getBean(SyntheticAuthority.class);authority.outcome="DENY";
            assertEquals(403,http.api("/api/results/"+saved.id(),"GET",null,current).statusCode());
            assertEquals(403,http.api("/api/references/"+web.id(),"GET",null,current).statusCode());
            assertEquals(403,http.api("/api/references/"+tool.id(),"GET",null,current).statusCode());
            assertEquals(403,http.api("/api/results","POST",request,current).statusCode());
            assertEquals(2,fixture.sourceCalls.get(),"Read, resolve, and rejected saves cannot rerun business source I/O");
            assertEquals(1,count(fixture,"SELECT count(*) FROM generated_result"));
            secrets.addAll(http.rawSecrets);assertNoPersistedValues(fixture,secrets);
        }
        assertPhysicalSecrecy(secrets);
    }

    @Test void referencePreviewRequiresClientBoundDelegationBeforeAnySourceRead()throws Exception {
        try(var fixture=new GatewayFixture(directory,-1,true);var http=new GatewayHttpClient(fixture.server.getURI())) {
            fixture.server.getApplicationContext().getBean(SyntheticAuthority.class).administratorRoles=Set.of("administrator","clinician");
            var manager=http.login("MANAGEMENT");
            var rejected=http.send("/management/workflows/lab-workflow/preview","POST",
                http.json.writeValueAsString(Map.of("arguments",arguments("A","DA"))),
                Map.of("Content-Type","application/json","Cookie",manager.cookie(),"Origin",SecurityFixture.ISSUER,"X-CSRF-Token",manager.csrf()));
            assertEquals(403,rejected.statusCode());assertEquals(0,fixture.sourceCalls.get());
            assertEquals(0,count(fixture,"SELECT count(*) FROM execution"));
            String delegated=http.authorize(GatewayFixture.REST_RESOURCE,"A",MCP_ACTIONS);
            var response=http.api("/api/workflows/lab-workflow/execute","POST",arguments("A","DA"),delegated);
            assertEquals(200,response.statusCode(),response.body());var execution=http.object(response);
            assertEquals("SUCCEEDED",execution.get("businessOutcome"));
            var references=(List<String>)execution.get("references");assertEquals(2,references.size());
            for(String reference:references)assertEquals(200,http.api("/api/references/"+reference,"GET",null,delegated).statusCode());
            assertEquals(1,fixture.sourceCalls.get(),"Resolving client-owned references cannot rerun the preview");
        }
    }

    @Test void unsafeObservedWebUrlFailsBeforeOutputAuditOrReferencePersistence()throws Exception {
        String sentinel="OBSERVED_ACCESS_TOKEN_SENTINEL_NEVER_PERSIST";
        List<String> secrets=new ArrayList<>(List.of(sentinel,GatewayFixture.RECORD_TEXT,GatewayFixture.SOURCE_SECRET,SecurityFixture.VERIFIER));
        try(var fixture=new GatewayFixture(directory,-1,true);var http=new GatewayHttpClient(fixture.server.getURI())) {
            fixture.sourceWebLink="https://clinical.example/notes/synthetic?access_token="+sentinel;
            String token=http.authorize(SecurityFixture.RESOURCE,"A",MCP_ACTIONS);
            var response=http.call(token,arguments("A","DA"));assertEquals(200,response.statusCode(),response.body());
            var execution=structured(http,response);
            assertEquals("FAILED",execution.get("businessOutcome"),response.body());
            assertEquals("FAILED",execution.get("responseOutcome"),response.body());
            assertFalse(response.body().contains(sentinel));assertEquals(1,fixture.sourceCalls.get());
            assertEquals(0,count(fixture,"SELECT count(*) FROM source_reference"));
            assertEquals(0,count(fixture,"SELECT count(*) FROM web_reference"));
            assertEquals(0,count(fixture,"SELECT count(*) FROM audit_parameter WHERE port IN ('SOURCE_OUTPUT','RESPONSE')"));
            assertEquals(0,count(fixture,"SELECT count(*) FROM audit_event WHERE event_type='REFERENCE_RECORDED'"));
            secrets.add(fixture.sourceWebLink);secrets.addAll(http.rawSecrets);assertNoPersistedValues(fixture,secrets);
        }
        assertPhysicalSecrecy(secrets);
    }

    private static Map<String,Object> arguments(String patient,String document){return Map.of("patientId",patient,"documentId",document,"sourceSecret",GatewayFixture.SOURCE_SECRET);}
    private static Map<String,Object> structured(GatewayHttpClient http,HttpResponse<String> response){return (Map<String,Object>)((Map<String,Object>)http.object(response).get("result")).get("structuredContent");}
    private static Map<String,Object> successful(GatewayHttpClient http,HttpResponse<String> response){assertEquals(200,response.statusCode(),response.body());var execution=structured(http,response);assertEquals("SUCCEEDED",execution.get("status"),response.body());return execution;}
    private static CreateResult request(GatewayFixture fixture,String execution,List<String> references) {
        var inputs=new ArrayList<ReferenceInput>();for(int i=0;i<references.size();i++)inputs.add(new ReferenceInput(references.get(i),"summary-value",i));
        return new CreateResult(execution,fixture.generatedOutput.version().id(),"synthetic-generation",MODEL,
                List.of(new ValueInput("summary-value",null,"summary-field",0,"STRING",SUMMARY,null,null,null)),inputs);
    }
    private static ResultDocument read(GatewayHttpClient http,String id,String token)throws Exception {
        var response=http.api("/api/results/"+id,"GET",null,token);assertEquals(200,response.statusCode(),response.body());return http.json.readValue(response.body(),ResultDocument.class);
    }
    private static Map<String,Object> parameter(List<Map<String,Object>> values,String port,String name){return values.stream().filter(p->port.equals(p.get("port"))&&name.equals(p.get("parameter_name"))).findFirst().orElseThrow();}
    private static long count(GatewayFixture fixture,String sql){return fixture.store.read(s->s.getMapper(SecurityFixture.FixtureMapper.class).count(sql));}
    private static void assertNoPersistedValues(GatewayFixture fixture,List<String> secrets) {
        String excluded=String.join(",",secrets.stream().map(value->"'"+value.replace("'","''")+"'").toList());
        assertEquals(0,count(fixture,"SELECT count(*) FROM (SELECT string_value AS value FROM audit_parameter UNION ALL SELECT text_value FROM result_value UNION ALL SELECT string_value FROM reference_parameter UNION ALL SELECT original_url FROM web_reference) WHERE value IN ("+excluded+")"));
    }
    private void assertPhysicalSecrecy(List<String> secrets)throws Exception {
        try(var files=Files.list(directory)) {
            for(Path file:files.filter(path->path.getFileName().toString().startsWith("platform.db")).toList()) {
                String contents=new String(Files.readAllBytes(file),StandardCharsets.ISO_8859_1);
                for(String secret:secrets)assertFalse(contents.contains(secret),"Raw recoverable content or authentication material reached "+file.getFileName());
            }
        }
    }
}
