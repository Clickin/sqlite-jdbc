package io.gateway.runtime;

import io.gateway.authorization.*;
import io.gateway.definitions.DefinitionMapper;
import io.gateway.definitions.DefinitionRepository;
import io.gateway.definitions.Definitions.*;
import io.gateway.identity.Authority;
import io.gateway.oauth.*;
import io.gateway.persistence.PlatformStore;
import io.micronaut.context.ApplicationContext;
import io.micronaut.context.annotation.Requires;
import io.micronaut.context.event.BeanCreatedEvent;
import io.micronaut.context.event.BeanCreatedEventListener;
import jakarta.inject.Singleton;
import java.nio.file.Path;
import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.reflection.SystemMetaObject;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

/** Real SQLite/MyBatis execution; latches instrument bean creation, metadata reads and row consumption only. */
final class RuntimeBarrierTest {
    private static final String DTD = "<!DOCTYPE mapper PUBLIC \"-//mybatis.org//DTD Mapper 3.0//EN\" \"https://mybatis.org/dtd/mybatis-3-mapper.dtd\">";
    @TempDir Path directory;

    @Test void coldConcurrentFirstAcquireConstructsOneRuntimeAndRetiresAfterLastLease() throws Exception {
        String url = source("cold.db", "cold-one", "cold-two");
        String workflowId;
        try (var context = context()) {
            workflowId = fixture(context, "cold", url, false).workflow().object().id();
        }
        // Publication prepares candidate graphs. A fresh context, not an already acquired lease,
        // makes these the first requests for the persisted dependency vector in this JVM registry.
        try (var context = context(); var workers = Executors.newVirtualThreadPerTaskExecutor()) {
            var repository = context.getBean(DefinitionRepository.class);
            var registry = context.getBean(RuntimeRegistry.class);
            var graph = repository.resolve(workflowId);
            var creations = context.getBean(GraphCreations.class);
            var constructing = new Gate(1);
            creations.block(graph.key(), constructing);
            var start = new CyclicBarrier(12);
            List<Future<RuntimeRegistry.Lease>> requests = new ArrayList<>();
            List<RuntimeRegistry.Lease> leases = new ArrayList<>();
            try {
                for (int i = 0; i < 12; i++) requests.add(workers.submit(() -> {
                    start.await(10, TimeUnit.SECONDS);
                    return registry.acquire(graph);
                }));
                constructing.awaitEntered();
                assertEquals(1, creations.count(graph.key()));
                assertTrue(requests.stream().noneMatch(Future::isDone));
                constructing.release();
                for (var request : requests) leases.add(request.get(10, TimeUnit.SECONDS));
                var runtime = leases.getFirst().get();
                for (var lease : leases) assertSame(runtime, lease.get());
                assertEquals(1, creations.count(graph.key()));
                String operation = inputOperation(graph);
                assertEquals(rows("cold-one", "cold-two"), execute(runtime, operation).value());
                registry.evict(graph.key());
                for (int i = 0; i < leases.size() - 1; i++) leases.get(i).close();
                assertEquals(rows("cold-one", "cold-two"), execute(leases.getLast().get(), operation).value());
                leases.getLast().close();
                assertThrows(IllegalStateException.class, () -> execute(runtime, operation));
            } finally {
                constructing.release();
                for (var lease : leases) lease.close();
                for (var request : requests) if (!request.isDone()) request.cancel(true);
            }
        }
    }

    @Test void sourceCutoverKeepsAlreadyConsumingResultSetOpenAndNewRequestsUseNewSource() throws Exception {
        String oldUrl = source("old.db", "cutover-A-one", "cutover-A-two");
        String newUrl = source("new.db", "cutover-B-one", "cutover-B-two");
        try (var context = context(); var workers = Executors.newVirtualThreadPerTaskExecutor();
             var consuming = new RowGate(1, "cutover-A-one")) {
            var fixture = fixture(context, "cutover", oldUrl, true);
            var repository = context.getBean(DefinitionRepository.class);
            var registry = context.getBean(RuntimeRegistry.class);
            var oldGraph = repository.resolve(fixture.workflow().object().id());
            Future<Payload> oldRequest = workers.submit(() -> {
                try (var lease = registry.acquire(oldGraph)) { return execute(lease.get(), fixture.operation().object().id()); }
            });
            try {
                consuming.gate.awaitEntered();
                var changed = replace(repository, fixture.source(), jdbcSource(newUrl, true, 1));
                var newGraph = repository.resolve(fixture.workflow().object().id());
                context.getBean(GraphCreations.class).evictUsing(registry, fixture.source());
                assertEquals(fixture.source().version().id(), oldGraph.version(fixture.source().object().id()));
                assertEquals(changed.version().id(), newGraph.version(fixture.source().object().id()));
                assertEquals(fixture.workflow().version().id(), newGraph.version(fixture.workflow().object().id()));
                assertEquals(List.of(fixture.workflow().version()), repository.history(fixture.workflow().object().id()));
                try (var fresh = registry.acquire(newGraph)) {
                    assertEquals(rows("cutover-B-one", "cutover-B-two"), execute(fresh.get(), fixture.operation().object().id()).value());
                }
                assertFalse(oldRequest.isDone());
                assertEquals(1, consuming.gate.cursors.size());
                for (var cursor : consuming.gate.cursors) {
                    assertFalse(cursor.isClosed(), "The old request still owns its SQLite result set");
                    assertFalse(cursor.getStatement().getConnection().isClosed());
                }
                consuming.gate.release();
                assertEquals(rows("cutover-A-one", "cutover-A-two"), oldRequest.get(10, TimeUnit.SECONDS).value());
                for (var cursor : consuming.gate.cursors) assertTrue(cursor.isClosed());
            } finally { consuming.gate.release(); }
        }
    }

    @Test void outputEnvelopeAndMapperRevisionsReuseTheLivePrivateSqliteConnection() throws Exception {
        try (var context = context()) {
            var fixture = fixture(context, "reuse", "jdbc:sqlite::memory:", false, false);
            var repository = context.getBean(DefinitionRepository.class);
            var registry = context.getBean(RuntimeRegistry.class);
            var original = repository.resolve(fixture.workflow().object().id());
            var old = registry.acquire(original);
            // A private :memory: database belongs to precisely one physical JDBC connection.
            // Keeping its table across changed graphs proves resource reuse without private-field inspection.
            var count = publish(repository, "reuse-count", new Contract("VALUE", List.of(field("count", null, "count", "SCALAR", "INTEGER", 0))));
            for (String statement : List.of("create", "seed")) {
                var setup = publish(repository, "reuse-" + statement, new JdbcOperation(fixture.source().object().id(), fixture.input().object().id(), count.object().id(),
                        Effect.WRITE, 20_000, 10, 4096L, fixture.mapper().object().id(), "fixture." + statement, "EXECUTE", "LOCAL_WRITE", List.of(), List.of()));
                try (var lease = registry.acquire(repository.resolve(setup.object().id()))) { execute(lease.get(), setup.object().id()); }
            }
            assertEquals(rows("one", "two"), execute(old.get(), fixture.operation().object().id()).value());
            var output = replace(repository, fixture.output(), output("reuse", "records"));
            var rebound = repository.resolve(fixture.workflow().object().id());
            try (var current = registry.acquire(rebound)) {
                assertNotSame(old.get(), current.get());
                assertEquals(output.version().id(), rebound.version(fixture.output().object().id()));
                assertEquals(Map.of("records", List.of(Map.of("value", "one"), Map.of("value", "two"))),
                        execute(current.get(), fixture.operation().object().id()).value());
                replace(repository, fixture.mapper(), mapper(readXml(false).replace("ORDER BY rowid", "ORDER BY rowid DESC")));
                var remapped = repository.resolve(fixture.workflow().object().id());
                try (var newest = registry.acquire(remapped)) {
                    assertEquals(Map.of("records", List.of(Map.of("value", "two"), Map.of("value", "one"))),
                            execute(newest.get(), fixture.operation().object().id()).value());
                    assertEquals(rows("one", "two"), execute(old.get(), fixture.operation().object().id()).value());
                    registry.evict(original.key());
                    old.close();
                    registry.evict(rebound.key());
                    current.close();
                    assertEquals(Map.of("records", List.of(Map.of("value", "two"), Map.of("value", "one"))),
                            execute(newest.get(), fixture.operation().object().id()).value());
                    context.getBean(GraphCreations.class).evictUsing(registry, fixture.source());
                }
                try (var reopened = registry.acquire(remapped)) {
                    assertEquals("JDBC_EXECUTION_FAILED", assertThrows(ExecutionFailure.class,
                            () -> execute(reopened.get(), fixture.operation().object().id())).code());
                }
            } finally { old.close(); }
        }
    }

    @Test void dependencyHeadsChangedDuringLoadingNeverMixSnapshots() throws Exception {
        String oldUrl = source("snapshot-old.db", "old-one", "old-two");
        String newUrl = source("snapshot-new.db", "new-one", "new-two");
        try (var context = context(); var workers = Executors.newVirtualThreadPerTaskExecutor()) {
            var fixture = fixture(context, "snapshot", oldUrl, false);
            var repository = context.getBean(DefinitionRepository.class);
            var registry = context.getBean(RuntimeRegistry.class);
            var store = context.getBean(PlatformStore.class);
            var before = repository.resolve(fixture.workflow().object().id());
            var loading = new SnapshotGate();
            store.read(session -> { session.getConfiguration().addInterceptor(loading); return null; });
            loading.armed.set(true);
            var pending = workers.submit(() -> repository.resolve(fixture.workflow().object().id()));
            try {
                loading.gate.awaitEntered();
                var source = replace(repository, fixture.source(), jdbcSource(newUrl, true, 1));
                var mapper = replace(repository, fixture.mapper(), mapper(readXml(false).replace("ORDER BY rowid", "ORDER BY rowid DESC")));
                var output = replace(repository, fixture.output(), output("snapshot", "records"));
                loading.gate.release();
                var pinned = pending.get(10, TimeUnit.SECONDS);
                assertEquals(before.key(), pinned.key());
                try (var lease = registry.acquire(pinned)) {
                    assertEquals(rows("old-one", "old-two"), execute(lease.get(), fixture.operation().object().id()).value());
                }
                var next = repository.resolve(fixture.workflow().object().id());
                assertEquals(source.version().id(), next.version(fixture.source().object().id()));
                assertEquals(mapper.version().id(), next.version(fixture.mapper().object().id()));
                assertEquals(output.version().id(), next.version(fixture.output().object().id()));
                try (var lease = registry.acquire(next)) {
                    assertEquals(Map.of("records", List.of(Map.of("value", "new-two"), Map.of("value", "new-one"))),
                            execute(lease.get(), fixture.operation().object().id()).value());
                }
            } finally { loading.gate.release(); }
        }
    }

    @Test void unusableNewHeadFailsInsteadOfFallingBackAndUnrelatedSourceStillExecutes() throws Exception {
        String goodUrl = source("good.db", "good-one", "good-two");
        String unrelatedUrl = source("unrelated.db", "other-one", "other-two");
        try (var context = context()) {
            var fixture = fixture(context, "broken", goodUrl, false);
            var unrelated = fixture(context, "unrelated", unrelatedUrl, false);
            var repository = context.getBean(DefinitionRepository.class);
            var registry = context.getBean(RuntimeRegistry.class);
            var oldGraph = repository.resolve(fixture.workflow().object().id());
            try (var old = registry.acquire(oldGraph)) {
                assertEquals(rows("good-one", "good-two"), execute(old.get(), fixture.operation().object().id()).value());
                var broken = repository.draft(new Draft(fixture.mapper().object().id(), fixture.mapper().object().logicalKey(),
                        "broken fixture", null, "preparation failure", mapper(readXml(false).replace("id=\"read\"", "id=\"missing\""))), "fixture");
                assertThrows(ExecutionFailure.class, () -> repository.validate(broken.object().id(), broken.version().id()));
                // Inject a persisted unusable head (e.g. incompatible definitions at process startup).
                // Normal publication correctly refuses it; immutable revision rows themselves are not changed.
                context.getBean(PlatformStore.class).write(session -> {
                    assertEquals(1, session.getMapper(DefinitionMapper.class).cas(broken.object().id(), broken.version().id(), broken.object().generation()));
                    return null;
                });
                var newGraph = repository.resolve(fixture.workflow().object().id());
                assertEquals(broken.version().id(), newGraph.version(broken.object().id()));
                for (int attempt = 0; attempt < 2; attempt++) {
                    var failure = assertThrows(ExecutionFailure.class, () -> registry.acquire(newGraph));
                    assertEquals("JDBC_PREPARATION_FAILED", failure.code());
                    assertEquals(ExecutionFailure.Outcome.FAILED_BEFORE_EFFECT, failure.outcome());
                }
                try (var good = registry.acquire(repository.resolve(unrelated.workflow().object().id()))) {
                    assertEquals(rows("other-one", "other-two"), execute(good.get(), unrelated.operation().object().id()).value());
                }
                assertEquals(rows("good-one", "good-two"), execute(old.get(), fixture.operation().object().id()).value());
            }
        }
    }

    @Test void concurrentPrincipalsAndPatientsRemainIsolatedAcrossRevisionAndThreadReuse() throws Exception {
        String url = source("patients.db", "unused");
        try (var connection = DriverManager.getConnection(url); var statement = connection.createStatement()) {
            statement.execute("CREATE TABLE clinical(subject TEXT, patient TEXT, value TEXT)");
            statement.execute("INSERT INTO clinical VALUES('doctor-a','A','only-A'),('doctor-b','B','only-B')");
        }
        try (var context = context(); var workers = Executors.newVirtualThreadPerTaskExecutor();
             var threadA = Executors.newSingleThreadExecutor(Thread.ofVirtual().factory());
             var threadB = Executors.newSingleThreadExecutor(Thread.ofVirtual().factory());
             var consuming = new RowGate(2, "only-A", "only-B")) {
            var store = context.getBean(PlatformStore.class);
            var security = new SecurityFixture(store, directory, true);
            Authority authority = new Authority() {
                public String securityBindingId() { return "security"; }
                public Identity authenticate(String subject) {
                    if (!Set.of("doctor-a", "doctor-b").contains(subject)) throw AccessDenied.unauthenticated();
                    return new Identity("identity-operation", subject, true);
                }
                public Set<String> roles(String provider, String subject) { return Set.of("clinician"); }
                public CanonicalTarget resolve(String provider, String subject, String action, CanonicalTarget claimed, String policy) { return claimed; }
                public Decision decide(String provider, String subject, String action, CanonicalTarget target) {
                    return new Decision("ALLOW", subject + ":" + target.patientIdentifier(), Set.of("clinician"));
                }
            };
            var sessions = new BrowserSessionService(store, security.settings, authority);
            var oauth = new OAuthService(store, security.settings, sessions, authority);
            var authorization = new AuthorizationService(store, authority, sessions);
            var principalA = principal(sessions, oauth, authorization, "doctor-a", "A");
            var principalB = principal(sessions, oauth, authorization, "doctor-b", "B");
            assertNotEquals(principalA.principalId(), principalB.principalId());
            var repository = context.getBean(DefinitionRepository.class);
            var input = publish(repository, "isolation-input", new Contract("VALUE", List.of()));
            var output = publish(repository, "isolation-output", new Contract("VALUE", List.of(
                    field("patient", null, "patient", "SCALAR", "STRING", 0),
                    field("subject", null, "subject", "SCALAR", "STRING", 1),
                    field("value", null, "value", "SCALAR", "STRING", 2),
                    field("revision", null, "revision", "SCALAR", "STRING", 3))));
            var source = publish(repository, "isolation-source", jdbcSource(url, true, 4));
            var mapper = publish(repository, "isolation-mapper", mapper(patientXml("old")));
            var operation = publish(repository, "isolation-operation", new JdbcOperation(source.object().id(), input.object().id(), output.object().id(),
                    Effect.READ_ONLY, 20_000, 10, 4096L, mapper.object().id(), "fixture.read", "SELECT_ONE", "READ_ONLY", List.of(), List.of()));
            var workflow = publish(repository, "isolation-workflow", new Workflow(null, List.of(new Stage("INPUT", 0, operation.object().id(), null)), List.of(), List.of()));
            var old = repository.resolve(workflow.object().id());
            var runner = context.getBean(WorkflowRunner.class);
            var firstA = threadA.submit(() -> runAuthorized(runner, authorization, old, principalA, "A"));
            var firstB = threadB.submit(() -> runAuthorized(runner, authorization, old, principalB, "B"));
            try {
                consuming.gate.awaitEntered();
                replace(repository, mapper, mapper(patientXml("new")));
                var next = repository.resolve(workflow.object().id());
                context.getBean(RuntimeRegistry.class).evict(old.key());
                // Gates consume their first arrival only: the new requests must finish while both old rows are retained.
                var nextA = workers.submit(() -> runAuthorized(runner, authorization, next, principalA, "A"));
                var nextB = workers.submit(() -> runAuthorized(runner, authorization, next, principalB, "B"));
                assertEquals(patientRow("doctor-a", "A", "only-A", "new"), nextA.get(10, TimeUnit.SECONDS).value());
                assertEquals(patientRow("doctor-b", "B", "only-B", "new"), nextB.get(10, TimeUnit.SECONDS).value());
                assertFalse(firstA.isDone());
                assertFalse(firstB.isDone());
                assertEquals(2, consuming.gate.cursors.size());
                for (var cursor : consuming.gate.cursors) {
                    assertFalse(cursor.isClosed(), "Old principal requests retain their live SQLite result sets");
                    assertFalse(cursor.getStatement().getConnection().isClosed());
                }
                consuming.gate.release();
                assertEquals(patientRow("doctor-a", "A", "only-A", "old"), firstA.get(10, TimeUnit.SECONDS).value());
                assertEquals(patientRow("doctor-b", "B", "only-B", "old"), firstB.get(10, TimeUnit.SECONDS).value());
                for (var cursor : consuming.gate.cursors) assertTrue(cursor.isClosed());
                // Reverse the principals on the same two live worker threads to expose stale ThreadLocal state.
                var reusedA = threadA.submit(() -> runAuthorized(runner, authorization, next, principalB, "B"));
                var reusedB = threadB.submit(() -> runAuthorized(runner, authorization, next, principalA, "A"));
                assertEquals(patientRow("doctor-b", "B", "only-B", "new"), reusedA.get(10, TimeUnit.SECONDS).value());
                assertEquals(patientRow("doctor-a", "A", "only-A", "new"), reusedB.get(10, TimeUnit.SECONDS).value());
                assertThrows(AccessDenied.class, () -> runAuthorized(runner, authorization, next, principalA, "B"));
                assertThrows(AccessDenied.class, () -> runAuthorized(runner, authorization, next, principalB, "A"));
            } finally { consuming.gate.release(); }
        }
    }

    private static Payload runAuthorized(WorkflowRunner runner, AuthorizationService authorization, ResolvedGraph graph,
                                         AuthenticatedPrincipal principal, String patient) {
        var target = SecurityFixture.patient(patient);
        var authorized = authorization.authorize(principal, "clinical.lab.read", target);
        assertEquals(principal.subject() + ":" + patient, authorized.decisionId());
        return runner.run(graph, authorized, Payload.of(Map.of()), cancellation(), (stage, value) -> {
            var current = authorization.authorize(principal, "clinical.lab.read", target);
            assertEquals(principal.principalId(), current.principalId());
            assertEquals(principal.subject() + ":" + patient, current.decisionId());
            return new WorkflowRunner.StageInput(current, value);
        }, (stage, payload) -> {
            if (stage.equals("SOURCE_REQUEST")) {
                var bound = (Map<?, ?>) payload.object().get("authorized");
                assertEquals(principal.principalId(), bound.get("principalId"));
                assertEquals(patient, bound.get("patientIdentifier"));
                assertEquals(principal.grantId(), bound.get("grantId"));
            }
        });
    }

    private static AuthenticatedPrincipal principal(BrowserSessionService sessions, OAuthService oauth,
                                                    AuthorizationService authorization, String subject, String patient) {
        var pre = sessions.session(null);
        var browser = sessions.login(pre.cookie(), SecurityFixture.ISSUER, pre.view().csrfToken(), subject, "USER");
        String request = oauth.begin(SecurityFixture.authorizeParameters("public", SecurityFixture.REDIRECT, "clinical.read"), browser.cookie());
        String redirect = oauth.consent(request, browser.cookie(), SecurityFixture.ISSUER, browser.view().csrfToken(),
                new OAuthService.Consent("synthetic-care", List.of(new OAuthService.ActionTarget("clinical.lab.read", SecurityFixture.patient(patient))), true));
        var query = new com.nimbusds.oauth2.sdk.http.HTTPRequest(com.nimbusds.oauth2.sdk.http.HTTPRequest.Method.GET, java.net.URI.create(redirect)).getQueryStringParameters();
        var code = new SecurityFixture.Code(query.get("code").getFirst(), "public", SecurityFixture.VERIFIER, SecurityFixture.REDIRECT, request);
        var token = oauth.token(SecurityFixture.exchangeForm(code), null);
        return authorization.authenticateBearer(List.of("Bearer " + token.get("access_token")), SecurityFixture.RESOURCE);
    }

    private ApplicationContext context() {
        return ApplicationContext.run(Map.of("micronaut.server.enabled", false,
                "gateway.database.url", "jdbc:sqlite:" + directory.resolve("platform.db"), "runtime-barrier-test", true));
    }
    private record Fixture(Saved source, Saved input, Saved output, Saved mapper, Saved operation, Saved workflow) {}
    private Fixture fixture(ApplicationContext context, String prefix, String url, boolean barrier) {
        return fixture(context, prefix, url, barrier, true);
    }
    private Fixture fixture(ApplicationContext context, String prefix, String url, boolean barrier, boolean readOnly) {
        var repository = context.getBean(DefinitionRepository.class);
        var input = publish(repository, prefix + "-input", new Contract("VALUE", List.of()));
        var output = publish(repository, prefix + "-output", output(prefix, "rows"));
        var source = publish(repository, prefix + "-source", jdbcSource(url, readOnly, 1));
        var mapper = publish(repository, prefix + "-mapper", mapper(readXml(barrier)));
        var operation = publish(repository, prefix + "-operation", new JdbcOperation(source.object().id(), input.object().id(), output.object().id(),
                Effect.READ_ONLY, 20_000, 10, 4096L, mapper.object().id(), "fixture.read", "MANY", "READ_ONLY", List.of(), List.of()));
        var workflow = publish(repository, prefix + "-workflow", new Workflow(null, List.of(new Stage("INPUT", 0, operation.object().id(), null)), List.of(), List.of()));
        return new Fixture(source, input, output, mapper, operation, workflow);
    }
    private String source(String filename, String... values) throws Exception {
        String url = "jdbc:sqlite:" + directory.resolve(filename);
        try (var connection = DriverManager.getConnection(url); var statement = connection.createStatement()) {
            statement.execute("CREATE TABLE fixture(value TEXT NOT NULL)");
            try (var insert = connection.prepareStatement("INSERT INTO fixture VALUES(?)")) {
                for (String value : values) { insert.setString(1, value); insert.executeUpdate(); }
            }
        }
        return url;
    }
    private static JdbcSource jdbcSource(String url, boolean readOnly, int connections) {
        return new JdbcSource(url, "SQLITE", null, 0, connections, 5000, readOnly, 4, 5000);
    }
    private static Saved publish(DefinitionRepository repository, String key, Detail detail) {
        var draft = repository.draft(new Draft(null, key, key, null, "synthetic fixture", detail), "fixture");
        return repository.apply(repository.validate(draft.object().id(), draft.version().id()), "fixture", "synthetic fixture");
    }
    private static Saved replace(DefinitionRepository repository, Saved old, Detail detail) {
        var draft = repository.draft(new Draft(old.object().id(), old.object().logicalKey(), old.version().displayName(), null, "synthetic cutover", detail), "fixture");
        return repository.apply(repository.validate(draft.object().id(), draft.version().id()), "fixture", "synthetic cutover");
    }
    private static Field field(String id, String parent, String member, String kind, String type, int ordinal) {
        return new Field(id, id, parent, member, kind, type, ordinal, true, false, null, null,
                "STRING".equals(type) ? 128 : null, Payload.Disposition.PERSIST);
    }
    private static Contract output(String prefix, String envelope) {
        return new Contract("VALUE", List.of(field(prefix + "-rows", null, envelope, "ARRAY", null, 0),
                field(prefix + "-row", prefix + "-rows", "item", "OBJECT", null, 0),
                field(prefix + "-value", prefix + "-row", "value", "SCALAR", "STRING", 0)));
    }
    private static Mapper mapper(String xml) { return new Mapper("SQLITE", List.of(new MapperDocument("fixture.xml", xml)), List.of()); }
    private static String resultMap() {
        return "<resultMap id=\"row\" type=\"map\"/>";
    }
    private static String readXml(boolean barrier) {
        return DTD + "<mapper namespace=\"fixture\">" + (barrier ? resultMap() : "") + "<select id=\"read\" " +
                (barrier ? "resultMap=\"row\"" : "resultType=\"map\"") + ">SELECT value FROM fixture ORDER BY rowid</select>" +
                "<update id=\"create\">CREATE TABLE fixture(value TEXT NOT NULL)</update>" +
                "<insert id=\"seed\">INSERT INTO fixture VALUES('one'),('two')</insert></mapper>";
    }
    private static String patientXml(String revision) {
        return DTD + "<mapper namespace=\"fixture\">" + resultMap() + "<select id=\"read\" resultMap=\"row\">SELECT subject, patient, value, '" + revision +
                "' AS revision FROM clinical WHERE subject=#{authorized.subject} AND patient=#{authorized.patientIdentifier}</select></mapper>";
    }
    private static Map<String, Object> rows(String... values) {
        return Map.of("rows", Arrays.stream(values).map(value -> Map.of("value", value)).toList());
    }
    private static Map<String, Object> patientRow(String subject, String patient, String value, String revision) {
        return Map.of("subject", subject, "patient", patient, "value", value, "revision", revision);
    }
    private static String inputOperation(ResolvedGraph graph) { return ((Workflow) graph.require(graph.rootObjectId()).detail()).stages().getFirst().operationObjectId(); }
    private static Payload execute(RuntimeGraph runtime, String operation) { return runtime.execute(operation, Payload.of(Map.of()), cancellation()); }
    private static Cancellation cancellation() { return new Cancellation(Instant.now().plusSeconds(30)); }

    private static final class Gate {
        final CountDownLatch entered;
        final CountDownLatch resume = new CountDownLatch(1);
        final Set<ResultSet> cursors = ConcurrentHashMap.newKeySet();
        Gate(int count) { entered = new CountDownLatch(count); }
        void stop() {
            entered.countDown();
            try { if (!resume.await(15, TimeUnit.SECONDS)) throw new AssertionError("Fixture barrier timed out"); }
            catch (InterruptedException failure) { Thread.currentThread().interrupt(); throw new AssertionError(failure); }
        }
        void awaitEntered() throws InterruptedException { assertTrue(entered.await(10, TimeUnit.SECONDS), "Request did not reach fixture barrier"); }
        void release() { resume.countDown(); }
    }

    private static final class RowGate implements AutoCloseable {
        final Gate gate;
        final List<String> values;
        RowGate(int count, String... values) {
            gate = new Gate(count); this.values = List.of(values);
            for (String value : values) assertNull(RowBarrier.GATES.putIfAbsent(value, gate));
        }
        @Override public void close() { gate.release(); for (String value : values) RowBarrier.GATES.remove(value, gate); }
    }

    public static final class RowBarrier extends BaseTypeHandler<String> {
        static final ConcurrentMap<String, Gate> GATES = new ConcurrentHashMap<>();
        private String consume(ResultSet result, String value) {
            var gate = value == null ? null : GATES.remove(value);
            if (gate != null) { gate.cursors.add(result); gate.stop(); }
            return value;
        }
        @Override public void setNonNullParameter(PreparedStatement statement, int index, String value, JdbcType type) throws SQLException { statement.setString(index, value); }
        @Override public String getNullableResult(ResultSet result, String column) throws SQLException { return consume(result, result.getString(column)); }
        @Override public String getNullableResult(ResultSet result, int column) throws SQLException { return consume(result, result.getString(column)); }
        @Override public String getNullableResult(CallableStatement statement, int column) throws SQLException { return statement.getString(column); }
    }

    @Singleton
    @Requires(property = "runtime-barrier-test", value = "true")
    public static final class GraphCreations implements BeanCreatedEventListener<RuntimeGraph> {
        private final ConcurrentMap<String, AtomicInteger> counts = new ConcurrentHashMap<>();
        private final ConcurrentMap<String, Gate> gates = new ConcurrentHashMap<>();
        private final ConcurrentMap<String, ResolvedGraph> graphs = new ConcurrentHashMap<>();
        void evictUsing(RuntimeRegistry registry, Saved dependency) {
            for (var graph : graphs.values()) {
                var selected = graph.definitions().get(dependency.object().id());
                if (selected != null && selected.version().id().equals(dependency.version().id())) registry.evict(graph.key());
            }
        }
        void block(String key, Gate gate) { assertEquals(0, count(key)); gates.put(key, gate); }
        int count(String key) { var count = counts.get(key); return count == null ? 0 : count.get(); }
        @Override public RuntimeGraph onCreated(BeanCreatedEvent<RuntimeGraph> event) {
            if (!RowBarrier.GATES.isEmpty()) {
                // Test-only native registration; mapper XML cannot name executable Java handlers.
                var adapters = (Map<?, ?>) SystemMetaObject.forObject(event.getBean()).getValue("operations");
                for (var adapter : adapters.values()) {
                    var factory = (SqlSessionFactory) SystemMetaObject.forObject(adapter).getValue("factory");
                    factory.getConfiguration().getTypeHandlerRegistry().register(String.class, JdbcType.VARCHAR, new RowBarrier());
                }
            }
            String key = event.getBean().definitions().key();
            graphs.put(key, event.getBean().definitions());
            counts.computeIfAbsent(key, ignored -> new AtomicInteger()).incrementAndGet();
            var gate = gates.remove(key);
            if (gate != null) gate.stop();
            return event.getBean();
        }
    }

    @Intercepts(@Signature(type = Executor.class, method = "query", args = {MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class}))
    public static final class SnapshotGate implements Interceptor {
        final AtomicBoolean armed = new AtomicBoolean();
        final Gate gate = new Gate(1);
        @Override public Object intercept(Invocation invocation) throws Throwable {
            Object result = invocation.proceed();
            if (((MappedStatement) invocation.getArgs()[0]).getId().equals(DefinitionMapper.class.getName() + ".heads") && armed.compareAndSet(true, false)) gate.stop();
            return result;
        }
    }
}
