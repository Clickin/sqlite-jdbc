package io.gateway.credentials;

import io.gateway.audit.AuditService;
import io.gateway.persistence.PlatformMapper;
import io.gateway.persistence.PlatformStore;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermissions;
import java.security.SecureRandom;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class CredentialServiceTest {
    @TempDir Path directory;

    @Test void encryptionRotationAndRevocationRemainDistinctFromSemanticRevision() throws Exception {
        key("first"); key("second");
        try (PlatformStore store = new PlatformStore(directory.resolve("platform.db"))) {
            CredentialService service = new CredentialService(store, new AuditService(store), directory.toString(), "first");
            byte[] sentinel = "synthetic-secret-비밀".getBytes(StandardCharsets.UTF_8);
            CredentialService.Metadata first = service.create("outbound", "PASSWORD", "reader", sentinel, "operator", "initial");
            CredentialMapper.Row encrypted = store.read(s -> s.getMapper(CredentialMapper.class).versionRow(first.versionId()));
            assertFalse(Arrays.equals(sentinel, encrypted.ciphertext()));
            assertEquals(12, encrypted.nonce().length);
            try (var secret = service.resolveVersion(first.versionId())) {
                assertArrayEquals(sentinel, secret.bytes());
                assertEquals("reader", secret.publicUsername());
                assertFalse(secret.toString().contains("synthetic"));
            }
            service.reencrypt(first.versionId(), "second", "operator");
            CredentialService.Metadata rotated = service.metadata(first.objectId());
            assertEquals(first.versionId(), rotated.versionId());
            assertEquals(first.revision(), rotated.revision());
            assertEquals(first.generation(), rotated.generation());
            assertEquals("second", rotated.keyId());
            try (var secret = service.resolve(first.objectId())) { assertArrayEquals(sentinel, secret.bytes()); }
            CredentialService.Metadata replaced = service.replace(first.objectId(), first.generation(), "PASSWORD", "reader",
                "new-secret".getBytes(StandardCharsets.UTF_8), "operator", "replace");
            assertEquals(2, replaced.revision());
            assertEquals(2, replaced.generation());
            service.revoke(first.versionId(), "operator");
            store.write(s -> s.getMapper(Fixture.class).head(first.objectId(), first.versionId()));
            assertThrows(CredentialService.CredentialException.class, () -> service.resolve(first.objectId()));
            assertThrows(CredentialService.CredentialException.class, () -> service.checkVersion(first.versionId()));
            assertEquals(4, store.read(s -> s.getMapper(Fixture.class).auditCount()).intValue());
        }
    }

    @Test void tamperedCiphertextAndWrongKeyFailWithoutSecretInException() throws Exception {
        key("first");
        try (PlatformStore store = new PlatformStore(directory.resolve("platform.db"))) {
            CredentialService service = new CredentialService(store, new AuditService(store), directory.toString(), "first");
            var metadata = service.create("outbound", "PASSWORD", null,
                "SECRET_SENTINEL".getBytes(StandardCharsets.UTF_8), "operator", "initial");
            store.write(s -> s.getMapper(Fixture.class).corrupt(metadata.versionId()));
            var failure = assertThrows(CredentialService.CredentialException.class,
                () -> service.resolveVersion(metadata.versionId()));
            assertEquals("CREDENTIAL_DECRYPTION_FAILED", failure.getMessage());
            assertNull(failure.getCause());
            assertFalse(failure.toString().contains("SECRET_SENTINEL"));
            assertThrows(CredentialService.CredentialException.class,
                () -> new CredentialService(store, new AuditService(store), directory.toString(), "missing")
                    .create("another", "PASSWORD", null, new byte[]{1}, "operator", "initial"));
            assertEquals(1, store.read(s -> s.getMapper(Fixture.class).credentialCount()).intValue());
            var intact = service.create("intact", "PASSWORD", null,
                "SECOND_SECRET".getBytes(StandardCharsets.UTF_8), "operator", "initial");
            Files.setPosixFilePermissions(directory.resolve("first.key"), PosixFilePermissions.fromString("rw-------"));
            key("first");
            assertEquals("CREDENTIAL_DECRYPTION_FAILED", assertThrows(CredentialService.CredentialException.class,
                () -> service.resolveVersion(intact.versionId())).getMessage());
        }
    }

    private void key(String id) throws Exception {
        byte[] key = new byte[32]; new SecureRandom().nextBytes(key);
        Path file = directory.resolve(id + ".key");
        Files.write(file, key);
        Files.setPosixFilePermissions(file, PosixFilePermissions.fromString("r--------"));
        Arrays.fill(key, (byte) 0);
    }

    public interface Fixture extends PlatformMapper {
        @Update("UPDATE config_object SET current_version_id=#{version},generation=generation+1 WHERE id=#{id}")
        int head(@Param("id") String id, @Param("version") String version);
        @Update("UPDATE credential_cipher SET ciphertext=nonce WHERE credential_version_id=#{id}") int corrupt(String id);
        @Select("SELECT count(*) FROM audit_event") int auditCount();
        @Select("SELECT count(*) FROM credential_version") int credentialCount();
    }
}
