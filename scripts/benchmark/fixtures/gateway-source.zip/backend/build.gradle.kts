plugins {
    java
    application
}

repositories { mavenCentral() }

java { toolchain { languageVersion.set(JavaLanguageVersion.of(25)) } }
application {
    mainClass.set("io.gateway.Application")
    applicationDefaultJvmArgs = listOf("--enable-native-access=ALL-UNNAMED")
}

dependencies {
    implementation(platform("io.micronaut.platform:micronaut-platform:5.1.5"))
    annotationProcessor(platform("io.micronaut.platform:micronaut-platform:5.1.5"))
    annotationProcessor("io.micronaut:micronaut-inject-java")
    annotationProcessor("io.micronaut.serde:micronaut-serde-processor")
    testAnnotationProcessor(platform("io.micronaut.platform:micronaut-platform:5.1.5"))
    testAnnotationProcessor("io.micronaut:micronaut-inject-java")
    testAnnotationProcessor("io.micronaut.serde:micronaut-serde-processor")
    implementation("io.micronaut:micronaut-runtime")
    implementation("io.micronaut:micronaut-http-server-netty")
    implementation("io.micronaut.serde:micronaut-serde-jackson")
    implementation("tools.jackson.core:jackson-databind")
    implementation("org.mybatis:mybatis")
    implementation("com.zaxxer:HikariCP")
    implementation("org.flywaydb:flyway-core")
    implementation("org.flywaydb:flyway-database-postgresql")
    implementation("org.xerial:sqlite-jdbc:3.53.4.0")
    implementation("org.postgresql:postgresql")
    implementation("org.apache.httpcomponents.client5:httpclient5")
    implementation("com.nimbusds:oauth2-oidc-sdk:11.38.2")
    implementation("io.modelcontextprotocol.sdk:mcp:2.0.0")
    testImplementation("ch.qos.logback:logback-classic")
    runtimeOnly("ch.qos.logback:logback-classic")
    runtimeOnly("com.oracle.database.jdbc:ojdbc11")
    testImplementation("org.junit.jupiter:junit-jupiter")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
    testImplementation("io.micronaut:micronaut-http-client")
}

tasks.withType<JavaCompile>().configureEach {
    options.compilerArgs.add("-parameters")
    options.encoding = "UTF-8"
}
tasks.test {
    useJUnitPlatform()
    testLogging { events("passed", "skipped", "failed") }
    jvmArgs("--enable-native-access=ALL-UNNAMED")
    systemProperty("gateway.test.classpath",sourceSets.test.get().runtimeClasspath.asPath)
}
dependencyLocking { lockAllConfigurations() }
tasks.withType<JavaExec>().configureEach { jvmArgs("--enable-native-access=ALL-UNNAMED") }

tasks.register<JavaExec>("syntheticServer") {
    dependsOn(tasks.testClasses)
    classpath = sourceSets.test.get().runtimeClasspath
    mainClass.set("io.gateway.GatewayFixture")
}

tasks.register<JavaExec>("workflowBoundaryServer") {
    dependsOn(tasks.testClasses)
    classpath = sourceSets.test.get().runtimeClasspath
    mainClass.set("io.gateway.WorkflowBoundaryFixture")
    standardInput = System.`in`
}

tasks.register<JavaExec>("bootstrap") {
    dependsOn(tasks.classes)
    classpath = sourceSets.main.get().runtimeClasspath
    mainClass.set("io.gateway.management.OfflineBootstrap")
}
